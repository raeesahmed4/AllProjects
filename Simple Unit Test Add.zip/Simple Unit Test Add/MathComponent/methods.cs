﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MathComponent
{
    public class methods
    {
        
        public int  Add(int fn, int sn)
        {

            return fn + sn;
        }
 


    }
}
