﻿using MathComponent;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MathComponent.Tests
{
    [TestClass()]
    public class methodsTests
    {
        [TestMethod()]
        public void AddTest()
        {
            methods m = new methods();

            int Result = m.Add(10, 10);
            Assert.AreEqual(20, Result);
        }

        [TestMethod()]
        public void AddTest1()
        {
            methods m = new methods();
            int result = m.Add(10, 10);
            Assert.AreEqual(20, result);
        }
    }
}