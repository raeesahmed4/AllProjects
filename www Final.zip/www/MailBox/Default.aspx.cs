﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using CodenameRabbitFoot.BusinessLogic;
using System.Web.Services;
using System.Text.RegularExpressions;
using System.Text;
using Telerik.Web.UI;
using System.Media;
using System.IO;
using System.Web.Script.Services;

public partial class MailBox_Default : System.Web.UI.Page
{
    public static Dictionary<int, int> linkIds = new Dictionary<int, int>();
    public static bool IsReply;
    public static string UserID;
    public string ClientTypeName = "";
    public string RepositryKey
    {
        get
        {
            return Request.Url.AbsolutePath.Replace("/", "").TrimEnd(".aspx".ToCharArray());
        }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        Web.CheckSession();
        this.uploaderControl.WebPageName = this.RepositryKey;

        if (Web.SessionMembers == null) //!Web.IsMemberSession)
            Web.Redirect("../index.aspx");

        if (Web.SessionMembers != null)
            UpdateMessageStatus();

        if (Request.QueryString["Action"] != null)
        {
            if (Request.QueryString["Action"].ToLower() == "messages")
            {
                this.Page.Title = "My Messages";
            }
            else if (Request.QueryString["Action"].ToLower() == "messagetoone")
            {
                var profileClass = "Unknown";
                var tomember = new Members();
                if (Web.IsMemberSession)
                    profileClass = Web.GetProfileClass(Web.RecordID, Web.SessionMembers.MemberID);
                else
                    profileClass = Web.GetProfileClass(Web.RecordID, null);

                if (Web.SessionMembers.MemberID == Web.RecordID)
                {
                    this.Master.ShowMessage("You cannot post a message to yourself.", "");
                    // multiMessagesView.ActiveViewIndex = 2;
                    //this.Master.PageHeading = "Post New Message";
                }
                else
                {
                    Contacts contact = new Contacts();
                    contact.Where.ContactMemberID.Value = Web.RecordID;
                    contact.Where.MemberID.Value = Web.SessionMembers.MemberID;
                    contact.Query.Load();


                    tomember.LoadByPrimaryKey(Web.RecordID);
                    ClientTypeName = tomember.FullName;
                    //this.Master.PageHeading = "Post Message to <span class=\"" + profileClass + "\">" + tomember.UserName + "</span>";
                }
            }
            else
                if (Request.QueryString["Action"].ToLower() == "videos")
                {
                    this.Page.Title = "My Videos";
                }
                else
                    if (Request.QueryString["Action"].ToLower() == "photos")
                    {
                        this.Page.Title = "My Photos";
                    }

        }
    }
    public void playaudio(string s)
    {

        SoundPlayer mplayer = new SoundPlayer(); mplayer.SoundLocation = s; mplayer.Play();

    }
    private void UpdateMessageStatus()
    {
        // ContactMessages.UpdateNewMessageStatus(Web.SessionMembers.MemberID);
    }

    [WebMethod]
    public static string LoadData(string type)
    {
        string strComment = "";
        type = type.ToLower();
        UserID = Web.SessionMembers.MemberID.ToString();

        try
        {

            if (type.Equals("inboxmessages"))
            {
                ExhibitLog.UpdateExhibitLog(Web.SessionMembers.MemberID, ExhibitViews.Message);
                //DataTable dt = Contacts.GetInboxMessages(Web.SessionMembers.MemberID);
                DataTable dt = Contacts.GetSentnInboxMessages(Web.SessionMembers.MemberID, false);

                if (dt.Rows.Count > 0)
                    strComment = GenerateHTML(dt);
                else
                    strComment = "<div class='feedItem' style='padding:5px 0px 5px 0px;width:550px;'>&nbsp;&nbsp; No inbox messages exists.</div>";

            }
            else if (type.Equals("sentmessages"))
            {
                ExhibitLog.UpdateExhibitLog(Web.SessionMembers.MemberID, ExhibitViews.Message);
                //DataTable dt = Contacts.GetInboxMessages(Web.SessionMembers.MemberID);
                DataTable dt = Contacts.GetSentnInboxMessages(Web.SessionMembers.MemberID, true);
                if (dt.Rows.Count > 0)
                    strComment = GenerateHTML(dt);
                else
                    strComment = "<div class='feedItem' style='padding:5px 0px 5px 0px;width:550px;'>&nbsp;&nbsp; No sent messages exists.</div>";
            }
            else
                if (type.Equals("videos"))
                {
                    strComment = GenerateHTML(Contacts.GetVideos(Web.SessionMembers.MemberID));
                    if (string.IsNullOrEmpty(strComment))
                    {
                        strComment = "<div class='feedItem' style='padding:5px 0px 5px 0px;width:550px;'>&nbsp;&nbsp; No videos exists.</div>";
                    }
                }
                else
                    if (type.Equals("photos"))
                    {
                        strComment = GenerateHTML(Contacts.GetPhotos(Web.SessionMembers.MemberID));
                        if (string.IsNullOrEmpty(strComment))
                        {
                            strComment = "<div class='feedItem' style='padding:5px 0px 5px 0px;width:550px;'>&nbsp;&nbsp; No photos exists.</div>";
                        }
                    }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
        return strComment;
    }
    [WebMethod(EnableSession = true)]
    public static string GetMessageHtml()
    {
        string html = string.Empty;
        ContactMessages mesObj = new ContactMessages();
        //if (ToID.Equals(Web.SessionMembers.MemberID))
        //{

        //}
        //else
        //{

        //}
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();

        ds = mesObj.getMainMessage(Web.SessionMembers.MemberID);
        dt = ds.Tables[0];
        if (dt.Rows.Count == 0)
        {
            ds = mesObj.getMainToMessage(Web.SessionMembers.MemberID);
            dt = ds.Tables[0];
        }

        string itemHtml = string.Empty;
        string isReplied = string.Empty;//obj["IsReplied"].ToString();
        string isRead = string.Empty; //obj["IsRead"].ToString();
        string MemberLogoHref = string.Empty;
        DataSet dsgetData = new DataSet();
        DataTable dtgetData = new DataTable();
        DataTable getName = new DataTable();
        if (dt.Rows.Count > 0)
        {
            html = "<ul style='width: 550px; list-style-type: none;' >";
            foreach (DataRow obj in dt.Rows)
            {
                int ToID = Convert.ToInt32(obj["to"].ToString());
                int FromID = Convert.ToInt32(obj["from"].ToString());
                int tID = Convert.ToInt32(obj["ThreadID"].ToString());
                string thID = Secure.Encrypt(obj["ThreadID"].ToString());
                if (ToID == Web.SessionMembers.MemberID)
                {
                    dsgetData = mesObj.getMessageDataTo(ToID, FromID, tID);
                    dtgetData = dsgetData.Tables[0];
                }
                else if (FromID == Web.SessionMembers.MemberID)
                {
                    dsgetData = mesObj.getMessageDataFrom(ToID, FromID, tID);
                    dtgetData = dsgetData.Tables[0];
                }


                if (dtgetData.Rows.Count > 0)
                {
                    html = GenrateHTML(html);
                    foreach (DataRow objgetData in dtgetData.Rows)
                    {
                        itemHtml = string.Format("{0}", objgetData["Message"]);
                        html = html.Replace("#MESSAGE#", itemHtml);
                        html = html.Replace("#THID#", obj["ThreadID"].ToString());
                        html = html.Replace("#TIME#", String.Format("{0:m}", objgetData["MessageDate"]));
                        html = html.Replace("#TIMETITLE#", String.Format("{0:F}", objgetData["MessageDate"]));
                        isReplied = objgetData["IsReplied"].ToString();
                        isRead = objgetData["IsRead"].ToString();

                    }
                }
                if (ToID.Equals(Web.SessionMembers.MemberID))
                {
                    getName = mesObj.getMemberName(FromID).Tables[0];
                    MemberLogoHref = string.Format("/ePage/ImageViewer.ashx?Action=MembersLogoThumbnail&RecordID={0}", FromID);
                    html = html.Replace("#RecordID#", FromID.ToString());
                }
                else
                {
                    getName = mesObj.getMemberName(ToID).Tables[0];
                    MemberLogoHref = string.Format("/ePage/ImageViewer.ashx?Action=MembersLogoThumbnail&RecordID={0}", ToID);
                    html = html.Replace("#RecordID#", ToID.ToString());
                }

                //getName = mesObj.getMemberName(ToID).Tables[0];
                string NameRec = string.Empty;
                foreach (DataRow row in getName.Rows)
                {
                    NameRec = row["FullName"].ToString();
                }
                itemHtml = string.Format("<b>{0}</b>", NameRec);
                html = html.Replace("#SENDERNAME#", itemHtml);
                html = html.Replace("#IMAGE#", MemberLogoHref);

                itemHtml = string.Format("{0}", thID);
                html = html.Replace("#TID#", itemHtml);


                html = html.Replace("#LIID#", "liThrid." + obj["ThreadID"].ToString());
                if (isRead.Equals("0"))
                {
                    html = html.Replace("#SETSTYLE#", "liStyleisNotRead");
                }
                else
                {
                    html = html.Replace("#SETSTYLE#", "liStyleisRead");
                }
            }
            html += @"</ul>";

        }
        else
        {
            html = "<div id='MessagingMessages' style='width: 550px;'>No Recorde Exits</div>";
        }
        return html;
    }

    private static string GenrateHTML(string html)
    {
        html += @"<li id='#LIID#' class='#SETSTYLE#'>
                     <table class='uiGrid' cellspacing='0' cellpadding='0' style='border: 0px currentColor; border-collapse: collapse; border-spacing: 0;'>
                        <tbody>
                            <tr>
                                <td>
                                <div style='width:535px;'>
                                    <a class='threadLink' href='/MailBox/Default.aspx?action=read&amp;tid=#TID#&amp;RecordID=#RecordID#' rel='ignore'>
                                     <div style='width:530px;' >
                                        <div style='width:50px; height:50px; float:left;'>
                                            <img class='ImgClass' alt='' src='#IMAGE#'></div> <div style='float:left; width:10px; height:55px;'> </div>   
                                            <div style='width:470px; float:left;'>
                                                <div style='width:340px; float:left;'>
                                                    <strong style=' padding-top: 2px; font-weight: bold; white-space: normal;'>#SENDERNAME#</strong>
                                                   </div>
                                                <div style='min-width:120px; float: right; text-align: right;'>
                                                        <span style='color: rgb(157, 157, 157); padding-top: 2px; font-size: 9px; display: block;'>
                                                        <abbr style='color: rgb(157, 157, 157); padding-top: 2px; font-size: 9px; display: block;'
                                                        title='#TIMETITLE#' data-utime='1350823498'>#TIME#</abbr></span></div> </div>
                                        </div>
                                        <div><span style='width:470px;'>#MESSAGE#</span></div>
                                    </a>
                                    </div>
                                </td>
                                <td style='vertical-align:top;'>
                              <span style='margin-top:5px;'>


                                <img herf='#' src='../Images/LiveFeed/cross.png' style='border-width: 0px;margin-top:5px; cursor:pointer;' title='Remove' onclick='DeleteMainMessage(#THID#)' /> 

                                 </td>
                            </tr>
                        </tbody>
                    </table>
                </li>";
        return html;
        //<input style='border-width: 0px;margin-top:5px;' title='Remove' name='Remove' onclick='myFunction()' alt='Remove' src='../Images/LiveFeed/cross.png' type='image' /></span>
    }
    [WebMethod]
    public static string LoadInboxMessages()
    {
        string strComment = "";
        DataTable dt = Contacts.GetSentnInboxMessages(Web.SessionMembers.MemberID, false);
        if (dt.Rows.Count > 0)
            strComment = GenerateHTML(dt);
        else
            strComment = "<div class='feedItem' style='padding:5px 0px 5px 0px;'>&nbsp;&nbsp; No messages exists.</div>";

        return strComment;
    }
    [WebMethod]
    public static string LoadSentMessages()
    {
        string strComment = "";
        DataTable dt = Contacts.GetSentnInboxMessages(Web.SessionMembers.MemberID, true);
        if (dt.Rows.Count > 0)
            strComment = GenerateHTML(dt);
        else
            strComment = "<div class='feedItem' style='padding:5px 0px 5px 0px;'>&nbsp;&nbsp; No messages exists.</div>";

        return strComment;
    }
    [WebMethod]
    public static void DeleteMessages(string tid, string mid, string deletetype)
    {
        ContactMessages objMessages = new ContactMessages();
        if (Web.IsMemberSession)
        {
            int MemberID = Web.SessionMembers.MemberID;
            bool dsDelete = objMessages.Delete_by_Message("DeleteMessage", Convert.ToInt32(tid), Convert.ToInt32(mid), deletetype, MemberID);
        }
    }
    [WebMethod(EnableSession = true)]
    public static string MakeInboxHTML(string tid, string messageAction)
    {
        string html = string.Empty;
        string Attachhtml = string.Empty;

        string innerHTML = string.Empty;
        string thID = string.Empty;
        int ToID = 0;
        int FromID = 0;
        int tID = 0;
        if (messageAction == "read")
        {
            thID = Secure.Decrypt(tid);
            tID = Convert.ToInt32(thID);
        }
        else if (messageAction == "MessageToOne")
        {
            HttpContext.Current.Response.Redirect("/MailBox/Default.aspx?Action=messages");
        }


        DataSet ds = new DataSet();
        DataSet dsID = new DataSet();

        ContactMessages objMessages = new ContactMessages();

        dsID = objMessages.getToFromID(tID);
        DataTable dtId = dsID.Tables[0];
        DataTable dt = new DataTable();

        if (dtId.Rows.Count > 0)
        {
            foreach (DataRow row in dtId.Rows)
            {
                ToID = Convert.ToInt32(row["to"].ToString());
                FromID = Convert.ToInt32(row["from"].ToString());
            }
            if (FromID.Equals(Web.SessionMembers.MemberID))
            {
                ds = objMessages.getinboxMessageFrom(Web.SessionMembers.MemberID, tID);
                dt = ds.Tables[0];
            }
            else if (ToID.Equals(Web.SessionMembers.MemberID))
            {
                ds = objMessages.getinboxMessageTO(Web.SessionMembers.MemberID, tID);
                dt = ds.Tables[0];
            }
        }
        //ds = objMessages.getinboxMessageFrom(FromID, ToID, tID);


        if (dt.Rows.Count > 0)
        {
            int contectMessageID = 0;

            DataSet IsReadds = objMessages.IsreadMessage(Convert.ToInt32(tID));
            html = "<div id='MessagingMessages' style='width: 550px;'><ul style='width: 550px; list-style-type: none;' >";
            foreach (DataRow row in dt.Rows)
            {
                html = inboxMessage(html);
                ToID = Convert.ToInt32(row["to"].ToString());
                tID = Convert.ToInt32(row["ThreadID"].ToString());
                contectMessageID = Convert.ToInt32(row["ContactMessageID"].ToString());
                string isReplied = row["IsReplied"].ToString();
                string isRead = row["IsRead"].ToString();
                FromID = Convert.ToInt32(row["from"].ToString());
                DataTable getName = new DataTable();
                string NameRec = string.Empty;
                string href = string.Empty;
                string DocType = string.Empty;
                string MemberLogoHref = string.Empty;
                getName = objMessages.getMemberName(FromID).Tables[0];
                MemberLogoHref = string.Format("/ePage/ImageViewer.ashx?Action=MembersLogoThumbnail&RecordID={0}", FromID);
                html = html.Replace("#IMAGE#", MemberLogoHref);//
                foreach (DataRow row1 in getName.Rows)
                {
                    NameRec = row1["FullName"].ToString();
                }
                html = html.Replace("#SENDERNAME#", NameRec);
                html = html.Replace("#INTHID#", row["ThreadID"].ToString());
                html = html.Replace("#MID#", row["ContactMessageID"].ToString());
                innerHTML = NameRec;
                href = string.Format("/Contacts/ViewProfile.aspx?Action=ViewDealer&RecordID={0}", FromID);

                html = html.Replace("#PROFILELINK#", href);
                innerHTML = row["Message"].ToString();
                html = html.Replace("#MESSAGE#", innerHTML);
                html = html.Replace("#TIME#", String.Format("{0:m}", row["MessageDate"]));
                html = html.Replace("#TIMETITLE#", String.Format("{0:F}", row["MessageDate"]));
                DataSet AttachDS = objMessages.getAttachmentData(contectMessageID, ToID);
                DataTable attachDT = AttachDS.Tables[0];
                string videoHtml = "";
                if (attachDT.Rows.Count > 0)
                {
                    int count = 0;
                    Attachhtml = "";
                    foreach (DataRow rowAttach in attachDT.Rows)
                    {
                        if (rowAttach["FileFormat"].ToString().ToLower().Trim().Equals("photo"))
                        {
                            if (count == 0 || count % 2 != 0)
                            {
                                Attachhtml += @"<div style='float:left; margin-left:15px; width:200px; height:160px;margin-bottom:5px;margin-top:10px;'>
                         <img class='uiMediaThumb' src='#IMGURL#' height='150' width='200' alt='image' /></div>";
                            }
                            else if (count % 2 == 0)
                            {
                                Attachhtml += @"<div style='float:left; margin-left:75px; width:200px; height:160px;margin-bottom:5px;margin-top:10px;'>
                         <img class='uiMediaThumb' src='#IMGURL#' height='150' width='200' alt='image' /></div>";
                            }

                            innerHTML = rowAttach["URL"].ToString();
                            Attachhtml = Attachhtml.Replace("#HFREMESSAGE#", innerHTML);
                            Attachhtml = Attachhtml.Replace("#IMGURL#", innerHTML);
                            count++;
                        }
                        else
                            if (rowAttach["FileFormat"].ToString().ToLower().Trim().Equals("video"))
                            {
                                videoHtml += "<div><object width='420' height='240'><param name='movie' value='" + (rowAttach["URL"] == null ? "" : rowAttach["URL"].ToString()) + "'><param name='type' value='application/x-shockwave-flash'><param name='allowfullscreen' value='true'><param name='allowscriptaccess' value='always'><param name=\"wmode\" value=\"opaque\" /><embed width='420' height='240' src='" + (rowAttach["URL"] == null ? "" : rowAttach["URL"].ToString()) + "' type='application/x-shockwave-flash' allowfullscreen='true' allowscriptaccess='always' wmode=\"opaque\"></embed></object></div>";

                            }
                            else
                            {
                                string icon = "/" + Web.GetFileIconUrl(rowAttach["URL"].ToString());
                                //DocType += string.Format("<div class='defaultIcon' style='width:400px; padding-top:5px;  padding-left:75px; margin-top:5px;margin-bottom:5px; background-image:url(" + icon + ")'><a href='{0}'><storng>{1}</storng></a> </div> ", rowAttach["URL"].ToString(), rowAttach["OriginalFileName"].ToString());
                                DocType += string.Format("<div style='float:leftx;'><span style='padding:0px 2px 0px 2px;valign:middle;'><img src='{0}'/></span><span><a href='{1}'><storng>{2}</storng></a></span> </div> ", icon, rowAttach["URL"].ToString(), rowAttach["OriginalFileName"].ToString());
                            }

                    }

                    //html = html.Replace("#Attachment#", Attachhtml);
                    html = html.Replace("#Attachment#", Attachhtml + "<div style='clear:both;'><center>" + videoHtml + "</center></div>");
                    html = html.Replace("#DocType#", "<div style='clear:both;padding:5px 0px 5px 60px;'>" + DocType + "</div>");
                }
                else
                {

                    html = html.Replace("#Attachment#", "");
                    html = html.Replace("#DocType#", "");
                }
            }
            html += "</ul></div>";
        }
        else
        {
            html = "<div id='MessagingMessages' style='width: 550px;'>No Recorde Exits</div>";
        }


        return html;
    }

    private static string inboxMessage(string html)
    {
        html += @"<li id='#LIMID#' class='liStyleisRead'>
                     <table class='uiGrid' cellspacing='0' cellpadding='0' style='border: 0px currentColor; border-collapse: collapse; border-spacing: 0;'>
                        <tbody>
                            <tr>
                                <td>
                                <div style='width:535px;'>
                                     <div style='width:530px;' >
                                        <a class='threadLink' href='#PROFILELINK#' rel='ignore'>
                                        <div style='width:50px; height:50px; float:left;'>
                                            <img class='ImgClass' alt='#PROFLIENAME#' src='#IMAGE#'></div>  </a> 
                                     <div style='float:left; width:10px; height:55px;'> </div>   
                                            <div style='width:470px; float:left;'>
                                               <a class='threadLink' href='#PROFILELINK#' rel='ignore'>   <div style='width:340px; float:left;'>
                                                    <strong style=' padding-top: 2px; font-weight: bold; white-space: normal;'>#SENDERNAME#</strong>
                                                   </div> </a>
                                      <div style='min-width:120px; float: right; text-align: right;'>
                                                        <span style='color: rgb(157, 157, 157); padding-top: 2px; font-size: 9px; display: block;'>
                                                        <abbr style='color: rgb(157, 157, 157); padding-top: 2px; font-size: 9px; display: block;'
                                                        title='#TIMETITLE#' data-utime='1350823498'>#TIME#</abbr></span></div> </div>
                                      </div>
                                      <div  style='width:470px;'>#MESSAGE#
                                     
                                    </div>
                                    <div style='width:550px; min-height:5px;'>#Attachment#
                                     
                                    </div>
                                     <div style='width:550px;'>#DocType#
                                     
                                    </div>
                                </div>
                                </td>
                               <td style='vertical-align:top;'>
                              <span style='margin-top:5px;'>


                                <img herf='#' src='../Images/LiveFeed/cross.png' style='border-width: 0px;margin-top:5px; cursor:pointer;' title='Remove' onclick='DeleteInBoxMessages(#INTHID#,#MID#)' /> 

                                 </td>
                            </tr>
                        </tbody>
                    </table>
                </li>";
        return html;
    }

    public static string GenerateHTML(DataTable dt)
    {
        string strComment = "";
        string replyHTML = "";
        string message, activityTitle;
        int logID;
        string refID, actID, memID, date_, xml, related, user, title, posttypeid, xmlComments;
        StringBuilder sb = new StringBuilder();
        try
        {
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    IsReply = false;
                    logID = Convert.ToInt32(dt.Rows[i]["ActivityLogID"]);
                    user = Convert.ToString(dt.Rows[i]["UserName"]);
                    actID = Convert.ToString(dt.Rows[i]["ActivityID"]);
                    xml = Convert.ToString(dt.Rows[i]["Details"]);
                    xmlComments = Convert.ToString(dt.Rows[i]["ActivityComments"]);
                    memID = Convert.ToString(dt.Rows[i]["MemberID"]);
                    date_ = Convert.ToString(dt.Rows[i]["ActivityDate"]);
                    refID = Convert.ToString(dt.Rows[i]["ReferenceID"]);
                    message = dt.Rows[i]["Description"].ToString();
                    related = dt.Rows[i]["RelatedToContact"].ToString();
                    title = Convert.ToString(dt.Rows[i]["ActivityTitle"]);
                    posttypeid = "";// Convert.ToString(dt.Rows[i]["PostTypeID"]);
                    //------------------------------------------------------------------------------
                    // go to to netxt iteration of the for loop as reply will not shown as a posts 
                    if (actID == "19")
                    {
                        continue;
                    }
                    //------------------------------------------------------------------------------
                    if (!message.Contains(" ") && message.Length > 70)
                    {
                        message = Web.SplitString(message, 70);
                    }
                    activityTitle = Web.GetActivityTitle(memID, related, actID, title, message, refID, xml);

                    ///
                    activityTitle = activityTitle.Replace("posted a comment to all", "posted a comment to the world");
                    ////////get xml for new post (from post to the world) if activityID=45
                    if (actID == "45")
                    {
                        title = message;
                    }
                    message = Web.GetActivityDescription(true, logID.ToString(), actID, xml, message, refID, memID, date_, posttypeid);

                    if (actID == "40")
                    {
                        message = message.Replace("width: 468px;", "width: 433px;");
                    }

                    //-----------------------------------------------------------------------------
                    //if a message is sent

                    //generate reply html 
                    DataTable dtReply = ContactMessages.LoadMessageReply(Convert.ToInt32(refID));
                    if (dtReply.Rows.Count == 1 && actID == "4")
                    {
                        IsReply = true;
                        string newXML = dtReply.Rows[0][0].ToString();
                        replyHTML = loadFeeds(logID.ToString(), actID, refID, memID, 3, newXML, false);
                    }
                    //-----------------------------------------------------------------------------

                    //foreach (DataRow row in dt.Rows)
                    //{
                    sb.Append("<table class='feedItem'><tr><td id='Feed_" + logID + "'>");
                    sb.Append("<div style='width: 8%; float: left; text-align: left;'>");
                    sb.Append("<div style='padding: 0px;'>");
                    sb.Append("<img id='Img1' src='../../ePage/ImageViewer.ashx?Action=MembersLogoThumbnail&amp;RecordID=" + Secure.Encrypt(memID) + "' alt='eOpen' title='eOpen' style='border: 1px solid white;' width='32' height='32'>");
                    sb.Append("</div>");
                    sb.Append("</div>");
                    sb.Append("<div style='width: 92%; float: left; text-align: left;'>");
                    if (actID != "33")
                    {
                        sb.Append("<a href='/contacts/ViewProfile.aspx?Action=ViewDealer&amp;RecordID=" + Secure.Encrypt(memID) + "'>");
                        //set user name color 
                        string profileclass;
                        if (Web.IsMemberSession)
                            profileclass = Web.GetProfileClass(Convert.ToInt32(memID), Web.SessionMembers.MemberID);
                        else
                            profileclass = "Unknown";
                        sb.Append("<span class='" + profileclass + "'>");
                        sb.Append(Web.GetUserName(Convert.ToInt32(memID), user));
                        sb.Append("</span>");
                        sb.Append("</a>");
                    }
                    sb.Append("&nbsp;<span class='details'>");

                    //setting title
                    if (actID == "45")
                        sb.Append(title + "</span><br />");
                    else
                        sb.Append(activityTitle + "</span><br />");




                    sb.Append("<div class='feed_TimeStamp'>");
                    sb.Append(Web.GetTime(Convert.ToDateTime(date_)));
                    sb.Append("</span>&nbsp;</div>");
                    //actions buttons
                    if (Web.IsMemberSession)
                        sb.Append("<div style='float:right; padding-right:10px;'>");//moved the action buttons to right


                    if (!Web.IsMemberSession)
                    {
                        sb.Append("<div style='display: inline;' class='feed_actionLinks'>");
                        sb.Append("<a href='../index.aspx?Action=signup'>");
                        sb.Append("<img src='../../Images/LiveFeed/comment.png' alt='Comment' title='Comment' width='15' height='10'>&nbsp;&nbsp;&nbsp;&gt;Sign up to start exhibiting</a></div>");
                    }
                    if (Web.IsMemberSession)
                    {

                        sb.Append("<div style='display: inline;' class='feed_actionLinks'>");
                        sb.Append("<a href='javascript:void(0);' onclick='openCommentBox(" + logID + ");'>");
                        sb.Append("<img src='../../Images/LiveFeed/comment.png' alt='Comment' title='Comment' width='15' height='10'>");

                        sb.Append("</a></div>");
                        if (Web.ShowMessageIcon(memID, related) && (IsMyContactOrMe(memID)))
                        {
                            sb.Append("<div style='display: inline;' class='feed_actionLinks'>");
                            sb.Append("<a href='/contacts/MessageToSelected.aspx?Action=messagetoone&amp;RecordID=" + Secure.Encrypt(memID) + "'>");
                            sb.Append("<img src='../../Images/LiveFeed/mail.png' id='Img4' alt='Send Message' title='Send Message' width='13' height='10'>");
                            sb.Append("</a></div>");
                        }
                        if ((Web.ShowReply(actID, refID)) && (IsMyContactOrMe(memID)))
                        {
                            sb.Append("<div style='display: inline;' class='feed_actionLinks'>");
                            sb.Append("<a href='/contacts/MessageToSelected.aspx?Action=replytomessage&amp;RecordID=" + Secure.Encrypt(refID) + "'>");
                            sb.Append("<img src='../../Images/LiveFeed/reply_private_message_big.png' id='Img4' alt='Reply' title='Reply' width='13' height='10'>");
                            sb.Append("</a></div>");
                        }
                        if (Web.SessionMembers.MemberID.ToString() != memID && actID == "144")
                        {
                            sb.Append("<div class='feed_actionLinks' style='display: inline;'>");
                            sb.Append("<a href='../WTS/ViewLot.aspx?Action=View&amp;RecordID=" + Secure.Encrypt(refID) + "'>");
                            sb.Append("<img src='../../Images/LiveFeed/dollar_bag.png' id='Img2' alt='Make Offer' title='Make Offer' width='15' height='11'>");
                            sb.Append("</a></div>");
                        }
                        if (Web.SessionMembers.MemberID.ToString() != memID && actID == "3")
                        {
                            sb.Append("<div class='feed_actionLinks' style='display: inline;'>");
                            sb.Append("<a href='../WTB/ViewDetails.aspx?Action=View&amp;RecordID=" + Secure.Encrypt(refID) + "'>");
                            sb.Append("<img src='../../Images/LiveFeed/dollar_bag.png' id='Img5' alt='Make Offer' title='Make Offer' width='15' height='11'>");
                            sb.Append("</a></div>");
                        }
                        ///////////to update the link / unlink icon for the purticular user
                        if (linkIds.ContainsKey(Convert.ToInt32(memID)))
                            linkIds[Convert.ToInt32(memID)]++;
                        else
                            linkIds.Add(Convert.ToInt32(memID), 0);


                        if (Web.ShowLink(memID, actID))
                        {
                            //link
                            sb.Append("<div id='link_" + memID + "_" + linkIds[Convert.ToInt32(memID)] + "' class='feed_actionLinks' style='display: inline;'>");
                            sb.Append("<a href='javascript:void();' onclick='Link(" + memID + "," + logID + ");' >");
                            sb.Append("<img src='../../Images/Linkings/Link-15.png'  title='Link' alt='Link'  style='border-width: 0px;' />");
                            sb.Append("</a></div>");
                            //unlink
                            sb.Append("<div id='Unlink_" + memID + "_" + linkIds[Convert.ToInt32(memID)] + "' class='feed_actionLinks' style='display: none;'>");
                            sb.Append("<a href='javascript:void();'onclick='Unlink(" + memID + "," + logID + ");' >");
                            sb.Append("<img src='../../Images/Linkings/Unlink-15.png'  title='Unlink'  alt='Unlink' style='border-width: 0px;'/></a></div>");

                        }
                        if (Web.ShowUnlink(memID, actID))
                        {
                            //link
                            sb.Append("<div id='link_" + memID + "_" + linkIds[Convert.ToInt32(memID)] + "' class='feed_actionLinks' style='display: none;'>");
                            sb.Append("<a href='javascript:void();' onclick='Link(" + memID + "," + logID + ");' >");
                            sb.Append("<img src='../../Images/Linkings/Link-15.png'  title='Link' alt='Link'  style='border-width: 0px;' /></a></div>");
                            //unlink
                            sb.Append("<div id='Unlink_" + memID + "_" + linkIds[Convert.ToInt32(memID)] + "' class='feed_actionLinks' style='display: inline;'>");
                            sb.Append("<a href='javascript:void();'onclick='Unlink(" + memID + "," + logID + ");' >");
                            sb.Append("<img src='../../Images/Linkings/Unlink-15.png'  title='Unlink'  alt='Unlink' style='border-width: 0px;'/>");
                            sb.Append("</a></div>");
                        }
                        //end linking
                        sb.Append("<div class='feed_actionLinks' style='display: inline;'>");
                        sb.Append("<a href='javascript:void(0);' onclick='DeleteMessage(" + logID + ");'>");
                        sb.Append("<img src='../../Images/LiveFeed/cross.png' alt='Remove' title='Remove'></a>");
                        sb.Append("</div>");
                        if (memID != Web.SessionMembers.MemberID.ToString())
                        {
                            if (Web.ShowReportAbuse(actID))
                            {
                                sb.Append("<div class='feed_actionLinks' style='display: inline;'>");
                                sb.Append(" <a href='javascript:void(0);' onclick=\"openblockMemberWindow('ReportAbuse.aspx?Action=" + Secure.Encrypt(1) + "&RecordID=" + Secure.Encrypt(logID) + "');\">");
                                sb.Append("Report inappropriate> </a>");
                                sb.Append("</div>");
                            }
                        }
                    }

                    if (Web.IsMemberSession)
                        sb.Append("</div>");//end moved div

                    //'''''''''''''''''''''''''''''''''''''''''''''
                    sb.Append("</div>");
                    sb.Append("<table style='margin-bottom:10px;float:left;padding-left:18px; margin-left:15px; border-left:0px solid #febe10;border-bottom:0px solid #febe10;'");
                    sb.Append("<tr><td>&nbsp;");
                    sb.Append("</td></tr>");
                    sb.Append("<tr><td style='padding-right:10px;'>");
                    //'''''''''''''''''''''''''''''               
                    sb.Append(message);
                    if (IsReply)
                        sb.Append(replyHTML);
                    //activity comments  
                    sb.Append("<div id='TD_" + logID + "' style='width:445px;'>");
                    if (xmlComments != "")
                    {
                        sb.Append(loadFeeds(logID.ToString(), actID, refID, memID, 3, "", false));
                    }
                    sb.Append("</div>");

                    sb.Append("</div>");
                    if (Web.IsMemberSession)
                    {
                        sb.Append("<div style='display:none; border:0px solid #cccccc; overflow:hidden; padding:10px; width:422px;' id='CommentDiv_" + logID + "''>");
                        sb.Append("<textarea id='txtComment_" + logID + "' rows='3' cols='5' style='width:415px;'></textarea><br />");
                        sb.Append("<div style='float:right;'>");
                        sb.Append("<input type='button' class='InnerButtonGray' onclick=OnHide('CommentDiv_" + logID + "');  value='Cancel' /> &nbsp;");
                        sb.Append("<input type='button' id='btnPost' value='Post' class='InnerGridButton' onclick=\"SaveUserComments(" + Web.SessionMembers.MemberID.ToString() + "," + logID + "," + actID + "," + refID + ",'" + user + "'," + memID + ");\" />");
                        sb.Append("</div>");
                        sb.Append("</div>");
                    }
                    sb.Append("</div>");
                    sb.Append("</td></tr></table><br />");
                    sb.Append("</td></tr></table>");

                    //} 
                    strComment = sb.ToString();
                }
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
        return strComment;
    }

    public static string loadFeeds(string logID, string actID, string refID, string membID, int count, string xmlDtl, bool isBill)
    {
        StringBuilder sb = new StringBuilder();
        string activityComments;
        string username, comment;
        string commentDate;
        string activitLogID, activityCommentID;
        string[] subComments;
        string memberID;
        int counter = 0;
        string xml = xmlDtl;
        string jsMethod = "openBillboardCommentBox";
        string css = "defaultBillboard_Comments";

        if (xml == "")
        {
            //  xml = ViewAllFeeds(logID, membID); ToDo
            css = "feed_Comments";
            jsMethod = "openCommentBox";
        }
        //Activity comments
        sb.Append("<div  id='DV_" + logID.ToString() + "'>");

        //if it is a reply then do not show the arrow 
        if (!IsReply)
            sb.Append("<div class='feed_Comments_arrow'></div>");
        //-------------------------------------------------------
        activityComments = xml;
        subComments = Regex.Split(activityComments, "/>");

        try
        {
            foreach (var item in subComments)
            {
                if (item == "") break;

                if (count != 0)
                {
                    if (counter >= 3)
                    { break; }
                    counter++;
                }

                if (IsReply)//if this is a reply to any message then
                {
                    css = "feed_Comments";

                    username = item.Substring(item.IndexOf("UserName=\"") + 10);
                    username = username.Remove(username.IndexOf("\""));
                    //get the original reply
                    comment = ContactMessages.GetMessageReply(Convert.ToInt32(refID));

                    string[] chunks = { };
                    chunks = Regex.Split(comment, " ");
                    foreach (var str in chunks)
                    {
                        if (str.Length > 40)
                            if ((!str.Contains("www.")) && (!str.Contains("http")))
                                comment = Web.SplitString(comment, 60);
                    }

                    // memberID = item.Substring(item.IndexOf("RelatedToContact=\"") + 18);
                    memberID = item.Substring(item.IndexOf("MemberID=\"") + 10);
                    memberID = memberID.Remove(memberID.IndexOf("\""));
                    commentDate = item.Substring(item.IndexOf("ActivityDate=\"") + 14);
                    commentDate = commentDate.Remove(commentDate.IndexOf("\""));
                    commentDate = Web.GetTime(Convert.ToDateTime(commentDate));
                    activitLogID = item.Substring(item.IndexOf("ActivityLogID=\"") + 15);
                    activitLogID = activitLogID.Remove(activitLogID.IndexOf("\""));
                    activityCommentID = item.Substring(item.IndexOf("ReferenceID=\"") + 13);
                    activityCommentID = activityCommentID.Remove(activityCommentID.IndexOf("\""));
                }
                else
                {
                    username = item.Substring(item.IndexOf("UserName=\"") + 10);
                    username = username.Remove(username.IndexOf("\""));
                    comment = item.Substring(item.IndexOf("Comments=\"") + 10);
                    comment = comment.Remove(comment.IndexOf("\""));

                    string[] chunks = { };
                    chunks = Regex.Split(comment, " ");
                    foreach (var str in chunks)
                    {
                        if (str.Length > 40)
                            if ((!str.Contains("www.")) && (!str.Contains("http")))
                                comment = Web.SplitString(comment, 60);
                    }

                    memberID = item.Substring(item.IndexOf("CommentsBy=\"") + 12);
                    memberID = memberID.Remove(memberID.IndexOf("\""));
                    commentDate = item.Substring(item.IndexOf("CommentsDate=\"") + 14);
                    commentDate = commentDate.Remove(commentDate.IndexOf("\""));
                    commentDate = Web.GetTime(Convert.ToDateTime(commentDate));
                    activitLogID = item.Substring(item.IndexOf("ActivityLogID=\"") + 15);
                    activitLogID = activitLogID.Remove(activitLogID.IndexOf("\""));
                    activityCommentID = item.Substring(item.IndexOf("ActivityLogCommentsID=\"") + 23);
                    activityCommentID = activityCommentID.Remove(activityCommentID.IndexOf("\""));

                }
                //if there is no space or breaks in the comment
                if (!comment.Contains(" ") && comment.Length > 280)
                {
                    comment = Web.SplitString(comment, 70);
                }
                //if (comment.Length > 280 && actID == "40")
                //    isBill = true;

                sb.Append("<div id=\"DV_Del_" + activityCommentID + "\">");
                sb.Append("<div class='" + css + "' style=' text-align: left;padding-right:10px;margin-right:5px;'> ");
                sb.Append("<table style='margin: 2px; width: 100%; text-align: left;' border='0' cellpadding='0' cellspacing='0'>");
                sb.Append("<tr><td rowspan='2' valign='top' width='5%'>");
                sb.Append("<img src='../../ePage/ImageViewer.ashx?Action=MembersLogoThumbnail&amp;RecordID=" + Secure.Encrypt(memberID) + "' title='Logo' alt='Logo' width='24' height='24'>");
                sb.Append("</td><td align='left' valign='top' width='95%'>");
                sb.Append("<table border='0' cellpadding='1' width='100%'>");
                sb.Append("<tr><td align='left' width='50%'>");
                sb.Append("<span style='font-size: 7.5pt;'>");
                sb.Append("<a href='/contacts/ViewProfile.aspx?Action=ViewDealer&amp;RecordID=" + Secure.Encrypt(memberID) + "'>");
                //set user name class 
                string profileclass;
                if (Web.IsMemberSession)
                    profileclass = Web.GetProfileClass(Convert.ToInt32(memberID), Web.SessionMembers.MemberID);
                else
                    profileclass = "Unknown";
                sb.Append("<span class='" + profileclass + "'>");
                sb.Append(Web.GetUserName(Convert.ToInt32(memberID), username));
                sb.Append("</span></a>&nbsp;");
                sb.Append("<span class='details' style='font-size: 7.5pt;'>");

                if (IsReply)
                    sb.Append("replied&nbsp;");
                else
                    sb.Append("posted a comment&nbsp;");

                sb.Append("</span>");
                sb.Append("</span></td><td align='right'>");
                sb.Append("<span id='feed_TimeStamp" + activityCommentID + "' class='feed_TimeStamp' style='font-weight:200;'>");
                sb.Append(commentDate + "</span> ");

                sb.Append("<div class='feed_actionLinks' style='display: inline;>");
                //if this is reply to message then
                if (IsReply)
                {
                    //no comment button for reply post
                }
                else
                {
                    sb.Append("<a href='javascript:void(0);' onclick='" + jsMethod + "(" + activitLogID + ");' style='cursor:pointer;'>");
                    sb.Append("<img src='../../Images/LiveFeed/comment.png' alt='Comment' title='Comment' width='15' height='10'  style='cursor:pointer;'>");
                }
                //using (StringWriter sw = new StringWriter(sb))
                //{
                //    using (HtmlTextWriter tw = new HtmlTextWriter(sw))
                //    {
                //        sprite.RenderControl(tw);
                //    }
                //}
                sb.Append("</a></div>");
                if (Web.ShowReply(actID, refID) && (IsMyContactOrMe(memberID)))
                {
                    sb.Append("<div class='feed_actionLinks' style='display: inline;'>");
                    sb.Append("<a target='_top' href='/contacts/MessageToSelected.aspx?Action=MessageToOne&amp;RecordID=" + Secure.Encrypt(memberID) + "'>");
                    sb.Append("<img src='../../Images/LiveFeed/mail.png' alt='Send Message' title='Send Message' width='11' height='8'>");
                    //using (StringWriter sw = new StringWriter(sb))
                    //{
                    //    using (HtmlTextWriter tw = new HtmlTextWriter(sw))
                    //    {
                    //        spriteMessage.RenderControl(tw);
                    //    }
                    //}
                    sb.Append("</a></div>");
                }
                sb.Append("<div class='feed_actionLinks' style='display: inline;'>");

                //---------------if reply message  activityCommentID
                if (IsReply)
                {
                    sb.Append("<a href='javascript:void(0);' onclick='DeleteReply(" + activityCommentID + ");'>");
                    sb.Append("<img src='../../Images/LiveFeed/cross.png' alt='Remove' title='Remove'></a>");
                }
                else
                {
                    sb.Append("<a href='javascript:void(0);' onclick='DeleteSubComment(" + activityCommentID + "," + actID + "," + refID + "," + UserID + "," + activitLogID + ");'>");
                    sb.Append("<img src='../../Images/LiveFeed/cross.png' alt='Remove' title='Remove'></a>");
                }
                //using (StringWriter sw = new StringWriter(sb))
                //{
                //    using (HtmlTextWriter tw = new HtmlTextWriter(sw))
                //    {
                //        spriteDel.RenderControl(tw);
                //    }
                //}
                sb.Append("</div></td></tr></table>");
                sb.Append("</td></tr>");
                sb.Append("<tr><td style='font-size: 8pt; font-weight: normal; padding-left: 5px; text-align: justify; ");
                sb.Append("width: 415px; overflow: hidden;'>");

                //activity comment short.....
                comment = HttpUtility.HtmlDecode(comment);
                sb.Append("<div id='short_" + activityCommentID + "'>");
                bool isURL = false;
                Regex regx = new Regex("http(s)?://([\\w+?\\.\\w+])+([a-zA-Z0-9\\~\\!\\@\\#\\$\\%\\^\\&amp;\\*\\(\\)_\\-\\=\\+\\\\\\/\\?\\.\\:\\;\\'\\,]*)?", RegexOptions.IgnoreCase);
                MatchCollection mactches = regx.Matches(comment);
                foreach (Match match in mactches)
                {
                    isURL = true;
                }

                if (!isURL)
                    sb.Append(Web.ShortenComment(comment, Convert.ToInt32(activityCommentID)));
                else
                    sb.Append(comment);

                sb.Append("</div>");
                sb.Append("<div id=\"full_" + activityCommentID + "\" style=\"display: none;overflow: hidden; padding-right:3px;\">");
                sb.Append(Web.MakeLinksClickable(Web.BreakLongString(comment, 70)));
                sb.Append("<br />");
                sb.Append("<a href=\"javascript:void(0);\" onclick=\"Hide('full_" + activityCommentID + "');Show('short_" + activityCommentID + "');\">");
                sb.Append("View less>></a></div>");

                sb.Append("</div>");
                sb.Append("</td></tr></table>");
                sb.Append("</div>");
                sb.Append("</div>");
                /////////////////////////////////////////
                //string shortComment = "";
                //shortComment = sb.ToString();
                if (isBill)
                {
                    sb.Replace("short_", "bill_short_");
                    sb.Replace("full_", "bill_full_");
                }

                // sb.Append(shortComment);
            }
            if (xmlDtl == "")//not billboard comments
            {
                if (count == 0)
                {
                    sb.Append("<div id='less_" + logID + "' style='float:right;'><a href='javascript:void(0);' onclick='ViewLessComments(" + logID + "," + actID + "," + refID + "," + membID + ");'>View Less Comments>></a>");
                    sb.Append("</div>");
                }
                if (count != 0 && subComments.Length > 4)
                {
                    sb.Append("<div id='more_" + logID + "' style='float:right;'><a href='javascript:void(0);' onclick='ViewAllComments(" + logID + "," + actID + "," + refID + "," + membID + ");'>View All Comments>></a>");
                    sb.Append("</div>");
                }
            }
            else
            {
                if (count == 0)
                {
                    sb.Append("<div id='billboard_less_" + logID + "' style='float:right;'><a href='javascript:void(0);' onclick='ViewLessBollboardComments();'>View Less Comments>></a>");
                    sb.Append("</div>");
                }
                if (count != 0 && subComments.Length > 4)
                {
                    sb.Append("<div id='billboard_more_" + logID + "' style='float:right;'><a href='javascript:void(0);' onclick='ViewAllBollboardComments();'>View All Comments>></a>");
                    sb.Append("</div>");
                }
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
        return sb.ToString();
    }

    protected static bool IsMyContactOrMe(string s_MemberID)
    {
        bool result = false;
        try
        {
            if (s_MemberID != Web.SessionMembers.MemberID.ToString())
            {
                Contacts contact = new Contacts();
                contact.Where.MemberID.Value = Web.SessionMembers.MemberID;
                contact.Where.ContactMemberID.Value = s_MemberID;
                contact.Query.Load();
                if (contact.RowCount > 0)
                    result = true;
            }
        }
        catch (Exception ex)
        {
            //Log.Write("Error", ex.GetBaseException().ToString(), ex);
            Web.LogError(ex);
        }
        return result;
    }
    string ThreadID = string.Empty;

    [WebMethod]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public static string Post_Click(string tid, string ActionType, string Message, string RecordID, string repositryKey)
    {
        bool Responce = false;  //show warning if message is duplicate
        string status = "message send";
        int threadID = 0;
        string ThreadID = Secure.Decrypt(tid);
        if (ActionType == "read")
        {
            threadID = Convert.ToInt32(ThreadID);
        }
        else if (ActionType == "MessageToOne")
        {
            threadID = ContactMessages.GetNextThreadID();
        }
        bool isChecked = false;
        try
        {
            if (ActionType != "")
            {
                int groupID = ContactMessages.GetNextGroupID();
                Responce = MessageToOne(Message, groupID, threadID, Convert.ToInt32(Secure.Decrypt(RecordID)), repositryKey);
                if (Responce == true)
                {
                    return status;
                }
                else
                {
                    return status = "not send";
                }
                isChecked = true;

            }

        }
        catch (Exception exp)
        {
            Web.LogError(exp);
        }

        return status;
    }

    private static bool MessageToOne(string Message, int groupID, int threadID, int Toid, string repositryKey)
    {
        bool showDuplicateWarning = false;
        try
        {
            Members tomember = new Members();
            tomember.LoadByPrimaryKey(Web.RecordID);
            MailBox_Default page = (MailBox_Default)HttpContext.Current.CurrentHandler;
            ContactMessages contactmessage = new ContactMessages();
            contactmessage.AddNew();
            contactmessage.From = Web.SessionMembers.MemberID;
            contactmessage.To = Toid;
            contactmessage.Message = Message;
            contactmessage.MessageDate = DateTime.Now;
            contactmessage.IsRead = 0;
            contactmessage.IsPrivate = 1;
            contactmessage.SystemObjectID = (int)SystemObjects.Messages;
            contactmessage.ThreadID = threadID;
            contactmessage.Save();
            string filesList = string.Empty;

            Web.SaveFiles(Convert.ToInt32(SystemObjects.Messages), contactmessage.ContactMessageID, repositryKey);
            showDuplicateWarning = true;
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
        return showDuplicateWarning;
    }
        
}