﻿using System;
using System.Web.UI.WebControls;
using CodenameRabbitFoot.BusinessLogic;
using System.Data;
using System.Text;
using Telerik.Web.UI;

public partial class MailBox_Send : System.Web.UI.Page
{
    public static bool ShowPreviousMessage = false;
    public string ClientTypeName = "Vendors";
    protected void Page_Load(object sender, EventArgs e)
    { 
            if (Request["Action"] != null && Request["Action"].ToString().ToLower() == "toallcontacts")
            {
                //this.Master.HeadingIcon = "~/Images/PageIcons/messageworld.png";
            }
            else
            {
                //this.Master.HeadingIcon = "~/Images/PageIcons/message.png";
            }

            if (!Web.IsMemberSession)
                Web.Redirect("../index.aspx?ReturnUrl=~/Contacts/MessageToSelected.aspx" + Request.Url.Query);
            if (!IsPostBack)
            {
                LoadData();
            }

            txtVideoLink.Attributes.Add("onkeyup", "return GetMetaData();");

            //  this.Master.HideLinkApps();
 
    }

    private void LoadData()
    {
        multiMessagesView.ActiveViewIndex = 0;
        ShowPreviousMessage = false;
        if (Request["Action"] != null)
        {
            if (Request["Action"].ToString().ToLower() == "messagetoselected")
            {
                multiMessagesView.ActiveViewIndex = 0;
               // RadTabStrip1.Tabs[0].Selected = true;
                RadMultiPage1.SelectedIndex = 0;
                populateItems();
                populateLots();
                populateMembers();
            }
            else if (Request["Action"].ToString().ToLower() == "toall" || Request["Action"].ToString().ToLower() == "toallcontacts" || Request["Action"].ToString().ToLower() == "toallvendors" || Request["Action"].ToString().ToLower() == "toallclients")
            {
                if (Request["Action"].ToString().ToLower() == "toallcontacts")
                {
                    RadTabStrip1.Tabs[0].Visible = false;
                    populateItems();
                    populateLots();
                }
                else if (Request["Action"].ToString().ToLower() == "toallvendors")
                {
                    if (Contacts.CheckIfHasContacts(ContactTypes.Vendor, Web.SessionMembers.MemberID))
                    {
                        populateItems();
                        populateLots();
                        RadTabStrip1.Tabs[0].Visible = false;
                        RadTabStrip1.Tabs[1].Visible = false;
                    }
                    else
                        multiMessagesView.ActiveViewIndex = 1;
                }
                else if (Request["Action"].ToString().ToLower() == "toallclients")
                {
                    if (Contacts.CheckIfHasContacts(ContactTypes.Client, Web.SessionMembers.MemberID))
                    {
                        populateItems();
                        populateLots();
                        RadTabStrip1.Tabs[0].Visible = false;
                        RadTabStrip1.Tabs[1].Visible = false;
                    }
                    else
                        multiMessagesView.ActiveViewIndex = 1;
                }
                else
                    multiMessagesView.ActiveViewIndex = 1;
            }
            else
            {
                try
                {
                    var tomember = new Members();
                    if (Request["Action"].ToString().ToLower() == "messagetoone")
                    {
                        var profileClass = "Unknown";
                        if (Web.IsMemberSession)
                            profileClass = Web.GetProfileClass(Web.RecordID, Web.SessionMembers.MemberID);
                        else
                            profileClass = Web.GetProfileClass(Web.RecordID, null);

                        if (Web.SessionMembers.MemberID == Web.RecordID)
                        {
                            this.Master.ShowMessage("You cannot post a message to yourself.", "");
                            multiMessagesView.ActiveViewIndex = 2;
                            //this.Master.PageHeading = "Post New Message";
                        }
                        else
                        {
                            Contacts contact = new Contacts();
                            contact.Where.ContactMemberID.Value = Web.RecordID;
                            contact.Where.MemberID.Value = Web.SessionMembers.MemberID;
                            contact.Query.Load();
                            if (contact.RowCount <= 0)
                                multiMessagesView.ActiveViewIndex = 1;

                            tomember.LoadByPrimaryKey(Web.RecordID);
                            ClientTypeName = tomember.FullName;
                            //this.Master.PageHeading = "Post Message to <span class=\"" + profileClass + "\">" + tomember.UserName + "</span>";
                        }
                    }
                    else if (Request["Action"].ToString().ToLower() == "replytomessage")
                    {
                        ContactMessages message = new ContactMessages();
                        message.LoadByPrimaryKey(Web.RecordID);
                        if (message.To == Web.SessionMembers.MemberID)
                        {
                            tomember.LoadByPrimaryKey(message.From);
                            //this.Master.PageHeading = "Post Message to " + tomember.UserName;
                            LoadMessages(message);
                        }
                        else
                        {
                            Web.SessionMembers = null;
                            Web.IsMemberSession = false;
                            Web.IsAdminSession = false;
                            System.Web.Security.FormsAuthentication.SignOut();

                            if (!Web.IsSecuritySession)
                            {
                                Session.RemoveAll();
                                Session.Abandon();
                            }
                            else
                            {
                                Session.RemoveAll();
                                Web.IsSecuritySession = true;
                            }

                            if (Response.Cookies["loginCookie"] != null)
                            {
                                System.Web.HttpCookie eofferCookie = Request.Cookies.Get("loginCookie");
                                eofferCookie.Values.Set("login", eofferCookie.Values["login"]);
                                eofferCookie.Values.Set("rememberMe", eofferCookie.Values["rememberMe"]);
                                eofferCookie.Values.Set("password", "");
                                eofferCookie.Values.Set("keepLoggedIn", "False");
                                eofferCookie.Expires = DateTime.Now.AddDays(-1); //DateTime.Now.AddHours(12);
                                System.Web.HttpContext.Current.Response.Cookies.Add(eofferCookie);
                            }
                            Web.Redirect("~/index.aspx?ReturnURL=" + Request.Url.Query);
                        }
                    }
                } 
                catch (Exception exp)
                {
                    Web.LogError(exp);
                }

                RadTabStrip1.Tabs[2].Selected = true;
                RadMultiPage1.SelectedIndex = 1;
                RadTabStrip1.Tabs[0].Visible = false;
                RadTabStrip1.Tabs[1].Visible = false;
                RadPageView1.Visible = false;

                populateItems();
                populateLots();
            }
        }
    }

    private void LoadMessages(ContactMessages message)
    {
        try
        {
            if (!String.IsNullOrEmpty(message.s_ThreadID))
            {
                DataTable dt = ContactMessages.LoadMessages(Web.SessionMembers.MemberID, message.From, message.ThreadID);
                if (dt.Rows.Count > 0)
                {
                    rptMessages.DataSource = dt;
                    rptMessages.DataBind();
                    ShowPreviousMessage = true;
                }
                else
                    ShowPreviousMessage = false;
            }
            else
            {
                rptMessages.DataSource = ContactMessages.LoadMessageDetails(message.ContactMessageID);
                rptMessages.DataBind();
                ShowPreviousMessage = true;
            }
        }
        catch (Exception ex) { Web.LogError(ex); }
    }

    private void getName()
    {
        try
        {
            if (Web.RecordID > 0)
            {
                var member = new Members();
                member.Query.AddResultColumn(MembersSchema.UserName);
                member.Where.MemberID.Value = Web.RecordID;
                member.Query.Load();
                if (member.RowCount > 0)
                {
                    //this.Master.PageHeading = "Post Message To:&nbsp;" + member.UserName;
                }
            }
        }
        catch (Exception exp)
        {

            //Log.Write("error:", exp.GetBaseException().ToString(), exp);
            Web.LogError(exp);
        }
    }

    private void populateLots()
    {
        try
        {
            Lots lots = new Lots();
            lots.Query.AddResultColumn(LotsSchema.LotID);
            lots.Query.AddResultColumn(LotsSchema.LotName);
            lots.Where.MemberID.Value = Web.SessionMembers.MemberID;
            lots.Where.LotEndDate.Value = DateTime.Now;
            lots.Where.LotEndDate.Operator = NCI.EasyObjects.WhereParameter.Operand.GreaterThanOrEqual;
            lots.Where.IsActive.Value = 1;
            lots.Where.StatusCode.Value = 100;
            lots.Where.IsPrivate.Value = 0;
            lots.Query.AddOrderBy(LotsSchema.LotName);
            lots.Query.Load();
            if (lots.RowCount > 0)
            {
                dlLots.DataSource = lots.DefaultView;
                dlLots.DataBind();
                RadTabStrip1.SelectedIndex = 2;
                RadMultiPage1.SelectedIndex = 1;
            }
            else
            {
                RadTabStrip1.Tabs[1].Visible = false;
                RadTabStrip1.Tabs[2].Visible = false;
            }

            if (RadTabStrip1.Tabs[0].Visible == false && RadTabStrip1.Tabs[2].Visible == false && RadTabStrip1.Tabs[4].Visible == false)
                pnlAdditionalOptions.Visible = false;
        }
        catch (Exception exp)
        {
            Web.LogError(exp);
        }
    }
    private void populateItems()
    {
        try
        {
            Items items = new Items();
            items.Query.AddResultColumn(ItemsSchema.ItemID);
            items.Query.AddResultColumn(ItemsSchema.ItemName);
            items.Where.MemberID.Value = Web.SessionMembers.MemberID;
            items.Where.ItemEndDate.Value = DateTime.Now;
            items.Where.ItemEndDate.Operator = NCI.EasyObjects.WhereParameter.Operand.GreaterThanOrEqual;
            items.Where.IsActive.Value = 1;
            items.Where.StatusCode.Value = 100;
            items.Where.IsPrivate.Value = 0;
            items.Query.Load();
            items.Query.AddOrderBy(ItemsSchema.ItemName);
            if (items.RowCount > 0)
            {
                dlItems.DataSource = items.DefaultView;
                dlItems.DataBind();
                RadTabStrip1.SelectedIndex = 4;
                RadMultiPage1.SelectedIndex = 2;
            }
            else
            {
                RadTabStrip1.Tabs[3].Visible = false;
                RadTabStrip1.Tabs[4].Visible = false;
            }

            if (RadTabStrip1.Tabs[0].Visible == false && RadTabStrip1.Tabs[2].Visible == false && RadTabStrip1.Tabs[4].Visible == false)
                pnlAdditionalOptions.Visible = false;
        }
        catch (Exception exp)
        {
            Web.LogError(exp);
        }
    }
    private void populateMembers()
    {
        try
        {
            int type = Convert.ToInt32(Request["Type"].ToString());
            DataTable dt = new DataTable();
            dt = Contacts.GetSharedContacts(Web.SessionMembers.MemberID, ((type == 1) ? ContactTypes.Client : ContactTypes.Vendor), ContactView.ApprovedContacts);
            DataView dv = new DataView(dt);
            dv.Sort = "UserName asc";
            if (dt.Rows.Count > 0)
            {
                dlMembers.DataSource = dv.ToTable();
                dlMembers.DataBind();
                multiMessagesView.ActiveViewIndex = 0;
                RadTabStrip1.SelectedIndex = 0;
                RadMultiPage1.SelectedIndex = 0;
            }
            else
            {
                RadTabStrip1.Tabs[0].Visible = false;
                RadTabStrip1.Tabs[1].Visible = false;
                multiMessagesView.ActiveViewIndex = 1;
            }
            if (RadTabStrip1.Tabs[0].Visible == false && RadTabStrip1.Tabs[2].Visible == false && RadTabStrip1.Tabs[4].Visible == false)
                pnlAdditionalOptions.Visible = false;
        }
        catch (Exception exp)
        {
            Web.LogError(exp);
        }
    }
    protected void dlMembers_ItemDataBound(object sender, DataListItemEventArgs e)
    {
        try
        {
            if (e.Item.ItemType == ListItemType.Item ||
                e.Item.ItemType == ListItemType.AlternatingItem)
            {
                int ContactStatusID = Convert.ToInt32(dlMembers.DataKeys[e.Item.ItemIndex].ToString());
                HiddenField hfMemberStatusID = e.Item.FindControl("hfMemberStatusID") as HiddenField;
                HiddenField hfMemberID = e.Item.FindControl("hfMemberID") as HiddenField;
                CheckBox chkSelect = e.Item.FindControl("chkSelect") as CheckBox;
                HyperLink lnkViewContact = e.Item.FindControl("lnkViewContact") as HyperLink;
                Label lblStatus = e.Item.FindControl("lblStatus") as Label;

                if (hfMemberID.Value == Web.SessionMembers.s_MemberID)
                    lnkViewContact.CssClass = "Unknown";
                else
                {
                    if (Request["Type"].ToString() == "2")
                        lnkViewContact.CssClass = "Vendors";
                    else
                        lnkViewContact.CssClass = "Clients";
                }

                if (hfMemberStatusID != null && chkSelect != null && lnkViewContact != null)
                {
                    if (hfMemberStatusID.Value == "200")
                    {
                        if (ContactStatusID == 1)
                            chkSelect.Visible = true;
                        else if (ContactStatusID == 2)
                        {
                            chkSelect.Visible = false;
                            lnkViewContact.CssClass = "Unknown";
                            if (lblStatus != null)
                                lblStatus.Visible = true;
                        }
                    }
                    else
                    {
                        chkSelect.Visible = false;
                        lnkViewContact.CssClass = "Unknown";
                        if (lblStatus != null)
                            lblStatus.Visible = true;
                    }
                }
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }
    protected void btnPost_Click(object sender, EventArgs e)
    {

        bool showDuplicateWarning = false;  //show warning if message is duplicate
        bool isChecked = false;
        try
        {
            if (Request["Action"] != null)
            {
                //this.Master.ShowMessage("Please wait while loading...","");
                string Message = Server.HtmlEncode(txtMessage.Value) + AddSelectedLotsnItemsActivity();
                //if (string.IsNullOrEmpty(Message))
                //{
                //    Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "SCRP56789T", "ShowMessageBox('Validation Error', 'Please add some comments to post', '');",true);
                //    return;
                //}
                int groupID = ContactMessages.GetNextGroupID();
                int threadID = ContactMessages.GetNextThreadID();

                Response.Write(Message + "..." + groupID + "..." + threadID);

                if (Request["Action"].ToString().ToLower() == "messagetoselected")
                {
                    isChecked = true;
                    showDuplicateWarning = MessageToSelected(Message, groupID, threadID, ref isChecked);
                }
                else if (Request["Action"].ToString().ToLower() == "messagetoone")
                {
                    isChecked = true;
                    showDuplicateWarning = MessageToOne(Message, groupID, threadID);
                }
                else if (Request["Action"].ToString().ToLower() == "replytomessage")
                {
                    isChecked = true;
                    ReplyToMessage(Message, groupID, threadID);
                }
                else
                {
                    MessageToAll(Request.QueryString["Action"], Message, groupID, threadID);
                    isChecked = true;
                }
            }
        }
        catch (Exception exp)
        {
            Web.LogError(exp);
        }
        finally
        {
            
                if (showDuplicateWarning)
                {
                    this.Master.ShowMessage("You have already sent this message.", "");
                    LoadData();
                }
                else
                {
                    if (!isChecked)
                    {
                        this.Master.ShowMessage("Please select a contact first", "");
                        LoadData();
                    }
                    else
                    {
                        if (Request["Action"].ToString().ToLower() == "toallcontacts")
                            Session["TabIndex"] = 0;
                        else if (Request["Action"].ToString().ToLower() == "toallvendors")
                            Session["TabIndex"] = 4;
                        else if (Request["Action"].ToString().ToLower() == "toallclients")
                            Session["TabIndex"] = 6;
                        else
                            Session["TabIndex"] = 14;
                        Web.Redirect("~/Live.aspx");
                    }
                }
            
        }
    }

    private void ReplyToMessage(string Message, int groupID, int threadID)
    {
        try
        {
            int ContactMessageID = Web.RecordID;

            ContactMessages message = new ContactMessages();
            message.LoadByPrimaryKey(ContactMessageID);
            if (message.RowCount > 0)
            {
                ContactMessages contactmessage = new ContactMessages();
                contactmessage.AddNew();
                contactmessage.From = message.To;
                contactmessage.To = message.From;
                contactmessage.Message = Message;
                contactmessage.MessageDate = System.DateTime.Now;
                contactmessage.IsRead = 0;
                contactmessage.IsPrivate = 1;
                if (!String.IsNullOrEmpty(message.s_GroupID))
                    contactmessage.GroupID = message.GroupID;
                contactmessage.SystemObjectID = (int)SystemObjects.Messages;
                contactmessage.ThreadID = (!String.IsNullOrEmpty(message.s_ThreadID)) ? message.ThreadID : threadID;
                contactmessage.Save();

                message.IsReplied = 1;
                message.MessageReplyID = contactmessage.ContactMessageID;
                message.Save();

                SaveFiles(ref contactmessage);

                Members tomember = new Members();
                tomember.LoadByPrimaryKey(message.From);
                var templateKeys = new System.Collections.Specialized.StringDictionary();
                templateKeys.Add("#viewlink#", "LiveFeed.aspx?Action=Message&RecordID=#encrypt#" + contactmessage.ContactMessageID + "#endencrypt#");
                templateKeys.Add("#initiatedto#", "#memberid#" + tomember.MemberID + "#endmemberid#");
                templateKeys.Add("#profileclass#", "#profileclass#" + contactmessage.To + "#endprofileclass#");
                templateKeys.Add("#initiatedtoprofile#", "/Contacts/ViewProfile.aspx?Action=ViewDealer&RecordID=#encrypt#" + tomember.MemberID + "#endencrypt#");
                Web.AddPrivateActivityLog(19, templateKeys, tomember.MemberID, contactmessage.ContactMessageID, contactmessage.To);
                MemberActivityLog.UpdateActivityTime(message.From, Web.SessionMembers.MemberID, message.ContactMessageID);

                templateKeys = new System.Collections.Specialized.StringDictionary();
                templateKeys.Add("#email_header#", Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER"));
                templateKeys.Add("#message#", Web.ParseTemplate(contactmessage.Message));
                templateKeys.Add("#company_sender#", Web.SessionMembers.CompanyName);
                templateKeys.Add("#fullname_sender#", Web.SessionMembers.FullName);
                templateKeys.Add("#public_profile_sender#", Web.SessionMembers.UserName);
                templateKeys.Add("#fullname#", tomember.FullName);
                templateKeys.Add("#reply_link_on_contact_module#", Web.SystemConfigs.GetKey("SITE_URL") + "Contacts/MessageToSelected.aspx?Action=replytomessage&RecordID=" + Secure.Encrypt(contactmessage.ContactMessageID));
                templateKeys.Add("#link_log_myeoffer#", Web.SystemConfigs.GetKey("SITE_URL") + "index.aspx");
                templateKeys.Add("#email_footer#", Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER"));
                Web.SendMail(tomember.Email, Web.SystemConfigs.GetKey("ALERTS_EMAIL"), 404, templateKeys);
            }
            else
            {
                ContactMessages contactmessage = new ContactMessages();
                contactmessage.AddNew();
                contactmessage.From = Web.SessionMembers.MemberID;
                contactmessage.To = Web.RecordID;
                contactmessage.Message = Message;
                contactmessage.MessageDate = System.DateTime.Now;
                contactmessage.IsRead = 0;
                contactmessage.IsPrivate = 1;
                if (!String.IsNullOrEmpty(contactmessage.s_GroupID))
                    contactmessage.GroupID = groupID;
                contactmessage.SystemObjectID = (int)SystemObjects.Messages;
                contactmessage.ThreadID = threadID;
                contactmessage.Save();

                SaveFiles(ref contactmessage);

                Members tomember = new Members();
                tomember.LoadByPrimaryKey(Web.RecordID);
                var templateKeys = new System.Collections.Specialized.StringDictionary();
                templateKeys.Add("#viewlink#", "LiveFeed.aspx?Action=Message&RecordID=#encrypt#" + contactmessage.ContactMessageID + "#endencrypt#");
                templateKeys.Add("#initiatedto#", "#memberid#" + tomember.MemberID + "#endmemberid#");
                templateKeys.Add("#profileclass#", "#profileclass#" + contactmessage.To + "#endprofileclass#");
                templateKeys.Add("#initiatedtoprofile#", "/Contacts/ViewProfile.aspx?Action=ViewDealer&RecordID=#encrypt#" + tomember.MemberID + "#endencrypt#");
                Web.AddPrivateActivityLog(4, templateKeys, tomember.MemberID, contactmessage.ContactMessageID, tomember.MemberID);

                templateKeys = new System.Collections.Specialized.StringDictionary();
                templateKeys.Add("#email_header#", Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER"));
                templateKeys.Add("#message#", Web.ParseTemplate(contactmessage.Message));
                templateKeys.Add("#company_sender#", Web.SessionMembers.CompanyName);
                templateKeys.Add("#fullname_sender#", Web.SessionMembers.FullName);
                templateKeys.Add("#public_profile_sender#", Web.SessionMembers.UserName);
                templateKeys.Add("#fullname#", tomember.FullName);
                templateKeys.Add("#reply_link_on_contact_module#", Web.SystemConfigs.GetKey("SITE_URL") + "Contacts/MessageToSelected.aspx?Action=replytomessage&RecordID=" + Secure.Encrypt(contactmessage.ContactMessageID));
                templateKeys.Add("#link_log_myeoffer#", Web.SystemConfigs.GetKey("SITE_URL") + "index.aspx");
                templateKeys.Add("#email_footer#", Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER"));
                Web.SendMail(tomember.Email, Web.SystemConfigs.GetKey("ALERTS_EMAIL"), 404, templateKeys);
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }
    private bool MessageToOne(string Message, int groupID, int threadID)
    {
        bool showDuplicateWarning = false;
        try
        {
            Members tomember = new Members();
            tomember.LoadByPrimaryKey(Web.RecordID);

            if (!ContactMessages.CheckIfDuplicate(Message, Web.RecordID, Web.SessionMembers.MemberID))
            {
                ContactMessages contactmessage = new ContactMessages();
                contactmessage.AddNew();
                contactmessage.From = Web.SessionMembers.MemberID;
                contactmessage.To = Web.RecordID;
                contactmessage.Message = Message;
                contactmessage.MessageDate = DateTime.Now;
                contactmessage.IsRead = 0;
                contactmessage.IsPrivate = 1;
                contactmessage.SystemObjectID = (int)SystemObjects.Messages;
                contactmessage.ThreadID = threadID;
                contactmessage.Save();

                //Code modified by Irfan Dayan. 15-07-2011.
                Web.SaveFiles(Convert.ToInt32(SystemObjects.Messages), contactmessage.ContactMessageID, fupPhoto, fupDocument, txtLink, txtURL, 6);
                //Code modified by Irfan Dayan ends here. 15-07-2011.


                var templateKeys = new System.Collections.Specialized.StringDictionary();
                templateKeys.Add("#viewlink#", "LiveFeed.aspx?Action=Message&RecordID=" + Secure.Encrypt(contactmessage.ContactMessageID));
                templateKeys.Add("#initiatedto#", "#memberid#" + contactmessage.To + "#endmemberid#");
                templateKeys.Add("#profileclass#", "#profileclass#" + contactmessage.To + "#endprofileclass#");
                templateKeys.Add("#initiatedtoprofile#", "/Contacts/ViewProfile.aspx?Action=ViewDealer&RecordID=#encrypt#" + contactmessage.To + "#endencrypt#");
                Web.AddPrivateActivityLog(4, templateKeys, contactmessage.To, contactmessage.ContactMessageID, contactmessage.To);

                templateKeys = new System.Collections.Specialized.StringDictionary();
                templateKeys.Add("#email_header#", Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER"));
                templateKeys.Add("#message#", Web.ParseTemplate(contactmessage.Message));
                templateKeys.Add("#company_sender#", Web.SessionMembers.CompanyName);
                templateKeys.Add("#fullname_sender#", Web.SessionMembers.FullName);
                templateKeys.Add("#public_profile_sender#", Web.SessionMembers.UserName);
                templateKeys.Add("#fullname#", tomember.FullName);
                templateKeys.Add("#reply_link_on_contact_module#", Web.SystemConfigs.GetKey("SITE_URL") + "Contacts/MessageToSelected.aspx?Action=replytomessage&RecordID=" + Secure.Encrypt(contactmessage.ContactMessageID));
                templateKeys.Add("#link_log_myeoffer#", Web.SystemConfigs.GetKey("SITE_URL") + "index.aspx");
                templateKeys.Add("#email_footer#", Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER"));
                Web.SendMail(tomember.Email, Web.SystemConfigs.GetKey("ALERTS_EMAIL"), 404, templateKeys);
            }
            else showDuplicateWarning = true;
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
        return showDuplicateWarning;
    }
    private bool MessageToSelected(string Message, int groupID, int threadID, ref bool isChecked)
    {
        bool showDuplicateWarning = false;
        try
        {

            var templateKeys = new System.Collections.Specialized.StringDictionary();
            int MessageID = 0;

            if (chkSelectAll.Checked)
            {
                string action = (Request["Type"].ToString() == "1") ? "toallclients" : "toallvendors";
                isChecked = true;
                MessageToAll(action, Message, groupID, threadID);
            }
            else
            {
                foreach (DataListItem item in dlMembers.Items)
                {
                    HiddenField hfMemberID = item.FindControl("hfMemberID") as HiddenField;
                    CheckBox chkSelect = item.FindControl("chkSelectMember") as CheckBox;
                    if (chkSelect.Checked == true)
                    {
                        isChecked = true;
                        int MemberID = Convert.ToInt32(hfMemberID.Value);

                        if (!ContactMessages.CheckIfDuplicate(Message, MemberID, Web.SessionMembers.MemberID))
                        {
                            Members tomember = new Members();
                            tomember.LoadByPrimaryKey(MemberID);

                            ContactMessages contactmessage = new ContactMessages();
                            contactmessage.AddNew();
                            contactmessage.From = Web.SessionMembers.MemberID;
                            contactmessage.To = MemberID;
                            contactmessage.Message = Message;
                            contactmessage.MessageDate = System.DateTime.Now;
                            contactmessage.IsRead = 0;
                            contactmessage.IsPrivate = 1;
                            contactmessage.GroupID = groupID;
                            contactmessage.SystemObjectID = (int)SystemObjects.Messages;
                            contactmessage.ThreadID = threadID;
                            contactmessage.Save();

                            SaveFiles(ref contactmessage);

                            templateKeys = new System.Collections.Specialized.StringDictionary();
                            templateKeys.Add("#initiatedto#", "#memberid#" + contactmessage.To + "#endmemberid#");
                            templateKeys.Add("#profileclass#", "#profileclass#" + contactmessage.To + "#endprofileclass#");
                            templateKeys.Add("#initiatedtoprofile#",
                                             "/Contacts/ViewProfile.aspx?Action=ViewDealer&RecordID=#encrypt#" +
                                             contactmessage.To + "#endencrypt#");
                            Web.AddPrivateActivityLog(4, templateKeys, contactmessage.To,
                                                      contactmessage.ContactMessageID, contactmessage.To);

                            templateKeys = new System.Collections.Specialized.StringDictionary();
                            templateKeys.Add("#email_header#", Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER"));
                            templateKeys.Add("#message#", Web.ParseTemplate(contactmessage.Message));
                            templateKeys.Add("#company_sender#", Web.SessionMembers.CompanyName);
                            templateKeys.Add("#fullname_sender#", Web.SessionMembers.FullName);
                            templateKeys.Add("#public_profile_sender#", Web.SessionMembers.UserName);
                            templateKeys.Add("#fullname#", tomember.FullName);
                            templateKeys.Add("#reply_link_on_contact_module#",
                                             Web.SystemConfigs.GetKey("SITE_URL") +
                                             "Contacts/MessageToSelected.aspx?Action=replytomessage&RecordID=" +
                                             Secure.Encrypt(contactmessage.ContactMessageID));
                            templateKeys.Add("#link_log_myeoffer#",
                                             Web.SystemConfigs.GetKey("SITE_URL") + "index.aspx");
                            templateKeys.Add("#email_footer#", Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER"));
                            Web.SendMail(tomember.Email, Web.SystemConfigs.GetKey("ALERTS_EMAIL"), 404,
                                         templateKeys);
                        }
                        else showDuplicateWarning = true;
                    }
                }
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
        return showDuplicateWarning;
    }
    private void MessageToAll(string action, string Message, int GroupID, int ThreadID)
    {
        try
        {
            int MessageID = 0, TemplateID = 13;
            System.Collections.Specialized.StringDictionary templateKeys = new System.Collections.Specialized.StringDictionary();
            int from = Web.SessionMembers.MemberID;

            if (action != "toallcontacts")
                TemplateID = (action == "toallvendors") ? 37 : 38;

            if (action != "toallcontacts")
            {
                Contacts contact = new Contacts();
                contact.Query.AddResultColumn(ContactsSchema.ContactMemberID);
                contact.Where.ContactMemberID.Operator = NCI.EasyObjects.WhereParameter.Operand.IsNotNull;
                contact.Where.MemberID.Value = from;
                contact.Where.ContactType.Value = (action == "toallvendors") ? "2,3" : "1,3";
                contact.Where.ContactType.Operator = NCI.EasyObjects.WhereParameter.Operand.In;
                contact.Where.ContactStatusID.Value = 1;
                contact.Query.Load();

                if (contact.RowCount > 0)
                {
                    bool done = false;
                    do
                    {
                        Members member = new Members();
                        member.LoadByPrimaryKey(contact.ContactMemberID);

                        if (!ContactMessages.CheckIfDuplicate(Message, member.MemberID, Web.SessionMembers.MemberID))
                        {
                            ContactMessages contactmessage = new ContactMessages();
                            contactmessage.AddNew();
                            contactmessage.From = from;
                            contactmessage.To = contact.ContactMemberID;
                            contactmessage.Message = Message;
                            contactmessage.MessageDate = System.DateTime.Now;
                            contactmessage.IsRead = 0;
                            contactmessage.IsPrivate = 1;
                            contactmessage.GroupID = GroupID;
                            contactmessage.SystemObjectID = (int)SystemObjects.Messages;
                            contactmessage.ThreadID = ThreadID;
                            contactmessage.Save();

                            if (MessageID == 0)
                                MessageID = contactmessage.ContactMessageID;

                            SaveFiles(ref contactmessage);
                            done = true;
                        }
                    } while (contact.MoveNext());

                    if (done)
                    {
                        templateKeys = new System.Collections.Specialized.StringDictionary();
                        templateKeys.Add("#message#", Message);
                        Web.AddActivityLog(TemplateID, templateKeys, MessageID);
                    }
                    else
                        this.Master.ShowMessage("You have already sent this message.", "");
                }
                else
                    multiMessagesView.ActiveViewIndex = 1;
            }
            else
            {
                Members members = new Members();
                members.Query.AddResultColumn(MembersSchema.MemberID);
                members.Query.AddResultColumn(MembersSchema.Email);
                members.Query.AddResultColumn(MembersSchema.FullName);
                members.Where.MemberStatusID.Value = 200;
                members.Where.IsPrivate.Value = 0;
                members.Query.Load();

                if (members.RowCount > 0)
                {
                    bool done = false;
                    do
                    {
                        if (!ContactMessages.CheckIfDuplicate(Message, members.MemberID, Web.SessionMembers.MemberID))
                        {
                            ContactMessages contactmessage = new ContactMessages();
                            contactmessage.AddNew();
                            contactmessage.From = from;
                            contactmessage.To = members.MemberID;
                            contactmessage.Message = Message;
                            contactmessage.MessageDate = System.DateTime.Now;
                            contactmessage.IsRead = 0;
                            contactmessage.IsPrivate = 1;
                            contactmessage.GroupID = GroupID;
                            contactmessage.SystemObjectID = (int)SystemObjects.Messages;
                            contactmessage.ThreadID = ThreadID;
                            contactmessage.Save();

                            if (MessageID == 0)
                                MessageID = contactmessage.ContactMessageID;

                            SaveFiles(ref contactmessage);
                            done = true;
                        }
                    } while (members.MoveNext());

                    if (done)
                    {
                        templateKeys = new System.Collections.Specialized.StringDictionary();
                        templateKeys.Add("#message#", Message);
                        Web.AddActivityLog(13, templateKeys, MessageID);
                    }
                    else
                        this.Master.ShowMessage("You have already sent this message.", "");
                }
                else
                    multiMessagesView.ActiveViewIndex = 1;
            }
        }
        catch (Exception exp)
        {
            multiMessagesView.ActiveViewIndex = 1;
            Web.LogError(exp);
        }
    }

    private void SaveFiles(ref ContactMessages contactmessage)
    {
        try
        {
            if (fupPhoto.UploadedFiles.Count > 0)
            {
                foreach (UploadedFile file in fupPhoto.UploadedFiles)
                {
                    SystemObjectFiles objfile = new SystemObjectFiles();
                    objfile.AddNew();
                    objfile.FileDate = DateTime.Now;
                    objfile.FileTypeID = (int)FileTypes.Photo;
                    objfile.s_IsActive = "1";
                    objfile.ObjectID = contactmessage.ContactMessageID;
                    objfile.SystemObjectID = (int)SystemObjects.Messages;
                    objfile.RemoteIP = Request.UserHostAddress;
                    objfile.FileFormat = file.ContentType;
                    objfile.FileContents = Web.UploadImage(file);
                    objfile.Save();
                }
            }
            if (fupDocument.UploadedFiles.Count > 0)
            {
                foreach (UploadedFile file in fupDocument.UploadedFiles)
                {
                    SystemObjectFiles objfile = new SystemObjectFiles();
                    objfile.AddNew();
                    objfile.FileDate = DateTime.Now;
                    objfile.FileTypeID = (int)FileTypes.Document;
                    objfile.s_IsActive = "1";
                    objfile.ObjectID = contactmessage.ContactMessageID;
                    objfile.SystemObjectID = (int)SystemObjects.Messages;
                    objfile.RemoteIP = Request.UserHostAddress;
                    objfile.FileFormat = file.GetExtension();
                    objfile.FileContents = Web.UploadImage(file);
                    objfile.Save();
                }
            }
            if (!String.IsNullOrEmpty(txtLink.Text))
            {
                string URL = txtLink.Text;
                if (txtLink.Text.Contains("http://"))
                    URL = txtLink.Text;
                else
                    URL = "http://" + txtLink.Text;
                SystemObjectFiles file = new SystemObjectFiles();
                file.AddNew();
                file.FileDate = DateTime.Now;
                file.FileTypeID = (int)FileTypes.Link;
                file.s_IsActive = "1";
                file.ObjectID = contactmessage.ContactMessageID;
                file.SystemObjectID = (int)SystemObjects.Messages;
                file.RemoteIP = Request.UserHostAddress;
                file.URL = URL;
                file.Save();
            }
            if (!String.IsNullOrEmpty(txtVideoLink.Text))
            {
                string videoLink = txtVideoLink.Text;
                //RegEx to Find YouTube ID
                System.Text.RegularExpressions.Match regexMatch = System.Text.RegularExpressions.Regex.Match(videoLink, "^[^v]+v=(.{11}).*",
                                   System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                if (regexMatch.Success)
                    videoLink = "http://www.youtube.com/v/" + regexMatch.Groups[1].Value;

                SystemObjectFiles file = new SystemObjectFiles();
                file.AddNew();
                file.FileDate = DateTime.Now;
                file.FileTypeID = (int)FileTypes.Video;
                file.s_IsActive = "1";
                file.ObjectID = contactmessage.ContactMessageID;
                file.SystemObjectID = (int)SystemObjects.Messages;
                file.RemoteIP = Request.UserHostAddress;
                file.URL = videoLink;
                file.Save();
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }

    private string AddSelectedLotsnItemsActivity()
    {
        System.Text.StringBuilder sb = new System.Text.StringBuilder();
        try
        {
            int count = 0;
            foreach (DataListItem item in dlLots.Items)
            {
                HiddenField hfLotID = item.FindControl("hfLotID") as HiddenField;
                HiddenField hfLotName = item.FindControl("hfLotName") as HiddenField;
                CheckBox chkSelect = item.FindControl("chkSelect") as CheckBox;
                if (chkSelect.Checked == true)
                {
                    if (count == 0)
                    {
                        sb.Append("<div style=\"margin-top:3px;width:400px;\"><a href=\"");
                        sb.Append("/Contacts/ViewProfile.aspx?Action=ViewDealer&RecordID=#encrypt#" + Web.SessionMembers.MemberID + "#endencrypt#");
                        sb.Append("\">" + Web.SessionMembers.UserName + "</a> wants to sell,");
                        sb.Append("</div>");
                    }

                    Lots lot = new Lots();
                    lot.LoadByPrimaryKey(Convert.ToInt32(hfLotID.Value));
                    if (lot.RowCount > 0)
                    {
                        LotItems items = new LotItems();
                        items.Where.LotID.Value = lot.LotID;
                        if (items.Query.Load())
                        {
                            sb.Append("<table width=\"400px\">");
                            sb.Append("<tr><th align=\"left\" style=\"font-size:10px;\" width=\"50%\">Lot</th><th align=\"center\" style=\"font-size:10px;\" width=\"25%\">Quantity</th><th align=\"center\" style=\"font-size:10px;\" width=\"25%\">Price</th></tr>");
                            do
                            {
                                sb.Append("<tr><td align=\"left\"><span style=\" font-size: 10px; font-weight:normal;\"><a runat=\"server\" href=\"#site_url#/MarketPlace/ItemDetails.aspx?Action=View&RecordID=#encrypt#" + lot.LotID + "#endencrypt#\">" + items.s_ItemName + "</a></span></td><td align=\"center\"><span style=\" font-size: 10px; font-weight:normal;\">" + items.s_Quantity + "</span></td><td align=\"center\"><span style=\" font-size: 10px; font-weight:normal;\">" + Web.GetCurrencySymbol(items.s_CurrencyID) + items.s_ItemPrice + "</span></td></tr> ");
                            } while (items.MoveNext());
                            sb.Append("</table>");
                        }
                    }
                    if (count == 0)
                        sb.Append("<div id=\"break\"></div>");
                    count++;
                }
            }
            foreach (DataListItem item in dlItems.Items)
            {
                int innercount = 0;
                HiddenField hfItemID = item.FindControl("hfItemID") as HiddenField;
                HiddenField hfItemName = item.FindControl("hfItemName") as HiddenField;
                CheckBox chkSelect = item.FindControl("chkSelect") as CheckBox;
                if (chkSelect.Checked == true)
                {
                    if (innercount == 0)
                    {
                        sb.Append("<div style=\"margin-top:3px;width:400px;\"><a href=\"");
                        sb.Append("/Contacts/ViewProfile.aspx?Action=ViewDealer&RecordID=#encrypt#" + Web.SessionMembers.MemberID + "#endencrypt#");
                        sb.Append("\">" + Web.SessionMembers.UserName + "</a> wants to buy,");
                        sb.Append("</div>");
                        sb.Append("<table width=\"400px\">");
                    }
                    count++;
                    innercount++;

                    Items itemShared = new Items();
                    itemShared.LoadByPrimaryKey(Convert.ToInt32(hfItemID.Value));
                    if (itemShared.RowCount > 0)
                    {
                        sb.Append("<tr><th align=\"left\" style=\"font-size:10px;\" width=\"40%\">Item</th><th align=\"center\" style=\"font-size:10px;\" width=\"25%\">Quantity</th><th align=\"center\" style=\"font-size:10px;\" width=\"25%\">Price</th></tr>");
                        sb.Append("<tr>");
                        sb.Append("<td width=\"40%\" align=\"left\"><span style=\" font-size: 10px;font-weight:normal;\"><a runat=\"server\" href=\"");
                        sb.Append("#site_url#/MarketPlace/ItemDetails.aspx?Action=View&RecordID=#encrypt#");
                        sb.Append(hfItemID.Value);
                        sb.Append("#endencrypt#\">" + itemShared.ItemName);
                        sb.Append("</a></span></td><td align=\"center\" width=\"25%\"><span style=\" font-size: 10px;font-weight:normal;\">");
                        sb.Append(itemShared.s_Quantity);
                        sb.Append("</span></td><td align=\"center\" width=\"25%\"><span style=\" font-size: 10px;font-weight:normal;\">$");
                        sb.Append(itemShared.s_DesiredPrice + "</span></td></tr>");
                    }
                }
                if (innercount > 0)
                    sb.Append("</table>");
            }

            if (count <= 0)
                sb = new System.Text.StringBuilder();
        }
        catch (Exception exp)
        {
            Web.LogError(exp);
        }
        return sb.ToString();
    }
}