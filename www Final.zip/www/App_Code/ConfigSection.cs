using System;
using System.Configuration;

namespace VS.Security
{
    public class SwitchProtocolSection : ConfigurationSection
    {
        [ConfigurationProperty("urls", IsRequired = true)]
        public UrlsFormElement Urls
        {
            get
            {
                return (UrlsFormElement)base["urls"];
            }
        }
    }

    public class UrlsFormElement : ConfigurationElement
    {
        [ConfigurationProperty("baseUrl", IsRequired = true)]
        public string BaseUrl
        {
            get
            {
                return (string)base["baseUrl"];
            }
        }

        [ConfigurationProperty("baseSecureUrl", IsRequired = true)]
        public string BaseSecureUrl
        {
            get
            {
                return (string)base["baseSecureUrl"];
            }
        }
    }
}
