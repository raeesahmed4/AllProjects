using System;
using System.Collections;
using System.Collections.Specialized;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Net.Mail;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CodenameRabbitFoot.BusinessLogic;
using VisualSoft.UserManagement;
using VisualSoft.VSharp.Utils;
using System.Xml;
using System.Collections.Generic;
using Telerik.Web.UI;
using System.Xml.Linq;
using VisualSoft.SystemManagement;
using Amazon.SimpleEmail.Model;
using Amazon.SimpleEmail;
using System.Linq;
using Image = System.Drawing.Image;
using Elmah;

/// <summary>
/// Summary description for Web
/// </summary>
public partial class Web
{
    public static IEnumerable GetListingDataFromXml(string xml)
    {
        XDocument doc = XDocument.Parse(xml);
        var data = from d in doc.Root.Descendants()
                   select new
                   {
                       FieldID = d.Attribute("FieldID").Value,
                       FieldName = d.Attribute("FieldName").Value,
                       Data = d.Attribute("Data").Value
                   };
        return data.ToList();
    }

    #region Members


    private static byte[] key_192 = new byte[] 
    {10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10,
        10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10};

    private static byte[] iv_128 = new byte[]
    {10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10,
        10, 10, 10, 10};

    public static string EmailType { get; set; }
    #endregion

    /// <summary>
    /// Log application errors using WriteLog()
    /// </summary>
    /// <param name="exception"></param>
    public static void LogError(Exception exception)
    {
        try
        {
            SessionVariables.LastErrorMessage = exception.Message;

            if (System.Configuration.ConfigurationManager.AppSettings["EnableErrorLog"] == "1")
            {
                //WriteLog(Radium.Platform.Core.Categories.ErrorLog, Radium.Platform.Core.UserActivity.Default, exception);
                //Log.Write("exception err", exception.GetBaseException().ToString(), exception);


                ErrorSignal.FromCurrentContext().Raise(exception);
            }
        }
        catch (Exception) { }
    }

    /// <summary>
    /// Log the error message.
    /// </summary>
    /// <param name="exception">Error message to log.</param>
    public static void LogError(string exception)
    {
        LogError(new Exception(exception));
    }

    /// <summary>
    /// Log user activity using WriteLog()
    /// </summary>
    /// <param name="userActivityCode"></param>
    public static void LogUserActivity(Radium.Platform.Core.UserActivity userActivityCode)
    {
        WriteLog(Radium.Platform.Core.Categories.UserActivityLog, userActivityCode, null);
    }

    /// <summary>
    /// This function is used to define the Page Meta Tags in code behind for the Google Adsense Optimization.
    /// </summary>
    /// <param name="page">Page</param>
    /// <param name="MetaTagDescription">JointLoop is an on-demand and embedded solution that allows you to capture, prioritize and centrally manage customer feedback. Make your customer feedback process more efficient. Save time and involve more stakeholders without significant cost. etc.</param>
    /// <param name="MetaTagKeywords">feedback, product, product manager, product marketing etc.</param>
    public static void Metatag(Page page, string MetaTagDescription, string MetaTagKeywords)
    {
        if (!string.IsNullOrEmpty(MetaTagDescription))
        {
            System.Web.UI.HtmlControls.HtmlMeta descMetaTag = new System.Web.UI.HtmlControls.HtmlMeta();
            descMetaTag.Name = "description";
            descMetaTag.Content = MetaTagDescription;
            page.Header.Controls.Add(descMetaTag);
        }

        if (!string.IsNullOrEmpty(MetaTagKeywords))
        {
            var keywordsMetaTag = new System.Web.UI.HtmlControls.HtmlMeta();
            keywordsMetaTag.Name = "keywords";
            keywordsMetaTag.Content = MetaTagKeywords;
            page.Header.Controls.Add(keywordsMetaTag);
        }
    }

    /// <summary>
    /// Actual method to call db or file logging component
    /// </summary>
    /// <param name="logCategory"></param>
    /// <param name="logActivityCode"></param>
    /// <param name="exp"></param>
    public static void WriteLog(Radium.Platform.Core.Categories logCategory, Radium.Platform.Core.UserActivity logActivityCode, Exception exp)
    {
        try
        {
            string errorTemplate;
            string callerMethodName = string.Empty;
            // string exceptionMessage = exp != null ? exp.Message : string.Empty; ;
            string exceptionMessage = exp != null ? exp.GetBaseException().ToString() : string.Empty; ;

            if (logCategory == Radium.Platform.Core.Categories.ErrorLog)
            {
                // get calling methood name
                StackFrame stackFrame = new StackFrame(2, true);
                MethodBase methodBase = stackFrame.GetMethod();
                callerMethodName = methodBase != null ? methodBase.Name : "";

                // set error format
                errorTemplate = "{0}[{1}]:{2}";
            }
            else
            {
                // set error format
                errorTemplate = "{0}";
            }

            // get fullFileName
            string path = HttpContext.Current.Request.Url.AbsolutePath;
            int index = path.IndexOf("/");
            string fullFileName = path.Substring(index + 1);

            //System.Web.HttpContext.Current.Response.Write(logString);
            string logString = string.Format(errorTemplate, fullFileName, callerMethodName, exceptionMessage);

            string LogUserName = HttpContext.Current.Request.ServerVariables["Remote_Addr"];

            if (Web.IsMemberSession)
                LogUserName = Web.SessionMembers.FullName;

            // when logging, use the defined Access Interface?
            //Radium.Platform.Core.Log.Write(logString, logCategory, Radium.Platform.Core.Severity.Information, Radium.Platform.Core.Priority.Debug, null, LogUserName, HttpContext.Current.Session.SessionID, logActivityCode);
        }
        catch
        {
            //HttpContext.Current.Response.Write(ex.InnerException.Message);
        }
    }

    #region Session Users

    /// <summary>
    /// Returns true if subscriber's session is established
    /// </summary>
    [Obsolete("Please use Web.SessionVariables.IsSystemUserSession instead.")]
    public static bool IsSystemUserSession
    {
        get
        {
            try
            {
                return (bool)System.Web.HttpContext.Current.Session["IsSystemUserSession"];
            }
            catch
            {
                return false;
            }
        }
        set
        {
            System.Web.HttpContext.Current.Session["IsSystemUserSession"] = value;
        }
    }

    // [Obsolete("Please use Web.SessionVariables.IsMemberSession instead.")]
    public static bool IsMemberSession
    {
        get
        {
            try
            {
                return (bool)System.Web.HttpContext.Current.Session["IsMemberSession"];
            }
            catch
            {
                return false;
            }
        }
        set
        {
            System.Web.HttpContext.Current.Session["IsMemberSession"] = value;
        }
    }

    //[Obsolete("Please use Web.SessionVariables.SessionMembers instead.")]
    public static Members SessionMembers
    {
        get
        {
            try
            {
                if (System.Web.HttpContext.Current.Session["Member"] == null)
                    return null;

                return System.Web.HttpContext.Current.Session["Member"] as Members;
            }
            catch (Exception ex)
            {
                //Log.Write("err", ex.GetBaseException().ToString(), ex);
                //Web.LogError(ex);
                //System.Web.HttpContext.Current.Session["URL2Redirect"] = System.Web.HttpContext.Current.Request.Url.AbsoluteUri; 
                //HttpContext.Current.Web.Redirect("~/index.aspx");

                throw ex;
                //return null;
            }
        }
        set
        {
            System.Web.HttpContext.Current.Session["Member"] = value;
        }

    }


    /// <summary>
    /// Process subscriber signin request
    /// </summary>
    /// <param name="Login"></param>
    /// <param name="Password"></param>

    public static void SystemUserSignIn(string Login, string Password)
    {
        var environment = ConfigurationManager.AppSettings["Environment"];
        VisualSoft.UserManagement.ConnectionManager.ConnectionString = ConfigurationManager.ConnectionStrings[environment + "ConnectionString"].ConnectionString;

        try
        {
            SystemUser systemUser = SystemUserManager.Authenticate(Login, Password);
            //Member systemMember = eOffer.BusinessLogic.DataLayer.

            // store object in session for later use
            Web.SessionSystemUser = systemUser;


            // set subscriber session flag
            Web.IsSystemUserSession = true;

            //Event Logged
            //Log.Write("9999", "SystemUser " + systemUser.Login + " signed-in", null);
            //Web.LogActivity(1, "Login Success");
        }
        catch (VException vx)
        {
            //Web.LogActivity(2, "Login Failure");
            throw vx;
        }

        // set authenticate cookie using forms authentication
        // and redirect to default url specified in Web.config
        //FormsAuthentication.RedirectFromLoginPage(subscriber.FullName, false);

        //Web.LogActivity(1, "");
        // redirect to subscriber's home page

        //HttpContext.Current.Web.Redirect("Default.aspx");

    }

    [Obsolete("Please use Web.SessionVariables.IsSecuritySession instead.")]
    public static bool IsSecuritySession
    {
        get
        {
            try
            {
                if (Web.SystemConfigs.GetKey("EnableIdentityCheck").ToString() == "0")
                {
                    return true;
                }
                else
                {
                    return (bool)System.Web.HttpContext.Current.Session["IsSecuritySession"];
                }
            }
            catch
            {
                return false;
            }
        }
        set
        {
            System.Web.HttpContext.Current.Session["IsSecuritySession"] = value;
        }
    }
    /// <summary>
    /// get/set SystemUser object in session
    /// </summary>
    [Obsolete("Please use Web.SessionVariables.IsAdminSession instead.")]
    public static bool IsAdminSession
    {
        get
        {
            try
            {
                return (bool)System.Web.HttpContext.Current.Session["IsSystemUserSession"];
            }
            catch
            {
                return false;
            }
        }
        set
        {
            System.Web.HttpContext.Current.Session["IsSystemUserSession"] = value;
        }
    }

    [Obsolete("Please use Web.SessionVariables.SessionSystemUser instead.")]
    public static SystemUser SessionSystemUser
    {
        get
        {
            try
            {
                return System.Web.HttpContext.Current.Session["SystemUser"] as SystemUser;
            }
            catch (Exception ex)
            {
                //Log.Write("err", ex.GetBaseException().ToString(), ex);
                Web.LogError(ex);
                return null;
            }
        }

        set
        {
            System.Web.HttpContext.Current.Session["SystemUser"] = value;
        }
    }

    [Obsolete("Please use Web.SessionVariables.MemberModuleAccess instead.")]
    public static Hashtable MemberModuleAccess
    {
        get
        {
            try
            {
                return System.Web.HttpContext.Current.Session["MemberModuleAccess"] as Hashtable;
            }
            catch (Exception ex)
            {
                //Log.Write("err", ex.GetBaseException().ToString(), ex);
                Web.LogError(ex);
                return null;
            }
        }

        set
        {
            System.Web.HttpContext.Current.Session["MemberModuleAccess"] = value;
        }
    }
    #endregion

    /// <summary>
    /// To Fill Lookup Lists
    /// </summary>
    /// <param name="LookupData"></param>
    /// <param name="ListName"></param>
    /// <param name="TextField"></param>
    /// <param name="ValueField"></param>
    public static void FillLookUpList(DataTable LookupData, DropDownList ListName, DataColumn TextField, DataColumn ValueField)
    {
        try
        {
            ListName.DataSource = LookupData.DefaultView;
            ListName.DataTextField = TextField.ColumnName;
            ListName.DataValueField = ValueField.ColumnName;
            ListName.DataBind();
        }
        catch (VException VException)
        {
            throw VException;
        }
    }


    /// <summary>
    /// Extract RecordID in current query string
    /// </summary>    
    //[Obsolete("Please use Web.QueryStringVariables.RecordID instead.")]
    public static int RecordID
    {
        get
        {
            string recordID = string.Empty;
            try
            {
                //int recordID;
                recordID = System.Web.HttpContext.Current.Request.QueryString["RecordID"];

                if (recordID != null)
                {
                    if (recordID != null || recordID != "")
                    {
                        if (recordID.Length < 6)
                            return int.Parse(recordID);
                        else
                            return int.Parse(Secure.Decrypt(recordID));
                        //
                    }
                }

            }
            catch (Exception ex)
            {
                Web.WriteLog("Error Getting Record ID of value " + recordID, ex.Message, ex);
            }

            return -1;
        }
        set
        {
            try
            {
                System.Web.HttpContext.Current.Request.QueryString["RecordID"] = value.ToString();
            }
            catch
            { }
        }
    }
     
    /// <summary>
    /// true if a given keyword is found in query string paramater "Action"
    /// i.e. Action=Edit or Action=Details
    /// </summary>
    /// <param name="ActionKeyword"></param>
    /// <returns></returns>
    public static bool IsAction(string ActionKeyword)
    {
        try
        {
            string action = System.Web.HttpContext.Current.Request.QueryString["Action"];

            if (action == null)
                return false;

            // return true if action is found and a record id is given
            if (action.ToLower() == ActionKeyword.ToLower())
                if (RecordID > 0)
                    return true;


            return false;
        }
        catch
        {
            return false;
        }
    }

    /// <summary>
    /// returns action in lower case letters
    /// </summary>
    /// <returns></returns>
    public static string Action()
    {
        string action = "";
        try
        {
            action = System.Web.HttpContext.Current.Request.QueryString["Action"];


        }
        catch
        {

        }
        return action;
    }
    public static string OffID()
    {
        string OffID = "";
        try
        {
            OffID = System.Web.HttpContext.Current.Request.QueryString["OffID"];


        }
        catch
        {

        }
        return OffID;
    }

    /// <summary>
    /// true if a given keyword is found in query string paramater "Action"
    /// i.e. Action=Edit or Action=Details
    /// </summary>
    /// <param name="ActionKeyword"></param>
    /// <returns></returns>
    public static bool IsParam(string ParameterKeyword)
    {
        try
        {
            string action = System.Web.HttpContext.Current.Request.QueryString["Param"];

            if (action == null)
                return false;

            // return true if action is found and a record id is given
            if (action.ToLower() == ParameterKeyword.ToLower())
                if (RecordID >= 0)
                    return true;


            return false;
        }
        catch
        {
            return false;
        }
    }
    /// <summary>
    /// To set the focus on specific asp control
    /// </summary>
    /// <param name="ctrl">Control</param>
    /// <param name="page">Page</param>
    public static void SetFocus(Control ctrl, Page page)
    {
        var focusScript = new StringBuilder();
        focusScript.Append("<script language='javascript'>");
        focusScript.Append("document.getElementById('" + ctrl.ClientID + "').focus();</script>");

        page.RegisterStartupScript("FocusScript", focusScript.ToString());
    }
    /// <summary>
    /// To get the specific sized string with (...) dots
    /// </summary>
    /// <param name="val"></param>
    /// <param name="length"></param>
    /// <returns></returns>
    public static string GetShortString(string val, int length)
    {
        string newstring;
        if (val.Length > length)
        {
            newstring = val.Remove(length);
            newstring = newstring + "...";
        }
        else
        {
            newstring = val;
        }
        return newstring;
    }
    /// <summary>
    /// To get the specific sized string with (...) dots
    /// </summary>
    /// <param name="val"></param>
    /// <param name="length"></param>
    /// <returns></returns>
    public static string BreakString(string val, int length)
    {
        string Pattern = "\\S{" + length + "}";
        int Counter = 0;
        bool IsMatching = Regex.IsMatch(val, Pattern);
        // string urlPattern = "(([a-zA-Z][0-9a-zA-Z+\\-\\.]*:)?/{0,2}[0-9a-zA-Z;/?:@&=+$\\.\\-_!~*'()%]+)?(#[0-9a-zA-Z;/?:@&=+$\\.\\-_!~*'()%]+)?";
        Regex r1 = new Regex("((http://|www\\.)([A-Z0-9.-:]{1,})\\.[0-9A-Z?;~&+%#=\\-_\\./]{2,})", RegexOptions.Compiled | RegexOptions.IgnoreCase);
        bool IsURL = false;
        MatchCollection mc = r1.Matches(val);

        //IsURL = mc.Cast<Match>().Any();
        //if (IsURL)
        for (int i = 0; i < mc.Count; i++)
        {
            var matchedString = mc[i].Value;
            val = val.Replace(matchedString.Substring(0, (length - 1)), matchedString.Substring(0, (length - 1)) + " ");
        }

        while (IsMatching)
        {
            Counter++;
            string MatchedString = Regex.Match(val, Pattern).Value;
            // if (!Regex.Match(val, urlPattern).Success)
            val = val.Replace(MatchedString.Substring(0, (length - 1)), MatchedString.Substring(0, (length - 1)) + " ");

            // Prevent endless loops
            if (Counter > 100) break;

            // Check if we still have long strings
            IsMatching = Regex.IsMatch(val, Pattern);
        }
        return val;
    }


    public static string BreakLongString(string val, int length)
    {
        string Pattern = "\\S{" + length + "}";
        int Counter = 0;
        bool IsMatching = Regex.IsMatch(val, Pattern);
        // string urlPattern = "(([a-zA-Z][0-9a-zA-Z+\\-\\.]*:)?/{0,2}[0-9a-zA-Z;/?:@&=+$\\.\\-_!~*'()%]+)?(#[0-9a-zA-Z;/?:@&=+$\\.\\-_!~*'()%]+)?";

        while (IsMatching)
        {

            Counter++;
            string MatchedString = Regex.Match(val, Pattern).Value;
            // if (!Regex.Match(val, urlPattern).Success)
            val = val.Replace(MatchedString.Substring(0, (length - 1)), MatchedString.Substring(0, (length - 1)) + " ");

            // Prevent endless loops
            if (Counter > 100) break;

            // Check if we still have long strings
            IsMatching = Regex.IsMatch(val, Pattern);
        }

        return val;
    }
    /// <summary>
    /// Returns short date time format in string 
    /// as dd-mmm-yy
    /// Example: 27-Aug-06
    /// </summary>
    /// <param name="DateTime"></param>
    /// <returns></returns>
    public static string ShortDate(DateTime DateTime)
    {
        if (DateTime.ToString() != "1/1/0001 12:00:00 AM")
        {
            return DateTime.ToString("dd-MMM-yyyy");
        }
        else
        {
            return "";
        }
    }

    /// <summary>
    /// Returns Formatted Currency
    /// 1000.00 to 1,000.00
    /// </summary>
    /// <param name="price"></param>
    /// <returns></returns>
    public static string GetFormattedCurrency(decimal price)
    {
        try
        {
            return string.Format("{0:N}", price);
        }
        catch (Exception exp)
        {
        }
        return price.ToString();
    }


    /// <summary>
    /// Returns short date time format in string 
    /// as dd-mmm-yy hh:mm:ss a
    /// Example: 27-Aug-06 03:28a
    /// </summary>
    /// <param name="DateTime"></param>
    /// <returns></returns>
    public static string ShortDateTime(DateTime DateTime)
    {
        if (DateTime.ToString() != "1/1/0001 12:00:00 AM")
        {
            return DateTime.ToString("dd-MMM-yyyy hh:mm:ss tt");
        }
        else
        {
            return "";
        }
    }
    /// <summary>
    /// This function prevent the page being retrieved from broswer cache
    /// </summary>
    public static void ExpirePageCache()
    {
        HttpContext.Current.Response.Cache.SetCacheability(HttpCacheability.NoCache);
        HttpContext.Current.Response.Cache.SetExpires(DateTime.Now - new TimeSpan(1, 0, 0));
        HttpContext.Current.Response.Cache.SetLastModified(DateTime.Now);
        HttpContext.Current.Response.Cache.SetAllowResponseInBrowserHistory(false);
    }

    /// <summary>
    /// Get the value of the key provided in the configuration file
    /// </summary>
    /// <param name="ConfigKey"></param>
    /// <returns></returns>
    public static string GetConfigValue(string ConfigKey)
    {
        string keyValue = string.Empty;

        try
        {
            Hashtable configKeys = (Hashtable)HttpContext.Current.Session["ConfigKeys"];
            keyValue = (configKeys[ConfigKey].ToString());
        }
        catch
        {
            // log problem
            keyValue = "n/a";
        }

        return keyValue;
    }

    // Returns the application path
    public static string GetApplicationPath()
    {
        return HttpContext.Current.Request.ApplicationPath.ToString();
    }


    public static string GetXMLPackage(DataSet ds)
    {
        StringBuilder xmlPackage = new StringBuilder();
        StringWriter swPackage = new StringWriter(xmlPackage);

        foreach (DataTable dt in ds.Tables)
        {
            foreach (DataColumn col in dt.Columns)
            {
                //Gets the mapping Type of the col
                col.ColumnMapping = MappingType.Attribute;
            }
        }

        // Write XML 
        ds.WriteXml(swPackage, XmlWriteMode.WriteSchema);

        return xmlPackage.ToString();

    }
    /// <summary>
    /// Calculates height for thumbnail with Fixed width=64px
    /// </summary>
    /// <param name="w1">Original Width of image</param>
    /// <param name="h1">Original Height of image</param>
    /// <returns></returns>
    public static int CalculateThumbnailHeight(decimal w1, decimal h1)
    {
        decimal height = 0;
        decimal ratio = 0;
        int myWidth = Convert.ToInt32(SystemConfigs.GetKey("THUMBNAIL_SIZE"));


        if (myWidth < w1)
        {
            ratio = w1 / myWidth;
            height = h1 / ratio;

            return Convert.ToInt32(height);
        }

        if (w1 < myWidth)
        {
            ratio = myWidth / w1;
            height = h1 * ratio;
            return Convert.ToInt32(height);
        }

        return Convert.ToInt32(height);
    }
    public static byte[] UploadImage(Telerik.Web.UI.RadUpload FileName)
    {
        int intImageSize;
        string strImageType;
        Stream ImageStream;
        byte[] ImageContent = null;
        try
        {
            //  Gets the Size of the Image
            intImageSize = Convert.ToInt32(FileName.UploadedFiles[0].ContentLength);
            if (intImageSize > 0)
            {
                // Gets the Image Type
                strImageType = FileName.UploadedFiles[0].ContentType;

                // Reads the Image
                ImageStream = FileName.UploadedFiles[0].InputStream;

                ImageContent = new byte[intImageSize];

                int intStatus;
                intStatus = ImageStream.Read(ImageContent, 0, intImageSize);
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
        return ImageContent;
    }
    public static byte[] UploadImage(Telerik.Web.UI.UploadedFile file)
    {
        int intImageSize;
        string strImageType;
        Stream ImageStream;
        byte[] ImageContent = null;
        try
        {
            //  Gets the Size of the Image
            intImageSize = Convert.ToInt32(file.ContentLength);
            if (intImageSize > 0)
            {
                // Gets the Image Type
                strImageType = file.ContentType;

                // Reads the Image
                ImageStream = file.InputStream;

                ImageContent = new byte[intImageSize];

                int intStatus;
                intStatus = ImageStream.Read(ImageContent, 0, intImageSize);
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
        return ImageContent;
    }
    public static byte[] UploadImage(FileUpload FileName)
    {
        int intImageSize;
        string strImageType;
        Stream ImageStream;
        byte[] ImageContent = null;
        try
        {
            //  Gets the Size of the Image
            intImageSize = Convert.ToInt32(FileName.PostedFile.ContentLength);
            if (intImageSize > 0)
            {
                // Gets the Image Type
                strImageType = FileName.PostedFile.ContentType;

                // Reads the Image
                ImageStream = FileName.PostedFile.InputStream;

                ImageContent = new byte[intImageSize];

                int intStatus;
                intStatus = ImageStream.Read(ImageContent, 0, intImageSize);
            }
        }
        catch (Exception ex)
        {
            //Log.Write("Error", ex.GetBaseException().ToString(), ex);
            Web.LogError(ex);
        }
        return ImageContent;
    }

    public static string GetDefaultCurrencyCode()
    {
        return Currencies.GetDefaultCurrencyCode();
    }

    public static string GetDefaultCurrencySymbol()
    {
        return "$";
        //return Currencies.GetDefaultCurrencySymbol();
    }

    public static string GetCurrencyCode(string strCurrencyID)
    {
        if (!String.IsNullOrEmpty(strCurrencyID))
        {
            int CurrencyID = int.Parse(strCurrencyID);
            if (CurrencyID > 0)
            {
                Currencies currency = new Currencies();
                currency.LoadByPrimaryKey(CurrencyID);
                if (currency.RowCount > 0)
                {
                    if (!String.IsNullOrEmpty(currency.s_CurrencyCode))
                        return currency.s_CurrencyCode;
                    else
                        return GetDefaultCurrencyCode();
                }
                else
                    return GetDefaultCurrencyCode();
            }
            else
                return GetDefaultCurrencyCode();
        }
        else
            return GetDefaultCurrencyCode();
    }
    public static string GetCurrencySymbol(string strCurrencyID)
    {
        if (!String.IsNullOrEmpty(strCurrencyID))
        {
            int CurrencyID = int.Parse(strCurrencyID);
            if (CurrencyID > 0)
            {
                Currencies currency = new Currencies();
                currency.LoadByPrimaryKey(CurrencyID);
                if (currency.RowCount > 0)
                {
                    if (!String.IsNullOrEmpty(currency.s_CurrencySymbol))
                        return currency.s_CurrencySymbol;
                    else
                        return "";
                }
                else
                    return "";
            }
            else
                return "";
        }
        else
            return "";
    }

    public static string GetPriceUnit(string unit)
    {
        if (unit == "1")
            return "per Item";
        else if (unit == "2")
            return "per Lot";
        else
            return "";
    }
    public static string GetListingPriceUnit(string unit)
    {
        if (unit == "1")
            return " per Item";
        else if (unit == "2")
            return " per Listing";
        else
            return "";
    }

    public static string GetPriceUnitAdditional(string unit)
    {
        if (unit == "1")
            return "for each additional Item";
        else if (unit == "2")
            return "for each additional Lot";
        else
            return "";
    }

    public static string CheckDaysLeft(string DaysBeforeClose, int AuctionType, string TimeLeft)
    {
        if (!String.IsNullOrEmpty(DaysBeforeClose))
        {
            if (DaysBeforeClose == "1000" || DaysBeforeClose == "100")
            {
                if (AuctionType == 1)
                    return "Until Sold";
                else
                    return "Until Request Fulfilled";
            }
            else
            {
                if (!String.IsNullOrEmpty(TimeLeft))
                {
                    int time = Convert.ToInt32(TimeLeft);
                    if (time > 0)
                        return TimeLeft + " Day(s)";
                    else
                        return "Expired";
                }
                else
                    return TimeLeft + " Day(s)";
            }
        }
        else
            return "";
    }

    /// <summary>
    /// Extract ErrorMsg in current query string
    /// </summary>
    public static string ErrorMsg
    {
        get
        {
            try
            {
                string ErrorMsg = System.Web.HttpContext.Current.Request.QueryString["ErrorMsg"];

                if (ErrorMsg != null || ErrorMsg != "")
                    return ErrorMsg;

            }
            catch
            {

            }

            return "";
        }
    }

    /// <summary>
    /// return current page name
    /// </summary>
    /// <returns></returns>
    public static string GetCurrentPageName()
    {
        return Path.GetFileName(HttpContext.Current.Request.Url.AbsolutePath).ToLower();
    }

    /// <summary>
    /// Property of Record Key using Session
    /// </summary>
    public static string SessionRecordKey
    {
        get
        {
            try
            {
                string action = System.Web.HttpContext.Current.Session["SessionRecordKey"].ToString();
                return action;
            }
            catch
            { }
            return null;
        }
        set { System.Web.HttpContext.Current.Session["SessionRecordKey"] = value; }
    }

    public static string[] SplitByComma(string strInput)
    {
        // constants for the space and comma characters
        const char Space = ' ';
        const char Comma = ',';

        // array of delimiters to split the sentence with
        char[] delimiters = new char[]
                 {
                    Space,
                    Comma
                 };

        // split the string and then iterate over the
        // resulting array of strings

        String[] resultArray = strInput.Split(delimiters);
        return resultArray;
    }

    #region Encrypt or Decrypt Data

    /// <summary>
    /// Encryption
    /// </summary>
    /// <param name="value"></param>
    /// <returns></returns>
    public static string EncryptRijndaelManaged(string value)
    {
        if (value == "")
            return "";

        RijndaelManaged crypto = new RijndaelManaged();
        MemoryStream ms = new MemoryStream();
        CryptoStream cs = new CryptoStream(ms, crypto.CreateEncryptor(key_192, iv_128), CryptoStreamMode.Write);

        StreamWriter sw = new StreamWriter(cs);

        sw.Write(value);
        sw.Flush();
        cs.FlushFinalBlock();
        ms.Flush();

        return Convert.ToBase64String(ms.GetBuffer(), 0, (int)ms.Length);
    }

    /// <summary>
    /// Decryption
    /// </summary>
    /// <param name="value"></param>
    /// <returns></returns>
    public static string DecryptRijndaelManaged(string value)
    {
        if (value == "")
            return "";

        RijndaelManaged crypto = new RijndaelManaged();
        MemoryStream ms = new MemoryStream(Convert.FromBase64String(value));
        CryptoStream cs = new CryptoStream(ms, crypto.CreateDecryptor(key_192, iv_128), CryptoStreamMode.Read);

        StreamReader sw = new StreamReader(cs);

        return sw.ReadToEnd();
    }
    #endregion


    #region Mail Processing
    /// <summary>
    /// The Email Template Keys for system
    /// </summary>
    /// <returns></returns>
    public static StringDictionary templateKeys()
    {
        StringDictionary templateKeys = new StringDictionary();

        //all the keys will be listed here
        templateKeys.Add("<TMPL_VAR NAME=SITE_NAME>", ConfigurationManager.AppSettings["SiteName"]);

        return templateKeys;
    }

    public static SystemConfigs SystemConfigs
    {
        get
        {
            try
            {
                return SystemManager.GetConfigurations(ConfigurationManager.AppSettings["ApplicationAccessKey"].ToString());
            }
            catch (Exception exp)
            {
                LogError(exp);
            }

            return null;
        }

        set
        {
            System.Web.HttpContext.Current.Application["SystemConfigs"] = value;
        }
    }



    public static void NotifyMember(int MemberID, int EmailNotificationTypeID, StringDictionary templateKeys)
    {

        MemberEmailNotifications mememailnotification = new MemberEmailNotifications();
        mememailnotification.Where.MemberID.Value = MemberID;
        mememailnotification.Where.EmailNotificationTypeID.Value = EmailNotificationTypeID;
        mememailnotification.Query.Load();
        if (mememailnotification.RowCount > 0)
        {
            if (mememailnotification.IsEnabled == 1)
            {
                EmailNotificationTypes emailnotificationtype = new EmailNotificationTypes();
                emailnotificationtype.LoadByPrimaryKey(EmailNotificationTypeID);
                int TemplateID = emailnotificationtype.TemplateID;
                Members member = new Members();
                member.LoadByPrimaryKey(MemberID);

                string memberEmail = member.Email;
                string fromEmail = Web.SystemConfigs.GetKey("SUPPORT_EMAIL");



                VisualSoft.SystemManagement.TemplateManager templateManager = new VisualSoft.SystemManagement.TemplateManager();
                DataTable resultData = EmailTemplates.GetTemplateDetails(TemplateID);
                string subjecttemplate = templateManager.ParseTemplate(resultData.Rows[0]["TemplateSubject"].ToString(), templateKeys);
                string parsedEmailTemplate = templateManager.ParseTemplate(resultData.Rows[0]["HTMLTemplateBody"].ToString(), templateKeys);
                string parseTextTemplate = templateManager.ParseTemplate(resultData.Rows[0]["TextTemplateBody"].ToString(), templateKeys);

                MemberNotifications membernotification = new MemberNotifications();
                membernotification.AddNew();
                membernotification.MemberID = MemberID;
                membernotification.EmailNotificationTypeID = EmailNotificationTypeID;
                membernotification.Notification = parseTextTemplate;
                membernotification.NotificationDate = System.DateTime.Now;
                membernotification.Save();

                // SendMail(memberEmail, fromEmail, subjecttemplate, parsedEmailTemplate);
                // generateEmail(memberEmail, fromEmail, TemplateID, templateKeys);
                SendEmailUsingAmazonService(memberEmail, fromEmail, TemplateID, templateKeys);

            }
        }
        else
        {
            // if member has not subscribed
            mememailnotification = new MemberEmailNotifications();
            mememailnotification.Where.EmailNotificationTypeID.Value = EmailNotificationTypeID;
            mememailnotification.Query.Load();
            EmailNotificationTypes emailnotificationtype = new EmailNotificationTypes();
            emailnotificationtype.LoadByPrimaryKey(EmailNotificationTypeID);
            int TemplateID = emailnotificationtype.TemplateID;
            Members member = new Members();
            member.LoadByPrimaryKey(MemberID);
            string memberEmail = member.Email;
            string fromEmail = Web.SystemConfigs.GetKey("SUPPORT_EMAIL");
            VisualSoft.SystemManagement.TemplateManager templateManager = new VisualSoft.SystemManagement.TemplateManager();
            DataTable resultData = EmailTemplates.GetTemplateDetails(TemplateID);
            string subjecttemplate = templateManager.ParseTemplate(resultData.Rows[0]["TemplateSubject"].ToString(), templateKeys);
            string parsedEmailTemplate = templateManager.ParseTemplate(resultData.Rows[0]["HTMLTemplateBody"].ToString(), templateKeys);
            string parseTextTemplate = templateManager.ParseTemplate(resultData.Rows[0]["TextTemplateBody"].ToString(), templateKeys);
            //  SendMail(memberEmail, fromEmail, subjecttemplate, parsedEmailTemplate);
            // generateEmail(memberEmail, fromEmail, TemplateID, templateKeys);
            SendEmailUsingAmazonService(memberEmail, fromEmail, TemplateID, templateKeys);

        }

        // 1. Check if member is enabled for this emailnotificationtypeid
        // IsEnabled = select IsEnabled from MemberEmailNotifications where MemberID = <MemberID> and EmailNotificationTypeID = <EmailNotificationTYpeID>

        // 2. if IsEnabled = 1
        // Get Email Template of this EmailNotificationTypeID 
        //  string EmailBody = "", EmailSubject = "";
        // EmailTemplate, EmailSubject = (SELECT * From EmailTemplates where TemplateID = (select TemplateID from EmailNotificationTypes where EmailNotificationTypeID = 2))

        // 3. Parse Templates 
        //  a) Email Template
        //  b) Text Template (Template for Notification Table

        // 4. Get Member Email Address
        // string memberEmail = "";
        // string fromEmail = Web.SystemConfigs.GetKey("SUPPORT_EMAIL");

        // 5. Ssve in MemberNotifications Table
        // text template will be saved

        // 6. Send Email
        // email parsed template will be sent in email
        //    SendMail(memberEmail, fromEmail, EmailSubject, EmailBody);       

    }


    /// <summary>
    /// Web Mail
    /// </summary>
    /// <param name="To"></param>
    /// <param name="AccessKey"></param>
    /// <param name="templateKeys"></param>
    public static void SendMail(string To, string From, int TemplateID, StringDictionary templateKeys)
    {
        try
        {
            {
                //var fromName = (From.Length == 0) ? SystemConfigKeys.GetKey("ALERTS_EMAIL") : From;

                //check from the email block list.
                EmailBlockList list = new EmailBlockList();
                list.Where.Email.Value = To;
                list.Query.Load();

                if (list.RowCount == 0)
                {
                    SendEmailUsingAmazonService(To, From, TemplateID, templateKeys);
                    //generateEmail(To, from, TemplateID, templateKeys);
                }
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }

    }

    public static void SendMail(string To, string From, string Body, string Subject, Telerik.Web.UI.RadUpload attachment, string BCC)
    {
        try
        {
            //check from the email block list.
            EmailBlockList list = new EmailBlockList();
            list.Where.Email.Value = To;
            list.Query.Load();

            if (list.RowCount == 0)
                SendEmailUsingAmazonService(To, From, Body, Subject, attachment, BCC);
            //generateEmail(To, from, Body, Subject, attachment, BCC);
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }

    }

    /*
    private static void generateEmail(string To, string From, int TemplateID, StringDictionary templateKeys)
    {
        Web.WriteLog("SEND EMAIL", string.Format("From:{0}, To:{1}, TmeplateID:{2}", From, To, TemplateID), new Exception(string.Format("From:{0}, To:{1}, TmeplateID:{2}", From, To, TemplateID)));
        var templateManager = new VisualSoft.SystemManagement.TemplateManager();
        var template = new EmailTemplates();
        template.LoadByPrimaryKey(TemplateID);
        string Body = templateManager.ParseTemplate(template.HTMLTemplateBody, templateKeys);
        string Subject = templateManager.ParseTemplate(template.TemplateSubject, templateKeys);
        string enable = System.Configuration.ConfigurationManager.AppSettings["SysEnableEmail"];
        string enableTesterEmail = System.Configuration.ConfigurationManager.AppSettings["SysEnableTesterEmail"];
        string testerEmail = System.Configuration.ConfigurationManager.AppSettings["SysTesterEmail"];

        var fromTitle = SystemConfigKeys.GetKey("X_MAILER");
        var fromEmail = (From.Length == 0) ? SystemConfigKeys.GetKey("ALERTS_EMAIL") : From;

        //From = (!String.IsNullOrEmpty(fromTitle)) ? new Address(fromEmail, fromTitle) : new Address(fromEmail);

        MailMessage message;
        if (enableTesterEmail == "1")
            message = new MailMessage(From, testerEmail);
        else
            message = new MailMessage(From, To);

        message.Subject = Subject;
        message.Body = Body;
        message.IsBodyHtml = true;

        //if sending a copy for testing too
        if (enableTesterEmail == "1")
            message.Body = "Note: Email forwarded from " + To + "<br /><br />" + message.Body;

        // Log Email in file
        EmailLogger.LogEmail(TemplateID, message);

        // send email if Email Sending is enabled
        if (enable == "1")
        {
            var smtp = new SmtpClient();
            smtp.Send(message);
        }

        // add email to Email log in DB
        var email = new Emails();
        email.AddNew();
        email.FromEmail = message.From.ToString();
        email.ToEmail = message.To.ToString();
        email.Subject = message.Subject;
        email.Body = Body;
        email.Save();
    }
    private static void generateEmail(string To, string From, string Body, string Subject, Telerik.Web.UI.RadUpload attachment, string BCC)
    {
        string enable = System.Configuration.ConfigurationManager.AppSettings["SysEnableEmail"];
        string enableTesterEmail = System.Configuration.ConfigurationManager.AppSettings["SysEnableTesterEmail"];
        string testerEmail = System.Configuration.ConfigurationManager.AppSettings["SysTesterEmail"];

        var fromTitle = SystemConfigKeys.GetKey("X_MAILER");
        var fromEmail = (From.Length == 0) ? SystemConfigKeys.GetKey("ALERTS_EMAIL") : From;

        //From = (!String.IsNullOrEmpty(fromTitle)) ? new Address(fromEmail, fromTitle) : new Address(fromEmail);

        MailMessage message;
        if (enableTesterEmail == "1")
            message = new MailMessage(From, testerEmail);
        else
            message = new MailMessage(From, To);

        message.Subject = Subject;
        message.Body = Body;
        message.IsBodyHtml = true;

        if (!String.IsNullOrEmpty(BCC))
            message.Bcc.Add(new MailAddress(BCC));

        if (attachment.UploadedFiles.Count > 0)
            message.Attachments.Add(new System.Net.Mail.Attachment(attachment.UploadedFiles[0].InputStream, attachment.UploadedFiles[0].FileName));

        //if sending a copy for testing too
        if (enableTesterEmail == "1")
            message.Body = "Note: Email forwarded from " + To + "<br /><br />" + message.Body;

        // Log Email in file
        EmailLogger.LogEmail(9999, message);

        // send email if Email Sending is enabled
        if (enable == "1")
        {
            var smtp = new SmtpClient();
            smtp.Send(message);
        }

        // add email to Email log in DB
        var email = new Emails();
        email.AddNew();
        email.FromEmail = message.From.ToString();
        email.ToEmail = message.To.ToString();
        email.Subject = message.Subject;
        email.Body = Body;
        email.Save();
    }
    */
    //public static void sendMail(string From, string To, string Bcc, string Subject, string Body, MailPriority Priority)
    //{
    //    try
    //    {

    //        Message mail = new Message();

    //        //set the addresses
    //        string FromTitle = Web.SystemConfigs.GetKey("EMAIL_FROM_TITLE");
    //        if (!String.IsNullOrEmpty(FromTitle))
    //            mail.From = new Address(From, FromTitle);
    //        else
    //            mail.From = new Address(From);

    //        mail.To.Add(To);

    //        if (Bcc != null)
    //            mail.Bcc.Add(Bcc);

    //        mail.Subject = Subject;
    //        mail.BodyHtml = Body;

    //        mail.Headers.Add("X-Mailer", "eOffer Powered By VisualSoft");

    //        Log.Write(mail.BodyHtml, "", null);


    //    }
    //    catch (Exception ex)
    //    {
    //        throw ex;
    //    }
    //}

    #endregion


    /// new methods 5-Nov-08
    ///   


    public static Categories Categories
    {
        get
        {
            //Web.CategoriesTable = Categories.GetCategoriesTable();
            return Categories.GetCachedCategories();
        }

    }

    public static DataTable CategoriesTable
    {
        get
        {
            return Categories.GetCategoriesTable();
        }
    }

    #region Cookies n Login
    public static void CookieLogin()
    {
        //Log.Write("Cookie Login: ", "Cookie login called", null);
        try
        {
            if (!Web.IsMemberSession)
                if (HttpContext.Current.Request.Cookies["loginCookie"] != null)
                {
                    HttpCookie eofferCookie = HttpContext.Current.Request.Cookies.Get("loginCookie");
                    string pwd = null, userlogin = null;

                    if (!String.IsNullOrEmpty(eofferCookie.Values["password"]))
                        pwd = Web.DecryptRijndaelManaged(eofferCookie.Values["password"]);

                    if (!String.IsNullOrEmpty(eofferCookie.Values["login"]))
                        userlogin = Web.DecryptRijndaelManaged(eofferCookie.Values["login"]);

                    if (eofferCookie.Values["keepLoggedIn"] != null)
                        if (eofferCookie.Values["keepLoggedIn"].ToString().ToLower() == "true")
                            AuthenticateMember(userlogin, pwd, Convert.ToBoolean(eofferCookie.Values["keepLoggedIn"]), Convert.ToBoolean(eofferCookie.Values["rememberMe"].ToString()), true);
                }
        }
        catch (Exception ex)
        {
            //Log.Write("Login: 001", ex.GetBaseException().ToString(), ex);
            Web.LogError(ex);
        }
    }

    public static bool IsEmailAddress(string emailAddress)
    {
        string patternStrict = @"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}" +
         @"\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\" +
         @".)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$";

        System.Text.RegularExpressions.Regex reStrict = new System.Text.RegularExpressions.Regex(patternStrict);
        bool isStrictMatch = reStrict.IsMatch(emailAddress);
        return isStrictMatch;
    }


    public static void AuthenticateMember(string login, string password, bool chkKeepmeSignIn, bool chkRememberMe, bool GoToWelcomePage)
    {
        try
        {
            Members member = Members.Authenticate(login, password);

            if (member.RowCount > 0)
            {
                // check for later implementation
                //if (Secure.CheckHash(password, member.SurrogatePassword))
                {
                    Web.SessionMembers = member;
                    Web.IsMemberSession = true;
                    ShippingAddresses address = new ShippingAddresses();
                    address.Where.MemberID.Value = member.MemberID;
                    address.Query.Load();
                    if (address.RowCount > 0)
                        Web.SessionMembers.shippingAddress = address;

                    if (chkKeepmeSignIn || chkRememberMe)
                    {
                        WriteCookie("loginCookie", login, password, chkRememberMe, chkKeepmeSignIn, DateTime.Now.AddHours(12));
                    }
                    else
                    {
                        HttpContext.Current.Response.Cookies["loginCookie"].Expires = DateTime.Now.AddDays(-1);
                    }

                    //Update last login date
                    string s_LastLoginDate = member.s_LastLoginDate;
                    member.LoadByPrimaryKey(member.MemberID);
                    member.LastLoginDate = DateTime.Now;
                    member.Save();

                    if (GoToWelcomePage)
                    {
                        if (String.IsNullOrEmpty(s_LastLoginDate))
                            Redirect("/Live.aspx");
                        else
                        {
                            if (HttpContext.Current.Request.QueryString["ReturnUrl"] != null)
                            {
                                string url = HttpContext.Current.Request.Url.ToString();
                                url = url.Substring(url.IndexOf("ReturnUrl=") + 10);
                                Redirect(url);
                            }
                            else
                                Redirect("/Live.aspx");
                        }
                    }
                    else
                    {
                        if (HttpContext.Current.Request.QueryString["ReturnUrl"] != null)
                        {
                            string url = HttpContext.Current.Request.Url.ToString();
                            url = url.Substring(url.IndexOf("ReturnUrl=") + 10);
                            Redirect(url);
                        }
                        else
                            Redirect("/Live.aspx");
                    }
                }
            }
        }
        catch (Exception ex)
        {
            //Log.Write("Login: 002", ex.GetBaseException().ToString(), ex);
            Web.LogError(ex);
        }
        finally
        {

            HttpContext.Current.Response.Cache.SetCacheability(HttpCacheability.NoCache);
            HttpContext.Current.Response.Cache.SetAllowResponseInBrowserHistory(false);
        }
    }

    private static string getNavigateURL(string absPath, string fullPath)
    {
        var navigateUrl = "";

        try
        {
            navigateUrl = fullPath.Contains("ReturnUrl=") ? fullPath.Substring(fullPath.IndexOf("ReturnUrl=")).Replace("ReturnUrl=~", "") : fullPath;
        }
        catch (Exception)
        {
            navigateUrl = "/Live.aspx";
        }

        return navigateUrl;
    }

    public static string AuthenticateUser(string login, string password, bool chkKeepmeSignIn, bool chkRememberMe, bool GoToWelcomePage, string currentPageUrl)
    {
        try
        {
            Members member = Members.AuthenticateAll(login, password);

            Uri currentUrl = new Uri(currentPageUrl) as System.Uri;

            string absPath = currentUrl.AbsolutePath;
            string completePath = currentUrl.PathAndQuery;
            string navigatePath = getNavigateURL(absPath, completePath);

            if (member.RowCount > 0)
            {
                Web.SessionMembers = member;
                Web.IsMemberSession = true;
                ShippingAddresses address = new ShippingAddresses();
                address.Where.MemberID.Value = member.MemberID;
                address.Query.Load();
                if (address.RowCount > 0)
                    Web.SessionMembers.shippingAddress = address;

                if (chkKeepmeSignIn || chkRememberMe)
                {
                    WriteCookie("loginCookie", login, password, chkRememberMe, chkKeepmeSignIn, DateTime.Now.AddMonths(12));
                }
                else
                {
                    HttpContext.Current.Response.Cookies["loginCookie"].Expires = DateTime.Now.AddDays(-1);
                }

                //Update last login date
                string s_LastLoginDate = member.s_LastLoginDate;
                member.LoadByPrimaryKey(member.MemberID);
                member.LastLoginDate = DateTime.Now;
                member.Save();

                if (GoToWelcomePage)
                {
                    if (String.IsNullOrEmpty(s_LastLoginDate))
                        return navigatePath;
                    else
                    {
                        if (HttpContext.Current.Request.QueryString["ReturnUrl"] != null)
                        {
                            string url = HttpContext.Current.Request.Url.ToString();
                            url = url.Substring(url.IndexOf("ReturnUrl=") + 10);
                            return url;
                        }
                        else
                            return navigatePath;
                    }
                }
                else
                {
                    if (HttpContext.Current.Request.QueryString["ReturnUrl"] != null)
                    {
                        string url = HttpContext.Current.Request.Url.ToString();
                        url = url.Substring(url.IndexOf("ReturnUrl=") + 10);
                        return url;
                    }
                    else
                        return "/Live.aspx";
                }
            }
        }
        catch (Exception ex)
        {
            //Log.Write("Login: 002", ex.GetBaseException().ToString(), ex);
            Web.LogError(ex);
        }
        finally
        {

            HttpContext.Current.Response.Cache.SetCacheability(HttpCacheability.NoCache);
            HttpContext.Current.Response.Cache.SetAllowResponseInBrowserHistory(false);
        }
        return "";
    }

    public static void WriteCookie(string cookieName, string login, string password, bool rememberMe, bool keepLoggedIn, DateTime expiryDate)
    {
        try
        {
            HttpCookie eofferCookie = new HttpCookie(cookieName);
            eofferCookie.Values.Add("login", Web.EncryptRijndaelManaged(login));
            eofferCookie.Values.Add("rememberMe", rememberMe.ToString());
            if (keepLoggedIn)
            {
                eofferCookie.Values.Add("password", Web.EncryptRijndaelManaged(password));
                eofferCookie.Values.Add("keepLoggedIn", keepLoggedIn.ToString());
            }
            eofferCookie.Expires = expiryDate;

            HttpContext.Current.Response.Cookies.Add(eofferCookie);
        }
        catch (Exception ex)
        {
            //Log.Write("Login: 003", ex.GetBaseException().ToString(), ex);
            Web.LogError(ex);
        }

    }
    //public static void CookieLogin()
    //{
    //    try
    //    {
    //        if (HttpContext.Current.Request.Cookies["ECLIPSE"] != null)
    //        {
    //            if (HttpContext.Current.Request.Browser.Cookies)
    //            {
    //                if ((HttpContext.Current.Request.Cookies["ECLIPSE"]["X"] != null && HttpContext.Current.Request.Cookies["ECLIPSE"]["Y"] != null) || HttpContext.Current.Request.Cookies["ECLIPSE"]["Z"] != null)
    //                {
    //                    string temp = Web.DecryptRijndaelManaged(HttpContext.Current.Request.Cookies["ECLIPSE"]["X"]);
    //                    if (!String.IsNullOrEmpty(temp))
    //                    {
    //                        int UserID = Convert.ToInt32(temp);
    //                        string userType = Web.DecryptRijndaelManaged(HttpContext.Current.Request.Cookies["ECLIPSE"]["Y"]);
    //                        string cookieType = (HttpContext.Current.Request.Cookies["ECLIPSE"]["Z"] != null) ? Web.DecryptRijndaelManaged(HttpContext.Current.Request.Cookies["ECLIPSE"]["Z"]) : "Member";

    //                        string securitylogin = ConfigurationManager.AppSettings["securityLogin"].ToString();
    //                        string securityPassword = ConfigurationManager.AppSettings["securityPassword"].ToString();
    //                        if (cookieType == "Member")
    //                        {
    //                            if (userType == "Member")
    //                            {
    //                                var objMember = new Members();
    //                                objMember.LoadByPrimaryKey(UserID);
    //                                if (objMember.RowCount > 0)
    //                                {
    //                                    var member = Members.Authenticate(objMember.UserName, objMember.Password);

    //                                    Web.SessionMembers = member;
    //                                    Web.IsMemberSession = true;


    //                                }
    //                            }
    //                            else
    //                            {

    //                            }
    //                        }
    //                    }
    //                }
    //            }
    //        }
    //    }
    //    catch (VException vex)
    //    {
    //        Log.Write(vex.ErrorCode, vex.BaseException.ToString(), vex);
    //    }
    //    catch (Exception ex)
    //    {
    //        Log.Write("444", ex.GetBaseException().ToString(), ex);
    //    }
    //} 
    #endregion

    /// <summary>
    /// Binds drop down with the categories from cache
    /// </summary>
    /// <param name="ddlCategories">Drop down to bind</param>
    /// <param name="AddAllCategoriesItem">Whether to show "All Categories" Item in the list</param>
    public static void BindCategories(DropDownList ddlCategories, bool AddAllCategoriesItem)
    {
        try
        {
            ListItem item = new ListItem();
            if (AddAllCategoriesItem)
            {
                item = new ListItem("-- All Categories --", "0");
                ddlCategories.Items.Add(item);
            }

            Categories categories = Web.Categories;
            if (categories != null)
                if (categories.RowCount > 0)
                {
                    foreach (DataRow row in categories.DefaultView.Table.Rows)
                    {
                        if (row["ParentCategory"].ToString() == "0")
                        {
                            item = new ListItem(row["CategoryName"].ToString(), row["CategoryID"].ToString());
                            ddlCategories.Items.Add(item);
                        }
                    }
                }
            ddlCategories.DataBind();
        }
        catch (Exception ex)
        {
            //Log.Write("444", ex.GetBaseException().ToString(), ex);
            Web.LogError(ex);
        }
    }

    public static void BindCategories(Telerik.Web.UI.RadComboBox ddlCategories, bool AddAllCategoriesItem)
    {
        try
        {
            Telerik.Web.UI.RadComboBoxItem item = new Telerik.Web.UI.RadComboBoxItem();
            Categories categories = Web.Categories;
            if (categories != null)
                if (categories.RowCount > 0)
                {
                    if (AddAllCategoriesItem)
                    {
                        item = new Telerik.Web.UI.RadComboBoxItem(" All Categories ", "0");
                        ddlCategories.Items.Add(item);
                    }
                    foreach (DataRow row in categories.DefaultView.Table.Rows)
                    {
                        if (row["ParentCategory"].ToString() == "0")
                        {
                            item = new Telerik.Web.UI.RadComboBoxItem(row["CategoryName"].ToString(), row["CategoryID"].ToString());
                            ddlCategories.Items.Add(item);
                        }
                    }
                }
            ddlCategories.DataBind();

            item = new Telerik.Web.UI.RadComboBoxItem("All Other Categories ", "4590");
            ddlCategories.Items.Add(item);
        }
        catch (Exception ex)
        {
            //Log.Write("444", ex.GetBaseException().ToString(), ex);
            Web.LogError(ex);
        }
    }

    public static string GetValidImageFormats()
    {
        string expression = @"^(([a-zA-Z]:)|(\\{2}\w+)\$?)(\\(\w[\w].*))+(.jpg|.JPG|.jpeg|.JPEG|.gif|.GIF|.bmp|.BMP|.png|.PNG|.tiff|.TIFF|.tif|.TIF)$";
        try
        {
            System.Text.StringBuilder sb = new System.Text.StringBuilder();

            //get extensions from system settings
            char[] chr = { ',' };
            string[] fileExtensions = Web.SystemConfigs.GetKey("DEF_IMAGE_FORMAT").Split(chr);

            //append them all in one string
            for (int i = 0; i < fileExtensions.Length; i++)
            {
                sb.Append(fileExtensions[i].Replace(" ", ""));
                sb.Append("|");
            }
            if (sb.Length > 1)
                sb.Remove(sb.Length - 1, 1);

            expression = @"^(([a-zA-Z]:)|(\\{2}\w+)\$?)(\\(\w[\w].*))+(" + sb.ToString() + ")$";
        }
        catch (Exception ex)
        {
            //Log.Write("444", ex.GetBaseException().ToString(), ex);
            Web.LogError(ex);
        }
        return expression;
    }

    public static double ConvertCurrency(double originalPrice, int CurrencyID)
    {
        double convertedCurrency = 0;
        try
        {
            if (CurrencyID > 0)
            {
                Currencies currency = new Currencies();
                currency.LoadByPrimaryKey(CurrencyID);
                if (currency.RowCount > 0)
                {
                    decimal result = 0;
                    if (currency.ExchangeRate > 0)
                        result = Convert.ToDecimal(originalPrice) / currency.ExchangeRate;
                    convertedCurrency = Convert.ToDouble(Decimal.Round(result, 3));
                }
            }
        }
        catch (Exception ex)
        {
            //Log.Write("ConvertCurrency", ex.GetBaseException().ToString(), ex);
            Web.LogError(ex);
        }
        return convertedCurrency;
    }

    public static decimal ConvertCurrency(decimal originalPrice, int CurrencyID)
    {
        decimal convertedCurrency = 0;
        try
        {
            if (CurrencyID > 0)
            {
                Currencies currency = new Currencies();
                currency.LoadByPrimaryKey(CurrencyID);
                if (currency.RowCount > 0)
                {
                    decimal result = 0;
                    if (currency.ExchangeRate > 0)
                        result = originalPrice / currency.ExchangeRate;
                    convertedCurrency = Decimal.Round(result, 3);
                }
            }
        }
        catch (Exception ex)
        {
            //Log.Write("ConvertCurrency", ex.GetBaseException().ToString(), ex);
            Web.LogError(ex);
        }
        return convertedCurrency;
    }

    public static string GetItemStatus(string StatusID)
    {
        string status = "";
        try
        {
            if (!String.IsNullOrEmpty(StatusID))
            {
                ItemStatusCodes codes = new ItemStatusCodes();
                codes.LoadByPrimaryKey(Convert.ToInt32(StatusID));
                if (codes.RowCount > 0)
                    status = codes.StatusName;
            }
        }
        catch (Exception ex)
        {
            //Log.Write("GetItemStatus", ex.GetBaseException().ToString(), ex);
            Web.LogError(ex);
        }
        return status;
    }

    public static string GetDealerName(int MemberID)
    {
        try
        {
            Members members = new Members();
            members.Query.AddResultColumn(MembersSchema.FullName);
            members.Query.AddResultColumn(MembersSchema.UserName);
            members.Where.MemberID.Value = MemberID;
            members.Query.Load();
            return members.s_UserName;
        }
        catch (Exception exp)
        {
            //Log.Write("GetDealerName", exp.GetBaseException().ToString(), exp);
            Web.LogError(exp);
        }
        return "N/A";
    }

    public static void SetFocus(Control control)
    {
        StringBuilder sb = new StringBuilder();

        sb.Append("\r\n<script language='JavaScript'>\r\n");
        sb.Append("<!--\r\n");
        sb.Append("function SetFocus()\r\n");
        sb.Append("{\r\n");
        sb.Append("\tdocument.");

        Control p = control.Parent;
        while (!(p is System.Web.UI.HtmlControls.HtmlForm)) p = p.Parent;

        sb.Append(p.ClientID);
        sb.Append("['");
        sb.Append(control.UniqueID);
        sb.Append("'].focus();\r\n");
        sb.Append("}\r\n");
        sb.Append("window.onload = SetFocus;\r\n");
        sb.Append("// -->\r\n");
        sb.Append("</script>");

        control.Page.RegisterClientScriptBlock("SetFocus", sb.ToString());
    }

    public static void WriteLog(string ErrorCode, string Error, Exception exception)
    {
        try
        {
            Log.Write(ErrorCode, Error, exception);
        }
        catch (Exception) { }
    }

    public static bool ShowBlockContactbutton(int ContactMemberID)
    {
        bool result = false;
        try
        {
            if (Web.IsMemberSession)
            {
                if (Web.SessionMembers.MemberID != ContactMemberID)
                {
                    Contacts contact = new Contacts();
                    contact.Where.MemberID.Value = Web.SessionMembers.MemberID;
                    contact.Where.ContactMemberID.Value = ContactMemberID;
                    contact.Where.ContactStatusID.Value = 1;
                    contact.Query.Load();
                    if (contact.RowCount > 0)
                    {
                        if (AllowBlockUnblockContact(contact.ContactID))
                        {
                            result = true;
                        }

                    }
                }
            }

        }
        catch (Exception exp)
        {
            // Log.Write("mycontacterror", exp.GetBaseException().ToString(), exp);
            Web.LogError(exp);
        }
        return result;
    }
    public static bool AllowBlockUnblockContact(int ContactID)
    {
        bool result = false;
        try
        {
            if (BlockContactLog.GetContactBlockedByID(ContactID).Rows.Count > 0)
            {

                int blockedby = 0;
                DateTime BlockedDate = Convert.ToDateTime(BlockContactLog.GetContactBlockedByID(ContactID).Rows[0]["BlockedDate"]);
                blockedby = Convert.ToInt32(BlockContactLog.GetContactBlockedByID(ContactID).Rows[0]["BlockedBy"]);
                TimeSpan timespan = System.DateTime.Now.Subtract(BlockedDate);
                int hours = timespan.Hours;
                if (blockedby == Web.SessionMembers.MemberID)
                {
                    int ConfigTime = Convert.ToInt32(Web.SystemConfigs.GetKey("BlockContactTimeSpan").ToString());
                    if (ConfigTime <= hours)
                    {
                        result = true;

                    }
                }



            }


        }
        catch (Exception exp)
        {

            //Log.Write("AllowBlockUnblock:", exp.GetBaseException().ToString(), exp);
            Web.LogError(exp);
        }
        return result;
    }
    public static bool ShowUnblockContactbutton(int ContactMemberID)
    {
        bool result = false;
        try
        {
            if (Web.IsMemberSession)
            {
                if (Web.SessionMembers.MemberID != ContactMemberID)
                {
                    Contacts contact = new Contacts();
                    contact.Where.MemberID.Value = Web.SessionMembers.MemberID;
                    contact.Where.ContactMemberID.Value = ContactMemberID;
                    contact.Where.ContactStatusID.Value = 4;
                    contact.Query.Load();
                    if (contact.RowCount > 0)
                    {
                        if (AllowBlockUnblockContact(contact.ContactID))
                        {
                            result = true;
                        }

                    }
                }
            }

        }
        catch (Exception exp)
        {
            //Log.Write("mycontacterror", exp.GetBaseException().ToString(), exp);
            Web.LogError(exp);
        }
        return result;
    }
    public static void WriteMemberStatusChangeLog(int MemberID, int MemberStatusID, string UpdatedBy)
    {
        try
        {
            MemberStatusLog log = new MemberStatusLog();
            log.AddNew();
            log.MemberID = MemberID;
            log.MemberStatusID = MemberStatusID;
            log.StatusDate = DateTime.Now;
            log.StatusUpdatedBy = UpdatedBy;
            log.Save();
        }
        catch (Exception exp)
        {
            //Log.Write("WriteMemberStatusChangeLog", exp.GetBaseException().ToString(), exp);
            Web.LogError(exp);
        }
    }

    public static string GetContactType(int ContactTypeID)
    {
        if (ContactTypeID == 1)
            return "Client";
        else if (ContactTypeID == 2)
            return "Vendor";
        else
            return "Client/Vendor";
    }
    /// <summary>
    /// Returns color of profile name from configurations
    /// </summary>
    /// <param name="MemberID"></param>
    /// <param name="SessionMemberID">NULLABLE: if session member otherwise null</param>
    /// <returns></returns>
    public static string GetProfileColor(int MemberID, int? SessionMemberID)
    {
        string color = System.Configuration.ConfigurationManager.AppSettings["UnknownColor"];
        try
        {
            if (SessionMemberID.HasValue)
            {
                if (MemberID == SessionMemberID.Value)
                    color = System.Configuration.ConfigurationManager.AppSettings["MyColor"];
                else
                {
                    Contacts contact = new Contacts();
                    contact.Where.MemberID.Value = SessionMemberID.Value;
                    contact.Where.ContactMemberID.Value = MemberID;
                    contact.Where.ContactStatusID.Value = "1";
                    contact.Query.Load();
                    if (contact.RowCount > 0)
                    {
                        if (contact.ContactType == (int)ContactTypes.Client)
                            color = System.Configuration.ConfigurationManager.AppSettings["ClientColor"];
                        else if (contact.ContactType == (int)ContactTypes.Vendor)
                            color = System.Configuration.ConfigurationManager.AppSettings["VendorColor"];
                        else
                            color = System.Configuration.ConfigurationManager.AppSettings["ClientColor"];
                    }
                    //else
                    //{
                    //    contact = new Contacts();
                    //    contact.Where.ContactMemberID.Value = SessionMemberID.Value;
                    //    contact.Where.MemberID.Value = MemberID;
                    //    contact.Where.ContactStatusID.Value = "1";
                    //    contact.Query.Load();
                    //    if (contact.RowCount > 0)
                    //    {
                    //        if (contact.ContactType == (int)ContactTypes.Client)
                    //            color = System.Configuration.ConfigurationManager.AppSettings["VendorColor"];
                    //        else if (contact.ContactType == (int)ContactTypes.Vendor)
                    //            color = System.Configuration.ConfigurationManager.AppSettings["ClientColor"];
                    //        else
                    //            color = System.Configuration.ConfigurationManager.AppSettings["ClientColor"];
                    //    }
                    //}
                }
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
        return color;
    }
    /// <summary>
    /// Returns class of profile name
    /// </summary>
    /// <param name="MemberID"></param>
    /// <param name="SessionMemberID"></param>
    /// <returns></returns>
    public static string GetProfileClass(int MemberID, int? SessionMemberID)
    {
        string cssClass = "Unknown";
        try
        {
            if (SessionMemberID.HasValue)
            {
                if (MemberID == SessionMemberID.Value)
                    cssClass = "Me";
                else
                {
                    Contacts contact = new Contacts();
                    contact.Query.AddResultColumn(ContactsSchema.ContactType);
                    contact.Where.MemberID.Value = SessionMemberID.Value;
                    contact.Where.ContactMemberID.Value = MemberID;
                    contact.Where.ContactStatusID.Value = "1";
                    contact.Query.Load();
                    if (contact.RowCount > 0)
                    {
                        if (contact.ContactType == (int)ContactTypes.Client)
                            cssClass = "Clients";
                        else if (contact.ContactType == (int)ContactTypes.Vendor)
                            cssClass = "Vendors";
                        else
                            cssClass = "Unknown";
                    }

                }
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
        return cssClass;
    }
    public static string GetProfileClass(ContactTypes type)
    {
        string cssClass = "Unknown";
        try
        {
            if (type == ContactTypes.Client)
                cssClass = "Clients";
            else if (type == ContactTypes.Vendor)
                cssClass = "Vendors";
            else
                cssClass = "Unknown";
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
        return cssClass;
    }
    public static string GetBillboardClass(int MemberID, int? SessionMemberID)
    {
        string cssClass = "defaultBillboard";
        try
        {
            if (SessionMemberID.HasValue)
            {
                if (MemberID == SessionMemberID.Value)
                    cssClass = "defaultBillboard";
                else
                {
                    Contacts contact = new Contacts();
                    contact.Where.MemberID.Value = SessionMemberID.Value;
                    contact.Where.ContactMemberID.Value = MemberID;
                    contact.Where.ContactStatusID.Value = "1";
                    contact.Query.Load();
                    if (contact.RowCount > 0)
                    {
                        if (contact.ContactType == (int)ContactTypes.Client)
                            cssClass = "ClientBillboard";
                        else if (contact.ContactType == (int)ContactTypes.Vendor)
                            cssClass = "VendorBillboard";
                        else
                            cssClass = "defaultBillboard";
                    }
                    //else
                    //{
                    //    contact = new Contacts();
                    //    contact.Where.ContactMemberID.Value = SessionMemberID.Value;
                    //    contact.Where.MemberID.Value = MemberID;
                    //    contact.Where.ContactStatusID.Value = "1";
                    //    contact.Query.Load();
                    //    if (contact.RowCount > 0)
                    //    {
                    //        if (contact.ContactType == (int)ContactTypes.Client)
                    //            cssClass = "VendorBillboard";
                    //        else if (contact.ContactType == (int)ContactTypes.Vendor)
                    //            cssClass = "ClientBillboard";
                    //        else
                    //            cssClass = "defaultBillboard";
                    //    }
                    //}
                }
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
        return cssClass;
    }
    public static string GetBillboardClass(ContactTypes type)
    {
        string cssClass = "defaultBillboard";
        try
        {
            if (type == ContactTypes.Client)
                cssClass = "ClientBillboard";
            else if (type == ContactTypes.Vendor)
                cssClass = "VendorBillboard";
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
        return cssClass;
    }

    public static string GetContactTypeInverse(int ContactTypeID)
    {
        if (ContactTypeID == 2)
            return "Client";
        else if (ContactTypeID == 1)
            return "Vendor";
        else
            return "Client/Vendor";
    }

    public static string GetActivityType(int Type)
    {
        switch (Type)
        {
            case 1:
                return "buying";
            case 2:
                return "selling";
            default:
                return "buying/selling";
        }
    }
    public static string GetCleanHTML(string html)
    {
        string cleanHtml = html;
        try
        {
            cleanHtml = System.Text.RegularExpressions.Regex.Replace(html, "&lt;script.*?&gt;[\\s\\S]*?&lt;/.*?script&gt;", "", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            cleanHtml = System.Text.RegularExpressions.Regex.Replace(html, "&lt;applet.*?&gt;[\\s\\S]*?&lt;/.*?applet&gt;", "", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            cleanHtml = System.Text.RegularExpressions.Regex.Replace(html, "&lt;embed.*?&gt;[\\s\\S]*?&lt;/.*?embed&gt;", "", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            cleanHtml = System.Text.RegularExpressions.Regex.Replace(html, "&lt;object.*?&gt;[\\s\\S]*?&lt;/.*?object&gt;", "", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            cleanHtml = System.Text.RegularExpressions.Regex.Replace(html, "&lt;body.*?&gt;[\\s\\S]*?&lt;/.*?body&gt;", "", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            cleanHtml = System.Text.RegularExpressions.Regex.Replace(html, "&lt;frame.*?&gt;[\\s\\S]*?&lt;/.*?frame&gt;", "", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            cleanHtml = System.Text.RegularExpressions.Regex.Replace(html, "&lt;frameset.*?&gt;[\\s\\S]*?&lt;/.*?frameset&gt;", "", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            cleanHtml = System.Text.RegularExpressions.Regex.Replace(html, "&lt;html.*?&gt;[\\s\\S]*?&lt;/.*?html&gt;", "", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            cleanHtml = System.Text.RegularExpressions.Regex.Replace(html, "&lt;style.*?&gt;[\\s\\S]*?&lt;/.*?style&gt;", "", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            cleanHtml = System.Text.RegularExpressions.Regex.Replace(html, "&lt;iframe.*?&gt;[\\s\\S]*?&lt;/.*?iframe&gt;", "", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            cleanHtml = System.Text.RegularExpressions.Regex.Replace(html, "&lt;img.*?&gt;[\\s\\S]*?&lt;/.*?img&gt;", "", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            cleanHtml = System.Text.RegularExpressions.Regex.Replace(html, "&lt;layer.*?&gt;[\\s\\S]*?&lt;/.*?layer&gt;", "", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            cleanHtml = System.Text.RegularExpressions.Regex.Replace(html, "&lt;link.*?&gt;[\\s\\S]*?&lt;/.*?link&gt;", "", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            cleanHtml = System.Text.RegularExpressions.Regex.Replace(html, "&lt;ilayer.*?&gt;[\\s\\S]*?&lt;/.*?ilayer&gt;", "", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            cleanHtml = System.Text.RegularExpressions.Regex.Replace(html, "&lt;meta.*?&gt;[\\s\\S]*?&lt;/.*?meta&gt;", "", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
        }
        catch (Exception exp)
        {
            Web.LogError(exp);
        }
        return cleanHtml;
    }

    public static string GetRatingTypeByValue(RatingTypes type)
    {
        return type.ToString().Replace('_', ' ');
    }

    #region Activity Management

    #region Activity Logging
    public static int AddActivity(int ActivityID, StringDictionary templateKeys)
    {
        int ActivityLogID = 0;
        try
        {
            Activities activity = new Activities();
            VisualSoft.SystemManagement.TemplateManager templateManager = new VisualSoft.SystemManagement.TemplateManager();

            activity.LoadByPrimaryKey(ActivityID);
            if (activity != null)
            {
                string parsedTemplate = templateManager.ParseTemplate(activity.s_Template, templateKeys);

                MemberActivityLog log = new MemberActivityLog();
                log.AddNew();
                log.MemberID = Web.SessionMembers.MemberID;
                log.ActivityDate = DateTime.Now;
                log.ActivityID = activity.ActivityID;
                log.Description = parsedTemplate;
                log.Save();
                ActivityLogID = log.ActivityLogID;

                Members member = new Members();
                member.LoadByPrimaryKey(Web.SessionMembers.MemberID);
                member.LastActivityDate = DateTime.Now;
                member.Save();
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
        return ActivityLogID;
    }
    public static void AddActivityLog(int ActivityID, StringDictionary templateKeys)
    {
        try
        {
            Activities activity = new Activities();
            VisualSoft.SystemManagement.TemplateManager templateManager = new VisualSoft.SystemManagement.TemplateManager();

            activity.LoadByPrimaryKey(ActivityID);
            if (activity != null)
            {
                string parsedTemplate = templateManager.ParseTemplate(activity.s_Template, templateKeys);

                MemberActivityLog log = new MemberActivityLog();
                log.AddNew();
                log.MemberID = Web.SessionMembers.MemberID;
                log.ActivityDate = DateTime.Now;
                log.ActivityID = activity.ActivityID;
                log.Description = parsedTemplate;
                log.Save();

                Members member = new Members();
                member.LoadByPrimaryKey(Web.SessionMembers.MemberID);
                member.LastActivityDate = DateTime.Now;
                member.Save();
            }
        }
        catch (Exception ex)
        {
            //Log.Write("AddActivityLog", ex.GetBaseException().ToString(), ex);
            Web.LogError(ex);
        }
    }
    public static void AddActivityLog(int ActivityID, StringDictionary templateKeys, int ReferenceID)
    {
        try
        {
            Activities activity = new Activities();
            VisualSoft.SystemManagement.TemplateManager templateManager = new VisualSoft.SystemManagement.TemplateManager();

            activity.LoadByPrimaryKey(ActivityID);
            if (activity != null)
            {
                string parsedTemplate = templateManager.ParseTemplate(activity.s_Template, templateKeys);

                MemberActivityLog log = new MemberActivityLog();
                log.AddNew();
                log.MemberID = Web.SessionMembers.MemberID;
                log.ActivityDate = DateTime.Now;
                log.ActivityID = activity.ActivityID;
                log.Description = parsedTemplate;
                log.ReferenceID = ReferenceID;
                log.Save();

                Members member = new Members();
                member.LoadByPrimaryKey(Web.SessionMembers.MemberID);
                member.LastActivityDate = DateTime.Now;
                member.Save();
            }
        }
        catch (Exception ex)
        {
            //Log.Write("AddActivityLog", ex.GetBaseException().ToString(), ex);
            Web.LogError(ex);
        }
    }
    public static void AddActivityLog(int MemberID, int ActivityID, StringDictionary templateKeys, int ReferenceID)
    {
        try
        {
            Activities activity = new Activities();
            VisualSoft.SystemManagement.TemplateManager templateManager = new VisualSoft.SystemManagement.TemplateManager();

            activity.LoadByPrimaryKey(ActivityID);
            if (activity != null)
            {
                string parsedTemplate = templateManager.ParseTemplate(activity.s_Template, templateKeys);

                MemberActivityLog log = new MemberActivityLog();
                log.AddNew();
                log.MemberID = MemberID;
                log.ActivityDate = DateTime.Now;
                log.ActivityID = activity.ActivityID;
                log.Description = parsedTemplate;
                log.ReferenceID = ReferenceID;
                log.Save();

                Members member = new Members();
                member.LoadByPrimaryKey(MemberID);
                member.LastActivityDate = DateTime.Now;
                member.Save();
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }
    public static void AddActivityLog(int MemberID, int ActivityID, StringDictionary templateKeys, int ReferenceID, int TypeID, bool IsPosting)
    {
        try
        {
            Activities activity = new Activities();
            VisualSoft.SystemManagement.TemplateManager templateManager = new VisualSoft.SystemManagement.TemplateManager();

            activity.LoadByPrimaryKey(ActivityID);
            if (activity != null)
            {
                string parsedTemplate = templateManager.ParseTemplate(activity.s_Template, templateKeys);

                MemberActivityLog log = new MemberActivityLog();
                log.AddNew();
                log.MemberID = MemberID;
                log.ActivityDate = DateTime.Now;
                log.ActivityID = activity.ActivityID;
                log.Description = parsedTemplate;
                log.ReferenceID = ReferenceID;
                log.PostTypeID = TypeID;
                log.s_IsPosting = (IsPosting) ? "1" : "0";
                log.Save();

                Members member = new Members();
                member.LoadByPrimaryKey(MemberID);
                member.LastActivityDate = DateTime.Now;
                member.Save();
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }

    public static void AddActivityLog(int MemberID, int ActivityID, StringDictionary templateKeys, int ReferenceID, int TypeID, bool IsPosting, int privacyTypeID)
    {
        try
        {
            Activities activity = new Activities();
            VisualSoft.SystemManagement.TemplateManager templateManager = new VisualSoft.SystemManagement.TemplateManager();

            activity.LoadByPrimaryKey(ActivityID);
            if (activity != null)
            {
                string parsedTemplate = templateManager.ParseTemplate(activity.s_Template, templateKeys);

                MemberActivityLog log = new MemberActivityLog();
                log.AddNew();
                log.MemberID = MemberID;
                log.ActivityDate = DateTime.Now;
                log.ActivityID = activity.ActivityID;
                log.Description = parsedTemplate;
                log.ReferenceID = ReferenceID;
                log.PostTypeID = TypeID;
                log.s_IsPosting = (IsPosting) ? "1" : "0";
                log.PrivacyTypeID = privacyTypeID;
                log.Save();

                Members member = new Members();
                member.LoadByPrimaryKey(MemberID);
                member.LastActivityDate = DateTime.Now;
                member.Save();
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }


    public static void AddActivityLog(int MemberID, int ActivityID, StringDictionary templateKeys, int ReferenceID, int RelatedToContact)
    {
        try
        {
            Activities activity = new Activities();
            VisualSoft.SystemManagement.TemplateManager templateManager = new VisualSoft.SystemManagement.TemplateManager();

            activity.LoadByPrimaryKey(ActivityID);
            if (activity != null)
            {
                string parsedTemplate = templateManager.ParseTemplate(activity.s_Template, templateKeys);

                MemberActivityLog log = new MemberActivityLog();
                log.AddNew();
                log.MemberID = MemberID;
                log.ActivityDate = DateTime.Now;
                log.ActivityID = activity.ActivityID;
                log.Description = parsedTemplate;
                log.ReferenceID = ReferenceID;
                log.RelatedToContact = RelatedToContact;
                log.Save();

                Members member = new Members();
                member.LoadByPrimaryKey(MemberID);
                member.LastActivityDate = DateTime.Now;
                member.Save();
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }
    public static void AddPrivateActivityLog(int ActivityID, StringDictionary templateKeys, int PrivateTo)
    {
        try
        {
            Activities activity = new Activities();
            VisualSoft.SystemManagement.TemplateManager templateManager = new VisualSoft.SystemManagement.TemplateManager();

            activity.LoadByPrimaryKey(ActivityID);
            if (activity != null)
            {
                string parsedTemplate = templateManager.ParseTemplate(activity.s_Template, templateKeys);

                MemberActivityLog log = new MemberActivityLog();
                log.AddNew();
                log.MemberID = Web.SessionMembers.MemberID;
                log.ActivityDate = DateTime.Now;
                log.ActivityID = activity.ActivityID;
                log.Description = parsedTemplate;
                log.IsPrivate = 1;
                log.Save();

                MemberPrivateActivityLog plog = new MemberPrivateActivityLog();
                plog.AddNew();
                plog.ActivityLogID = log.ActivityLogID;
                plog.PrivateTo = PrivateTo;
                plog.Save();

                Members member = new Members();
                member.LoadByPrimaryKey(Web.SessionMembers.MemberID);
                member.LastActivityDate = DateTime.Now;
                member.Save();
            }
        }
        catch (Exception ex)
        {
            //Log.Write("AddPrivateActivityLog", ex.GetBaseException().ToString(), ex);
            Web.LogError(ex);
        }
    }
    public static void AddPrivateActivityLog(int ActivityID, StringDictionary templateKeys, int PrivateTo, int ReferenceID)
    {
        try
        {
            Activities activity = new Activities();
            VisualSoft.SystemManagement.TemplateManager templateManager = new VisualSoft.SystemManagement.TemplateManager();

            activity.LoadByPrimaryKey(ActivityID);
            if (activity != null)
            {
                string parsedTemplate = templateManager.ParseTemplate(activity.s_Template, templateKeys);

                MemberActivityLog log = new MemberActivityLog();
                log.AddNew();
                log.MemberID = Web.SessionMembers.MemberID;
                log.ActivityDate = DateTime.Now;
                log.ActivityID = activity.ActivityID;
                log.Description = parsedTemplate;
                log.IsPrivate = 1;
                log.ReferenceID = ReferenceID;
                log.Save();

                MemberPrivateActivityLog plog = new MemberPrivateActivityLog();
                plog.AddNew();
                plog.ActivityLogID = log.ActivityLogID;
                plog.PrivateTo = PrivateTo;
                plog.Save();

                Members member = new Members();
                member.LoadByPrimaryKey(Web.SessionMembers.MemberID);
                member.LastActivityDate = DateTime.Now;
                member.Save();
            }
        }
        catch (Exception ex)
        {
            //Log.Write("AddPrivateActivityLog", ex.GetBaseException().ToString(), ex);
            Web.LogError(ex);
        }
    }
    public static void AddPrivateActivityLog(int ActivityID, StringDictionary templateKeys, int PrivateTo, int ReferenceID, int RelatedToContact)
    {
        try
        {
            Activities activity = new Activities();
            VisualSoft.SystemManagement.TemplateManager templateManager = new VisualSoft.SystemManagement.TemplateManager();

            activity.LoadByPrimaryKey(ActivityID);
            if (activity != null)
            {
                string parsedTemplate = templateManager.ParseTemplate(activity.s_Template, templateKeys);

                MemberActivityLog log = new MemberActivityLog();
                log.AddNew();
                log.MemberID = Web.SessionMembers.MemberID;
                log.ActivityDate = DateTime.Now;
                log.ActivityID = activity.ActivityID;
                log.Description = parsedTemplate;
                log.IsPrivate = 1;
                log.ReferenceID = ReferenceID;
                log.RelatedToContact = RelatedToContact;
                log.Save();

                MemberPrivateActivityLog plog = new MemberPrivateActivityLog();
                plog.AddNew();
                plog.ActivityLogID = log.ActivityLogID;
                plog.PrivateTo = PrivateTo;
                plog.Save();

                Members member = new Members();
                member.LoadByPrimaryKey(Web.SessionMembers.MemberID);
                member.LastActivityDate = DateTime.Now;
                member.Save();
            }
        }
        catch (Exception ex)
        {
            //Log.Write("AddPrivateActivityLog", ex.GetBaseException().ToString(), ex);
            Web.LogError(ex);
        }
    }
    public static void AddPrivateActivityLog(int MemberID, int ActivityID, StringDictionary templateKeys, int PrivateTo, int ReferenceID, int RelatedToContact)
    {
        try
        {
            Activities activity = new Activities();
            VisualSoft.SystemManagement.TemplateManager templateManager = new VisualSoft.SystemManagement.TemplateManager();

            activity.LoadByPrimaryKey(ActivityID);
            if (activity != null)
            {
                string parsedTemplate = templateManager.ParseTemplate(activity.s_Template, templateKeys);

                MemberActivityLog log = new MemberActivityLog();
                log.AddNew();
                log.MemberID = MemberID;
                log.ActivityDate = DateTime.Now;
                log.ActivityID = activity.ActivityID;
                log.Description = parsedTemplate;
                log.IsPrivate = 1;
                log.ReferenceID = ReferenceID;
                log.RelatedToContact = RelatedToContact;
                log.Save();

                MemberPrivateActivityLog plog = new MemberPrivateActivityLog();
                plog.AddNew();
                plog.ActivityLogID = log.ActivityLogID;
                plog.PrivateTo = PrivateTo;
                plog.Save();

                Members member = new Members();
                member.LoadByPrimaryKey(MemberID);
                member.LastActivityDate = DateTime.Now;
                member.Save();
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }

    public static void AddActivityLog(int MemberID, int ActivityID, StringDictionary templateKeys, int ReferenceID, int TypeID, bool IsPosting, bool isPrivate)
    {
        try
        {
            Activities activity = new Activities();
            VisualSoft.SystemManagement.TemplateManager templateManager = new VisualSoft.SystemManagement.TemplateManager();

            activity.LoadByPrimaryKey(ActivityID);
            if (activity != null)
            {
                string parsedTemplate = templateManager.ParseTemplate(activity.s_Template, templateKeys);

                MemberActivityLog log = new MemberActivityLog();
                log.AddNew();
                log.MemberID = MemberID;
                log.ActivityDate = DateTime.Now;
                log.ActivityID = activity.ActivityID;
                log.Description = parsedTemplate;
                log.ReferenceID = ReferenceID;
                log.PostTypeID = TypeID;
                log.IsPrivate = (byte)(isPrivate ? 1 : 0);
                log.s_IsPosting = (IsPosting) ? "1" : "0";
                log.Save();

                Members member = new Members();
                member.LoadByPrimaryKey(MemberID);
                member.LastActivityDate = DateTime.Now;
                member.Save();
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }
    #endregion

    /// <summary>
    /// Summarize the feed if there's repetition
    /// </summary>
    /// <param name="dt"></param>
    /// <returns></returns>
    public static DataTable SummarizeFeed(DataTable dt)
    {
        DataTable temp = new DataTable();
        temp = dt.Copy();
        temp.Rows.Clear();
        DataTable dtable = new DataTable();
        try
        {
            Hashtable hTable = new Hashtable();
            //temp.Columns.Add("Parent", typeof(int));
            foreach (DataRow row in dt.Rows)
            {
                DataView view = temp.DefaultView;
                view.RowFilter = "ActivityID = 15 AND MemberID = " + row["MemberID"].ToString() + " AND ReferenceID = " + row["ReferenceID"].ToString();
                dtable = view.ToTable();
                if (dtable.Rows.Count <= 0)
                {
                    //if row doest belong to activity = 15
                    temp.ImportRow(row);
                    //temp.Rows[temp.Rows.Count - 1]["Parent"] = 0;
                }
                else
                {
                    if (Web.IsMemberSession && (int)row["MemberID"] == Web.SessionMembers.MemberID)
                    {
                        //temp.ImportRow(row);
                        //temp.Rows[temp.Rows.Count - 1]["Parent"] = dtable.Rows[0]["ActivityLogID"];
                        if (!String.IsNullOrEmpty(row["RelatedToContact"].ToString()))
                        {
                            Members member = new Members();
                            member.LoadByPrimaryKey((int)row["RelatedToContact"]);
                            if (member.RowCount > 0)
                            {
                                if (hTable.ContainsKey((int)dtable.Rows[0]["ActivityLogID"]))
                                    hTable[(int)dtable.Rows[0]["ActivityLogID"]] += "," + member.UserName;
                                else
                                    hTable.Add((int)dtable.Rows[0]["ActivityLogID"], member.UserName);
                            }
                        }
                    }
                    else
                    {
                        temp.ImportRow(row);
                    }
                }
            }
            foreach (DataRow row in temp.Rows)
            {
                if (hTable.ContainsKey((int)row["ActivityLogID"]))
                {
                    if ((int)row["ActivityID"] == 15)
                    {
                        string itemname = row["Description"].ToString().Substring(row["Description"].ToString().LastIndexOf("<a"), row["Description"].ToString().Length - row["Description"].ToString().LastIndexOf("<a"));
                        row["Description"] = " posted a link to all contacts for:" + itemname;
                    }
                }
            }
            temp.DefaultView.RowFilter = "";
        }
        catch (Exception ex) { Web.LogError(ex); }
        return temp;
    }
    /// <summary>
    /// Get activity's description according to the ActivityID
    /// </summary>
    /// <param name="IsLiveFeed"></param>
    /// <param name="ActivityLogID"></param>
    /// <param name="ActivityID"></param>
    /// <param name="XMLDetails"></param>
    /// <param name="Description"></param>
    /// <param name="ReferenceID"></param>
    /// <param name="MemberID"></param>
    /// <param name="activityDate"></param>
    /// <returns></returns>
    public static string GetActivityDescription(bool IsLiveFeed, string ActivityLogID, string ActivityID, string XMLDetails, string Description, string ReferenceID, string MemberID, string activityDate, string s_PostTypeID)
    {
        XmlNodeList _nodelist;
        string description = Description;
        try
        {
            StringBuilder viewdetail = new StringBuilder();
            switch (ActivityID)
            {
                case "2":
                case "15":
                    {
                        #region case 2 & 15
                        if (!String.IsNullOrEmpty(XMLDetails))
                        {
                            string img = "../../ePage/ImageViewer.ashx?Action=LotDefaultThumbnail&RecordID=" + Secure.Encrypt(ReferenceID);
                            viewdetail.Append("<table width=\"350\" cellspacing=\"0\" cellpadding=\"2\"> ");

                            bool SellWholeLot = false;
                            string lotPrice = "0";
                            string CurrencyID = "0";

                            var xdoc = new XmlDocument();
                            xdoc.LoadXml("<Items>" + XMLDetails + "</Items>");
                            _nodelist = xdoc.SelectNodes("Items/Details");
                            string url = "../../marketplace/ItemDetails.aspx?Action=View&RecordID=" + Secure.Encrypt(ReferenceID);
                            //viewdetail.Append("<tr><th align=\"left\" style=\"font-size:10px;\" width=\"50%\">Item</th><th align=\"left\" style=\"font-size:10px;\" width=\"25%\">Quantity</th><th align=\"left\" style=\"font-size:10px;\" width=\"25%\">Price</th></tr>");
                            foreach (XmlNode node in _nodelist)
                            {
                                if (node.Attributes[5].Value == "1")// AcceptBids
                                    viewdetail.Append("<tr><td align=\"left\" width=\"50%\" style=\"border-bottom:solid 1px #A8A8A8;font-size: 7.5pt;\"> " + node.Attributes[1].Value + "</span></td><td align=\"left\" width=\"15%\" style=\"border-bottom:solid 1px #A8A8A8;\"><span style=\" font-size: 7.5pt;\">" + node.Attributes[2].Value + "</span></td><td align=\"left\" width=\"25%\" style=\"border-bottom:solid 1px #A8A8A8;\"><span style=\" font-size: 7.5pt;\">Accept Bids</span></td><td align=\"right\" style=\"width:10%;border-bottom:solid 1px #A8A8A8;font-size: 7.5pt;\"><a href=\"" + url + "\">view>></a></td></tr> ");
                                else if (node.Attributes[6].Value == "0")// Sell Whole Lot
                                {
                                    SellWholeLot = true;
                                    lotPrice = node.Attributes[7].Value;
                                    CurrencyID = node.Attributes[8].Value;
                                    viewdetail.Append("<tr><td align=\"left\" width=\"50%\" style=\"border-bottom:solid 1px #A8A8A8;font-size: 7.5pt;\"> " + node.Attributes[1].Value + "</span></td><td align=\"left\" width=\"10%\" style=\"border-bottom:solid 1px #A8A8A8;\"><span style=\" font-size: 7.5pt;\">" + node.Attributes[2].Value + "</span></td><td align=\"right\" style=\"width:15%;border-bottom:solid 1px #A8A8A8;font-size: 7.5pt;\"><a href=\"" + url + "\">view>></a></td></tr> ");
                                }
                                else
                                    viewdetail.Append("<tr><td align=\"left\" width=\"50%\" style=\"border-bottom:solid 1px #A8A8A8;font-size: 7.5pt;\"> " + node.Attributes[1].Value + "</span></td><td align=\"left\" width=\"10%\" style=\"border-bottom:solid 1px #A8A8A8;\"><span style=\" font-size: 7.5pt;\">" + node.Attributes[2].Value + "</span></td><td align=\"right\" width=\"25%\" style=\"border-bottom:solid 1px #A8A8A8;\"><span style=\" font-size: 7.5pt;\">" + Web.GetCurrencySymbol(node.Attributes[3].Value) + node.Attributes[4].Value + " " + Web.GetCurrencyCode(node.Attributes[3].Value) + "</span></td><td align=\"right\" style=\"width:15%;border-bottom:solid 1px #A8A8A8;font-size: 7.5pt;\"><a href=\"" + url + "\">view>></a></td></tr> ");
                            }
                            if (SellWholeLot)
                                viewdetail.Append("<tr><td colspan=\"2\" align=\"right\" style=\" font-size: 7.5pt;\">Total Price:</span></td><td width=\"25%\"><span style=\" font-size: 7.5pt;\">" + Web.GetCurrencySymbol(CurrencyID) + lotPrice + " " + Web.GetCurrencyCode(CurrencyID) + "</span></td><td></td></tr> ");
                            viewdetail.Append("</table>");
                            description = "<table><tr><td valign=\"top\"><img alt=\"Details\" src=\"" + img + "\" /></td><td valign=\"top\">" + viewdetail.ToString() + "</td></tr></table>";
                        }
                        #endregion
                        break;
                    }
                case "3":
                    {
                        #region case 3
                        if (!String.IsNullOrEmpty(XMLDetails))
                        {
                            string img = "../../ePage/ImageViewer.ashx?Action=ItemDefaultThumbnail&RecordID=" + Secure.Encrypt(ReferenceID);
                            viewdetail.Append("<table width=\"350\" cellspacing=\"0\" cellpadding=\"2\">");

                            var xdoc = new XmlDocument();
                            xdoc.LoadXml(XMLDetails);
                            _nodelist = xdoc.SelectNodes("Details");
                            string url = "../WTB/ViewDetails.aspx?Action=View&RecordID=" + Secure.Encrypt(ReferenceID);
                            viewdetail.Append("<tr><td align=\"left\" width=\"50%\" style=\"border-bottom:solid 1px #A8A8A8;font-size: 7.5pt;\">" + _nodelist[0].Attributes[1].Value + "</td><td align=\"left\" width=\"10%\" style=\"border-bottom:solid 1px #A8A8A8;font-size: 7.5pt;\">" + _nodelist[0].Attributes[2].Value + "</td><td align=\"right\" width=\"25%\" style=\"border-bottom:solid 1px #A8A8A8;font-size: 7.5pt;\">" + ((Convert.ToDecimal(_nodelist[0].Attributes[3].Value) > 0) ? "$" + _nodelist[0].Attributes[3].Value + " USD" : "Open for Offers") + "</td><td align=\"right\" style=\"width:15%;border-bottom:solid 1px #A8A8A8;font-size: 7.5pt;\"><a href=\"" + url + "\">view>></a></td></tr> ");
                            viewdetail.Append("</table>");
                            description = "<table><tr><td valign=\"top\"><img alt=\"Details\" src=\"" + img + "\" /></td><td valign=\"top\">" + viewdetail.ToString() + "</td></tr></table>";
                        }
                        #endregion
                        break;
                    }
                case "4":
                case "19":
                    {
                        #region case 4 & 19
                        try
                        {
                            var xdoc = new XmlDocument();
                            xdoc.LoadXml(XMLDetails);
                            _nodelist = xdoc.SelectNodes("Details");
                            viewdetail.Append("<div id='div_short_msg_");
                            viewdetail.Append(ReferenceID);
                            viewdetail.Append("' style=\"display: block;padding:5px;text-align: justify; font-size: 7.5pt; font-weight: bold;width:98% !important;\">");
                            viewdetail.Append(Web.GetShortMessage(_nodelist[0].Attributes["Message"].Value, ReferenceID, "", null));
                            viewdetail.Append("</div><div id='div_full_msg_");
                            viewdetail.Append(ReferenceID);
                            viewdetail.Append("' style=\"display: none;padding:5px;width:98%; !important\"><table class=\"feed_Comments\" style=\"width:100% !important;\"><tr><td>");
                            viewdetail.Append("<div style=\"width:100%;float: left; display: inline; text-align: justify; padding: 0; font-size: 8pt;");
                            viewdetail.Append("font-weight: bold;\">");
                            viewdetail.Append("&nbsp;");
                            viewdetail.Append(Web.GetFullMessage(_nodelist[0].Attributes["Message"].Value, ReferenceID));
                            viewdetail.Append("</div></td></tr></table><br />");
                            viewdetail.Append("<a href=\"#\" onclick=\"ShowHide('div_full_msg_");
                            viewdetail.Append(ReferenceID);
                            viewdetail.Append("', 'div_short_msg_");
                            viewdetail.Append(ReferenceID);
                            viewdetail.Append("')\" style=\"font-size:9px;font-weight: bold;\">View less >></a></div>");
                            description = viewdetail.ToString();
                        }
                        catch (Exception ex)
                        {
                            string str = ex.Message;
                            var xdoc = new XmlDocument();
                            xdoc.LoadXml("<Messages>" + XMLDetails + "</Messages>");
                            _nodelist = xdoc.SelectNodes("Messages/Details");
                            if (_nodelist.Count > 0)
                            {
                                viewdetail.Append("<div id='div_short_msg_");
                                viewdetail.Append(ReferenceID);
                                viewdetail.Append("' style=\"display: block;padding:5px;text-align: justify; font-size: 7.5pt; font-weight: bold;width:98% !important;\">");
                                if (IsLiveFeed && ActivityID == "19")
                                {
                                    ContactMessages message = new ContactMessages();
                                    message.LoadByPrimaryKey(Convert.ToInt32(ReferenceID));
                                    if (message.RowCount > 0)
                                    {
                                        viewdetail.Append(Web.GetShortMessage(message.Message, ReferenceID, "", null));
                                        viewdetail.Append("</div><div id='div_full_msg_");
                                        viewdetail.Append(ReferenceID);
                                        viewdetail.Append("' style=\"display: none;padding:5px;width:98% !important;\"><table class=\"feed_Comments\" style=\"width:100% !important;\"><tr><td>");
                                        viewdetail.Append("<div style=\"width:100% !important;float: left; display: inline; text-align: justify; padding: 0; font-size: 7.5pt;");
                                        viewdetail.Append("font-weight: bold;\">");
                                        viewdetail.Append("&nbsp;");
                                        viewdetail.Append(Web.GetFullMessage(message.Message, ReferenceID));
                                    }
                                }
                                else
                                {
                                    viewdetail.Append(Web.GetShortMessage(_nodelist[0].Attributes["Message"].Value, ReferenceID, "", null));
                                    viewdetail.Append("</div><div id='div_full_msg_");
                                    viewdetail.Append(ReferenceID);
                                    viewdetail.Append("' style=\"display: none;padding:5px;width:98% !important;\"><table class=\"feed_Comments\" style=\"width:100% !important;\"><tr><td>");
                                    viewdetail.Append("<div style=\"width:100% !important;float: left; display: inline; text-align: justify; padding: 0; font-size: 8pt;");
                                    viewdetail.Append("font-weight: bold;\">");
                                    viewdetail.Append("&nbsp;");
                                    viewdetail.Append(Web.GetFullMessage(_nodelist[0].Attributes["Message"].Value, ReferenceID));
                                }
                                viewdetail.Append("</div></td></tr></table><br />");
                                viewdetail.Append("<a href=\"#\" onclick=\"ShowHide('div_full_msg_");
                                viewdetail.Append(ReferenceID);
                                viewdetail.Append("', 'div_short_msg_");
                                viewdetail.Append(ReferenceID);
                                viewdetail.Append("')\" style=\"font-size:9px;font-weight:bold;\">View less >></a></div>");
                                description = viewdetail.ToString();
                            }
                            else
                            {
                                ContactMessages message = new ContactMessages();
                                message.LoadByPrimaryKey(Convert.ToInt32(ReferenceID));
                                if (message.RowCount > 0)
                                {
                                    viewdetail.Append("<div id='div_short_msg_");
                                    viewdetail.Append(ReferenceID);
                                    viewdetail.Append("' style=\"display: block;padding:5px;text-align: justify; font-size: 7.5pt; font-weight: bold;width:98% !important;\">");
                                    viewdetail.Append(Web.GetShortMessage(message.Message, ReferenceID, "", null));
                                    viewdetail.Append("</div><div id='div_full_msg_");
                                    viewdetail.Append(ReferenceID);
                                    viewdetail.Append("' style=\"display: none;padding:5px;width:98% !important;\"><table class=\"feed_Comments\" style=\"width:100% !important;\"><tr><td>");
                                    viewdetail.Append("<div style=\"width:100% !important;float: left; display: inline; text-align: justify; padding: 0; font-size: 8pt;");
                                    viewdetail.Append("font-weight: bold;\">");
                                    viewdetail.Append("&nbsp;");
                                    viewdetail.Append(Web.GetFullMessage(message.Message, ReferenceID));
                                    viewdetail.Append("</div></td></tr></table><br />");
                                    viewdetail.Append("<a href=\"#\" onclick=\"ShowHide('div_full_msg_");
                                    viewdetail.Append(ReferenceID);
                                    viewdetail.Append("', 'div_short_msg_");
                                    viewdetail.Append(ReferenceID);
                                    viewdetail.Append("')\" style=\"font-size:9px;font-weight:bold;\">View less >></a></div>");
                                    description = viewdetail.ToString();
                                }
                            }
                        }
                        #endregion
                        break;
                    }
                case "5":
                case "39":
                    {
                        #region case 5 & 39
                        string Message = description, members = "", pattern = @"#separator#", value = "";
                        if (Description.Contains("#separator#"))
                        {
                            string[] substrings = Regex.Split(Description, pattern);
                            if (substrings.Length > 0)
                            {
                                Message = substrings[0];
                                if (substrings.Length > 1)
                                {
                                    members = substrings[1];
                                    if (members.Contains("#memberid#"))
                                    {
                                        Regex regex = new Regex("\\#memberid#(.*?)\\#endmemberid#", RegexOptions.IgnoreCase);
                                        Match match = regex.Match(members);
                                        members = "";
                                        while (match.Success)
                                        {
                                            value = match.Value.Substring(10, match.Value.Length - 23);
                                            if (!String.IsNullOrEmpty(value))
                                            {
                                                if (Web.IsMemberSession)
                                                {
                                                    if (Web.SessionMembers.MemberID != Convert.ToInt32(value))
                                                    {
                                                        Members member = new Members();
                                                        member.LoadByPrimaryKey(Convert.ToInt32(value));
                                                        members += "<a href=\"/Contacts/ViewProfile.aspx?Action=View&RecordID=" + Secure.Encrypt(member.MemberID) + "\"><span class=\"" + Web.GetProfileClass(member.MemberID, Web.SessionMembers.MemberID) + "\">" + member.UserName + "</span></a>&nbsp;|&nbsp;";
                                                    }
                                                }
                                                else
                                                {
                                                    Members member = new Members();
                                                    member.LoadByPrimaryKey(Convert.ToInt32(value));
                                                    members += "<a href=\"/Contacts/ViewProfile.aspx?Action=View&RecordID=" + Secure.Encrypt(member.MemberID) + "\"><span class=\"Unknown\">" + member.UserName + "</span></a>&nbsp;|&nbsp;";
                                                }
                                            }
                                            match = match.NextMatch();
                                        }
                                    }
                                    if (members.Length > 13)
                                        members = members.Remove(members.LastIndexOf("&nbsp;|&nbsp;"));
                                }
                            }
                        }

                        viewdetail.Append("<div id='div_short_msg_");
                        viewdetail.Append(ActivityLogID);
                        viewdetail.Append("' style=\"width:100%;display: block;padding:5px;text-align: justify; font-size: 7.5pt; font-weight: bold;\">");
                        if (!String.IsNullOrEmpty(members))
                        {
                            viewdetail.Append("To: <font style=\"font-weight:normal;\">");
                            viewdetail.Append(members);
                            viewdetail.Append("</font><br />");
                        }
                        viewdetail.Append(Web.GetShortMessage(Message, ReferenceID, "", ActivityLogID));
                        viewdetail.Append("</div><div id='div_full_msg_");
                        viewdetail.Append(ActivityLogID);
                        viewdetail.Append("' style=\"width:98%;display: none;padding:5px;\"><table width=\"100%\" class=\"feed_Comments\"><tr><td>");
                        viewdetail.Append("<div style=\"width:100%;float: left; display: inline; text-align: justify; padding: 0; font-size: 8pt;");
                        viewdetail.Append("font-weight: bold;\">");
                        viewdetail.Append("&nbsp;");
                        viewdetail.Append(Web.GetFullMessage(Message, ReferenceID));
                        viewdetail.Append("</div></td></tr></table><br />");
                        viewdetail.Append("<a href=\"#\" onclick=\"ShowHide('div_full_msg_");
                        viewdetail.Append(ActivityLogID);
                        viewdetail.Append("', 'div_short_msg_");
                        viewdetail.Append(ActivityLogID);
                        viewdetail.Append("')\" style=\"font-size:9px;font-weight:bold;\">View less >></a></div>");
                        description = viewdetail.ToString();
                        #endregion
                        break;
                    }
                case "11":
                    {
                        #region case 11
                        if (!String.IsNullOrEmpty(XMLDetails))
                        {
                            int SellerID = 0;
                            Lots lot = new Lots();
                            try
                            {
                                var xdoc = new XmlDocument();
                                xdoc.LoadXml(XMLDetails);
                                _nodelist = xdoc.SelectNodes("Details");

                                lot.LoadByPrimaryKey(Convert.ToInt32(_nodelist[0].Attributes[0].Value));
                                if (lot.RowCount > 0)
                                    SellerID = lot.MemberID;

                                string url = (!Web.IsMemberSession) ? "../DealingFloor/DealingFloor.aspx" : (((SellerID == Web.SessionMembers.MemberID) ? "../DealingFloor/Default.aspx?Action=" + ((_nodelist[0].Attributes[5].Value == "0") ? "ViewItemOffers" : "View") + "&RecordID=" + Secure.Encrypt(_nodelist[0].Attributes[0].Value) : "../DealingFloor/DealingFloor.aspx?Action=" + ((_nodelist[0].Attributes[5].Value == "0") ? "LotItemOffers" : "LotOffers")));
                                string img = "../../ePage/ImageViewer.ashx?Action=LotDefaultThumbnail&RecordID=" + Secure.Encrypt(_nodelist[0].Attributes[0].Value);
                                viewdetail.Append("<table width=\"350\" cellspacing=\"0\" cellpadding=\"2\">");
                                viewdetail.Append("<tr><td align=\"left\" width=\"50%\" style=\"border-bottom:solid 1px #A8A8A8;font-size: 7.5pt;\">" + _nodelist[0].Attributes[2].Value + "</td><td align=\"left\" width=\"10%\" style=\"border-bottom:solid 1px #A8A8A8;font-size: 7.5pt;\">" + _nodelist[0].Attributes[4].Value + "</td><td align=\"right\" width=\"25%\" style=\"border-bottom:solid 1px #A8A8A8;font-size: 7.5pt;\">$" + _nodelist[0].Attributes[3].Value + " USD</td><td align=\"right\" style=\"width:15%;border-bottom:solid 1px #A8A8A8;font-size: 7.5pt;\"><a href=\"" + url + "\">view>></a></td></tr> ");
                                viewdetail.Append("</table>");
                                description = "<table><tr><td valign=\"top\"><img alt=\"Details\" src=\"" + img + "\" /></td><td valign=\"top\">" + viewdetail.ToString() + "</td></tr></table>";
                            }
                            catch (Exception ex)
                            {
                                string str = ex.Message;
                                string url, img = "";
                                var xdoc = new XmlDocument();
                                xdoc.LoadXml("<Items>" + XMLDetails + "</Items>");
                                _nodelist = xdoc.SelectNodes("Items/Details");

                                lot.LoadByPrimaryKey(Convert.ToInt32(_nodelist[0].Attributes[0].Value));
                                if (lot.RowCount > 0)
                                    SellerID = lot.MemberID;

                                viewdetail.Append("<table width=\"350\" cellspacing=\"0\" cellpadding=\"2\">");
                                foreach (XmlNode node in _nodelist)
                                {
                                    url = (!Web.IsMemberSession) ? "../DealingFloor/DealingFloor.aspx" : (((SellerID == Web.SessionMembers.MemberID) ? "../DealingFloor/Default.aspx?Action=" + ((node.Attributes[5].Value == "0") ? "ViewItemOffers" : "View") + "&RecordID=" + Secure.Encrypt(node.Attributes[0].Value) : "../DealingFloor/DealingFloor.aspx?Action=" + ((node.Attributes[5].Value == "0") ? "LotItemOffers" : "LotOffers")));
                                    img = "../../ePage/ImageViewer.ashx?Action=LotDefaultThumbnail&RecordID=" + Secure.Encrypt(node.Attributes[0].Value);
                                    viewdetail.Append("<tr><td align=\"left\" width=\"50%\" style=\"border-bottom:solid 1px #A8A8A8;font-size: 7.5pt;\">" + node.Attributes[2].Value + "</td><td align=\"left\" width=\"10%\" style=\"border-bottom:solid 1px #A8A8A8;font-size: 7.5pt;\">" + node.Attributes[4].Value + "</td><td align=\"right\" width=\"25%\" style=\"border-bottom:solid 1px #A8A8A8;font-size: 7.5pt;\">" + ((node.Attributes[5].Value == "0") ? node.Attributes[3].Value : "$" + node.Attributes[6].Value) + " USD</td><td align=\"right\" style=\"width:15%;border-bottom:solid 1px #A8A8A8;font-size: 7.5pt;\"><a href=\"" + url + "\">view>></a></td></tr> ");
                                }
                                viewdetail.Append("</table>");
                                description = "<table><tr><td valign=\"top\"><img alt=\"Details\" src=\"" + img + "\" /></td><td valign=\"top\">" + viewdetail.ToString() + "</td></tr></table>";
                            }
                        }
                        else
                            description = "";
                        #endregion
                        break;
                    }
                case "12":
                    {
                        #region case 12
                        if (!String.IsNullOrEmpty(XMLDetails))
                        {
                            int SellerID = 0;
                            Lots lot = new Lots();

                            try
                            {
                                var xdoc = new XmlDocument();
                                xdoc.LoadXml(XMLDetails);
                                _nodelist = xdoc.SelectNodes("Details");

                                lot.LoadByPrimaryKey(Convert.ToInt32(_nodelist[0].Attributes[0].Value));
                                if (lot.RowCount > 0)
                                    SellerID = lot.MemberID;

                                string url = (!Web.IsMemberSession) ? "../DealingFloor/DealingFloor.aspx" : (((SellerID == Web.SessionMembers.MemberID) ? "../DealingFloor/Default.aspx?Action=" + ((_nodelist[0].Attributes[5].Value == "0") ? "ViewItemOffers" : "View") + "&RecordID=" + Secure.Encrypt(_nodelist[0].Attributes[0].Value) : "../DealingFloor/DealingFloor.aspx?Action=" + ((_nodelist[0].Attributes[5].Value == "0") ? "LotItemOffers" : "LotOffers")));
                                string img = "../../ePage/ImageViewer.ashx?Action=LotDefaultThumbnail&RecordID=" + Secure.Encrypt(_nodelist[0].Attributes[0].Value);
                                viewdetail.Append("<table width=\"350\" cellspacing=\"0\" cellpadding=\"2\">");
                                viewdetail.Append("<tr><td align=\"left\" width=\"50%\" style=\"border-bottom:solid 1px #A8A8A8;font-size: 7.5pt;\">" + _nodelist[0].Attributes[2].Value + "</td><td align=\"left\" width=\"10%\" style=\"border-bottom:solid 1px #A8A8A8;font-size: 7.5pt;\">" + _nodelist[0].Attributes[4].Value + "</td><td align=\"right\" width=\"25%\" style=\"border-bottom:solid 1px #A8A8A8;font-size: 7.5pt;\">$" + _nodelist[0].Attributes[3].Value + " USD</td><td align=\"right\" style=\"width:15%;border-bottom:solid 1px #A8A8A8;font-size: 7.5pt;\"><a href=\"" + url + "\">view>></a></td></tr> ");
                                viewdetail.Append("</table>");
                                description = "<table><tr><td valign=\"top\"><img alt=\"Details\" src=\"" + img + "\" /></td><td valign=\"top\">" + viewdetail.ToString() + "</td></tr></table>";
                            }
                            catch (Exception ex)
                            {
                                string str = ex.Message;
                                string url, img = "";
                                var xdoc = new XmlDocument();
                                xdoc.LoadXml("<Items>" + XMLDetails + "</Items>");
                                _nodelist = xdoc.SelectNodes("Items/Details");

                                lot.LoadByPrimaryKey(Convert.ToInt32(_nodelist[0].Attributes[0].Value));
                                if (lot.RowCount > 0)
                                    SellerID = lot.MemberID;

                                viewdetail.Append("<table width=\"350\" cellspacing=\"0\" cellpadding=\"2\">");
                                foreach (XmlNode node in _nodelist)
                                {
                                    url = (!Web.IsMemberSession) ? "../DealingFloor/DealingFloor.aspx" : (((SellerID == Web.SessionMembers.MemberID) ? "../DealingFloor/Default.aspx?Action=" + ((node.Attributes[5].Value == "0") ? "ViewItemOffers" : "View") + "&RecordID=" + Secure.Encrypt(node.Attributes[0].Value) : "../DealingFloor/DealingFloor.aspx?Action=" + ((node.Attributes[5].Value == "0") ? "LotItemOffers" : "LotOffers")));
                                    img = "../../ePage/ImageViewer.ashx?Action=LotDefaultThumbnail&RecordID=" + Secure.Encrypt(node.Attributes[0].Value);
                                    viewdetail.Append("<tr><td align=\"left\" width=\"50%\" style=\"border-bottom:solid 1px #A8A8A8;font-size: 7.5pt;\">" + node.Attributes[2].Value + "</td><td align=\"left\" width=\"10%\" style=\"border-bottom:solid 1px #A8A8A8;font-size: 7.5pt;\">" + node.Attributes[4].Value + "</td><td align=\"right\" width=\"25%\" style=\"border-bottom:solid 1px #A8A8A8;font-size: 7.5pt;\">" + ((node.Attributes[5].Value == "0") ? node.Attributes[3].Value : "$" + node.Attributes[6].Value) + " USD</td><td align=\"right\" style=\"width:15%;border-bottom:solid 1px #A8A8A8;font-size: 7.5pt;\"><a href=\"" + url + "\">view>></a></td></tr> ");
                                }
                                viewdetail.Append("</table>");
                                description = "<table><tr><td valign=\"top\"><img alt=\"Details\" src=\"" + img + "\" /></td><td valign=\"top\">" + viewdetail.ToString() + "</td></tr></table>";
                            }
                        }
                        else
                            description = "";
                        #endregion
                        break;
                    }
                case "13":
                case "42":
                case "43":
                case "44":
                case "37":
                case "38":
                    {
                        #region case 13 & 42 & 43 & 44 & 37 & 38
                        viewdetail.Append("<div id='div_short_msg_");
                        viewdetail.Append(ActivityLogID);
                        viewdetail.Append("' style=\"width:98%;display: block;padding:5px;text-align: justify; font-size: 7.5pt; font-weight: bold;\">");
                        viewdetail.Append(Web.GetShortMessage(Description, ReferenceID, "", ActivityLogID));
                        viewdetail.Append("</div><div id='div_full_msg_");
                        viewdetail.Append(ActivityLogID);
                        viewdetail.Append("' style=\"width:98%;display: none;padding:5px;\">");
                        viewdetail.Append(Web.GetFullMessage(Description, ReferenceID));
                        viewdetail.Append("<a href=\"javascript:void(0);\" onclick=\"ShowHide('div_full_msg_");
                        viewdetail.Append(ActivityLogID);
                        viewdetail.Append("', 'div_short_msg_");
                        viewdetail.Append(ActivityLogID);
                        viewdetail.Append("')\" style=\"font-size:9px;font-weight:bold;\">View less >></a></div>");
                        viewdetail.Append("<br />");
                        description = viewdetail.ToString();
                        #endregion
                        break;
                    }
                case "20":
                    {
                        #region case 20
                        var xdoc = new XmlDocument();
                        string url, img = "";
                        xdoc.LoadXml("<Items>" + XMLDetails + "</Items>");
                        _nodelist = xdoc.SelectNodes("Items/Details");
                        viewdetail.Append("<table width=\"350\" cellspacing=\"0\" cellpadding=\"2\"> ");
                        foreach (XmlNode node in _nodelist)
                        {
                            url = (!Web.IsMemberSession) ? "../DealingFloor/DealingFloor.aspx" : (((MemberID == Web.SessionMembers.MemberID.ToString()) ? "../DealingFloor/DealingFloor.aspx" : "../DealingFloor/DealingFloorBuying.aspx?Action=View&RecordID=" + Secure.Encrypt(node.Attributes[5].Value)));
                            img = "../../ePage/ImageViewer.ashx?Action=ItemDefaultThumbnail&RecordID=" + Secure.Encrypt(node.Attributes[0].Value);
                            viewdetail.Append("<tr><td align=\"left\" width=\"50%\" style=\"border-bottom:solid 1px #A8A8A8;font-size: 7.5pt;\">" + node.Attributes[1].Value + "</td><td align=\"left\" width=\"10%\" style=\"border-bottom:solid 1px #A8A8A8;font-size: 7.5pt;\">" + node.Attributes[2].Value + "</td><td align=\"right\" width=\"25%\" style=\"border-bottom:solid 1px #A8A8A8;font-size: 7.5pt;\">" + Web.GetCurrencySymbol(node.Attributes[3].Value) + node.Attributes[4].Value + " " + Web.GetCurrencyCode(node.Attributes[3].Value) + "</td><td align=\"right\" style=\"width:15%;border-bottom:solid 1px #A8A8A8;font-size: 7.5pt;\"><a href=\"" + url + "\">view>></a></td></tr>");
                        }
                        viewdetail.Append("</table>");
                        description = "<table><tr><td valign=\"top\"><img alt=\"Details\" src=\"" + img + "\" /></td><td valign=\"top\">" + viewdetail.ToString() + "</td></tr></table>";
                        #endregion
                        break;
                    }
                case "21":
                case "22":
                case "25":
                    {
                        #region case 21 & 22 & 25
                        if (!String.IsNullOrEmpty(XMLDetails))
                        {
                            int SellerID = 0;
                            Lots lot = new Lots();
                            try
                            {
                                var xdoc = new XmlDocument();
                                xdoc.LoadXml(XMLDetails);
                                _nodelist = xdoc.SelectNodes("Details");

                                lot.LoadByPrimaryKey(Convert.ToInt32(_nodelist[0].Attributes[0].Value));
                                if (lot.RowCount > 0)
                                    SellerID = lot.MemberID;

                                string url = (!Web.IsMemberSession) ? "../DealingFloor/DealingFloor.aspx" : (((MemberID != Web.SessionMembers.MemberID.ToString()) ? "../DealingFloor/Default.aspx?Action=" + ((_nodelist[0].Attributes[4].Value == "0") ? "ViewItemOffers" : "View") + "&RecordID=" + Secure.Encrypt(_nodelist[0].Attributes[0].Value) : "../DealingFloor/DealingFloor.aspx?Action=" + ((_nodelist[0].Attributes[4].Value == "0") ? "LotItemOffers" : "LotOffers")));
                                string img = "../../ePage/ImageViewer.ashx?Action=LotDefaultThumbnail&RecordID=" + Secure.Encrypt(_nodelist[0].Attributes[0].Value);
                                viewdetail.Append("<table width=\"350\" cellspacing=\"0\" cellpadding=\"2\">");
                                viewdetail.Append("<tr><td align=\"left\" width=\"50%\" style=\"border-bottom:solid 1px #A8A8A8;font-size: 7.5pt;\">" + _nodelist[0].Attributes[2].Value + "</td><td align=\"left\" width=\"25%\" style=\"border-bottom:solid 1px #A8A8A8;font-size: 7.5pt;\">" + _nodelist[0].Attributes[3].Value + "</td><td align=\"left\" style=\"width:15%;border-bottom:solid 1px #A8A8A8;font-size: 7.5pt;\"><a href=\"" + url + "\">view>></a></td></tr> ");
                                viewdetail.Append("</table>");
                                description = "<table><tr><td valign=\"top\"><img alt=\"Details\" src=\"" + img + "\" /></td><td valign=\"top\">" + viewdetail.ToString() + "</td></tr></table>";
                            }
                            catch (Exception ex)
                            {
                                string str = ex.Message;
                                string url, img = "";
                                var xdoc = new XmlDocument();
                                xdoc.LoadXml("<Items>" + XMLDetails + "</Items>");
                                _nodelist = xdoc.SelectNodes("Items/Details");

                                lot.LoadByPrimaryKey(Convert.ToInt32(_nodelist[0].Attributes[0].Value));
                                if (lot.RowCount > 0)
                                    SellerID = lot.MemberID;

                                viewdetail.Append("<table width=\"350\" cellspacing=\"0\" cellpadding=\"2\"> ");
                                foreach (XmlNode node in _nodelist)
                                {
                                    url = (!Web.IsMemberSession) ? "../DealingFloor/DealingFloor.aspx" : (((MemberID != Web.SessionMembers.MemberID.ToString()) ? "../DealingFloor/Default.aspx?Action=" + ((node.Attributes[4].Value == "0") ? "ViewItemOffers" : "View") + "&RecordID=" + Secure.Encrypt(node.Attributes[0].Value) : "../DealingFloor/DealingFloor.aspx?Action=" + ((node.Attributes[4].Value == "0") ? "LotItemOffers" : "LotOffers")));
                                    img = "../../ePage/ImageViewer.ashx?Action=LotDefaultThumbnail&RecordID=" + Secure.Encrypt(node.Attributes[0].Value);
                                    viewdetail.Append("<tr><td align=\"left\" width=\"50%\" style=\"border-bottom:solid 1px #A8A8A8;font-size: 7.5pt;\">" + node.Attributes[2].Value + "</td><td align=\"left\" width=\"10%\" style=\"border-bottom:solid 1px #A8A8A8;font-size: 7.5pt;\">" + node.Attributes[4].Value + "</td><td align=\"right\" width=\"25%\" style=\"border-bottom:solid 1px #A8A8A8;font-size: 7.5pt;\">$" + node.Attributes[3].Value + " USD</td><td align=\"right\" style=\"width:15%;border-bottom:solid 1px #A8A8A8;font-size: 7.5pt;\"><a href=\"" + url + "\">view>></a></td></tr> ");
                                }
                                viewdetail.Append("</table>");
                                description = "<table><tr><td valign=\"top\"><img alt=\"Details\" src=\"" + img + "\" /></td><td valign=\"top\">" + viewdetail.ToString() + "</td></tr></table>";
                            }
                        }
                        else
                            description = "";
                        #endregion
                        break;
                    }
                case "23":
                    {
                        #region case 23
                        var xdoc = new XmlDocument();
                        string url, img = "";
                        xdoc.LoadXml("<Items>" + XMLDetails + "</Items>");
                        _nodelist = xdoc.SelectNodes("Items/Details");
                        viewdetail.Append("<table width=\"350\" cellspacing=\"0\" cellpadding=\"2\"> ");
                        foreach (XmlNode node in _nodelist)
                        {
                            url = (!Web.IsMemberSession) ? "../DealingFloor/DealingFloor.aspx" : (((MemberID == Web.SessionMembers.MemberID.ToString()) ? "../DealingFloor/DealingFloor.aspx" : "../DealingFloor/DealingFloorBuying.aspx?Action=View&RecordID=" + Secure.Encrypt(node.Attributes[5].Value)));
                            img = "../../ePage/ImageViewer.ashx?Action=ItemDefaultThumbnail&RecordID=" + Secure.Encrypt(node.Attributes[0].Value);
                            viewdetail.Append("<tr><td align=\"left\" width=\"50%\" style=\"border-bottom:solid 1px #A8A8A8;font-size: 7.5pt;\">" + node.Attributes[1].Value + "</td><td align=\"left\" width=\"10%\" style=\"border-bottom:solid 1px #A8A8A8;font-size: 7.5pt;\">" + node.Attributes[2].Value + "</td><td align=\"right\" width=\"25%\" style=\"border-bottom:solid 1px #A8A8A8;font-size: 7.5pt;\">" + Web.GetCurrencySymbol(node.Attributes[3].Value) + node.Attributes[4].Value + " " + Web.GetCurrencyCode(node.Attributes[3].Value) + "</td><td align=\"right\" style=\"width:15%;border-bottom:solid 1px #A8A8A8;font-size: 7.5pt;\"><a href=\"" + url + "\">view>></a></td></tr> ");
                        }
                        viewdetail.Append("</table>");
                        description = "<table><tr><td valign=\"top\"><img alt=\"Details\" src=\"" + img + "\" /></td><td valign=\"top\">" + viewdetail.ToString() + "</td></tr></table>";
                        #endregion
                        break;
                    }
                case "24":
                    {
                        #region case 24
                        var xdoc = new XmlDocument();
                        string url, img = "";
                        xdoc.LoadXml("<Items>" + XMLDetails + "</Items>");
                        _nodelist = xdoc.SelectNodes("Items/Details");
                        viewdetail.Append("<table width=\"350\" cellspacing=\"0\" cellpadding=\"2\"> ");
                        foreach (XmlNode node in _nodelist)
                        {
                            url = (!Web.IsMemberSession) ? "../DealingFloor/DealingFloor.aspx" : (((MemberID != Web.SessionMembers.MemberID.ToString()) ? "../DealingFloor/DealingFloor.aspx" : "../DealingFloor/DealingFloorBuying.aspx?Action=View&RecordID=" + Secure.Encrypt(node.Attributes[5].Value)));
                            img = "../../ePage/ImageViewer.ashx?Action=ItemDefaultThumbnail&RecordID=" + Secure.Encrypt(node.Attributes[0].Value);
                            viewdetail.Append("<tr><td align=\"left\" width=\"50%\" style=\"border-bottom:solid 1px #A8A8A8;font-size: 7.5pt;\">" + node.Attributes[1].Value + "</td><td align=\"left\" width=\"10%\" style=\"border-bottom:solid 1px #A8A8A8;font-size: 7.5pt;\">" + node.Attributes[2].Value + "</td><td align=\"right\" width=\"25%\" style=\"border-bottom:solid 1px #A8A8A8;font-size: 7.5pt;\">" + Web.GetCurrencySymbol(node.Attributes[3].Value) + node.Attributes[4].Value + " " + Web.GetCurrencyCode(node.Attributes[3].Value) + "</td><td align=\"right\" style=\"width:15%;border-bottom:solid 1px #A8A8A8;font-size: 7.5pt;\"><a href=\"" + url + "\">view>></a></td></tr> ");
                        }
                        viewdetail.Append("</table>");
                        description = "<table><tr><td valign=\"top\"><img alt=\"Details\" src=\"" + img + "\" /></td><td valign=\"top\">" + viewdetail.ToString() + "</td></tr></table>";
                        #endregion
                        break;
                    }
                case "40":
                case "41":
                    {
                        #region case 40 & 41
                        if (Web.IsMemberSession)
                            viewdetail.Append("<div class=\"" + GetBillboardClass(Convert.ToInt32(MemberID), Web.SessionMembers.MemberID) + "\" style=\"float: left; text-align: left; width: 468px;\">\"");
                        else
                            viewdetail.Append("<div class=\"OthersBillboard\" style=\"float: left; text-align: left; width:468px;\">\"");
                        viewdetail.Append(GetShortBillboard(Description, Convert.ToInt32(ActivityLogID)));
                        viewdetail.Append("\"</div>");
                        description = viewdetail.ToString();
                        #endregion
                        break;
                    }
                case "45": // Postings
                    {
                        description = LoadPostXML(Convert.ToInt32(ActivityLogID));
                        break;
                    }
                case "46": // Listings
                    {
                        //description = "";
                        int postTypeID = 0;
                        if (s_PostTypeID != "")
                            postTypeID = Convert.ToInt32(s_PostTypeID);

                        description = LoadListingXML(Convert.ToInt32(ActivityLogID), Convert.ToInt32(ReferenceID), XMLDetails, postTypeID);
                        break;
                    }
                case "47":
                case "48":
                case "49":
                case "50":
                case "54":
                    {
                        #region case 47 & 48 & 49 & 50 & 51 & 54
                        description = "";
                        if (!String.IsNullOrEmpty(XMLDetails))
                        {
                            int SellerID = 0, ListingTypeID = 0;
                            try
                            {
                                var xdoc = new XmlDocument();
                                xdoc.LoadXml(XMLDetails);
                                _nodelist = xdoc.SelectNodes("Details");

                                SellerID = Convert.ToInt32(_nodelist[0].Attributes[7].Value);
                                ListingTypeID = Convert.ToInt32(_nodelist[0].Attributes[5].Value);

                                //string url = "/marketplace/ItemDetails.aspx?Action=View&RecordID=" + _nodelist[0].Attributes[0].Value;

                                //direct to appropriate tab in case of seller or buyer
                                string url = "";
                                if (Web.SessionMembers.MemberID.ToString() == _nodelist[0].Attributes[7].Value)
                                    url = "/MarketPlace/MyListings.aspx?tabid=tabs-2.tabs-2-2";
                                else
                                    url = "/MarketPlace/MyListings.aspx?tabid=tabs-3.tabs-3-1";

                                if (ActivityID != "47")
                                {
                                    if (ListingTypeID == 1 || ListingTypeID == 2) // _nodelist[0].Attributes[0].Value
                                    {
                                        if (Web.SessionMembers.MemberID.ToString() == _nodelist[0].Attributes[7].Value)
                                            url = "/MarketPlace/MyListings.aspx?tabid=tabs-2.tabs-2-3";
                                        else
                                            url = "/MarketPlace/MyListings.aspx?tabid=tabs-3.tabs-3-2";
                                    }
                                    //url = "/marketplace/ItemDetails.aspx?Action=View&RecordID=" + _nodelist[0].Attributes[0].Value;

                                    //url = (!Web.IsMemberSession) ? "/marketplace/ItemDetails.aspx?Action=View&RecordID=" : ((SellerID == Web.SessionMembers.MemberID) ? "/marketplace/" : "/marketplace/");
                                    //else
                                    //url = (!Web.IsMemberSession) ? "/marketplace/" : ((SellerID == Web.SessionMembers.MemberID) ? "/marketplace/" : "/marketplace/");
                                }

                                string img = (_nodelist[0].Attributes.Count > 8) ? _nodelist[0].Attributes[8].Value : "/Images/logo_50x50.png";
                                viewdetail.Append("<table width=\"350\" cellspacing=\"0\" cellpadding=\"2\">");
                                viewdetail.Append("<tr><td align=\"left\" width=\"50%\" style=\"border-bottom:solid 1px #A8A8A8;font-size: 7.5pt;\">" + _nodelist[0].Attributes[6].Value + "</td>");
                                if (ListingTypeID == 1)
                                    viewdetail.Append("<td align=\"left\" width=\"10%\" style=\"border-bottom:solid 1px #A8A8A8;font-size: 7.5pt;\">" + _nodelist[0].Attributes[3].Value + "</td>");

                                // SHows offer price
                                if (ListingTypeID != 4 || ListingTypeID != 5 || ListingTypeID != 6)
                                    viewdetail.Append("<td align=\"right\" width=\"25%\" style=\"border-bottom:solid 1px #A8A8A8;font-size: 7.5pt;\">$" + _nodelist[0].Attributes[2].Value + " USD</td><td align=\"right\" style=\"width:15%;border-bottom:solid 1px #A8A8A8;font-size: 7.5pt;\"><a href=\"" + url + "\">view>></a></td></tr> ");
                                viewdetail.Append("</table>");
                                description = "<table><tr><td valign=\"top\"><img style='border: 1px solid #bfccdc' alt=\"Details\" title='" + _nodelist[0].Attributes[6].Value + "' src=\"" + img + "\" /></td><td valign=\"top\">" + viewdetail.ToString() + "</td></tr></table>";
                            }
                            catch (Exception ex) { }
                        }
                        #endregion
                        break;
                    }
                case "53":
                    {
                        description = LoadListingXML(Convert.ToInt32(ActivityLogID), Convert.ToInt32(ReferenceID), XMLDetails, Convert.ToInt32(s_PostTypeID));
                        break;
                    }
                default:
                    {
                        description = "";
                        break;
                    }
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }

        return HttpUtility.HtmlDecode(description);
    }
    private static string LoadListingXML(int ActivityLogID, int ListingID, string XMLDetails, int ListingTypeID)
    {
        string description = "";
        StringBuilder sb = new StringBuilder();
        try
        {
            string img = "../../Images/noimage.png", url = "../Marketplace/Default.aspx", title = "N/A", data = "N/A", QTY = "N/A", endsOn = "N/A", price = "N/A";
            int FieldID = 0;

            // load fields xml
            var xdoc = new XmlDocument();
            xdoc.LoadXml("<Fields>" + XMLDetails + "</Fields>");
            XmlNodeList _nodelist = xdoc.SelectNodes("Fields/Details");

            if (_nodelist.Count > 0)
            {
                url = "../Marketplace/ItemDetails.aspx?Action=View&RecordID=" + Secure.Encrypt(ListingID);

                try
                {
                    if (!String.IsNullOrEmpty(_nodelist[0].Attributes["ThumbnailURL"].Value))
                        img = (!String.IsNullOrEmpty(_nodelist[0].Attributes["ThumbnailURL"].Value)) ? _nodelist[0].Attributes["ThumbnailURL"].Value : "../../Images/noimage.png";
                }
                catch (Exception ex)
                {// do nothing
                }

                endsOn = _nodelist[0].Attributes["timeleft"].Value;

                foreach (XmlNode node in _nodelist)
                {
                    if (node.Attributes.Count == 0)
                        break;
                    else
                    {
                        FieldID = Convert.ToInt32(node.Attributes["FieldID"].Value);
                        if (FieldID == 20)
                            title = node.Attributes["Data"].Value;
                        else if (FieldID == 4)
                            QTY = node.Attributes["Data"].Value;
                        else if (FieldID == 10 && price != "Make an Offer")
                            price = node.Attributes["Data"].Value + " per item";
                        else if (FieldID == 9 && price == "Make an Offer")
                            price = node.Attributes["Data"].Value;
                        else if (FieldID == 24 && node.Attributes["Data"].Value.ToString().ToLower().Equals("true"))
                            price = "Make an Offer";
                    }
                }
                if (price != "Make an Offer")
                    price = "$" + price;

                if (ListingTypeID == 1 || ListingTypeID == 2)
                    sb.Append("<table width='100%' padding='0'><tr><td align=\"left\" width=\"50%\" style=\"border-bottom:solid 1px #A8A8A8;font-size: 7.5pt;\"><a href='" + url + "'>" + title + "</a></span></td><td align=\"left\" width=\"10%\" style=\"border-bottom:solid 1px #A8A8A8;\"><span style=\" font-size: 7.5pt;\">" + QTY + "</span></td><td align=\"right\" width=\"25%\" style=\"border-bottom:solid 1px #A8A8A8;\"><span style=\" font-size: 7.5pt;\">" + price + "</span></td><td align=\"right\" style=\"width:15%;border-bottom:solid 1px #A8A8A8;font-size: 7.5pt;\"><a href=\"" + url + "\">view>></a></td></tr></table>");
                else
                {
                    sb.Append("<table width='100%' padding='0'><tr><td align=\"left\" width=\"50%\" style=\"border-bottom:solid 1px #A8A8A8;font-size: 7.5pt;\"><a href='" + url + "'>" + title + "</a></span></td><td align=\"right\" width=\"35%\" style=\"border-bottom:solid 1px #A8A8A8;\"><span style=\" font-size: 7.5pt;\">" + endsOn + "</span></td><td align=\"right\" style=\"width:15%;border-bottom:solid 1px #A8A8A8;font-size: 7.5pt;\"><a href=\"" + url + "\">view>></a></td></tr> ");
                    //if (data != "N/A")
                    //    sb.Append("<tr><td align=\"left\" colspan='3' width=\"100%\" style=\"border-bottom:solid 1px #A8A8A8;\"><span style=\" font-size: 7.5pt;\">" + ShortPostData(data, ActivityLogID) + "</span></td></tr>");
                    sb.Append("</table>");
                }

                description = "<table style='width:100%; padding:0;'><tr><td width='15%' valign=\"top\"><img alt='Details' src='" + img + "' /></td><td width='85%' valign=\"top\">" + sb.ToString() + "</td></tr></table>";
            }
        }
        catch (Exception ex) { LogError(ex); }
        return description;
    }
    private static string LoadPostXML(int ActivityLogID)
    {
        string description = "";
        try
        {
            // get attached files
            string filesHTML = Web.GetAttachments(ActivityLogID, Convert.ToInt32(SystemObjects.Posts));
            //----------------------------------------------------------------------
            string title, data;
            string xml = "";
            string[] xmlArray = { };
            StringBuilder sb = new StringBuilder();
            DataTable dtPosts = new DataTable();

            dtPosts = PostingExtendedFields.LoadUserPosts(ActivityLogID);
            for (int i = 0; i < dtPosts.Rows.Count; i++)
            {
                xml += dtPosts.Rows[i][0].ToString();
            }

            xmlArray = Regex.Split(xml, "/>");
            sb.Append("<table style='background-color:#ffffff; padding:4px; border:1px solid #cccccc;width:480px;'>");
            foreach (var item in xmlArray)
            {
                string val = HttpUtility.HtmlDecode(item);
                if (val == "") break;
                title = val.Substring(val.IndexOf("FieldName=\"") + 11);
                title = title.Substring(0, title.IndexOf("\""));

                data = val.Substring(val.IndexOf("Data=\"") + 6);


                //for formated descriptions
                if (data.Contains("<strong") || data.Contains("<div") || data.Contains("<span"))
                {
                    data = data.Substring(0, data.LastIndexOf("\""));
                    if (data.Contains("EntryTime"))
                        data = data.Remove(data.IndexOf("EntryTime") - 2);
                }
                else
                {
                    if (data.Contains("EntryTime"))
                    {
                        data = data.Remove(data.IndexOf("EntryTime") - 2);
                    }
                    else
                        data = data.Substring(0, data.IndexOf("\""));
                }


                data = HttpUtility.HtmlDecode(data);
                //date_ = item.Substring(item.IndexOf("EntryTime=\"", item.IndexOf("\"")));
                //--------------------------------------------------------------------------------------
                //--------------generate a table for posts
                if (title != "ShowAutomaticallyPostings")
                {
                    sb.Append("<tr>");
                    //sb.Append("<td valign='top' align='right' style='font-size:10px;padding:1px 5px 1px 0;font-weight:bold;width:60px;'>");
                    //sb.Append(title + ": ");
                    //sb.Append("</td>");
                    sb.Append("<td valign='top' align='left' style='padding:1px 0 1px 5px;width:100%;'>");
                    sb.Append(ShortPostData(data, ActivityLogID));
                    sb.Append("</td>");
                    sb.Append("</tr>");
                }
            }

            sb.Append("</table><br />");

            description = filesHTML + sb.ToString();
        }
        catch (Exception ex) { LogError(ex); }
        return description;
    }
    public static string ShortPostData(string data, int ActivityLogID)
    {
        string str = data;
        string newStr;
        try
        {
            if (str.Length > 400)
            {
                if (str.Contains("<span") || str.Contains("<div"))
                { }
                else
                {
                    newStr = str.Remove(400);
                    newStr = newStr.Substring(0, newStr.LastIndexOf(" "));
                    newStr = "<div id='" + ActivityLogID + "_shortPost' style=\"float: left; display: inline; text-align: justify; padding: 0; font-size: 8pt; font-weight: normal;\">" + newStr;
                    newStr += ".....<a onclick=\"togglepostDiv('" + ActivityLogID + "_shortPost', '" + ActivityLogID + "_fullPost')\" href=\"javascript:void(0);\" style=\"font-size:9px;\">View More>></a></div>";
                    newStr += "<div id='" + ActivityLogID + "_fullPost' style=\"display: none;float: left;text-align: justify; padding: 0; font-size: 8pt; font-weight: normal;\" >" + str;
                    newStr += "&nbsp;<a onclick=\"togglepostDiv('" + ActivityLogID + "_fullPost','" + ActivityLogID + "_shortPost')\" href=\"javascript:void(0);\" style=\"font-size:9px;\">View Less>></a></div>";
                    str = newStr;
                }
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
        return str;
    }

    /// <summary>
    /// Get Activity Title according to the Activity ID
    /// </summary>
    /// <param name="s_MemberID"></param>
    /// <param name="s_RelatedToContact"></param>
    /// <param name="s_ActivityID"></param>
    /// <param name="ActivityTitle"></param>
    /// <param name="Description"></param>
    /// <param name="s_ReferenceID"></param>
    /// <param name="XMLDetails"></param>
    /// <returns></returns>
    public static string GetActivityTitle(string s_MemberID, string s_RelatedToContact, string s_ActivityID, string ActivityTitle, string Description, string s_ReferenceID, string XMLDetails)
    {
        XmlNodeList _nodelist;
        string description = "";
        int LotID = 0;
        int MemberID = (!String.IsNullOrEmpty(s_MemberID)) ? Convert.ToInt32(s_MemberID) : 0;
        int ReferenceID = (!String.IsNullOrEmpty(s_ReferenceID)) ? Convert.ToInt32(s_ReferenceID) : 0;
        int RelatedToContactID = (!String.IsNullOrEmpty(s_RelatedToContact)) ? Convert.ToInt32(s_RelatedToContact) : 0;
        try
        {
            switch (s_ActivityID)
            {
                case "4":
                case "19":
                    {
                        if (!Description.Contains("#encrypt#"))
                        {
                            ContactMessages message = new ContactMessages();
                            message.LoadByPrimaryKey(Convert.ToInt32(s_ReferenceID));
                            if (message.RowCount > 0)
                            {
                                Members member = new Members();
                                member.LoadByPrimaryKey(message.To);
                                if (Web.IsMemberSession)
                                    description = "&nbsp;sent" + ((member.MemberID == Web.SessionMembers.MemberID) ? "<span class=\"" + Web.GetProfileClass(Web.SessionMembers.MemberID, Web.SessionMembers.MemberID) + "\">You</span>" : "<a href=\"/Contacts/ViewProfile.aspx?Action=ViewDealer&RecordID=" + Secure.Encrypt(member.s_MemberID) + "\"><span class=\"" + Web.GetProfileClass(member.MemberID, Web.SessionMembers.MemberID) + "\">" + member.UserName + "</span></a> a new message");
                                else
                                    description = "&nbsp;sent <a href=\"/Contacts/ViewProfile.aspx.aspx?Action=ViewDealer&RecordID=" + Secure.Encrypt(member.s_MemberID) + "\"><span class=\"Unknown\">" + member.UserName + "</span></a> a new message";
                            }
                        }
                        else
                            description = Web.ParseTemplate(Description);

                        break;
                    }
                case "5":
                case "39":
                    {
                        if (Web.IsMemberSession)
                        {
                            if (Web.SessionMembers.s_MemberID == s_MemberID)
                                description = Web.ParseTemplate(ActivityTitle);
                            else
                            {
                                description = " sent <span class=\"Me\">you</span> a new message";
                            }
                        }

                        break;
                    }
                case "11":
                case "20":
                    {
                        description = Web.ParseTemplate(Description);
                        break;
                    }
                case "27":
                case "28":
                    {
                        if (Web.IsMemberSession)
                        {
                            if (Web.SessionMembers.s_MemberID == s_MemberID)
                                description = Web.ParseTemplate(Description) + "&nbsp;&nbsp;&nbsp;<a href=\"/Contacts/ViewProfile.aspx?Action=ViewDealer&RecordID=" + Secure.Encrypt(s_ReferenceID) + "\">View Profile>></a>";
                            else
                                description = Web.ParseTemplate(Description) + "&nbsp;&nbsp;&nbsp;<a href=\"/Contacts/ViewProfile.aspx?Action=ViewDealer&RecordID=" + Secure.Encrypt(s_MemberID) + "\">View Profile>></a>";
                        }
                        else
                            description = Web.ParseTemplate(Description) + "&nbsp;&nbsp;&nbsp;<a href=\"/Contacts/ViewProfile.aspx?Action=ViewDealer&RecordID=" + Secure.Encrypt(s_MemberID) + "\">View Profile>></a>";

                        break;
                    }
                case "33":
                    {
                        Members member = new Members();
                        member.LoadByPrimaryKey(RelatedToContactID);
                        if (member.RowCount > 0)
                        {
                            if (member.MemberStatusID == 200)
                            {
                                string str = "<a runat=\"server\" href=\"/Contacts/ViewProfile.aspx?Action=ViewDealer&RecordID=" + Secure.Encrypt(member.MemberID) + "\"><span class=\"" + ((!Web.IsMemberSession) ? "Unknown" : Web.GetProfileClass(member.MemberID, Web.SessionMembers.MemberID)) + "\">" + member.UserName + "</span></a>";

                                member = new Members();
                                member.LoadByPrimaryKey(Convert.ToInt32(s_MemberID));
                                string str1 = "<a runat=\"server\" href=\"/Contacts/ViewProfile.aspx?Action=ViewDealer&RecordID=" + Secure.Encrypt(member.MemberID) + "\"><span class=\"" + ((!Web.IsMemberSession) ? "Unknown" : Web.GetProfileClass(member.MemberID, Web.SessionMembers.MemberID)) + "\">" + member.UserName + "</span></a>";

                                if (Description.Contains("#encrypt#"))
                                {
                                    if (Web.IsMemberSession)
                                        description = ((s_MemberID == Web.SessionMembers.MemberID.ToString()) ? "<span class=\"" + Web.GetProfileClass(Web.SessionMembers.MemberID, Web.SessionMembers.MemberID) + "\">You</span>" : str1) + Description + "&nbsp;&nbsp;<a runat=\"server\" href=\"../contacts/viewprofile.aspx?Action=ViewDealer&RecordID=" + ((s_RelatedToContact != Web.SessionMembers.MemberID.ToString()) ? Secure.Encrypt(s_RelatedToContact) : Secure.Encrypt(s_MemberID)) + "\">View Profile</a>";
                                    else
                                        description = str1 + Description + "&nbsp;&nbsp;<a runat=\"server\" href=\"/contacts/viewprofile.aspx?Action=ViewDealer&RecordID=" + Secure.Encrypt(s_MemberID) + "\">View Profile>></a>";
                                }
                                else
                                {
                                    if (Web.IsMemberSession)
                                        description = ((s_MemberID == Web.SessionMembers.MemberID.ToString()) ? "<span class=\"" + Web.GetProfileClass(Web.SessionMembers.MemberID, Web.SessionMembers.MemberID) + "\">You</span>" : str1) + " requested " + ((s_RelatedToContact == Web.SessionMembers.MemberID.ToString()) ? "<span class=\"" + Web.GetProfileClass(Web.SessionMembers.MemberID, Web.SessionMembers.MemberID) + "\">You</span> to be a" : str + " to be a") + Description + "&nbsp;&nbsp;<a runat=\"server\" href=\"../contacts/viewprofile.aspx?Action=ViewDealer&RecordID=" + ((s_RelatedToContact != Web.SessionMembers.MemberID.ToString()) ? Secure.Encrypt(s_RelatedToContact) : Secure.Encrypt(s_MemberID)) + "\">View Profile>></a>";
                                    else
                                        description = str1 + " requested " + str + " to be a" + Description + "&nbsp;&nbsp;<a runat=\"server\" href=\"../contacts/viewprofile.aspx?Action=ViewDealer&RecordID=" + Secure.Encrypt(s_MemberID) + "\">View Profile>></a>";
                                }
                            }
                            else
                            {
                                string str = member.FullName;
                                member = new Members();
                                member.LoadByPrimaryKey(Convert.ToInt32(s_MemberID));
                                string str1 = "<a runat=\"server\" href=\"/Contacts/ViewProfile.aspx?Action=ViewDealer&RecordID=" + Secure.Encrypt(member.MemberID) + "\">" + member.UserName + "</a>";

                                if (Description.Contains("#encrypt#"))
                                {
                                    Regex regex = new Regex("ViewContact(.*?)#endencrypt#", RegexOptions.IgnoreCase);
                                    Match match = regex.Match(Description);
                                    if (!string.IsNullOrEmpty(match.Value))
                                        Description = Description.Replace(match.Value, "#");
                                    if (Web.IsMemberSession)
                                        description = ((s_MemberID == Web.SessionMembers.MemberID.ToString()) ? "<span class=\"Me\">You</span>" : str1) + Description;
                                    else
                                        description = str1 + Description;
                                }
                                else
                                {
                                    if (Web.IsMemberSession)
                                        description = ((s_MemberID == Web.SessionMembers.MemberID.ToString()) ? "<span class=\"Me\">You</span>" : str1) + " requested " + ((s_RelatedToContact == Web.SessionMembers.MemberID.ToString()) ? "<span class=\"" + Web.GetProfileClass(Web.SessionMembers.MemberID, Web.SessionMembers.MemberID) + "\">You</span> to be a" : str + " to be a") + Description;
                                    else
                                        description = Description;
                                }
                            }
                            description = Web.ParseTemplate(description);
                        }
                        else description = Web.ParseTemplate(ActivityTitle);
                        break;
                    }
                case "34":
                    {
                        Members member = new Members();
                        member.LoadByPrimaryKey(Convert.ToInt32(s_MemberID));
                        if (member.RowCount > 0)
                        {
                            description = " posted a ";
                            string str = "<a runat=\"server\" href=\"../AddressBook/FeedDetails.aspx?Action=View&RecordID=" + Secure.Encrypt(ReferenceID) + "\">comment</a>.";
                            description += str;
                        }
                        else description = ActivityTitle;
                        break;
                    }
                case "35":
                case "36":
                    {
                        description = Web.ParseTemplate(Description) + "&nbsp;&nbsp;<a href=\"../ApplianceStore/Default.aspx?Action=ViewLinkApps&RecordID=" + Secure.Encrypt(s_MemberID) + "\">View >></a>";
                        break;
                    }
                case "13":
                case "37":
                case "38":
                case "40":
                case "41":
                case "42":
                case "43":
                case "44":
                case "45":
                    {
                        description = ActivityTitle;
                        break;
                    }
                default:
                    {
                        if (Description.Contains("#memberid#") || Description.Contains("#encrypt#") || Description.Contains("#referenceid#"))
                            description = Web.ParseTemplate(Description);
                        else description = Description;
                        break;
                    }
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }

        return HttpUtility.HtmlDecode(description);
    }
    /// <summary>
    /// Parse any text for keywords like
    /// #memberid#...#endmemberid#
    /// #encrypt#...#endencrypt#
    /// #pronoun#
    /// #profileclass#
    /// #site_url#
    /// </summary>
    /// <param name="ActivityFeedDescription"></param>
    /// <returns></returns>
    public static string ParseTemplate(string ActivityFeedDescription)
    {
        string parsedString = ActivityFeedDescription;
        var templateKeys = new System.Collections.Specialized.StringDictionary();
        try
        {
            int MemberID = 0;           // #memberid#...#endmemberid#
            int ToBeEncrypted = 0;      // #encrypt#...#endencrypt#
            string value = "";
            if (parsedString.Contains("#memberid#"))
            {
                Regex regex = new Regex("\\#memberid#(.*?)\\#endmemberid#", RegexOptions.IgnoreCase);
                Match match = regex.Match(parsedString);
                while (match.Success)
                {
                    value = match.Value.Substring(10, match.Value.Length - 23);
                    if (!String.IsNullOrEmpty(value))
                    {
                        MemberID = Convert.ToInt32(value);
                        if (Web.IsMemberSession)
                        {
                            if (Web.SessionMembers.MemberID != MemberID)
                            {
                                var member = new Members();
                                member.LoadByPrimaryKey(MemberID);
                                if (member.RowCount > 0)
                                    if (!templateKeys.ContainsKey("#memberid#" + MemberID + "#endmemberid#"))
                                        templateKeys.Add("#memberid#" + MemberID + "#endmemberid#", member.UserName);
                            }
                            else
                                templateKeys.Add("#memberid#" + MemberID + "#endmemberid#", "you");
                        }
                        else
                        {
                            var member = new Members();
                            member.LoadByPrimaryKey(MemberID);
                            if (member.RowCount > 0)
                                if (!templateKeys.ContainsKey("#memberid#" + MemberID + "#endmemberid#"))
                                    templateKeys.Add("#memberid#" + MemberID + "#endmemberid#", member.UserName);
                        }
                    }
                    match = match.NextMatch();
                }
            }

            if (parsedString.Contains("#pronoun#"))
            {
                Regex regex = new Regex("\\#pronoun#(.*?)\\#endpronoun#", RegexOptions.IgnoreCase);
                Match match = regex.Match(parsedString);
                while (match.Success)
                {
                    value = match.Value.Substring(9, match.Value.Length - 21);
                    if (!String.IsNullOrEmpty(value))
                    {
                        MemberID = Convert.ToInt32(value);
                        if (Web.IsMemberSession)
                        {
                            if (Web.SessionMembers.MemberID != MemberID)
                                templateKeys.Add("#pronoun#" + MemberID + "#endpronoun#", "their");
                            else
                                templateKeys.Add("#pronoun#" + MemberID + "#endpronoun#", "your");
                        }
                        else
                            templateKeys.Add("#pronoun#" + MemberID + "#endpronoun#", "their");
                    }
                    match = match.NextMatch();
                }
            }

            if (parsedString.Contains("#encrypt#"))
            {
                Regex regex = new Regex("\\#encrypt#(.*?)\\#endencrypt#", RegexOptions.IgnoreCase);
                Match match = regex.Match(parsedString);
                while (match.Success)
                {
                    value = match.Value.Substring(9, match.Value.Length - 21);
                    if (!String.IsNullOrEmpty(value))
                    {
                        ToBeEncrypted = Convert.ToInt32(value);
                        if (!templateKeys.ContainsKey("#encrypt#" + ToBeEncrypted + "#endencrypt#"))
                            templateKeys.Add("#encrypt#" + ToBeEncrypted + "#endencrypt#", Secure.Encrypt(ToBeEncrypted));
                    }
                    match = match.NextMatch();
                }
            }

            if (parsedString.Contains("#profileclass#"))
            {
                Regex regex = new Regex("\\#profileclass#(.*?)\\#endprofileclass#", RegexOptions.IgnoreCase);
                Match match = regex.Match(parsedString);
                while (match.Success)
                {
                    value = match.Value.Substring(14, match.Value.Length - 31);
                    if (!String.IsNullOrEmpty(value))
                    {
                        ToBeEncrypted = Convert.ToInt32(value);
                        if (!templateKeys.ContainsKey("#profileclass#" + ToBeEncrypted + "#endprofileclass#"))
                        {
                            if (Web.IsMemberSession)
                                templateKeys.Add("#profileclass#" + ToBeEncrypted + "#endprofileclass#", Web.GetProfileClass(ToBeEncrypted, Web.SessionMembers.MemberID));
                            else
                                templateKeys.Add("#profileclass#" + ToBeEncrypted + "#endprofileclass#", "Unknown");
                        }
                    }
                    match = match.NextMatch();
                }
            }

            if (parsedString.Contains("#site_url#"))
            {
                Regex regex = new Regex("\\#site_url#", RegexOptions.IgnoreCase);
                Match match = regex.Match(parsedString);
                while (match.Success)
                {
                    value = match.Value;
                    if (!String.IsNullOrEmpty(value))
                    {
                        if (!templateKeys.ContainsKey("#site_url#"))
                            templateKeys.Add("#site_url#", Web.SystemConfigs.GetKey("SITE_URL"));
                    }
                    match = match.NextMatch();
                }
            }

            var templateManager = new VisualSoft.SystemManagement.TemplateManager();
            parsedString = templateManager.ParseTemplate(parsedString, templateKeys);
        }
        catch (Exception ex) { Web.LogError(ex); }
        return parsedString;
    }
    public static bool ShowMessageIcon(string s_MemberID, string s_RelatedToContact)
    {
        bool show = false;
        try
        {
            if (Web.IsMemberSession)
            {
                if (s_MemberID != Web.SessionMembers.s_MemberID)
                {
                    if (Contacts.IsMyContact(s_MemberID, Web.SessionMembers.MemberID))
                        show = true;
                    else if (!String.IsNullOrEmpty(s_RelatedToContact))
                    {
                        if (s_RelatedToContact != Web.SessionMembers.s_MemberID)
                            if (Contacts.IsMyContact(s_RelatedToContact, Web.SessionMembers.MemberID))
                                show = true;
                    }
                }
                else if (!String.IsNullOrEmpty(s_RelatedToContact))
                {
                    if (s_RelatedToContact != Web.SessionMembers.s_MemberID)
                        if (Contacts.IsMyContact(s_RelatedToContact, Web.SessionMembers.MemberID))
                            show = true;
                }
            }
        }
        catch (Exception ex) { Web.LogError(ex); }
        return show;
    }
    public static int WhomToSendMessage(string s_MemberID, string s_RelatedToContact)
    {
        int ID = 0;
        try
        {
            if (Web.IsMemberSession)
            {
                if (s_MemberID != Web.SessionMembers.s_MemberID)
                {
                    if (Contacts.IsMyContact(s_MemberID, Web.SessionMembers.MemberID))
                        ID = Convert.ToInt32(s_MemberID);
                    else if (!String.IsNullOrEmpty(s_RelatedToContact))
                    {
                        if (s_RelatedToContact != Web.SessionMembers.s_MemberID)
                            if (Contacts.IsMyContact(s_RelatedToContact, Web.SessionMembers.MemberID))
                                ID = Convert.ToInt32(s_RelatedToContact);
                    }
                }
                else if (!String.IsNullOrEmpty(s_RelatedToContact))
                {
                    if (s_RelatedToContact != Web.SessionMembers.s_MemberID)
                        if (Contacts.IsMyContact(s_RelatedToContact, Web.SessionMembers.MemberID))
                            ID = Convert.ToInt32(s_RelatedToContact);
                }
            }
        }
        catch (Exception ex) { Web.LogError(ex); }
        return ID;
    }
    public static bool ShowReply(string s_ActivityID, string s_ReferenceID)
    {
        bool show = false;
        try
        {
            if (s_ActivityID == "4")
            {
                if (!String.IsNullOrEmpty(s_ReferenceID))
                {
                    ContactMessages message = new ContactMessages();
                    message.LoadByPrimaryKey(Convert.ToInt32(s_ReferenceID));
                    if (message.RowCount > 0)
                        show = (message.IsReplied == 1) ? false : true;
                }
                else
                    show = true;
            }
            else
                show = false;
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
        return show;
    }
    public static bool ShowLink(string s_MemberID, string s_ActivityID)
    {
        bool show = false;
        try
        {
            if (Web.IsMemberSession)
            {
                if (s_MemberID != Web.SessionMembers.s_MemberID)
                {
                    if (!MembersWatchListDealers.CheckIfWatched(Web.SessionMembers.MemberID, Convert.ToInt32(s_MemberID)))
                    {
                        if (!Contacts.IsMyContact(s_MemberID, Web.SessionMembers.MemberID))
                            if (s_ActivityID == "0" || s_ActivityID == "1" || s_ActivityID == "2" || s_ActivityID == "3" || s_ActivityID == "13" || s_ActivityID == "40" || s_ActivityID == "41" || s_ActivityID == "45")
                                show = true;
                    }
                }
                else
                    show = false;
            }
            else
            {
                if (s_ActivityID == "1" || s_ActivityID == "2" || s_ActivityID == "3" || s_ActivityID == "13" || s_ActivityID == "40" ||
                    s_ActivityID == "41" || s_ActivityID == "45")
                    show = true;
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
        return show;
    }
    public static bool ShowUnlink(string s_MemberID, string s_ActivityID)
    {
        bool show = false;
        try
        {
            if (Web.IsMemberSession)
            {
                if (s_MemberID != Web.SessionMembers.s_MemberID)
                {
                    if (MembersWatchListDealers.CheckIfWatched(Web.SessionMembers.MemberID, Convert.ToInt32(s_MemberID)))
                        if (s_ActivityID == "0" || s_ActivityID == "1" || s_ActivityID == "2" || s_ActivityID == "3" || s_ActivityID == "13" || s_ActivityID == "40" || s_ActivityID == "41" || s_ActivityID == "45")
                            show = true;
                }
                else
                    show = false;
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
        return show;
    }
    public static bool ShowReportAbuse(string s_ActivityID)
    {
        bool show = false;
        try
        {
            if (s_ActivityID == "2" || s_ActivityID == "3" || s_ActivityID == "13" || s_ActivityID == "40" || s_ActivityID == "41" || s_ActivityID == "45" || s_ActivityID == "46")
                show = true;
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
        return show;
    }
    public static bool ShowComment(string s_ActivityID)
    {
        bool result = true;
        try
        {
            if (!Web.IsMemberSession)
                result = false;
            else
            {
                if (s_ActivityID == "4" || s_ActivityID == "8" || s_ActivityID == "9" || s_ActivityID == "19" || s_ActivityID == "27" || s_ActivityID == "34")
                    result = false;
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
        return result;
    }
    public static bool ShowAddContact(string s_MemberID)
    {
        bool show = false;
        try
        {
            if (Web.IsMemberSession)
            {
                if (s_MemberID != Web.SessionMembers.s_MemberID)
                {
                    if (!Contacts.IsMyContact(s_MemberID, Web.SessionMembers.MemberID))
                        show = true;
                }
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
        return show;
    }
    public static bool ShowWatchListing(string s_ListingID, string s_Seller)
    {
        bool result = false;
        try
        {
            if (Web.IsMemberSession)
            {
                if (Web.SessionMembers.s_MemberID != s_Seller)
                    if (MembersWatchList.CanBeWatched(Convert.ToInt32(s_ListingID), Web.SessionMembers.MemberID))
                        result = true;
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
        return result;
    }
    /// <summary>
    /// Shorten a comment
    /// </summary>
    /// <param name="comment"></param>
    /// <param name="CommentID"></param>
    /// <returns></returns>
    public static string ShortenComment(string comment, int CommentID)
    {
        string newstring = comment;
        string[] substrings = { };
        try
        {
            // check if length is greater than 280
            if (newstring.Length > 280)
            {
                // if there is link tag then break after its closing tag
                if (newstring.Contains("<a") || newstring.Contains("&lt;a"))
                {
                    string decodedString = HttpUtility.HtmlDecode(newstring);
                    decodedString = decodedString.Substring(0, decodedString.LastIndexOf("</a>") + 4);
                    newstring = decodedString;
                }

                //check for multiple <br> in the post if so
                //then display only 6 lines
                string[] Breaks;
                string br = "<br/>";
                Breaks = Regex.Split(newstring, br);
                if (Breaks.Length > 6)
                    newstring = Breaks[0].ToString() + br + Breaks[1].ToString() + br + Breaks[2].ToString() + br + Breaks[3].ToString() + br + Breaks[4].ToString() + br + Breaks[5].ToString() + br;
                else
                {
                    Breaks = Regex.Split(newstring, "\n");
                    if (Breaks.Length > 6)
                        newstring = Breaks[0].ToString() + br + Breaks[1].ToString() + br + Breaks[2].ToString() + br + Breaks[3].ToString() + br + Breaks[4].ToString() + br + Breaks[5].ToString() + br;
                    else
                    {
                        if (newstring.Length > 440)//to show 6 lines in each comment
                            newstring = newstring.Remove(440);
                        else
                            newstring = newstring.Remove(280);
                        try
                        {
                            //place the try-catch block if the comment contains without any space
                            newstring = newstring.Substring(0, newstring.LastIndexOf(" "));
                        }
                        catch { }
                        if (newstring.EndsWith("<br"))
                        {
                            newstring = newstring.Insert(newstring.Length, "/>....");
                        }
                        else
                        {
                            newstring = newstring.Insert(newstring.Length, "....");
                        }
                    }
                }
                newstring += "...<a href=\"javascript:void(0);\" onclick=\"Show('full_" + CommentID + "');Hide('short_" + CommentID + "');\">View More>></a>";
            }
            else
            {
                //check for multiple <br /> in the post if so
                //then display only 6 lines
                string[] Breaks;
                string br = "<br/>";
                Breaks = Regex.Split(newstring, br);
                if (Breaks.Length > 6)
                {
                    newstring = Breaks[0].ToString() + br + Breaks[1].ToString() + br + Breaks[2].ToString() + br + Breaks[3].ToString() + br + Breaks[4].ToString() + br + Breaks[5].ToString() + br;
                    newstring += "...<a href=\"javascript:void(0);\" onclick=\"Show('full_" + CommentID + "');Hide('short_" + CommentID + "');\">View More>></a>";
                }
                else
                {
                    Breaks = Regex.Split(newstring, "\n");
                    if (Breaks.Length > 6)
                    {
                        newstring = Breaks[0].ToString() + br + Breaks[1].ToString() + br + Breaks[2].ToString() + br + Breaks[3].ToString() + br + Breaks[4].ToString() + br + Breaks[5].ToString() + br;
                        newstring += "...<a href=\"javascript:void(0);\" onclick=\"Show('full_" + CommentID + "');Hide('short_" + CommentID + "');\">View More>></a>";
                    }
                }
            }
            newstring = MakeLinksClickable(newstring);
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
        return newstring;
    }

    #endregion

    #region Messages Manipulation
    public static string GetShortMessage(string originalMessage, string s_ContactMsgID, string concat, string s_LogID)
    {
        string newstring = originalMessage;
        bool HasFile = false;
        string[] substrings = { };
        try
        {
            // get attached files
            string filesHTML = GetFileinHTML(Convert.ToInt32(s_ContactMsgID));

            // check if length is greater than 280
            if (newstring.Length > 400)
            {
                bool hasMore = false;

                // if message contains any div or table
                if (newstring.Contains("<div") || newstring.Contains("<table"))
                {
                    // if message contains attached lots/items, there will be a break line:<div id=\"break\"></div> to dovide the message
                    if (newstring.Contains("<div id=\"break\"></div>"))
                    {
                        Regex regex = new Regex("<div id=\"break\"></div>", RegexOptions.IgnoreCase);
                        substrings = regex.Split(newstring);
                        if (substrings.Length > 0)
                        {
                            if (substrings.Length >= 2) HasFile = true;
                            newstring = substrings[0];
                        }
                    }
                    // if message contains div
                    else if (newstring.Contains("<div>"))
                    {
                        Regex regex = new Regex("</div>", RegexOptions.IgnoreCase);
                        substrings = regex.Split(newstring);
                        if (substrings.Length > 0)
                        {
                            if (substrings.Length >= 2) HasFile = true;
                            newstring = substrings[0];
                        }
                    }
                    // if message contains table
                    else if (newstring.Contains("<table>"))
                    {
                        Regex regex = new Regex("</table>", RegexOptions.IgnoreCase);
                        substrings = regex.Split(newstring);
                        if (substrings.Length > 0)
                        {
                            if (substrings.Length >= 2) HasFile = true;
                            newstring = substrings[0];
                        }
                    }
                }
                // if there's no div or table
                else
                {
                    // if there is link tag then break after its closing tag
                    if (newstring.Contains("<a") || newstring.Contains("&lt;a"))
                    {
                        string decodedString = HttpUtility.HtmlDecode(newstring);
                        decodedString = decodedString.Substring(0, decodedString.LastIndexOf("</a>") + 4);
                        newstring = decodedString;
                    }
                    else
                    {
                        newstring = newstring.Remove(400);
                        try
                        {
                            //place the try-catch block if the comment contains without any space
                            newstring = newstring.Substring(0, newstring.LastIndexOf(" "));
                        }
                        catch { }
                        newstring = newstring.Insert(newstring.Length, "....");
                    }
                    hasMore = true;

                    //check for multiple <br /> in the post if so
                    //then display only 6 lines
                    string[] Breaks;
                    string br = "<br />";
                    string shortStr = "";
                    Breaks = Regex.Split(newstring, br);
                    if (Breaks.Length > 6)
                    {
                        shortStr = Breaks[0].ToString() + br + Breaks[1].ToString() + br + Breaks[2].ToString() + br + Breaks[3].ToString() + br + Breaks[4].ToString() + br + Breaks[5].ToString() + br;
                        newstring = shortStr;
                        hasMore = true;
                    }
                    else
                    {
                        shortStr = "";
                        Breaks = Regex.Split(newstring, "\r\n");
                        if (Breaks.Length > 6)
                        {
                            shortStr = Breaks[0].ToString() + br + Breaks[1].ToString() + br + Breaks[2].ToString() + br + Breaks[3].ToString() + br + Breaks[4].ToString() + br + Breaks[5].ToString() + br;
                            newstring = shortStr;
                            hasMore = true;
                        }
                    }
                }
                ////////show hide when more lots in the post
                string[] moreLots = { };
                Regex reg = new Regex("ViewLot.aspx", RegexOptions.IgnoreCase);
                moreLots = reg.Split(originalMessage);
                // if message exceeds 280 and doesn't contain any lots/items
                if (hasMore)
                {
                    // if message contains attachment
                    if (!String.IsNullOrEmpty(filesHTML))
                        newstring = filesHTML + "<br /><br /><table class=\"feed_Comments\" style=\"width:100%  !important;\"><tr><td><div style=\"float: left; display: inline; text-align: justify; padding: 0; font-size: 8pt; font-weight: normal;\">" + newstring + "</div></td></tr></table><br /><a onclick=\"ShowHide('div_short_msg_" + concat + ((!String.IsNullOrEmpty(s_LogID)) ? s_LogID : s_ContactMsgID) + "', 'div_full_msg_" + concat + ((!String.IsNullOrEmpty(s_LogID)) ? s_LogID : s_ContactMsgID) + "')\" href=\"javascript:void(0);\" style=\"font-size:9px;\">View More>></a>";
                    else
                        newstring = "<table class=\"feed_Comments\" style=\"width:100%  !important;\"><tr><td><div style=\"float: left; display: inline; text-align: justify; padding: 0; font-size: 8pt; font-weight: normal;\">" + newstring + "</div></td></tr></table><br /><a onclick=\"ShowHide('div_short_msg_" + concat + ((!String.IsNullOrEmpty(s_LogID)) ? s_LogID : s_ContactMsgID) + "', 'div_full_msg_" + concat + ((!String.IsNullOrEmpty(s_LogID)) ? s_LogID : s_ContactMsgID) + "')\" href=\"javascript:void(0);\" style=\"font-size:9px;\">View More>></a>";
                }
                else if (HasFile) // if message contains lots/items
                {
                    // if message contains attachment
                    if (!String.IsNullOrEmpty(filesHTML))
                    {
                        if (moreLots.Length >= 3)
                            newstring = filesHTML + "<table class=\"feed_Comments\" style=\"width:100%  !important;\"><tr><td><div style=\"float: left; display: inline; text-align: justify; padding: 0; font-size: 8pt; font-weight: normal;\">" + substrings[0] + "</div></td></tr></table><br /><a onclick=\"ShowHide('div_short_msg_" + concat + ((!String.IsNullOrEmpty(s_LogID)) ? s_LogID : s_ContactMsgID) + "', 'div_full_msg_" + concat + ((!String.IsNullOrEmpty(s_LogID)) ? s_LogID : s_ContactMsgID) + "')\" href=\"javascript:void(0);\" style=\"font-size:9px;\">View More>></a>";
                        else
                            newstring = filesHTML + "<table class=\"feed_Comments\" style=\"width:100%  !important;\"><tr><td><div style=\"float: left; display: inline; text-align: justify; padding: 0; font-size: 8pt; font-weight: normal;\">" + substrings[0] + "</div></td></tr></table>";
                    }
                    else
                    {
                        if (moreLots.Length >= 3)
                            newstring = "<table class=\"feed_Comments\" style=\"width:100%  !important;\"><tr><td><div style=\"float: left; display: inline; text-align: justify; padding: 0; font-size: 8pt; font-weight: normal;\">" + substrings[0] + "</div></td></tr></table><br /><a onclick=\"ShowHide('div_short_msg_" + concat + ((!String.IsNullOrEmpty(s_LogID)) ? s_LogID : s_ContactMsgID) + "', 'div_full_msg_" + concat + ((!String.IsNullOrEmpty(s_LogID)) ? s_LogID : s_ContactMsgID) + "')\" href=\"javascript:void(0);\" style=\"font-size:9px;\">View More>></a>";
                        else
                            newstring = "<table class=\"feed_Comments\" style=\"width:100%  !important;\"><tr><td><div style=\"float: left; display: inline; text-align: justify; padding: 0; font-size: 8pt; font-weight: normal;\">" + substrings[0] + "</div></td></tr></table>";
                    }
                }
                else // for simple message
                {
                    // if message contains attachment
                    if (!String.IsNullOrEmpty(filesHTML))
                        newstring = filesHTML + "<br /><br /><table class=\"feed_Comments\" style=\"width:100%  !important;\"><tr><td><div style=\"float: left; display: inline; text-align: justify; padding: 0; font-size: 8pt; font-weight: normal;\">" + newstring + "</div></td></tr></table>";
                    else
                        newstring = "<table class=\"feed_Comments\" style=\"width:100%  !important;\"><tr><td><div style=\"float: left; display: inline; text-align: justify; padding: 0; font-size: 8pt; font-weight: normal;\">" + newstring + "</div></td></tr></table>";
                }
            }
            else
            {
                //check for multiple <br /> in the post if so
                //then display only 6 lines
                string[] Breaks;
                string br = "<br />";
                string shortStr = "";
                Breaks = Regex.Split(newstring, br);
                if (Breaks.Length > 6)
                {
                    shortStr = Breaks[0].ToString() + br + Breaks[1].ToString() + br + Breaks[2].ToString() + br + Breaks[3].ToString() + br + Breaks[4].ToString() + br + Breaks[5].ToString() + br;
                    newstring = shortStr + "<br /><a onclick=\"ShowHide('div_short_msg_" + concat + ((!String.IsNullOrEmpty(s_LogID)) ? s_LogID : s_ContactMsgID) + "', 'div_full_msg_" + concat + ((!String.IsNullOrEmpty(s_LogID)) ? s_LogID : s_ContactMsgID) + "')\" href=\"javascript:void(0);\" style=\"font-size:9px;\">View More>></a>";
                }
                else
                {
                    shortStr = "";
                    Breaks = Regex.Split(newstring, "\r\n");
                    if (Breaks.Length > 6)
                    {
                        shortStr = Breaks[0].ToString() + br + Breaks[1].ToString() + br + Breaks[2].ToString() + br + Breaks[3].ToString() + br + Breaks[4].ToString() + br + Breaks[5].ToString() + br;
                        newstring = shortStr + "<br /><a onclick=\"ShowHide('div_short_msg_" + concat + ((!String.IsNullOrEmpty(s_LogID)) ? s_LogID : s_ContactMsgID) + "', 'div_full_msg_" + concat + ((!String.IsNullOrEmpty(s_LogID)) ? s_LogID : s_ContactMsgID) + "')\" href=\"javascript:void(0);\" style=\"font-size:9px;\">View More>></a>";
                    }
                }

                // final oputput
                if (!String.IsNullOrEmpty(filesHTML))
                    newstring = filesHTML + "<br /><br /><table class=\"feed_Comments\" style=\"width:100%  !important;\"><tr><td><div style=\"float: left; display: inline; text-align: justify; padding: 0; font-size: 8pt; font-weight: normal;\">" + newstring + "</div></td></tr></table>";
                else
                    newstring = "<table class=\"feed_Comments\" style=\"width:100%  !important;\"><tr><td><div style=\"float: left; display: inline; text-align: justify; padding: 0; font-size: 8pt; font-weight: normal;\">" + newstring + "</div></td></tr></table>";
            }

            // if message contains script
            if (newstring.Contains("<script>"))
            {
                string[] message = newstring.Split('<');
                newstring = (message[0].Contains("<script>")) ? HttpUtility.HtmlEncode(message[0]) : message[0];
            }

            // line breaks
            newstring = newstring.Replace("\r\n", "<br />");
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
        return newstring;
    }
    public static string GetFullMessage(string Message, string s_ContactMsgID)
    {
        string newstring = Message;
        try
        {
            string filesHTML = GetFileinHTML(Convert.ToInt32(s_ContactMsgID));
            //if (Message.Contains("<div") || Message.Contains("<table"))
            //{
            //    string[] message = Message.Split('<');
            //    if (message.Length > 0)
            //    {
            //        string msg = message[0].Replace("\r\n", "<br />");
            //        newstring = Web.ParseTemplate((msg.Contains("<script>")) ? (HttpUtility.HtmlEncode(msg) + Message.Substring(Message.IndexOf('<'), (Message.Length - Message.IndexOf('<')))) : msg + Message.Substring(Message.IndexOf('<'), (Message.Length - Message.IndexOf('<'))));
            //    }
            //    else
            //        newstring = Web.ParseTemplate((Message.Contains("<script>")) ? (HttpUtility.HtmlEncode((Message.Length > 60) ? Message.Replace("\r\n", "<br />") : Message.Replace("\r\n", "<br />"))) : Message.Replace("\r\n", "<br />"));
            //}
            //else
            //    newstring = Web.ParseTemplate((Message.Contains("<script>")) ? (HttpUtility.HtmlEncode((Message.Length > 60) ? Message.Replace("\r\n", "<br />") : Message.Replace("\r\n", "<br />"))) : Message.Replace("\r\n", "<br />"));

            //if (!String.IsNullOrEmpty(filesHTML))
            //    newstring = Web.ParseTemplate(filesHTML) + "<br /><br />" + newstring.Replace("\r\n", "<br />");

            newstring = "<div style='font-weight:bold;font-size: 7pt;'>" + filesHTML + "</div><table class='feed_Comments' style='width: 100% ! important;'><tbody><tr><td><div style='float: left; display: inline; text-align: justify; padding: 0pt; font-size: 8pt; font-weight: normal;'>" + Message + "</td></tr></tbody></table><br />";
            newstring = newstring.Replace("\r\n", "<br />");
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
        return newstring;
    }
    public static string GetFileinHTML(int ContactMessageID)
    {
        string s_filesHTML = "";
        StringBuilder filesHtml = new StringBuilder();
        try
        {
            DataTable files = SystemObjectFiles.GetFiles(400, ContactMessageID);
            if (files.Rows.Count > 0)
            {
                foreach (DataRow row in files.Rows)
                {
                    string type = row["FileTypeID"].ToString();
                    if (type == "1")
                    {
                        filesHtml.Append("<a class=\"highslide\" onclick=\"return hs.expand(this)\" href=\"../../ePage/ImageViewer.ashx?Action=SystemObjectPhoto&RecordID=");
                        filesHtml.Append(row["SystemObjectFileID"].ToString());
                        filesHtml.Append("\"><img id=\"Img3\" src=\"../../ePage/ImageViewer.ashx?Action=SystemObjectPhotoThumbnail&RecordID=");
                        filesHtml.Append(row["SystemObjectFileID"].ToString());
                        filesHtml.Append("\" />");
                        filesHtml.Append("</a>");
                    }
                    else if (type == "2")
                    {
                        filesHtml.Append("<a href='../../ePage/ImageViewer.ashx?Action=SystemObjectDocument&RecordID=");
                        filesHtml.Append(row["SystemObjectFileID"].ToString());
                        filesHtml.Append("'><img src=\"../../Images/attachment.png\" /></a>");
                    }
                    else if (type == "3")
                    {
                        //filesHtml.Append("<a target=\"_blank\" href=\"");
                        //filesHtml.Append(row["URL"].ToString());
                        //filesHtml.Append("\">");
                        //filesHtml.Append(Web.BreakString(files.Rows[0]["URL"].ToString(), 70));
                        //filesHtml.Append("</a>");
                        filesHtml.Append(row["URL"].ToString());
                    }
                    else if (type == "4")
                    {
                        //Code commented and added by Irfan Dayan. 15-07-2011.
                        filesHtml.Append("<div class=\"LoadingVideoBackground\" style=\"background-position: center 50%;width:420px;height:220px;\">");

                        filesHtml.Append("<div><object width='420' height='240'><param name='movie' value='" + row["URL"].ToString() + "'><param name='type' value='application/x-shockwave-flash'><param name='allowfullscreen' value='true'><param name='allowscriptaccess' value='always'><param name=\"wmode\" value=\"opaque\" /><embed width='420' height='240' src='" + row["URL"].ToString() + "' type='application/x-shockwave-flash' allowfullscreen='true' allowscriptaccess='always' wmode=\"opaque\"></embed></object></div>");

                        //filesHtml.Append("<iframe width=\"420\" height=\"220\" src=\"" + row["URL"].ToString() + "\" " +
                        //  " frameborder=\"0\" allowfullscreen  scrolling=\"no\" ></iframe>");

                        //filesHtml.Append("<object>");
                        //filesHtml.Append("<param name=\"movie\" value=\"");
                        //filesHtml.Append(row["URL"].ToString());
                        //filesHtml.Append("\" />");
                        //filesHtml.Append("<param name=\"allowFullScreen\" value=\"true\"></param>");
                        //filesHtml.Append("<param name=\"allowscriptaccess\" value=\"always\"></param>");
                        //filesHtml.Append("<param name=\"wmode\" value=\"opaque\" />");
                        ////filesHtml.Append("<param name=\"wmode\" value=\"transparent\" />");
                        //filesHtml.Append("<embed src=\"");
                        //filesHtml.Append(row["URL"].ToString());
                        //filesHtml.Append("&amp;hl=en_US&amp;fs=1&amp;rel=0&amp;border=1&amp;color1=0x2b405b&amp;color2=0x6b8ab6\"");
                        //filesHtml.Append("type=\"application/x-shockwave-flash\" allowscriptaccess=\"always\" allowfullscreen=\"true\"");
                        //filesHtml.Append(" width=\"280\" height=\"155\" wmode=\"opaque\" /></object>");
                        filesHtml.Append("</div>");
                        //Code commented and added by Irfan Dayan ends here. 15-07-2011.
                    }
                    else if (type == "5")
                    {
                        filesHtml.Append("<a class=\"highslide\" onclick=\"return hs.expand(this)\" href=\"");
                        filesHtml.Append(row["URL"].ToString());
                        filesHtml.Append("\"><img id=\"Img3\" src=\"");
                        filesHtml.Append(row["ThumbnailURL"].ToString());
                        filesHtml.Append("\" />");
                        filesHtml.Append("</a>");
                    }
                    else if (type == "6")
                    {
                        filesHtml.Append("<a href='");
                        filesHtml.Append(row["URL"].ToString());
                        filesHtml.Append("'><img src=\"../../Images/attachment.png\" /></a>");
                    }
                    if (filesHtml.Length > 0)
                        filesHtml.Append("&nbsp;&nbsp;");
                }
            }
            s_filesHTML = filesHtml.ToString();
        }
        catch (Exception ex) { Web.LogError(ex); }
        return s_filesHTML;
    }

    public static string RemoveExtraLines(string message)
    {
        string newstring = message;
        try
        {
            if (message.Contains("\r\n"))
                newstring = message.Replace("\r\n", "<br />");

            if (newstring.Contains("<br />"))
            {
                string[] lines = Regex.Split(newstring, "<br />");

                if (lines.Length > 3)
                {
                    newstring = "";
                    for (int i = 0; i < 3; i++)
                        newstring += lines[i] + "<br />";
                }
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
        return newstring;
    }
    #endregion

    #region Post to the World Comments Manipulation
    public static string GetShortComment(string originalComment, string activityLogId, string activityId, string activityDate)
    {
        string newstring = originalComment;
        try
        {
            string filesHTML = "";
            // previously comments were considered as messages, thats why this check was required
            if (activityId == "13")
            {
                DateTime changeDate = DateTime.Parse(ConfigurationManager.AppSettings["CommentChangeDate"].ToString());
                if (DateTime.Parse(activityDate) < changeDate)
                {
                    if (String.IsNullOrEmpty(filesHTML))
                        filesHTML = GetFileinHTML(Convert.ToInt32(activityLogId));
                }
                else filesHTML = GetAttachments(Convert.ToInt32(activityLogId));
            }
            else filesHTML = GetAttachments(Convert.ToInt32(activityLogId));

            if (originalComment.Length > 280)
            {
                if (originalComment.Contains("<div") || originalComment.Contains("<table"))
                {
                    if (originalComment.Contains("<div id=\"break\"></div>"))
                    {
                        Regex regex = new Regex("<div id=\"break\"></div>", RegexOptions.IgnoreCase);
                        string[] substrings = regex.Split(originalComment);
                        if (substrings.Length > 0)
                        {
                            string value = substrings[0];
                            newstring = (value.Contains("<script>")) ? HttpUtility.HtmlEncode(value) : value;
                        }
                    }
                    else
                    {
                        string[] comment = originalComment.Split('<');
                        newstring = (comment[0].Contains("<script>")) ? HttpUtility.HtmlEncode(comment[0]) : comment[0];
                    }
                }
                else
                    newstring = (originalComment.Contains("<script>")) ? HttpUtility.HtmlEncode(originalComment) : originalComment;

                bool hasMore = false;
                if (!originalComment.Contains("<div id=\"break\"></div>"))
                    if (newstring.Length > 280)
                    {
                        string decodedString = HttpUtility.HtmlDecode(newstring);
                        decodedString = decodedString.Substring(0, 280);
                        decodedString = decodedString.Substring(0, decodedString.LastIndexOf("</a>") + 4);
                        newstring = decodedString;
                        hasMore = true;
                    }

                newstring = newstring.Replace("\r\n", "<br />");

                if (hasMore)
                {
                    if (!String.IsNullOrEmpty(filesHTML))
                        newstring = filesHTML + "<br /><br /><table class=\"feed_Comments\" style=\"width:100%  !important;\"><tr><td><div style=\"float: left; display: inline; text-align: justify; padding: 0; font-size: 8pt; font-weight: normal;\">" + Web.BreakString(newstring, 60) + "</div></td></tr></table><br /><a onclick=\"ShowHide('div_short_feed_" + activityLogId + "', 'div_full_feed_" + activityLogId + "')\" href=\"javascript:void(0);\" style=\"font-size:9px;\">View More>></a>";
                    else
                        newstring = "<table class=\"feed_Comments\" style=\"width:100%  !important;\"><tr><td><div style=\"float: left; display: inline; text-align: justify; padding: 0; font-size: 8pt; font-weight: normal;\">" + Web.BreakString(newstring, 60) + "</div></td></tr></table><br /><a onclick=\"ShowHide('div_short_feed_" + activityLogId + "', 'div_full_feed_" + activityLogId + "')\" href=\"javascript:void(0);\" style=\"font-size:9px;\">View More>></a>";
                }
                else
                {
                    if (!String.IsNullOrEmpty(filesHTML))
                        newstring = filesHTML + "<br /><br /><table class=\"feed_Comments\" style=\"width:100%  !important;\"><tr><td><div style=\"float: left; display: inline; text-align: justify; padding: 0; font-size: 8pt; font-weight: normal;\">" + Web.BreakString(newstring, 60) + "</div></td></tr></table>";
                    else
                        newstring = "<table class=\"feed_Comments\" style=\"width:100%  !important;\"><tr><td><div style=\"float: left; display: inline; text-align: justify; padding: 0; font-size: 8pt; font-weight: normal;\">" + Web.BreakString(newstring, 60) + "</div></td></tr></table>";
                }
            }
            else
            {
                newstring = newstring.Replace("\r\n", "<br />");

                if (!String.IsNullOrEmpty(filesHTML))
                    newstring = filesHTML + "<br /><br /><table class=\"feed_Comments\" style=\"width:100%  !important;\"><tr><td><div style=\"float: left; display: inline; text-align: justify; padding: 0; font-size: 8pt; font-weight: normal;\">" + Web.BreakString(newstring, 60) + "</div></td></tr></table>";
                else
                    newstring = "<table class=\"feed_Comments\" style=\"width:100%  !important;\"><tr><td><div style=\"float: left; display: inline; text-align: justify; padding: 0; font-size: 8pt; font-weight: normal;\">" + Web.BreakString(newstring, 60) + "</div></td></tr></table>";
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
        return newstring;
    }
    public static string GetFullComment(string Comment, string activityLogId, string activityId, string activityDate)
    {
        string newstring = Comment;
        try
        {
            string filesHTML = "";
            // previously comments were considered as messages, thats why this check was required
            if (activityId == "13")
            {
                DateTime changeDate = DateTime.Parse(ConfigurationManager.AppSettings["CommentChangeDate"].ToString());
                Log.Write("Change Date: ", changeDate.ToString(), new Exception(""));
                if (DateTime.Parse(activityDate) < changeDate)
                {
                    if (String.IsNullOrEmpty(filesHTML))
                        filesHTML = GetFileinHTML(Convert.ToInt32(activityLogId));
                }
                else filesHTML = GetAttachments(Convert.ToInt32(activityLogId));
            }
            else filesHTML = GetAttachments(Convert.ToInt32(activityLogId));

            if (Comment.Contains("<div") || Comment.Contains("<table"))
            {
                string[] comment = Comment.Split('<');
                if (comment.Length > 0)
                {
                    string feed = comment[0].Replace("\r\n", "<br />");
                    newstring = Web.ParseTemplate((feed.Contains("<script>")) ? (HttpUtility.HtmlEncode((feed.Length > 60) ? Web.BreakString(feed, 60) : feed) + Comment.Substring(Comment.IndexOf('<'), (Comment.Length - Comment.IndexOf('<')))) : ((feed.Length > 60) ? Web.BreakString(feed, 60) : feed) + Comment.Substring(Comment.IndexOf('<'), (Comment.Length - Comment.IndexOf('<'))));
                }
                else
                    newstring = Web.ParseTemplate((Comment.Contains("<script>")) ? (HttpUtility.HtmlEncode((Comment.Length > 60) ? Web.BreakString(Comment, 60).Replace("\r\n", "<br />") : Comment.Replace("\r\n", "<br />"))) : (Comment.Length > 60) ? Web.BreakString(Comment, 60).Replace("\r\n", "<br />") : Comment.Replace("\r\n", "<br />"));
            }
            else
                newstring = Web.ParseTemplate((Comment.Contains("<script>")) ? (HttpUtility.HtmlEncode((Comment.Length > 60) ? Web.BreakString(Comment, 60).Replace("\r\n", "<br />") : Comment.Replace("\r\n", "<br />"))) : (Comment.Length > 60) ? Web.BreakString(Comment, 60).Replace("\r\n", "<br />") : Comment.Replace("\r\n", "<br />"));

            if (!String.IsNullOrEmpty(filesHTML))
                newstring = Web.ParseTemplate(filesHTML) + "<br /><br />" + newstring.Replace("\r\n", "<br />");
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
        return newstring;
    }
    protected static string GetAttachments(int objectId)
    {
        string s_filesHTML = "";
        var filesHtml = new StringBuilder();
        try
        {
            DataTable files = SystemObjectFiles.GetFiles(300, objectId);
            if (files.Rows.Count > 0)
            {
                foreach (DataRow row in files.Rows)
                {
                    string type = row["FileTypeID"].ToString();
                    if (type == "1")
                    {
                        filesHtml.Append("<a class=\"highslide\" onclick=\"return hs.expand(this)\" href=\"../../ePage/ImageViewer.ashx?Action=SystemObjectPhoto&RecordID=");
                        filesHtml.Append(row["SystemObjectFileID"].ToString());
                        filesHtml.Append("\"><img id=\"Img3\" src=\"../../ePage/ImageViewer.ashx?Action=SystemObjectPhotoThumbnail&RecordID=");
                        filesHtml.Append(row["SystemObjectFileID"].ToString());
                        filesHtml.Append("\" />");
                        filesHtml.Append("</a>");
                    }
                    else if (type == "2")
                    {
                        filesHtml.Append("<a href='../../ePage/ImageViewer.ashx?Action=SystemObjectDocument&RecordID=");
                        filesHtml.Append(row["SystemObjectFileID"].ToString());
                        filesHtml.Append("'><img src=\"../../Images/attachment.png\" /></a>");
                    }
                    else if (type == "3")
                    {
                        filesHtml.Append("<a target=\"_blank\" href=\"");
                        filesHtml.Append(row["URL"].ToString());
                        filesHtml.Append("\">");
                        filesHtml.Append(Web.BreakString(files.Rows[0]["URL"].ToString(), 70));
                        filesHtml.Append("</a>");
                    }
                    else if (type == "4")
                    {
                        //Code commented and added by Irfan Dayan. 15-07-2011.
                        filesHtml.Append("<div class=\"LoadingVideoBackground\" style=\"background-position: center 50%;width:280px;height:155px;\">");
                        filesHtml.Append("<iframe width=\"280\" height=\"155\" src=\"" + row["URL"].ToString() + "\" " +
                          " frameborder=\"0\" allowfullscreen  scrolling=\"no\" ></iframe>");

                        //filesHtml.Append("<object>");
                        //filesHtml.Append("<param name=\"movie\" value=\"");
                        //filesHtml.Append(row["URL"].ToString());
                        //filesHtml.Append("\" />");
                        //filesHtml.Append("<param name=\"allowFullScreen\" value=\"true\"></param>");
                        //filesHtml.Append("<param name=\"allowscriptaccess\" value=\"always\"></param>");
                        //filesHtml.Append("<embed src=\"");
                        //filesHtml.Append(row["URL"].ToString());
                        //filesHtml.Append("&amp;hl=en_US&amp;fs=1&amp;rel=0&amp;border=1&amp;color1=0x2b405b&amp;color2=0x6b8ab6\"");
                        //filesHtml.Append("type=\"application/x-shockwave-flash\" allowscriptaccess=\"always\" allowfullscreen=\"true\"");
                        //filesHtml.Append(" width=\"280\" height=\"155\" /></object>");
                        filesHtml.Append("</div>");
                        //Code commented and added by Irfan Dayan ends here. 15-07-2011.
                    }
                    else if (type == "5")
                    {
                        filesHtml.Append("<a class=\"highslide\" onclick=\"return hs.expand(this)\" href=\"");
                        filesHtml.Append(row["URL"].ToString());
                        filesHtml.Append("\"><img id=\"Img3\" src=\"");
                        filesHtml.Append(row["ThumbnailURL"].ToString());
                        filesHtml.Append("\" />");
                        filesHtml.Append("</a>");
                    }
                    else if (type == "6")
                    {
                        filesHtml.Append("<a  href=\"");
                        filesHtml.Append(row["URL"].ToString());
                        filesHtml.Append("\"><img src=\"../../Images/attachment.png\" /></a>");
                    }
                    if (filesHtml.Length > 0)
                        filesHtml.Append("&nbsp;&nbsp;");
                }
            }
            s_filesHTML = filesHtml.ToString();
        }
        catch (Exception ex) { Web.LogError(ex); }
        return s_filesHTML;
    }
    public static string GetAttachments(int objectId, int SystemObjectID)
    {
        string s_filesHTML = "";
        var filesHtml = new StringBuilder();
        try
        {
            DataTable files = SystemObjectFiles.GetFiles(SystemObjectID, objectId);
            if (files.Rows.Count > 0)
            {
                foreach (DataRow row in files.Rows)
                {
                    string type = row["FileTypeID"].ToString();
                    if (type == "1")// Photo
                    {
                        filesHtml.Append("<a class=\"highslide\" onclick=\"return hs.expand(this)\" href=\"../../ePage/ImageViewer.ashx?Action=SystemObjectPhoto&RecordID=");
                        filesHtml.Append(row["SystemObjectFileID"].ToString());
                        filesHtml.Append("\"><img id=\"Img3\" src=\"");
                        filesHtml.Append(row["ThumbnailURL"].ToString());
                        filesHtml.Append("\" />");
                        filesHtml.Append("</a>");
                    }
                    else if (type == "2")// Document
                    {
                        //filesHtml.Append("<br/>"); //fb like files uploads
                        //filesHtml.Append("<a href='../../ePage/ImageViewer.ashx?Action=SystemObjectDocument&RecordID=");
                        //filesHtml.Append(row["SystemObjectFileID"].ToString());
                        //filesHtml.Append("'><img src=\"../../Images/attachment.png\" /></a>");

                        filesHtml.Append("<div>"); //fb like files uploads
                        filesHtml.AppendFormat("<span><a href='../../ePage/ImageViewer.ashx?Action=SystemObjectDocument&RecordID={0}'><img src='{1}'>&nbsp;<span>{1}</span> </a> </span>", row["SystemObjectFileID"],GetFileIconUrl(row["URL"]), Path.GetFileName(row["URL"].ToString()));
                        filesHtml.Append("</div>");

                    }
                    else if (type == "3")// Link
                    {
                        if (!row["URL"].ToString().Contains("tinyURLs"))
                        {
                            //filesHtml.Append("<br/>"); //fb like files uploads
                            //filesHtml.Append("<a target=\"_blank\" href=\"");
                            //filesHtml.Append(row["URL"].ToString());
                            //filesHtml.Append("\">");
                            //filesHtml.Append(Web.BreakString(files.Rows[0]["URL"].ToString(), 70));
                            //filesHtml.Append("</a>");
                            filesHtml.Append("<div>"); //fb like files uploads
                            filesHtml.AppendFormat("<span><a target='_blank' href='{0}'><img src='/App_Themes/Space/Images/eOpen 16X16 Icons/eo_icon_url.png'>&nbsp;<span>Click Here to View Link&gt;&gt;</span> </a> </span>", row["URL"]);
                            filesHtml.Append("</div>");
                        }
                        else
                        {
                            filesHtml.Append("<br/>"); //fb like files uploads
                            filesHtml.Append("<img src='/App_Themes/Space/Images/eOpen 16X16 Icons/eo_icon_url.png'>&nbsp;");
                            filesHtml.Append(row["URL"].ToString());
                            filesHtml.Append("<br/>");
                        }
                    }
                    else if (type == "4")// Video
                    {
                        //filesHtml.Append("<div class=\"LoadingVideoBackground\" style=\"background-position: center 50%;width:280px;height:155px;\">");
                        //filesHtml.Append("<object>");
                        //filesHtml.Append("<param name=\"movie\" value=\"");
                        //filesHtml.Append(row["URL"].ToString());
                        //filesHtml.Append("\" />");
                        //filesHtml.Append("<param name=\"allowFullScreen\" value=\"true\"></param>");
                        //filesHtml.Append("<param name=\"allowscriptaccess\" value=\"always\"></param>");
                        //filesHtml.Append("<param name=\"wmode\" value=\"opaque\" />");
                        //filesHtml.Append("<param name=\"wmode\" value=\"transparent\" />");
                        //filesHtml.Append("<embed src=\"");
                        //filesHtml.Append(row["URL"].ToString());
                        //filesHtml.Append("&amp;hl=en_US&amp;fs=1&amp;rel=0&amp;border=1&amp;color1=0x2b405b&amp;color2=0x6b8ab6\"");
                        //filesHtml.Append("type=\"application/x-shockwave-flash\" allowscriptaccess=\"always\" allowfullscreen=\"true\"");
                        //filesHtml.Append(" width=\"280\" height=\"155\" /></object>");
                        //filesHtml.Append("</div>");

                        filesHtml.Append("<div class=\"LoadingVideoBackground\" style=\"background-position: center 50%;width:480px;height:250px;\">");
                        filesHtml.Append("<object>");
                        filesHtml.Append("<param name=\"movie\" value=\"");
                        filesHtml.Append(row["URL"].ToString());
                        filesHtml.Append("\" />");
                        filesHtml.Append("<param name=\"allowFullScreen\" value=\"true\"></param>");
                        filesHtml.Append("<param name=\"allowscriptaccess\" value=\"always\"></param>");
                        filesHtml.Append("<param name=\"wmode\" value=\"opaque\" />");
                        filesHtml.Append("<embed src=\"");
                        filesHtml.Append(row["URL"].ToString());
                        //filesHtml.Append("&amp;hl=en_US&amp;fs=1&amp;rel=0&amp;border=0&amp;color1=0x2b405b&amp;color2=0x6b8ab6\"");
                        filesHtml.Append("&amp;hl=en_US&amp;fs=1&amp;rel=0\"");
                        filesHtml.Append("type=\"application/x-shockwave-flash\" allowscriptaccess=\"always\" allowfullscreen=\"true\"");
                        filesHtml.Append(" width=\"100%\" height=\"100%\" wmode=\"opaque\" /></object>");
                        filesHtml.Append("</div>");
                    }
                    else if (type == "5")// ImageUrl
                    {
                        filesHtml.Append("<a class=\"highslide\" onclick=\"return hs.expand(this)\" href=\"");
                        filesHtml.Append(row["URL"].ToString());
                        filesHtml.Append("\"><img id=\"Img3\" src=\"");
                        filesHtml.Append(row["ThumbnailURL"].ToString());
                        filesHtml.Append("\" />");
                        filesHtml.Append("</a>");
                    }
                    else if (type == "6")// FileUrl
                    {
                        filesHtml.Append("<div>"); //fb like files uploads
                        filesHtml.AppendFormat("<span><a href='{0}'><img src='{1}'>&nbsp;<span>{2}</span> </a> </span>", row["URL"],GetFileIconUrl(row["URL"]), Path.GetFileName(row["URL"].ToString()));
                        filesHtml.Append("</div>");
                        //filesHtml.Append("<a  href=\"");
                        //filesHtml.Append(row["URL"].ToString());
                        //filesHtml.Append("\"><img src=\"../../Images/attachment.png\" /></a>");

                    }
                    if (filesHtml.Length > 0)
                        filesHtml.Append("&nbsp;&nbsp;");
                }
            }
            s_filesHTML = filesHtml.ToString();
        }
        catch (Exception ex) { Web.LogError(ex); }
        return s_filesHTML;
    }
    public static string GetFileIconUrl(object filePath)
    {
        string baseUrl = string.Format("App_Themes/Space/Images/eOpen 16X16 Icons/", HttpContext.Current.Server.MapPath("App_Themes").TrimEnd('/'));

        try
        {
            string fileExtention = Path.GetExtension(filePath.ToString()).ToLower().TrimEnd();

            if (fileExtention.Equals(".doc") || fileExtention.Equals(".docx") || fileExtention.Equals(".rtf") || fileExtention.Equals(".txt"))
            {
                return baseUrl + "eo_icon_word.png";
            }
            if (fileExtention.Equals(".ppt") || fileExtention.Equals(".pptx"))
            {
                return baseUrl + "eo_icon_powerpoint.png";
            }
            if (fileExtention.Equals(".xls") || fileExtention.Equals(".xlsx"))
            {
                return baseUrl + "eo_icon_xlsx.png";
            }
            if (fileExtention.Equals(".xls") || fileExtention.Equals(".xlsx"))
            {
                return baseUrl + "eo_icon_pdf.png";
            }
        }
        catch (Exception exp)
        {
            Web.LogError(exp);
        }
        return baseUrl + "eo_icon_default_file.png";
    }

    public static string ConvertToTinyURL(string val)
    {
        try
        {
            string HostName = SystemConfigs.GetKey("SITE_URL");
            int urlID;
            string anchorTag = "";
            TinyUrls tiny = new TinyUrls();

            Regex r1 = new Regex("((http://|www\\.)([A-Z0-9.-:]{1,})\\.[0-9A-Z?;~:&+%#=\\-_\\./]{2,})", RegexOptions.Compiled | RegexOptions.IgnoreCase);
            MatchCollection mc = r1.Matches(val);
            foreach (Match m in mc)
            {
                tiny.AddNew();
                tiny.TinyUrl = (m.Value.Contains("http://")) ? m.Value : "http://" + m.Value;
                tiny.Save();
                urlID = tiny.TinyUrlID;

                val = val.Replace(m.Value, HostName + "epage/tinyURLs.ashx?tinyURLID=" + urlID);

                anchorTag = "<a href='" + HostName + "epage/tinyURLs.ashx?tinyURLID=" + urlID + "' target='_blank'>Click to view link>></a>";
                val = val.Replace(HostName + "epage/tinyURLs.ashx?tinyURLID=" + urlID, anchorTag);


                val = val.Replace(m.Value, "<a href='" + m.Value + "'>" + m.Value + "</a>");
            }
        }
        catch (Exception exp)
        {
            Web.LogError(exp);
        }
        return val;
    }
    #endregion

    public static string GetShortBillboard(string billboard, int LogID)
    {
        string newstring = billboard;

        try
        {
            if (billboard.Length > 440)
            {
                //modified to cut the paragraph 
                billboard = billboard.Substring(0, 450);
                billboard = billboard.Substring(0, billboard.LastIndexOf(" "));
                billboard = billboard.Insert(billboard.Length, "....");
                newstring = "<div style=\"display:inline;padding-right:5px;\" id=\"div_short_banner_" + LogID + "\">" + Web.BreakLongString(billboard, 70) + "&nbsp;<a onclick=\"ShowHideInline('div_short_banner_" + LogID + "', 'div_full_banner_" + LogID + "')\" href=\"javascript:void(0);\" style=\"font-size:9px;\">View More>></a></div><div style=\"display:none;padding-right:5px;\" id=\"div_full_banner_" + LogID + "\">" + Web.BreakLongString(MakeLinksClickable(newstring), 70) + "&nbsp;<a onclick=\"ShowHideInline('div_full_banner_" + LogID + "', 'div_short_banner_" + LogID + "')\" href=\"javascript:void(0);\" style=\"font-size:9px;\">View Less>></a></div>";

            }
            newstring = MakeLinksClickable(newstring);
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
        return newstring;
    }
    public static string GetTime(DateTime currenttime)
    {
        string time = "";

        TimeSpan timespan = DateTime.Now.Subtract(currenttime);

        if (timespan.Days <= 0)
        {
            if (timespan.Hours <= 0)
            {
                if (timespan.Minutes <= 0)
                {
                    if (timespan.Seconds <= 15)
                        time = "few seconds ago";
                    else
                        time = timespan.Seconds.ToString() + " sec. ago";
                }
                else
                {
                    time = timespan.Minutes.ToString() + " min. ago";
                }
            }
            else
            {
                if (timespan.Hours == 1)
                    time = timespan.Hours.ToString() + " hour ago";
                else
                    time = timespan.Hours.ToString() + " hours ago";
            }
        }
        else
        {
            if (timespan.Days == 1)
            {
                time = timespan.Days.ToString() + " day ago";
            }
            else if (timespan.Days < 1)
            {
                if (timespan.Hours == 1)
                    time = timespan.Hours.ToString() + " hour ago";
                else if (timespan.Hours > 1)
                    time = timespan.Hours.ToString() + " hours ago";
                else if (timespan.Minutes < 60)
                    time = timespan.Minutes.ToString() + " mins ago";
                else time = timespan.Seconds.ToString() + " secs ago";
            }
            else if (timespan.Days > 1)
            {
                time = timespan.Days.ToString() + " days ago";
            }

            if (timespan.Days > 30 && timespan.Days < 365)
            {
                time = (int)((double)timespan.Days / 30.436875) + " months ago";
                if (time == "1 months ago")
                    time = time.Replace("months", "month");
            }
            if (timespan.Days >= 365)
            {
                time = (int)((double)timespan.Days / 365.2425) + " years ago";
                if (time == "1 years ago")
                    time = time.Replace("years", "year");
            }
        }
        return time;
    }
    public static string GetDetailedTime(DateTime currenttime)
    {
        string time = "";

        TimeSpan timespan = DateTime.Now.Subtract(currenttime);

        if (timespan.Days <= 0)
        {
            if (timespan.Hours <= 0)
            {
                if (timespan.Minutes <= 0)
                {
                    time = timespan.Seconds.ToString() + " sec. ago";
                }
                else
                {
                    time = timespan.Minutes.ToString() + " min. ago";
                }
            }
            else
            {
                if (timespan.Hours == 1)
                    time = timespan.Hours.ToString() + " hour ago";
                else
                    time = timespan.Hours.ToString() + " hours ago";
            }
        }
        else
        {
            if (timespan.Days == 1)
            {
                time = " Yesterday at " + currenttime.ToString("h:mm tt");
            }
            else if (timespan.Days < 1)
            {
                if (timespan.Hours == 1)
                    time = timespan.Hours.ToString() + " hour ago";
                else if (timespan.Hours > 1)
                    time = timespan.Hours.ToString() + " hours ago";
                else if (timespan.Minutes < 60)
                    time = timespan.Minutes.ToString() + " mins ago";
                else time = timespan.Seconds.ToString() + " secs ago";
            }
            else
            {
                if (timespan.Days > 1 && timespan.Days < 7)
                {
                    time = currenttime.ToString("dddd") + " at " + currenttime.ToString("h:mm tt");
                }
                else
                {
                    time = currenttime.ToString("MMM dd ") + " at " + currenttime.ToString("h:mm tt");
                }
            }
        }
        return time;
    }
    public static bool Link(int LinkedTo)
    {
        bool result = true;
        try
        {
            if (Web.IsMemberSession)
            {
                if (MembersWatchListDealers.Link(Web.SessionMembers.MemberID, LinkedTo))
                {
                    Members member = new Members();
                    if (member.LoadByPrimaryKey(LinkedTo))
                    {
                        if (MemberTrustScore.TrustMemberScoreOne(Web.SessionMembers.MemberID, LinkedTo, "Added to Linkings",
                                                             RatingTypes.Linked_To, null))
                        {
                            var templateKeys = new System.Collections.Specialized.StringDictionary();
                            templateKeys.Add("#email_header#", Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER"));
                            templateKeys.Add("#company#", Web.SessionMembers.CompanyName);
                            templateKeys.Add("#fullname_invitee#", Web.SessionMembers.FullName);
                            templateKeys.Add("#fullname#", member.FullName);
                            templateKeys.Add("#profile_name#", Web.SessionMembers.UserName);
                            templateKeys.Add("#profile_link#",
                                             Web.SystemConfigs.GetKey("SITE_URL") +
                                             "Contacts/ViewProfile.aspx?Action=View&RecordID=" +
                                             Secure.Encrypt(Web.SessionMembers.MemberID));
                            templateKeys.Add("#email_footer#", Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER"));
                            Web.SendMail(member.Email, Web.SystemConfigs.GetKey("ALERTS_EMAIL"), 801,
                                         templateKeys);
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
        return result;
    }
    public static string MakeLinksClickable(string input)
    {
        string output = input, value = "";
        try
        {
            Regex regx = new Regex(@"((www\.|(http|https)+\:\/\/)[_.a-z0-9-]+\.[a-z0-9\/_:@=.+?,##%&~-]*[^.|\'|\# |!|\(|?|,| |>|<|;|\)])", RegexOptions.IgnoreCase);
            Match match = regx.Match(output);
            while (match.Success)
            {
                value = match.Value;
                if (!String.IsNullOrEmpty(value))
                {
                    if (!value.Contains("http://") && !value.Contains("https://"))
                        value = "http://" + value;
                    output = output.Replace(match.Value, "<a runat=\"server\" target='_blank' href='" + value + "'>" + value + "</a>");
                }
                match = match.NextMatch();
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
        return output;
    }
    public static string GetUserName(int MemberID, string Name)
    {
        string result = "";
        try
        {
            if (Web.IsMemberSession)
            {
                if (MemberID == Web.SessionMembers.MemberID)
                    result = "You";
                else
                    result = Name;
            }
            else
                result = Name;
        }
        catch (Exception ex)
        {
            //Log.Write("Error", ex.GetBaseException().ToString(), ex);
            result = Name;
            Web.LogError(ex);
        }
        return result;
    }
    public static void EmailonComment(int ActivityLogID, string profileName, string Comment, int userID)
    {
        try
        {
            //commented to get email all the way
            Members member = new Members();
            string[] name;
            StringDictionary templateKeys = new StringDictionary();
            if (Web.SessionMembers.MemberID != userID)
            {
                member.LoadByPrimaryKey(userID);
                if (member.RowCount > 0)
                {
                    name = member.FullName.Split();
                    templateKeys.Add("#email_header#", Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER"));
                    templateKeys.Add("#first_name#", name[0]);
                    templateKeys.Add("#profile_name#", Web.SessionMembers.UserName);
                    templateKeys.Add("#comment#", Comment);
                    templateKeys.Add("#live_exhibit_link#", Web.SystemConfigs.GetKey("SITE_URL") + "Live.aspx");
                    templateKeys.Add("#sitename#", Web.SystemConfigs.GetKey("SITE_NAME"));
                    templateKeys.Add("#email_footer#", Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER"));
                    Web.SendMail(member.Email, Web.SystemConfigs.GetKey("REG_EMAIL"), 018, templateKeys);
                }
            }
            int lastCommentBy = MemberActivityLogComments.GetMemberOfLastComment(1, ActivityLogID, userID, Web.SessionMembers.MemberID);
            if (lastCommentBy > 0)
            {
                member = new Members();
                member.LoadByPrimaryKey(lastCommentBy);
                if (member.RowCount > 0)
                {
                    name = member.FullName.Split();
                    templateKeys = new StringDictionary();
                    templateKeys.Add("#email_header#", Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER"));
                    templateKeys.Add("#first_name#", name[0]);
                    templateKeys.Add("#profile_name#", Web.SessionMembers.UserName);
                    templateKeys.Add("#comment#", Comment);
                    templateKeys.Add("#live_exhibit_link#", Web.SystemConfigs.GetKey("SITE_URL") + "Live.aspx");
                    templateKeys.Add("#sitename#", Web.SystemConfigs.GetKey("SITE_NAME"));
                    templateKeys.Add("#email_footer#", Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER"));
                    Web.SendMail(member.Email, Web.SystemConfigs.GetKey("REG_EMAIL"), 018, templateKeys);
                }
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }

    #region "break messages or comment that does not contain any space, any break"
    /// <summary>
    /// breaks a string if it does not contain any "br" or "spaces"
    /// </summary>
    /// <param name="str">string to chunk</param>
    /// <param name="chunkSize">length for each line after broken</param>
    /// <returns>return the string broken into many chunks</returns>
    public static string SplitString(string str, int chunkSize)
    {
        ArrayList arList = new ArrayList();
        string strResult = "";
        try
        {
            for (int i = 0; i < str.Length; i += chunkSize)
            {
                if ((str.Substring(i).Length > chunkSize))
                {
                    if ((str.Contains("<br") || str.Contains("&lt;")) && (!str.Contains(" ")))
                    {
                        arList.Add(str.Substring(i));

                        if (str == arList[0].ToString())
                            break;
                    }
                    else
                        arList.Add(str.Substring(i, chunkSize));
                }
                else
                    arList.Add(str.Substring(i));

                if (str == arList[0].ToString())
                    break;
            }
            foreach (var s in arList)
            {
                if (!s.ToString().Contains(" "))
                    strResult += s + "<br />";
                else
                    strResult += s;
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
        return strResult;
    }
    #endregion


    #region Save Attachments
    /// <summary>
    /// Save attachments
    /// </summary>
    /// <param name="SystemObjectID"></param>
    /// <param name="ObjectID"></param>
    /// <param name="fupPhoto"></param>
    /// <param name="fupDocument"></param>
    /// <param name="txtLink"></param>
    /// <param name="txtVideoLink"></param>
    public static void SaveFiles(int SystemObjectID, int ObjectID, RadUpload fupPhoto, RadUpload fupDocument, TextBox txtLink, HiddenField txtVideoLink, int PrivacyTypeID)
    {
        try
        {
            SystemObjectFiles objfile = new SystemObjectFiles();
            if (fupPhoto.UploadedFiles.Count > 0)
            {
                UploadImages(SystemObjectID, ObjectID, fupPhoto, PrivacyTypeID);
            }
            if (fupDocument.UploadedFiles.Count > 0)
            {
                UploadFiles(SystemObjectID, ObjectID, fupDocument, PrivacyTypeID);
            }
            if (!String.IsNullOrEmpty(txtLink.Text))
            {
                string URL = txtLink.Text;
                if (txtLink.Text.Contains("http://"))
                    URL = txtLink.Text;
                else
                    URL = "http://" + txtLink.Text;
                URL = Web.ConvertToTinyURL(URL);
                SystemObjectFiles file = new SystemObjectFiles();
                file.AddNew();
                file.FileDate = DateTime.Now;
                file.FileTypeID = (int)FileTypes.Link;
                file.s_IsActive = "1";
                file.ObjectID = ObjectID;
                file.SystemObjectID = SystemObjectID;
                file.RemoteIP = System.Web.HttpContext.Current.Request.UserHostAddress;
                file.URL = URL;
                file.MemberID = Web.SessionMembers.MemberID;
                file.PrivacyTypeID = PrivacyTypeID;
                file.Save();
            }
            if (!String.IsNullOrEmpty(txtVideoLink.Value))
            {
                string videoLink = txtVideoLink.Value.Replace("/embed/", "/v/");
                //RegEx to Find YouTube ID
                //System.Text.RegularExpressions.Match regexMatch = System.Text.RegularExpressions.Regex.Match(videoLink, "^[^v]+v=(.{11}).*",
                //                   System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                //if (regexMatch.Success)
                //    videoLink = "http://www.youtube.com/v/" + regexMatch.Groups[1].Value;

                SystemObjectFiles file = new SystemObjectFiles();
                file.AddNew();
                file.FileDate = DateTime.Now;
                file.FileTypeID = (int)FileTypes.Video;
                file.s_IsActive = "1";
                file.ObjectID = ObjectID;
                file.SystemObjectID = SystemObjectID;
                file.RemoteIP = System.Web.HttpContext.Current.Request.UserHostAddress;
                file.URL = videoLink;
                file.MemberID = Web.SessionMembers.MemberID;
                file.PrivacyTypeID = PrivacyTypeID;
                file.Save();
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }
    public static void SaveFiles(int SystemObjectID, int ObjectID, List<string> filesList, string txtLink, string txtVideoLink, int PrivacyTypeID)
    {
        try
        {
            SystemObjectFiles objfile = new SystemObjectFiles();
            foreach (string file in filesList)
            {
                if (IsImageFile(file))
                {
                    UploadImages(SystemObjectID, ObjectID, file, PrivacyTypeID);
                }
                else
                {
                    UploadFiles(SystemObjectID, ObjectID, file, PrivacyTypeID);
                }
            }

            if (!String.IsNullOrEmpty(txtLink))
            {
                string URL = txtLink;
                if (txtLink.Contains("http://"))
                    URL = txtLink;
                else
                    URL = "http://" + txtLink;
                URL = Web.ConvertToTinyURL(URL);
                SystemObjectFiles file = new SystemObjectFiles();
                file.AddNew();
                file.FileDate = DateTime.Now;
                file.FileTypeID = (int)FileTypes.Link;
                file.s_IsActive = "1";
                file.ObjectID = ObjectID;
                file.SystemObjectID = SystemObjectID;
                file.RemoteIP = System.Web.HttpContext.Current.Request.UserHostAddress;
                file.URL = URL;
                file.MemberID = Web.SessionMembers.MemberID;
                file.PrivacyTypeID = PrivacyTypeID;
                file.Save();
            }
            if (!String.IsNullOrEmpty(txtVideoLink))
            {
                string videoLink = txtVideoLink.Replace("/embed/", "/v/");
                //RegEx to Find YouTube ID
                //System.Text.RegularExpressions.Match regexMatch = System.Text.RegularExpressions.Regex.Match(videoLink, "^[^v]+v=(.{11}).*",
                //                   System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                //if (regexMatch.Success)
                //    videoLink = "http://www.youtube.com/v/" + regexMatch.Groups[1].Value;

                SystemObjectFiles file = new SystemObjectFiles();
                file.AddNew();
                file.FileDate = DateTime.Now;
                file.FileTypeID = (int)FileTypes.Video;
                file.s_IsActive = "1";
                file.ObjectID = ObjectID;
                file.SystemObjectID = SystemObjectID;
                file.RemoteIP = System.Web.HttpContext.Current.Request.UserHostAddress;
                file.URL = videoLink;
                file.MemberID = Web.SessionMembers.MemberID;
                file.PrivacyTypeID = PrivacyTypeID;
                file.Save();
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }

    public static void SaveFiles(int SystemObjectID, int ObjectID, string repositryKey)
    {
        SaveFiles(Web.SessionMembers.MemberID, SystemObjectID, ObjectID, repositryKey);
    }

    public static void SaveFiles(int MemberID, int SystemObjectID, int ObjectID, string repositryKey)
    {
        try
        {
            var objfile = new SystemObjectFiles();

            string targetFolder = Web.SystemConfigs.GetKey("ATTACHMENTS_PHYSICAL_PATH");
            string folderVirtualPath = Web.SystemConfigs.GetKey("ATTACHMENTS_PATH");
            string targetThumbnailFolder = targetFolder + "/Thumbnails";
            string folderVirtualThumbnailPath = folderVirtualPath + "/Thumbnails";
            List<UploaderRepository> uploadedFiles = RepositryManager.GetRepositry(repositryKey);

            if (uploadedFiles.Count < 1)
                return;

            int counter = 0;
            foreach (var file in uploadedFiles)
            {
                counter++;
                objfile.AddNew();
                string fileName = ObjectID + "_" + SystemObjectID + "_" + counter.ToString() + file.FileExtention;

                if (file.FileType == FileTypes.Photo)
                {
                    File.Copy(file.FilePath, Path.Combine(targetFolder, fileName), true);
                    Web.CreateThumbnail(System.Drawing.Image.FromFile(targetFolder + "/" + fileName), 100, 100).Save(Path.Combine(targetThumbnailFolder, fileName));
                    objfile.ThumbnailURL = folderVirtualThumbnailPath + "/" + fileName;
                }

                if (file.FileType == FileTypes.Video || file.FileType == FileTypes.Link)
                {
                    objfile.URL = file.Url;
                }
                else
                {
                    objfile.URL = folderVirtualPath + "/" + fileName;
                }

                objfile.OriginalFileName = file.FileName;
                objfile.FileTypeID = (int)file.FileType;
                objfile.FileDate = DateTime.Now;
                objfile.s_IsActive = "1";
                objfile.ObjectID = ObjectID;
                objfile.SystemObjectID = SystemObjectID;
                objfile.RemoteIP = System.Web.HttpContext.Current.Request.UserHostAddress;
                objfile.FileFormat = file.FileType.ToString();
                objfile.FileName = fileName;
                objfile.MemberID = MemberID;
                objfile.PrivacyTypeID = 0;
                objfile.FileTypeID = Convert.ToInt32(file.FileType);
                objfile.Save();
            }

            RepositryManager.ClearRepositry(repositryKey);
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }



    public static bool IsImageFile(string filePath)
    {
        try
        {
            List<string> imageExtenions = new List<string>() { ".png", ".jpg", "jpeg", ".gif", ".bmp" };
            return imageExtenions.Contains(Path.GetExtension(filePath).ToLower());
        }
        catch
        {
            return false;
        }
    }
    public static void UpdateFiles(int SystemObjectID, int ObjectID, RadUpload fupPhoto, RadUpload fupDocument, TextBox txtLink, HiddenField txtVideoLink, int PrivacyTypeID)
    {
        try
        {
            SystemObjectFiles objfile = new SystemObjectFiles();
            if (fupPhoto.UploadedFiles.Count > 0)
            {
                // delete current images
                SystemObjectFiles files = new SystemObjectFiles();
                files.Where.ObjectID.Value = ObjectID;
                files.Where.FileTypeID.Value = (int)FileTypes.ImageURL;
                files.Where.SystemObjectID.Value = Convert.ToInt32(SystemObjects.Listings);
                if (files.Query.Load())
                {
                    do
                    {
                        if (File.Exists(files.URL))
                        {
                            File.Delete(files.URL);
                        }
                        files.MarkAsDeleted();
                        files.Save();
                    }
                    while (files.MoveNext());
                }
                UploadImages(SystemObjectID, ObjectID, fupPhoto, PrivacyTypeID);
            }
            if (fupDocument.UploadedFiles.Count > 0)
            {
                // delete current files
                SystemObjectFiles files = new SystemObjectFiles();
                files.Where.ObjectID.Value = ObjectID;
                files.Where.FileTypeID.Value = (int)FileTypes.Document;
                files.Where.SystemObjectID.Value = Convert.ToInt32(SystemObjects.Listings);
                if (files.Query.Load())
                {
                    do
                    {
                        files.MarkAsDeleted();
                        files.Save();
                    }
                    while (files.MoveNext());
                }
                UploadFiles(SystemObjectID, ObjectID, fupDocument, PrivacyTypeID);
            }
            if (!String.IsNullOrEmpty(txtLink.Text))
            {
                // delete current links
                SystemObjectFiles files = new SystemObjectFiles();
                files.Where.ObjectID.Value = ObjectID;
                files.Where.FileTypeID.Value = (int)FileTypes.Link;
                files.Where.SystemObjectID.Value = Convert.ToInt32(SystemObjects.Listings);
                if (files.Query.Load())
                {
                    do
                    {
                        files.MarkAsDeleted();
                        files.Save();
                    }
                    while (files.MoveNext());
                }
                string URL = txtLink.Text;
                if (txtLink.Text.Contains("http://"))
                    URL = txtLink.Text;
                else
                    URL = "http://" + txtLink.Text;
                URL = Web.ConvertToTinyURL(URL);
                SystemObjectFiles file = new SystemObjectFiles();
                file.AddNew();
                file.FileDate = DateTime.Now;
                file.FileTypeID = (int)FileTypes.Link;
                file.s_IsActive = "1";
                file.ObjectID = ObjectID;
                file.SystemObjectID = SystemObjectID;
                file.RemoteIP = System.Web.HttpContext.Current.Request.UserHostAddress;
                file.URL = URL;
                file.MemberID = Web.SessionMembers.MemberID;
                file.PrivacyTypeID = PrivacyTypeID;
                file.Save();
            }
            if (!String.IsNullOrEmpty(txtVideoLink.Value))
            {
                // delete current links
                SystemObjectFiles files = new SystemObjectFiles();
                files.Where.ObjectID.Value = ObjectID;
                files.Where.FileTypeID.Value = (int)FileTypes.Video;
                files.Where.SystemObjectID.Value = Convert.ToInt32(SystemObjects.Listings);
                if (files.Query.Load())
                {
                    do
                    {
                        files.MarkAsDeleted();
                        files.Save();
                    }
                    while (files.MoveNext());
                }
                string videoLink = txtVideoLink.Value;
                //RegEx to Find YouTube ID
                //System.Text.RegularExpressions.Match regexMatch = System.Text.RegularExpressions.Regex.Match(videoLink, "^[^v]+v=(.{11}).*",
                //                   System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                //if (regexMatch.Success)
                //    videoLink = "http://www.youtube.com/v/" + regexMatch.Groups[1].Value;

                SystemObjectFiles file = new SystemObjectFiles();
                file.AddNew();
                file.FileDate = DateTime.Now;
                file.FileTypeID = (int)FileTypes.Video;
                file.s_IsActive = "1";
                file.ObjectID = ObjectID;
                file.SystemObjectID = SystemObjectID;
                file.RemoteIP = System.Web.HttpContext.Current.Request.UserHostAddress;
                file.URL = videoLink;
                file.MemberID = Web.SessionMembers.MemberID;
                file.PrivacyTypeID = PrivacyTypeID;
                file.Save();
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }
    public static bool ThumbnailCallback()
    { return false; }

    public static void UploadImages(int SystemObjectID, int ObjectID, RadUpload fupPhoto, int PrivacyTypeID)
    {
        try
        {
            var objfile = new SystemObjectFiles();
            int counter = 1;
            string targetFolder = Web.SystemConfigs.GetKey("ATTACHMENTS_PHYSICAL_PATH");
            string folderVirtualPath = Web.SystemConfigs.GetKey("ATTACHMENTS_PATH");
            string targetThumbnailFolder = targetFolder + "/Thumbnails";
            string folderVirtualThumbnailPath = folderVirtualPath + "/Thumbnails";
            foreach (UploadedFile file in fupPhoto.UploadedFiles)
            {
                // Save image to physical path
                string fileName = ObjectID + "_" + SystemObjectID + "_" + counter.ToString() + file.GetExtension();
                string targetFileURL = targetFolder + "/" + fileName;// Path.Combine(targetFolder, fileName);
                string virtualURL = folderVirtualPath + "/" + fileName; //Path.Combine(folderVirtualPath, fileName);

                while (System.IO.File.Exists(targetFileURL))
                {
                    targetFileURL = targetFolder + "/" + fileName;//Path.Combine(targetFolder, fileName);
                }

                file.SaveAs(targetFileURL);

                // save thumbnail to physical path
                fileName = ObjectID + "_" + SystemObjectID + "_" + counter.ToString() + file.GetExtension();
                string thumbnailTargetFileURL = Path.Combine(targetThumbnailFolder, fileName);
                string virtualThumbnailURL = folderVirtualThumbnailPath + "/" + fileName;

                Web.CreateThumbnail(System.Drawing.Image.FromStream(file.InputStream), 100, 100).Save(thumbnailTargetFileURL);

                //System.Drawing.Image.GetThumbnailImageAbort thumbnailImageAbortDelegate = new System.Drawing.Image.GetThumbnailImageAbort(ThumbnailCallback);
                //using (Bitmap originalImage = new Bitmap(file.InputStream))
                //{
                //    decimal w1 = originalImage.Width;
                //    decimal h1 = originalImage.Height;

                //    int height = Web.CalculateThumbnailHeight(w1, h1);
                //    int width = Convert.ToInt32(SystemConfigs.GetKey("THUMBNAIL_SIZE"));

                //    using (System.Drawing.Image thumbnail = originalImage.GetThumbnailImage(width, height, thumbnailImageAbortDelegate, IntPtr.Zero))
                //    {
                //        thumbnail.Save(thumbnailTargetFileURL);
                //    }
                //}

                // add an entry to DB
                objfile.AddNew();
                objfile.FileDate = DateTime.Now;
                objfile.FileTypeID = (int)FileTypes.ImageURL;
                objfile.s_IsActive = "1";
                objfile.ObjectID = ObjectID;
                objfile.SystemObjectID = SystemObjectID;
                objfile.RemoteIP = System.Web.HttpContext.Current.Request.UserHostAddress;
                objfile.FileFormat = file.ContentType;
                objfile.FileName = fileName;
                objfile.URL = virtualURL;
                objfile.ThumbnailURL = virtualThumbnailURL;
                objfile.MemberID = Web.SessionMembers.MemberID;
                objfile.PrivacyTypeID = PrivacyTypeID;
                objfile.Save();

                counter++;
            }
        }
        catch (Exception ex)
        { Web.LogError(ex); }
    }
    public static void UploadImages(int SystemObjectID, int ObjectID, string filePath, int PrivacyTypeID)
    {
        try
        {
            var objfile = new SystemObjectFiles();

            string targetFolder = Web.SystemConfigs.GetKey("ATTACHMENTS_PHYSICAL_PATH");
            string folderVirtualPath = Web.SystemConfigs.GetKey("ATTACHMENTS_PATH");
            string targetThumbnailFolder = targetFolder + "/Thumbnails";
            string folderVirtualThumbnailPath = folderVirtualPath + "/Thumbnails";

            string fileName = string.Format("{0}_{1}_{2}{3}", ObjectID, SystemObjectID, DateTime.Now.Ticks, Path.GetExtension(filePath));
            string targetFileURL = targetFolder + "/" + fileName;// Path.Combine(targetFolder, fileName);
            string virtualURL = folderVirtualPath + "/" + fileName; //Path.Combine(folderVirtualPath, fileName);

            //if (System.IO.File.Exists(targetFileURL))
            //{
            //    targetFileURL = targetFolder + "/" + fileName;//Path.Combine(targetFolder, fileName);
            //}

            using (FileStream fs = File.Create(targetFileURL))
            {
            }


            // save thumbnail to physical path
            //fileName = ObjectID + "_" + SystemObjectID + Path.GetExtension(filePath);
            string thumbnailTargetFileURL = Path.Combine(targetThumbnailFolder, fileName);
            string virtualThumbnailURL = folderVirtualThumbnailPath + "/" + fileName;

            Web.CreateThumbnail(System.Drawing.Image.FromFile(filePath), 100, 100).Save(thumbnailTargetFileURL);
            //Web.CreateThumbnail(System.Drawing.Image.FromStream(fs.InputStream), 100, 100).Save(thumbnailTargetFileURL);

            // add an entry to DB
            objfile.AddNew();
            objfile.FileDate = DateTime.Now;
            objfile.FileTypeID = (int)FileTypes.ImageURL;
            objfile.s_IsActive = "1";
            objfile.ObjectID = ObjectID;
            objfile.SystemObjectID = SystemObjectID;
            objfile.RemoteIP = System.Web.HttpContext.Current.Request.UserHostAddress;
            objfile.FileFormat = Path.GetExtension(filePath);
            objfile.FileName = fileName;
            objfile.URL = virtualURL;
            objfile.ThumbnailURL = virtualThumbnailURL;
            objfile.MemberID = Web.SessionMembers.MemberID;
            objfile.PrivacyTypeID = PrivacyTypeID;
            objfile.Save();

            //counter++; 
        }
        catch (Exception ex)
        { Web.LogError(ex); }
    }

    public static void UploadFiles(int SystemObjectID, int ObjectID, RadUpload fupDocument, int PrivacyTypeID)
    {
        try
        {
            var objfile = new SystemObjectFiles();
            int counter = 1;
            string targetFolder = Web.SystemConfigs.GetKey("ATTACHMENTS_PHYSICAL_PATH");
            string folderVirtualPath = Web.SystemConfigs.GetKey("ATTACHMENTS_PATH");
            foreach (UploadedFile file in fupDocument.UploadedFiles)
            {
                // Save file to physical path
                string fileName = ObjectID + "_" + SystemObjectID + "_" + counter.ToString() + file.GetExtension();
                string targetFileURL = targetFolder + "/" + fileName; // Path.Combine(targetFolder, fileName);
                string virtualURL = folderVirtualPath + "/" + fileName;// Path.Combine(folderVirtualPath, fileName);

                while (System.IO.File.Exists(targetFileURL))
                {
                    targetFileURL = targetFolder + "/" + fileName; //Path.Combine(targetFolder, fileName);
                }

                file.SaveAs(targetFileURL);

                // add an entry to DB
                objfile.AddNew();
                objfile.FileDate = DateTime.Now;
                objfile.FileTypeID = (int)FileTypes.FileURL; //
                objfile.s_IsActive = "1";
                objfile.ObjectID = ObjectID;
                objfile.s_FileName = file.FileName;
                objfile.SystemObjectID = SystemObjectID;
                objfile.RemoteIP = System.Web.HttpContext.Current.Request.UserHostAddress;
                objfile.FileFormat = file.GetExtension();
                objfile.FileName = fileName;
                objfile.URL = virtualURL;
                objfile.MemberID = Web.SessionMembers.MemberID;
                objfile.PrivacyTypeID = PrivacyTypeID;
                objfile.Save();

                counter++;
            }
        }
        catch (Exception ex)
        { Web.LogError(ex); }
    }

    public static void UploadFiles(int SystemObjectID, int ObjectID, string filePath, int PrivacyTypeID)
    {
        try
        {
            var objfile = new SystemObjectFiles();
            string targetFolder = Web.SystemConfigs.GetKey("ATTACHMENTS_PHYSICAL_PATH");
            string folderVirtualPath = Web.SystemConfigs.GetKey("ATTACHMENTS_PATH");

            string fileName = string.Format("{0}_{1}_{2}{3}", ObjectID, SystemObjectID, DateTime.Now.Ticks, Path.GetExtension(filePath));
            string targetFileURL = targetFolder + "/" + fileName; // Path.Combine(targetFolder, fileName);
            string virtualURL = folderVirtualPath + "/" + fileName;// Path.Combine(folderVirtualPath, fileName);

            while (System.IO.File.Exists(targetFileURL))
            {
                targetFileURL = targetFolder + "/" + fileName; //Path.Combine(targetFolder, fileName);
            }

            File.Create(targetFileURL);

            // add an entry to DB
            objfile.AddNew();
            objfile.FileDate = DateTime.Now;
            objfile.FileTypeID = (int)FileTypes.FileURL; //
            objfile.s_IsActive = "1";
            objfile.ObjectID = ObjectID;
            objfile.s_FileName = Path.GetFileName(filePath);
            objfile.SystemObjectID = SystemObjectID;
            objfile.RemoteIP = System.Web.HttpContext.Current.Request.UserHostAddress;
            objfile.FileFormat = Path.GetExtension(filePath);
            objfile.FileName = fileName;
            objfile.URL = virtualURL;
            objfile.MemberID = Web.SessionMembers.MemberID;
            objfile.PrivacyTypeID = PrivacyTypeID;
            objfile.Save();
        }
        catch (Exception ex)
        { Web.LogError(ex); }
    }
    #endregion

    /// <summary>
    /// returns listingfields data for specific field
    /// </summary>
    /// <param name="fields"></param>
    /// <param name="FieldID"></param>
    /// <returns></returns>
    public static object GetFieldData(ListingExtendedFields fields, int FieldID)
    {
        object data = null;
        try
        {
            fields.Rewind();
            do
            {
                if (fields.FieldID == FieldID)
                {
                    data = fields.Data;
                    break;
                }
            }
            while (fields.MoveNext());
        }
        catch (Exception ex) { Web.LogError(ex); }
        return data;
    }
    
    public static bool HasPlacedOffer(int ListingID, int MemberID)
    {
        bool result = false;
        try
        {
            ListingOffers offers = new ListingOffers();
            offers.Query.AddResultColumn(ListingOffersSchema.ListingID);
            offers.Query.AddResultColumn(ListingOffersSchema.OfferBy);
            offers.Query.AddResultColumn(ListingOffersSchema.OfferStatusID);
            offers.Query.AddResultColumn(ListingOffersSchema.OfferDate);
            offers.Query.AddResultColumn(ListingOffersSchema.OfferValidFor);
            offers.Where.ListingID.Value = ListingID;
            offers.Where.OfferBy.Value = MemberID;
            offers.Where.OfferStatusID.Value = 100;
            offers.Where.OfferStatusID.Operator = NCI.EasyObjects.WhereParameter.Operand.NotEqual;
            offers.Query.Load();

            if (offers.RowCount > 0)
            {
                return true;

                int count = 0;
                do
                {
                    DateTime expiry = offers.OfferDate.AddDays(offers.OfferValidFor);
                    if (DateTime.Now > expiry) // pending
                        count++;

                    // offers.OfferStatusID > 100 && 
                }
                while (offers.MoveNext());

                if (count == 0)
                    result = true;
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
        return result;
    }

    public static void ExpireCookie(string cookieName)
    {
        if (HttpContext.Current.Request.Cookies[cookieName] != null)
        {
            HttpCookie myCookie = new HttpCookie(cookieName);
            myCookie.Expires = DateTime.Now.AddMonths(-1);
            HttpContext.Current.Response.Cookies.Add(myCookie);
        }
    }

    public static string RedirectURL
    {
        get
        {
            try
            {
                return System.Web.HttpContext.Current.Session["RedirectURL"] as string;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
        set
        {
            System.Web.HttpContext.Current.Session["RedirectURL"] = value;
        }

    }

    public static void CheckSession()
    {
        List<string> openPages = new List<string>();
        openPages.Add("/live.aspx");
        openPages.Add("/account/login.aspx");
        openPages.Add("/pressrelease.aspx");
        openPages.Add("/aboutus.aspx");
        openPages.Add("/termsofservice.aspx");
        openPages.Add("/contacts/viewprofile.aspx");
        openPages.Add("/marketplace/default.aspx");
        openPages.Add("/marketplace/itemdetails.aspx");
        openPages.Add("/marketplace");
        openPages.Add("/helpandtutorial.aspx");
        openPages.Add("/appliancestore/default.aspx");
        openPages.Add("/tools/exhibit/default.aspx");
        openPages.Add("/tools/exhibit/view.aspx");

        if (!Web.IsMemberSession)
        {
            // string fullOrigionalpath = Path.GetFileName(HttpContext.Current.Request.FilePath).ToLower();
            if (!openPages.Contains(HttpContext.Current.Request.FilePath.ToLower().Trim()))
            {
                //href="http://<%=Request.Url.Authority+"/Account/Login.aspx?ReturnUrl="+Server.UrlEncode(Request.Url.AbsolutePath)  %>"
                string returnUrl = string.Format("http://{0}{1}{2}", HttpContext.Current.Request.Url.Authority, HttpContext.Current.Request.Url.AbsolutePath, HttpContext.Current.Request.Url.Query);
                //Redirect("~/index.aspx?Action=signin&ReturnUrl="+HttpContext.Current.Server.UrlEncode(returnUrl));
                Redirect("~/Account/Login.aspx?Action=signin&ReturnUrl=" + HttpContext.Current.Server.UrlEncode(returnUrl));
            }
        }

    }

    public static void CheckSession(string ReturnURL)
    {
        if ((Web.IsMemberSession == false))
            Redirect("~/index.aspx?ReturnUrl=" + ReturnURL);

    }

    public static string TruncateAtWord(string sinputstring, int ilength)
    {
        if (sinputstring == null || sinputstring.Trim().Length <= ilength)
            return sinputstring.Trim();
        sinputstring = sinputstring.Trim();
        int iSpaceIndex = sinputstring.LastIndexOf(" ", ilength);
        string res = string.Format("{0}...", sinputstring.Substring(0, (iSpaceIndex > 0) ? iSpaceIndex : ilength).Trim());
        return string.Format("{0}...", sinputstring.Substring(0, (iSpaceIndex > 0) ? iSpaceIndex : ilength).Trim());
    }
     
    private static void SendMail(string FromAddress, string ToAddresses, string Subject, string MessageBody, StringDictionary templateKeys, MailPriority MailPriority)
    {


    }

    /// <summary>
    /// Send Email with Amazon Simple Email Service.
    /// </summary>
    /// <param name="toAddresses">List of address to whome email will be sent.</param>
    /// <param name="From">From email address.</param>
    /// <param name="TemplateID">Email template ID.</param>
    /// <param name="templateKeys">Template keys.</param>
    private static void SendEmailUsingAmazonService(string toAddresses, string From, int TemplateID, StringDictionary templateKeys)
    {


        string accessKeyID, secretKey, body, subject;

        TemplateManager templateManager = new TemplateManager();
        EmailTemplates template = new EmailTemplates();

        //accessKeyID = Web.SystemConfigs.GetKey("AmazonAccessKeyID");
        //secretKey = Web.SystemConfigs.GetKey("AmazonSecretKey");

        accessKeyID = ConfigurationManager.AppSettings["AmazonAccessKeyID"];
        secretKey = ConfigurationManager.AppSettings["AmazonSecretKey"];


        template.LoadByPrimaryKey(TemplateID);
        body = templateManager.ParseTemplate(template.HTMLTemplateBody, templateKeys);
        subject = templateManager.ParseTemplate(template.TemplateSubject, templateKeys);

        AmazonSimpleEmailServiceClient client = new AmazonSimpleEmailServiceClient(accessKeyID, secretKey);
        SendEmailRequest emailRequest = new SendEmailRequest().WithSource(From);
        Destination destination = new Destination().WithToAddresses(toAddresses);
        emailRequest.WithDestination(destination);
        Message message = new Message();
        message.Subject = new Amazon.SimpleEmail.Model.Content(subject);
        //message.Body = new Body(new Amazon.SimpleEmail.Model.Content(body));
        Body ebody = new Body() { Html = new Amazon.SimpleEmail.Model.Content(body) };
        message.Body = ebody;
        emailRequest.Message = message;

        string enable = System.Configuration.ConfigurationManager.AppSettings["SysEnableEmail"];
        if (enable == "1")
        {
            Amazon.SimpleEmail.Model.Content c = new Amazon.SimpleEmail.Model.Content();
            //client.SendEmail(emailRequest);
            client.BeginSendEmail(emailRequest, null, null);
        }

        //StringBuilder strToAddresses = new StringBuilder();
        //foreach (string address in toAddresses)
        //    strToAddresses.Append(address + " ; ");

        // Log Email in file
        //try
        //{
        //    //string outputFile = string.Format(@"C:\eOffer_Email_Debug\{0}.htm", TemplateID);
        //    //TextWriter output;

        //    //if (!File.Exists(outputFile))
        //    //    output = File.CreateText(outputFile);
        //    //else
        //    //    output = File.AppendText(outputFile);

        //    //output.Write(String.Format("TemplateID: {0} {1} To: {2} {3} From: {4} {5} Subject: {6} {7} Message: {8}",
        //    //                    TemplateID, "<br>", toAddresses.ToString(), "<br>",
        //    //                    From, "<br>", subject, "<br>", body));
        //}
        //catch (Exception ex)
        //{
        //    Web.LogError(ex);
        //}

        // Log Email in DB
        try
        {
            // add email to Email log in DB
            var email = new Emails();
            email.AddNew();
            email.FromEmail = From;
            email.ToEmail = toAddresses.ToString();
            email.Subject = subject;
            email.Body = body;

            //if (EmailType != "")
            //{ 
            //    email.EmailType=EmailType;
            ////email.BatchNumber=DateTime.Now.Year+DateTime.Now.Month+DateTime.Now.

            //    EmailType = "";
            //}

            email.Save();
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }

    }
     
    /// <summary>
    /// 
    /// </summary>
    /// <param name="To"></param>
    /// <param name="From"></param>
    /// <param name="Body"></param>
    /// <param name="Subject"></param>
    /// <param name="attachment"></param>
    /// <param name="BCC"></param>
    private static void SendEmailUsingAmazonService(string To, string From, string Body, string Subject, Telerik.Web.UI.RadUpload attachment, string BCC)
    {
        /* List<string> toAddresses = new List<string>();
         toAddresses.Add(To);

         string accessKeyID, secretKey, body, subject;

         TemplateManager templateManager = new TemplateManager();
         EmailTemplates template = new EmailTemplates();

         accessKeyID = Web.SystemConfigs.GetKey("AmazonAccessKeyID");
         secretKey = Web.SystemConfigs.GetKey("AmazonSecretKey");
         
         AmazonSimpleEmailServiceClient client = new AmazonSimpleEmailServiceClient(accessKeyID, secretKey);
         SendEmailRequest emailRequest = new SendEmailRequest().WithSource(From);
         Destination destination = new Destination().WithToAddresses(toAddresses);
         emailRequest.WithDestination(destination);
         Message message = new Message();
         message.Subject = new Amazon.SimpleEmail.Model.Content(subject);
         message.Body = new Body(new Amazon.SimpleEmail.Model.Content(body));
         emailRequest.Message = message;

         Amazon.SimpleEmail.Model.Content c = new Amazon.SimpleEmail.Model.Content();

         client.SendEmail(emailRequest);
         
         // Log Email in file
         try
         {
             string fileName = Guid.NewGuid().ToString().Replace("-", "");
             string outputFile = string.Format(@"C:\eOffer_Email_Debug\{0}.htm", fileName);
             TextWriter output;

             if (!File.Exists(outputFile))
                 output = File.CreateText(outputFile);
             else
                 output = File.AppendText(outputFile);

             output.Write(String.Format("TemplateID: {0} {1} To: {2} {3} From: {4} {5} Subject: {6} {7} Message: {8}",
                                 fileName, "<br>", To, "<br>",
                                 From, "<br>", subject, "<br>", body));

             // add email to Email log in DB
             var email = new Emails();
             email.AddNew();
             email.FromEmail = From;
             email.ToEmail = To;
             email.Subject = subject;
             email.Body = body;
             email.Save();
         }
         catch { }
         * */
    }

    public static string CalculateRegCode()
    {
        return Guid.NewGuid().ToString().Replace("-", "");
    }

    public static string LoadFeeds(string logID, string actID, string refID, string membID, int count, string xmlDtl, bool isBill, bool IsReply)
    {
        StringBuilder sb = new StringBuilder();
        string activityComments;
        string username, comment;
        string commentDate;
        string activitLogID, activityCommentID;
        string[] subComments;
        string memberID, feedItemOwner = "";
        int counter = 0;
        string xml = xmlDtl;
        string jsMethod = "openBillboardCommentBox";
        string css = "defaultBillboard_Comments";

        if (xml == "")
        {
            xml = ViewAllFeeds(logID, membID);
            css = "feed_Comments";
            jsMethod = "openCommentBox";
        }
        //Activity comments
        sb.Append("<div  id='DV_" + logID.ToString() + "'>");

        //if it is a reply then do not show the arrow 
        if (!IsReply)
            sb.Append("<div class='feed_Comments_arrow'></div>");
        //-------------------------------------------------------
        activityComments = xml;
        subComments = Regex.Split(activityComments, "/>");

        try
        {
            foreach (var item in subComments)
            {
                if (item == "") break;

                if (count != 0)
                {
                    if (counter >= 3)
                    { break; }
                    counter++;
                }

                if (IsReply)//if this is a reply to any message then
                {

                    css = "feed_Comments";

                    username = item.Substring(item.IndexOf("UserName=\"") + 10);
                    username = username.Remove(username.IndexOf("\""));
                    //get the original reply
                    comment = ContactMessages.GetMessageReply(Convert.ToInt32(refID));

                    string[] chunks = { };
                    chunks = Regex.Split(comment, " ");
                    foreach (var str in chunks)
                    {
                        if (str.Length > 40)
                            if ((!str.Contains("www.")) && (!str.Contains("http")))
                                comment = Web.SplitString(comment, 60);
                    }

                    memberID = item.Substring(item.IndexOf("MemberID=\"") + 10);
                    memberID = memberID.Remove(memberID.IndexOf("\""));
                    commentDate = item.Substring(item.IndexOf("ActivityDate=\"") + 14);
                    commentDate = commentDate.Remove(commentDate.IndexOf("\""));
                    DateTime date = DateTime.Now;
                    DateTime.TryParse(commentDate, out date);
                    commentDate = Web.GetTime(date);
                    //commentDate = Web.GetTime(Convert.ToDateTime(commentDate));
                    activitLogID = item.Substring(item.IndexOf("ActivityLogID=\"") + 15);
                    activitLogID = activitLogID.Remove(activitLogID.IndexOf("\""));
                    activityCommentID = item.Substring(item.IndexOf("ReferenceID=\"") + 13);
                    activityCommentID = activityCommentID.Remove(activityCommentID.IndexOf("\""));
                }
                else
                {
                    username = item.Substring(item.IndexOf("UserName=\"") + 10);
                    username = username.Remove(username.IndexOf("\""));
                    comment = item.Substring(item.IndexOf("Comments=\"") + 10);
                    comment = comment.Remove(comment.IndexOf("\""));

                    string[] chunks = { };
                    chunks = Regex.Split(comment, " ");
                    foreach (var str in chunks)
                    {
                        if (str.Length > 40)
                            if ((!str.Contains("www.")) && (!str.Contains("http")))
                                comment = Web.SplitString(comment, 60);
                    }
                    feedItemOwner = item.Substring(item.IndexOf("MemberID=\"") + 10);
                    feedItemOwner = feedItemOwner.Remove(feedItemOwner.IndexOf("\"")).Trim();
                    memberID = item.Substring(item.IndexOf("CommentsBy=\"") + 12);
                    memberID = memberID.Remove(memberID.IndexOf("\""));
                    commentDate = item.Substring(item.IndexOf("CommentsDate=\"") + 14);
                    commentDate = commentDate.Remove(commentDate.IndexOf("\""));
                    commentDate = Web.GetTime(Convert.ToDateTime(commentDate));
                    activitLogID = item.Substring(item.IndexOf("ActivityLogID=\"") + 15);
                    activitLogID = activitLogID.Remove(activitLogID.IndexOf("\""));
                    activityCommentID = item.Substring(item.IndexOf("ActivityLogCommentsID=\"") + 23);
                    activityCommentID = activityCommentID.Remove(activityCommentID.IndexOf("\""));

                }
                //if there is no space or breaks in the comment
                if (!comment.Contains(" ") && comment.Length > 280)
                {
                    comment = Web.SplitString(comment, 70);
                }

                sb.Append("<div class='comment' id=\"DV_Del_" + activityCommentID + "\" style='border:1px solid #cccccc; margin: 3px 0px 3px 0px; ' >");
                sb.Append("<div class='" + css + "' style=' text-align: left;padding-right:10px;margin-right:5px;'> ");
                sb.Append("<table style='margin: 2px; width: 100%; text-align: left;' border='0' cellpadding='0' cellspacing='0'>");
                sb.Append("<tr><td rowspan='2' valign='top' width='5%'>");
                sb.Append("<img src='../../ePage/ImageViewer.ashx?Action=MembersLogoThumbnail&amp;RecordID=" + memberID + "' title='Logo' alt='Logo' width='24' height='24' style='border: 2px solid white;'>");
                sb.Append("</td><td align='left' valign='top' width='95%'>");
                sb.Append("<table border='0' cellpadding='1' width='100%'>");
                sb.Append("<tr><td align='left' width='50%'>");
                sb.Append("<span style='font-size: 7.5pt;'>");
                sb.Append("<a href='/Contacts/ViewProfile.aspx?Action=ViewDealer&amp;RecordID=" + memberID + "'>");
                //set user name class 

                string profileclass;
                if (Web.IsMemberSession)
                    profileclass = Web.GetProfileClass(Convert.ToInt32(memberID), Web.SessionMembers.MemberID);
                else
                    profileclass = "Unknown";
                sb.Append("<span class='" + profileclass + "'>");
                sb.Append(Web.GetUserName(Convert.ToInt32(memberID), username));
                sb.Append("</span></a>&nbsp;");
                sb.Append("<span class='details' style='font-size: 7.5pt;'>");

                if (IsReply)
                    sb.Append("replied&nbsp;");
                else
                    sb.Append("posted a comment&nbsp;");

                sb.Append("</span>");
                sb.Append("</span></td><td align='right'>");
                sb.Append("<span id='feed_TimeStamp" + activityCommentID + "' class='feed_TimeStamp' style='font-weight:200;'>");
                sb.Append(commentDate + "</span> ");

                sb.Append("<div class='feed_actionLinks' style='display: inline;>");
                //if this is reply to message then
                if (IsReply)
                {
                    //no comment button for reply post
                }
                else
                {
                    if (Web.IsMemberSession)// do not show comment icon without login
                    {
                        sb.Append("<a href='javascript:void(0);' onclick='" + jsMethod + "(" + activitLogID + ");' style='cursor:pointer;'>");
                        sb.Append("<img src='../../Images/LiveFeed/comment.png' alt='Comment' title='Comment' width='15' height='12'  style='cursor:pointer;'>");
                    }
                }

                sb.Append("</a></div>");
                if (Web.ShowReply(actID, refID) && (IsMyContactOrMe(memberID)))
                {
                    sb.Append("<div class='feed_actionLinks' style='display: inline;'>");
                    sb.Append("<a target='_top' href='/Contacts/MessageToSelected.aspx?Action=MessageToOne&amp;RecordID=" + memberID + "'>");
                    sb.Append("<img src='../../Images/LiveFeed/mail.png' alt='Send Message' title='Send Message' width='16' height='14' >");
                    sb.Append("</a></div>");
                }
                sb.Append("<div class='feed_actionLinks' style='display: inline;'>");

                //---------------if reply message  activityCommentID
                if (Web.IsMemberSession)
                {
                    if (IsReply)
                    {
                        sb.Append("<a href='javascript:void(0);' onclick='DeleteReply(" + activityCommentID + ");'>");
                        sb.Append("<img src='../../Images/LiveFeed/cross.png' alt='Remove' title='Remove'></a>");
                    }
                    else
                    {
                        if (Web.SessionMembers.MemberID.ToString().Equals(memberID) || Web.SessionMembers.MemberID.ToString().Equals(feedItemOwner)) // Only Delete button for my comments
                        {
                            sb.Append("<a href='javascript:void(0);' onclick='DeleteSubComment(" + activityCommentID + "," + actID + "," + refID + "," + Web.SessionMembers.MemberID + "," + activitLogID + ");'>");
                            sb.Append("<img src='../../Images/LiveFeed/cross.png' alt='Remove' title='Remove'></a>");
                        }
                    }
                }

                sb.Append("</div></td></tr></table>");
                sb.Append("</td></tr>");
                sb.Append("<tr><td style='font-size: 8pt; font-weight: normal; padding-left: 5px; text-align: justify; ");
                sb.Append("width: 415px; overflow: hidden;'>");

                //activity comment short.....
                comment = HttpUtility.HtmlDecode(comment);
                sb.Append("<div id='short_" + activityCommentID + "'>");
                bool isURL = false;
                Regex regx = new Regex("http(s)?://([\\w+?\\.\\w+])+([a-zA-Z0-9\\~\\!\\@\\#\\$\\%\\^\\&amp;\\*\\(\\)_\\-\\=\\+\\\\\\/\\?\\.\\:\\;\\'\\,]*)?", RegexOptions.IgnoreCase);
                MatchCollection mactches = regx.Matches(comment);
                foreach (Match match in mactches)
                {
                    isURL = true;
                }

                if (!isURL)
                    sb.Append(Web.ShortenComment(comment, Convert.ToInt32(activityCommentID)));
                else
                    sb.Append(comment);

                sb.Append("</div>");
                sb.Append("<div id=\"full_" + activityCommentID + "\" style=\"display: none;overflow: hidden; padding-right:3px;\">");
                sb.Append(Web.MakeLinksClickable(Web.BreakLongString(comment, 70)));
                sb.Append("<br />");
                sb.Append("<a href=\"javascript:void(0);\" onclick=\"Hide('full_" + activityCommentID + "');Show('short_" + activityCommentID + "');\">");
                sb.Append("View Less>></a></div>");

                sb.Append("</div>");
                sb.Append("</td></tr></table>");
                sb.Append("</div>");
                sb.Append("</div>");
                /////////////////////////////////////////
                //string shortComment = "";
                //shortComment = sb.ToString();
                if (isBill)
                {
                    sb.Replace("short_", "bill_short_");
                    sb.Replace("full_", "bill_full_");
                }

            }
            if (xmlDtl == "")//not billboard comments
            {
                if (count == 0)
                {
                    sb.Append("<div id='less_" + logID + "' style='float:right;'><a href='javascript:void(0);' onclick='ViewLessComments(" + logID + "," + actID + "," + refID + "," + membID + ");'>View Less Comments>></a>");
                    sb.Append("</div>");
                }
                if (count != 0 && subComments.Length > 4)
                {
                    sb.Append("<div id='more_" + logID + "' style='float:right;'><a href='javascript:void(0);' onclick='ViewAllComments(" + logID + "," + actID + "," + refID + "," + membID + ");'>View All Comments>></a>");
                    sb.Append("</div>");
                }
            }
            else
            {
                if (count == 0)
                {
                    sb.Append("<div id='billboard_less_" + logID + "' style='float:right;'><a href='javascript:void(0);' onclick='ViewLessBollboardComments();'>View Less Comments>></a>");
                    sb.Append("</div>");
                }
                if (count != 0 && subComments.Length > 4)
                {
                    sb.Append("<div id='billboard_more_" + logID + "' style='float:right;'><a href='javascript:void(0);' onclick='ViewAllBollboardComments();'>View All Comments>></a>");
                    sb.Append("</div>");
                }
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
        return sb.ToString();
    }

    public static string ViewAllFeeds(string activityID, string memberID)
    {
        string strReturn = "";
        int ActivityLogID = (!String.IsNullOrEmpty(activityID)) ? Convert.ToInt32(activityID) : 0;
        if (ActivityLogID > 0)
        {
            DataTable dt = new DataTable();
            if (Web.IsMemberSession)
                dt = MemberActivityLogComments.LoadAllFeedComments(Web.SessionMembers.MemberID, ActivityLogID).Tables[0];
            else
                dt = MemberActivityLogComments.LoadAllFeedComments(null, ActivityLogID).Tables[0];

            if (dt.Rows.Count > 0)
            {
                foreach (DataRow row in dt.Rows)
                {
                    strReturn += row[0].ToString();
                }
            }
        }
        return strReturn;
    }
    public static bool IsMyContactOrMe(string s_MemberID)
    {
        bool result = false;
        try
        {
            if (s_MemberID != Web.SessionMembers.MemberID.ToString())
            {
                Contacts contact = new Contacts();
                contact.Where.MemberID.Value = Web.SessionMembers.MemberID;
                contact.Where.ContactMemberID.Value = s_MemberID;
                contact.Query.Load();
                if (contact.RowCount > 0)
                    result = true;
            }
        }
        catch (Exception ex)
        {
            //Log.Write("Error", ex.GetBaseException().ToString(), ex);
            Web.LogError(ex);
        }
        return result;
    }

    public static void SendWinnerEmail(int ListingOfferID)
    {
        try
        {
            var offer = new ListingOffers();
            if (offer.LoadByPrimaryKey(ListingOfferID))
            {
                var listing = new Listings();
                listing.LoadByPrimaryKey(offer.ListingID);

                if (listing.RowCount > 0) // if listing exists
                {
                    var title = Listings.GetTitle(offer.ListingID);

                    // getting the seller is so simple...
                    var seller = new Members();
                    seller.LoadByPrimaryKey(listing.MemberID);

                    // logic to get the buyer
                    var buyer = new Members();
                    if (listing.MemberID == offer.OfferBy) // mean the counter offer is by the seller to the buyer
                    {
                        // get the buyer from the fucking counteroffer id
                        var previousOffer = new ListingOffers();
                        previousOffer.Where.ListingOfferID.Value = offer.CounterOfferID;
                        previousOffer.Query.AddResultColumn(ListingOffersSchema.OfferBy);
                        previousOffer.Query.Load();

                        if (previousOffer.RowCount > 0)
                            buyer.LoadByPrimaryKey(previousOffer.OfferBy);
                    }
                    else
                        buyer.LoadByPrimaryKey(offer.OfferBy);

                    // get buyer Address
                    var buyerAddress = ShippingAddresses.LoadByMemberID(buyer.MemberID);

                    // get seller Address
                    var sellerAddress = ShippingAddresses.LoadByMemberID(seller.MemberID);


                    // logging displayed on live feed
                    var templateKeys = new StringDictionary();
                    templateKeys.Add("#lot#", title);
                    templateKeys.Add("#viewlot#", "/MarketPlace/ItemDetails.aspx?Action=View&RecordID=#encrypt#" + listing.ListingID + "#endencrypt#");
                    templateKeys.Add("#initiatedto#", "#memberid#" + buyer.MemberID + "#endmemberid#");
                    templateKeys.Add("#profileclass#", "#profileclass#" + buyer.MemberID + "#endprofileclass#");
                    templateKeys.Add("#initiatedtoprofile#", "/Contacts/ViewProfile.aspx?Action=ViewDealer&RecordID=#encrypt#" + buyer.MemberID + "#endencrypt#");
                    /*
                      You accepted offer by <a href="#initiatedtoprofile#"><span class="#profileclass#">#initiatedto#</span></a> on listing <a href="#viewlot#">#lot#<a/>
                     */
                    Web.AddPrivateActivityLog(seller.MemberID, 48, templateKeys, buyer.MemberID, offer.ListingOfferID, buyer.MemberID);

                    decimal totol = offer.OfferPrice;
                    if (!offer.IsColumnNull(ListingOffersSchema.ShippingPrice.FieldName))
                        totol += offer.ShippingPrice;


                    templateKeys = new StringDictionary();
                    templateKeys.Add("#email_header#", Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER"));
                    templateKeys.Add("#fullname#", buyer.FullName);
                    templateKeys.Add("#item#", title);
                    templateKeys.Add("#link#", Web.SystemConfigs.GetKey("SITE_URL") + "Marketplace/MyListings.aspx?Action=View&RecordID=" + Secure.Encrypt(offer.ListingID));


                    templateKeys.Add("#offerprice#", offer.s_OfferPrice);
                    templateKeys.Add("#shippingprice#", offer.s_ShippingPrice);
                    templateKeys.Add("#total#", totol.ToString());

                    templateKeys.Add("#seller#", seller.FullName);
                    templateKeys.Add("#city#", sellerAddress.s_City);
                    templateKeys.Add("#state#", sellerAddress.s_State);
                    templateKeys.Add("#company#", seller.CompanyName);
                    templateKeys.Add("#email#", seller.Email);
                    templateKeys.Add("#phone#", sellerAddress.Phone);
                    templateKeys.Add("#address#", sellerAddress.Address1);
                    templateKeys.Add("#country#", sellerAddress.CountryName);
                    templateKeys.Add("#link_dealingfloor#", Web.SystemConfigs.GetKey("SITE_URL") + "Marketplace/MyListings.aspx?tabid=tabs-3.tabs-3-1");
                    templateKeys.Add("#email_footer#", Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER"));
                    Web.SendMail(buyer.Email, Web.SystemConfigs.GetKey("ALERTS_EMAIL"), 309, templateKeys);


                    if (listing.ListingTypeID == 1) // IF FOR SALE ...
                    {
                        var fields = new ListingExtendedFields();
                        fields.Where.ObjectID.Value = listing.ListingID;
                        if (fields.Query.Load())
                        {
                            int QTY = 0;
                            int FieldID = 0;
                            var QTYField = new ListingExtendedFields();
                            do
                            {
                                if (fields.FieldID == 4)
                                {
                                    if (!String.IsNullOrEmpty(fields.Data))
                                    {
                                        QTY = Convert.ToInt32(fields.Data);
                                        FieldID = fields.ListingExtendedFieldID;
                                        break;
                                    }
                                }
                            }
                            while (fields.MoveNext());

                            //if (QTY > 0)
                            {
                                //if (QTY == offer.Quantity) // no item left
                                {
                                    templateKeys = new System.Collections.Specialized.StringDictionary();
                                    templateKeys.Add("#itemname#", title);
                                    templateKeys.Add("#link#", "/MarketPlace/ItemDetails.aspx?Action=View&RecordID=#encrypt#" + listing.ListingID + "#endencrypt#");
                                    templateKeys.Add("#initiatedto#", "#memberid#" + buyer.MemberID + "#endmemberid#");
                                    templateKeys.Add("#profileclass#", "#profileclass#" + buyer.MemberID + "#endprofileclass#");
                                    templateKeys.Add("#initiatedtoprofile#", "/Contacts/ViewProfile.aspx?Action=ViewDealer&RecordID=#encrypt#" + buyer.MemberID + "#endencrypt#");
                                    Web.AddPrivateActivityLog(Web.SessionMembers.MemberID, 50, templateKeys, seller.MemberID, offer.ListingOfferID, buyer.MemberID);

                                    templateKeys = new StringDictionary();
                                    templateKeys.Add("#email_header#", Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER"));

                                    templateKeys.Add("#offerprice#", offer.s_OfferPrice);
                                    templateKeys.Add("#shippingprice#", offer.s_ShippingPrice);
                                    templateKeys.Add("#total#", totol.ToString());

                                    templateKeys.Add("#fullname#", Web.SessionMembers.FullName);
                                    templateKeys.Add("#item_or_lot#", "Listing");
                                    templateKeys.Add("#item_or_lot_title#", title);
                                    templateKeys.Add("#buyer#", buyer.FullName);
                                    templateKeys.Add("#email#", buyer.Email);
                                    templateKeys.Add("#address#", buyerAddress.Address1);
                                    templateKeys.Add("#city#", buyerAddress.s_City);
                                    templateKeys.Add("#state#", buyerAddress.s_State);
                                    templateKeys.Add("#country#", buyerAddress.CountryName);
                                    templateKeys.Add("#company#", buyer.CompanyName);
                                    templateKeys.Add("#phone#", buyerAddress.Phone);
                                    templateKeys.Add("#link_contact_buyer#", Web.SystemConfigs.GetKey("SITE_URL") + "MarketPlace/MyListings.aspx?tabid=tabs-2.tabs-2-3");
                                    templateKeys.Add("#email_footer#", Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER"));
                                    Web.SendMail(Web.SessionMembers.Email, Web.SystemConfigs.GetKey("ALERTS_EMAIL"), 313, templateKeys);
                                }
                            }
                        }
                    }
                    else // for other listing types
                    {
                        templateKeys = new StringDictionary();
                        templateKeys.Add("#itemname#", title);
                        templateKeys.Add("#link#", "../MarketPlace/ItemDetails.aspx?Action=View&RecordID=#encrypt#" + listing.ListingID + "#endencrypt#");
                        templateKeys.Add("#initiatedto#", "#memberid#" + buyer.MemberID + "#endmemberid#");
                        templateKeys.Add("#profileclass#", "#profileclass#" + buyer.MemberID + "#endprofileclass#");
                        templateKeys.Add("#initiatedtoprofile#", "/Contacts/ViewProfile.aspx?Action=ViewDealer&RecordID=#encrypt#" + buyer.MemberID + "#endencrypt#");
                        Web.AddPrivateActivityLog(Web.SessionMembers.MemberID, 50, templateKeys, seller.MemberID, offer.ListingOfferID, buyer.MemberID);

                        templateKeys = new StringDictionary();
                        templateKeys.Add("#email_header#", Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER"));
                        templateKeys.Add("#fullname#", Web.SessionMembers.FullName);
                        templateKeys.Add("#item_or_lot#", "Listing");
                        templateKeys.Add("#item_or_lot_title#", title);
                        templateKeys.Add("#buyer#", buyer.FullName);
                        templateKeys.Add("#address#", buyerAddress.Address1);
                        templateKeys.Add("#city#", buyerAddress.s_City);
                        templateKeys.Add("#state#", buyerAddress.s_State);
                        templateKeys.Add("#country#", buyerAddress.CountryName);
                        templateKeys.Add("#company#", buyer.CompanyName);
                        templateKeys.Add("#email#", buyer.Email);
                        templateKeys.Add("#phone#", buyerAddress.Phone);
                        templateKeys.Add("#link_dealingfloor#", Web.SystemConfigs.GetKey("SITE_URL") + "MarketPlace/MyListings.aspx?tabid=tabs-2.tabs-2-3");
                        templateKeys.Add("#link_log_myeoffer#", Web.SystemConfigs.GetKey("SITE_URL"));
                        templateKeys.Add("#email_footer#", Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER"));
                        Web.SendMail(Web.SessionMembers.Email, Web.SystemConfigs.GetKey("ALERTS_EMAIL"), 313, templateKeys);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }

    public static void SendBuyNowEmail(int ListingOfferID)
    {
        try
        {
            ListingOffers offer = new ListingOffers();
            if (offer.LoadByPrimaryKey(ListingOfferID))
            {
                Listings listing = new Listings();
                listing.LoadByPrimaryKey(offer.ListingID);
                if (listing.RowCount > 0)
                {

                    Members seller = new Members();
                    seller.LoadByPrimaryKey(listing.MemberID);


                    ShippingAddresses sellerAddress = ShippingAddresses.LoadByMemberID(seller.MemberID);

                    if (sellerAddress.City == null)
                        sellerAddress.City = "";

                    if (sellerAddress.State == null)
                        sellerAddress.State = "";

                    if (sellerAddress.Phone == null)
                        sellerAddress.Phone = "";

                    if (sellerAddress.Address1 == null)
                        sellerAddress.Address1 = "";


                    string title = Listings.GetTitle(offer.ListingID);
                    Members buyer = new Members();
                    buyer.LoadByPrimaryKey(offer.OfferBy);

                    ShippingAddresses addres = new ShippingAddresses();
                    addres.Where.MemberID.Value = Web.SessionMembers.MemberID;
                    addres.Query.Load();
                    string countryname = "";
                    Country country = new Country();
                    if (addres.RowCount > 0)
                    {
                        country.Query.AddResultColumn(CountrySchema.CountryName);
                        country.Where.CountryID.Value = addres.CountryID;
                        country.Query.Load();
                        if (country.RowCount > 0)
                        {
                            countryname = country.CountryName;
                        }
                    }

                    /*var templateKeys = new System.Collections.Specialized.StringDictionary();
                    templateKeys.Add("#lot#", title);
                    templateKeys.Add("#viewlot#", "../MarketPlace/ItemDetails.aspx?Action=View&RecordID=#encrypt#" + listing.ListingID + "#endencrypt#");
                    templateKeys.Add("#initiatedto#", "#memberid#" + buyer.MemberID + "#endmemberid#");
                    templateKeys.Add("#profileclass#", "#profileclass#" + buyer.MemberID + "#endprofileclass#");
                    templateKeys.Add("#initiatedtoprofile#", "/Contacts/ViewProfile.aspx?Action=ViewDealer&RecordID=#encrypt#" + buyer.MemberID + "#endencrypt#");
                    Web.AddPrivateActivityLog(48, templateKeys, buyer.MemberID, offer.ListingOfferID, Web.SessionMembers.MemberID);
                    */

                    decimal totol = offer.OfferPrice;
                    if (!offer.IsColumnNull(ListingOffersSchema.ShippingPrice.FieldName))
                    {
                        totol += offer.ShippingPrice;
                    }


                    /*var strofferdetail = new System.Text.StringBuilder();
                    strofferdetail.Append("<table>");
                    strofferdetail.Append("<tr><td colspan=\"2\" valign=\"top\" align=\"center\" > Offer on Entire Lot</td></tr>");
                    strofferdetail.Append("<tr><td valign=\"top\" align=\"right\">Offered Price:</td><td valign=\"top\">" + offer.s_OfferPrice + "</td> </tr>");
                    strofferdetail.Append("<tr><td valign=\"top\" align=\"right\">Shipping Price:+</td><td valign=\"top\">" + offer.s_ShippingPrice + "</td> </tr>");
                    strofferdetail.Append("<tr><td valign=\"top\" style=\"border-top:solid 1px #000;\" align=\"right\"><b>Total:</b></td><td valign=\"top\"><b>" + totol.ToString() + "</b></td> </tr>");
                    strofferdetail.Append("</table>");
                    */
                    //Winner Email To Buyer
                    StringDictionary TemplateKeys = new StringDictionary();
                    TemplateKeys.Add("#email_header#", Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER"));
                    TemplateKeys.Add("#fullname#", buyer.FullName);
                    TemplateKeys.Add("#item#", title);
                    TemplateKeys.Add("#link#", Web.SystemConfigs.GetKey("SITE_URL") + "Marketplace/MyListings.aspx?Action=View&RecordID=" + Secure.Encrypt(offer.ListingID));


                    TemplateKeys.Add("#OfferPrice#", offer.s_OfferPrice);
                    TemplateKeys.Add("#ShippingPrice#", offer.s_ShippingPrice);
                    TemplateKeys.Add("#total#", totol.ToString());

                    TemplateKeys.Add("#seller#", seller.FullName);
                    TemplateKeys.Add("#city#", sellerAddress.s_City);
                    TemplateKeys.Add("#state#", sellerAddress.s_State);
                    TemplateKeys.Add("#company#", seller.CompanyName);
                    TemplateKeys.Add("#email#", seller.Email);
                    TemplateKeys.Add("#phone#", sellerAddress.Phone);
                    TemplateKeys.Add("#address#", sellerAddress.Address1);
                    TemplateKeys.Add("#country#", countryname);
                    TemplateKeys.Add("#link_dealingfloor#", Web.SystemConfigs.GetKey("SITE_URL") + "Marketplace/MyListings.aspx?tabid=tabs-3.tabs-3-1");
                    TemplateKeys.Add("#email_footer#", Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER"));
                    Web.SendMail(buyer.Email, Web.SystemConfigs.GetKey("ALERTS_EMAIL"), 309, TemplateKeys);

                    // Sold notification to seller
                    addres = new ShippingAddresses();
                    addres.Where.MemberID.Value = buyer.MemberID;
                    addres.Query.Load();
                    countryname = "";
                    country = new Country();
                    if (addres.RowCount > 0)
                    {
                        country.Query.AddResultColumn(CountrySchema.CountryName);
                        country.Where.CountryID.Value = addres.CountryID;
                        country.Query.Load();
                        if (country.RowCount > 0)
                        {
                            countryname = country.CountryName;
                        }
                    }

                    if (listing.ListingTypeID == 1)
                    {
                        ListingExtendedFields fields = new ListingExtendedFields();
                        fields.Where.ObjectID.Value = listing.ListingID;
                        if (fields.Query.Load())
                        {
                            int QTY = 0;
                            int FieldID = 0;
                            ListingExtendedFields QTYField = new ListingExtendedFields();
                            do
                            {
                                if (fields.FieldID == 4)
                                {
                                    if (!String.IsNullOrEmpty(fields.Data))
                                    {
                                        QTY = Convert.ToInt32(fields.Data);
                                        FieldID = fields.ListingExtendedFieldID;
                                        break;
                                    }
                                }
                            }
                            while (fields.MoveNext());

                            // if (QTY > 0)
                            {
                                //if (QTY == offer.Quantity) // no item left
                                {
                                    var templateKeys = new System.Collections.Specialized.StringDictionary();
                                    templateKeys.Add("#itemname#", title);
                                    templateKeys.Add("#link#", "../MarketPlace/ItemDetails.aspx?Action=View&RecordID=#encrypt#" + listing.ListingID + "#endencrypt#");
                                    templateKeys.Add("#initiatedto#", "#memberid#" + buyer.MemberID + "#endmemberid#");
                                    templateKeys.Add("#profileclass#", "#profileclass#" + buyer.MemberID + "#endprofileclass#");
                                    templateKeys.Add("#initiatedtoprofile#", "/Contacts/ViewProfile.aspx?Action=ViewDealer&RecordID=#encrypt#" + buyer.MemberID + "#endencrypt#");
                                    Web.AddPrivateActivityLog(listing.MemberID, 50, templateKeys, listing.MemberID, offer.ListingOfferID, buyer.MemberID);


                                    TemplateKeys = new StringDictionary();

                                    TemplateKeys.Add("#offerprice#", offer.s_OfferPrice);
                                    TemplateKeys.Add("#shippingprice#", offer.s_ShippingPrice);
                                    TemplateKeys.Add("#total#", totol.ToString());

                                    TemplateKeys.Add("#email_header#", Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER"));
                                    TemplateKeys.Add("#fullname#", seller.FullName);
                                    TemplateKeys.Add("#item_or_lot#", "Listing");
                                    TemplateKeys.Add("#item_or_lot_title#", title);
                                    TemplateKeys.Add("#buyer#", buyer.FullName);
                                    TemplateKeys.Add("#address#", addres.Address1);
                                    TemplateKeys.Add("#city#", addres.s_City);
                                    TemplateKeys.Add("#state#", addres.s_State);
                                    TemplateKeys.Add("#country#", countryname);
                                    TemplateKeys.Add("#company#", buyer.CompanyName);
                                    TemplateKeys.Add("#email#", buyer.Email);
                                    TemplateKeys.Add("#phone#", addres.Phone);
                                    TemplateKeys.Add("#link_contact_buyer#", Web.SystemConfigs.GetKey("SITE_URL") + "MarketPlace/MyListings.aspx?tabid=tabs-2.tabs-2-2");
                                    TemplateKeys.Add("#link_log_myeoffer#", Web.SystemConfigs.GetKey("SITE_URL"));
                                    TemplateKeys.Add("#email_footer#", Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER"));

                                    Web.SendMail(Web.SessionMembers.Email, Web.SystemConfigs.GetKey("ALERTS_EMAIL"), 313, TemplateKeys);
                                }
                            }
                        }
                    }
                    else
                    {
                        var templateKeys = new System.Collections.Specialized.StringDictionary();
                        templateKeys.Add("#itemname#", title);
                        templateKeys.Add("#link#", "../MarketPlace/ItemDetails.aspx?Action=View&RecordID=#encrypt#" + listing.ListingID + "#endencrypt#");
                        templateKeys.Add("#initiatedto#", "#memberid#" + buyer.MemberID + "#endmemberid#");
                        templateKeys.Add("#profileclass#", "#profileclass#" + buyer.MemberID + "#endprofileclass#");
                        templateKeys.Add("#initiatedtoprofile#", "/Contacts/ViewProfile.aspx?Action=ViewDealer&RecordID=#encrypt#" + buyer.MemberID + "#endencrypt#");
                        Web.AddPrivateActivityLog(listing.MemberID, 50, templateKeys, buyer.MemberID, offer.ListingOfferID, buyer.MemberID);

                        TemplateKeys = new StringDictionary();
                        TemplateKeys.Add("#email_header#", Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER"));

                        TemplateKeys.Add("#offerprice#", offer.s_OfferPrice);
                        TemplateKeys.Add("#shippingprice#", offer.s_ShippingPrice);
                        TemplateKeys.Add("#total#", totol.ToString());

                        TemplateKeys.Add("#fullname#", seller.FullName);
                        TemplateKeys.Add("#item_or_lot#", "Listing");
                        TemplateKeys.Add("#item_or_lot_title#", title);
                        TemplateKeys.Add("#buyer#", buyer.FullName);
                        TemplateKeys.Add("#address#", addres.Address1);
                        TemplateKeys.Add("#city#", addres.s_City);
                        TemplateKeys.Add("#state#", addres.s_State);
                        TemplateKeys.Add("#country#", countryname);
                        TemplateKeys.Add("#company#", buyer.CompanyName);
                        TemplateKeys.Add("#email#", buyer.Email);
                        TemplateKeys.Add("#phone#", addres.Phone);
                        TemplateKeys.Add("#link_dealingfloor#", Web.SystemConfigs.GetKey("SITE_URL") + "MarketPlace/MyListings.aspx");
                        TemplateKeys.Add("#link_log_myeoffer#", Web.SystemConfigs.GetKey("SITE_URL"));
                        TemplateKeys.Add("#email_footer#", Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER"));
                        Web.SendMail(Web.SessionMembers.Email, Web.SystemConfigs.GetKey("ALERTS_EMAIL"), 313, TemplateKeys);
                    }

                    //AddToContact(buyer.MemberID);
                }
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }

    /// <summary>
    /// creates the thumbnail of the image stream
    /// </summary>
    /// <param name="ImageStream"></param>
    /// <param name="RequiredWidth"></param>
    /// <param name="RequiredHeight"></param>
    /// <returns></returns>
    public static byte[] CreateThumbnail(Stream ImageStream, int RequiredWidth, int RequiredHeight)
    {
        return imageToByteArray(CreateThumbnail(System.Drawing.Image.FromStream(ImageStream), RequiredWidth, RequiredHeight));
    }

    /// <summary>
    /// creates the thumbnail of the image
    /// </summary>
    /// <param name="Original"></param>
    /// <param name="RequiredWidth"></param>
    /// <param name="RequiredHeight"></param>
    /// <returns></returns>
    public static System.Drawing.Image CreateThumbnail(System.Drawing.Image Original, int RequiredWidth, int RequiredHeight)
    {
        int AskedRequiredWidth = RequiredWidth;
        int AskedRequiredHeight = RequiredHeight;
        var final = new Bitmap(AskedRequiredWidth, AskedRequiredHeight);
        var image = new Bitmap(RequiredWidth, RequiredHeight);

        try
        {
            if ((Original.Width > RequiredWidth) || (Original.Height > RequiredHeight))
            {
                if (Original.Width > Original.Height)
                    RequiredWidth = (int)(RequiredHeight * (double)Original.Width / (double)(Original.Height));
                else
                    RequiredHeight = (int)(RequiredWidth * (double)Original.Height / (double)(Original.Width));

                image = new Bitmap(RequiredWidth, RequiredHeight);
            }

            using (Graphics graphics = Graphics.FromImage(image))
            {
                graphics.FillRectangle(Brushes.Transparent, new Rectangle(0, 0, RequiredWidth, RequiredHeight));
                //if any of width or height is larger than required then proceed
                //else return same small size as it is
                if ((Original.Width > RequiredWidth) || (Original.Height > RequiredHeight))
                {
                    graphics.DrawImage(Original, new Rectangle(0
                                                                , 0
                                                                , RequiredWidth
                                                                , RequiredHeight)
                                        , new Rectangle(0, 0, Original.Width, Original.Height), GraphicsUnit.Pixel);
                }
                else
                {
                    graphics.DrawImage(Original,
                                       new Rectangle((RequiredWidth - Original.Width) / 2,
                                                     (RequiredHeight - Original.Height) / 2, Original.Width,
                                                     Original.Height)
                                       , new Rectangle(0, 0, Original.Width, Original.Height), GraphicsUnit.Pixel);

                    return image;
                }
            }

            //cut extra and make as per asked size
            using (Graphics graphics = Graphics.FromImage(final))
            {
                graphics.FillRectangle(Brushes.Transparent, new Rectangle(0, 0, AskedRequiredWidth, AskedRequiredHeight));
                if (image.Width > image.Height)
                {
                    graphics.DrawImage(image, new Rectangle(0, 0, AskedRequiredWidth, AskedRequiredHeight)
                                        , new Rectangle((int)(((double)image.Width - (double)AskedRequiredWidth) / 2), 0, AskedRequiredWidth, AskedRequiredHeight), GraphicsUnit.Pixel);
                }
                else
                {
                    graphics.DrawImage(image, new Rectangle(0, 0, AskedRequiredWidth, AskedRequiredHeight)
                                        , new Rectangle(0, (int)(((double)image.Height - (double)AskedRequiredHeight) / 2), AskedRequiredWidth, AskedRequiredHeight), GraphicsUnit.Pixel);
                }
            }

        }
        catch (Exception ex)
        {
            Web.LogError(ex.ToString());
        }

        return final;
    }

    public static byte[] imageToByteArray(System.Drawing.Image imageIn)
    {
        var ms = new MemoryStream();
        imageIn.Save(ms, System.Drawing.Imaging.ImageFormat.Bmp);
        return ms.ToArray();
    }

    public static System.Drawing.Image byteArrayToImage(byte[] byteArrayIn)
    {
        MemoryStream ms = new MemoryStream(byteArrayIn);
        System.Drawing.Image returnImage = System.Drawing.Image.FromStream(ms);
        return returnImage;
    }

    public static string LoadFieldValues(int FieldID, string FieldName)
    {
        DataTable dtField = new DataTable();
        dtField = ListingExtendedFields.GetFieldValues(FieldID);
        StringBuilder sb = new StringBuilder();
        foreach (DataRow dr in dtField.Rows)
        {
            if (FieldName == "Duration" && dr["Value"].ToString() == "14")
            {
                sb.Append("<option selected='true' value='" + dr["Value"].ToString() + "'>");
                sb.Append(dr["Name"].ToString());
                sb.Append("</option>");
            }
            else
            {
                sb.Append("<option value='" + dr["Value"].ToString() + "'>");
                sb.Append(dr["Name"].ToString());
                sb.Append("</option>");
            }
        }
        return sb.ToString();
    }

    public static string LoadFieldValues(int FieldID)
    {
        DataTable dtField = new DataTable();
        dtField = ListingExtendedFields.GetFieldValues(FieldID);
        StringBuilder sb = new StringBuilder();
        foreach (DataRow dr in dtField.Rows)
        {
            sb.Append("<option value='" + dr["Value"].ToString() + "'>");
            sb.Append(dr["Name"].ToString());
            sb.Append("</option>");
        }
        return sb.ToString();
    }
      
    /// <summary>
    /// Use to upload the files from specific page. The method is used by UploadFile.aspx to store the file uploaded by user; 
    /// in the session.
    /// </summary>
    /// <param name="webPageName">The name of webpage where UploadFiles Control is used.</param>
    /// <param name="filePath">File to store in session collection.</param>
    /// <returns>True/False in case of sucdess or failier.</returns>
    public static bool AddToSessionFiles(string webPageName, string filePath)
    {
        try
        {
            if (string.IsNullOrEmpty(webPageName))
            {
                LogError("Could not find the WebPageName.");
                return false;
            }

            Object locker = new object();

            lock (locker)
            {
                Dictionary<string, List<string>> uploadedFiles = HttpContext.Current.Session[Constants.USER_UPLOADED_FILES] as Dictionary<string, List<string>>;
                List<string> currentPageCollection = null;

                if (uploadedFiles == null)
                {
                    uploadedFiles = new Dictionary<string, List<string>>();
                }

                if (uploadedFiles.Where(k => k.Key == webPageName).Count() < 1)
                {
                    currentPageCollection = new List<string>();
                }
                else
                {
                    currentPageCollection = uploadedFiles.Where(k => k.Key == webPageName).FirstOrDefault().Value;
                }

                if (!Directory.Exists(Path.Combine(ConfigVariables.UserTempFiles, webPageName)))
                {
                    Directory.CreateDirectory(Path.Combine(ConfigVariables.UserTempFiles, webPageName));
                }

                currentPageCollection.Add(filePath);
                uploadedFiles.Remove(webPageName);
                uploadedFiles.Add(webPageName, currentPageCollection);

                HttpContext.Current.Session[Constants.USER_UPLOADED_FILES] = uploadedFiles;
            }

            return true;
        }
        catch (Exception exp)
        {
            LogError("Could not add files to Session Collection:" + exp.Message);
            return false;
        }
    }

    /// <summary>
    /// Use to remove the file from session collection of upload control.    
    /// </summary>
    /// <param name="webPageName">The name of webpage where UploadFiles Control is used.</param>
    /// <param name="filePath">File to store in session collection.</param>
    /// <returns>True/False in case of sucdess or failier.</returns>
    public static bool RemoveFromSessionFiles(string webPageName, string filePath)
    {
        try
        {
            if (string.IsNullOrEmpty(webPageName))
            {
                LogError("Could not find the WebPageName.");
                return false;
            }

            Object locker = new object();

            lock (locker)
            {
                Dictionary<string, List<string>> uploadedFiles = HttpContext.Current.Session[Constants.USER_UPLOADED_FILES] as Dictionary<string, List<string>>;
                List<string> currentPageCollection = null;

                if (uploadedFiles == null)
                {
                    return true;
                }

                if (uploadedFiles.Where(k => k.Key == webPageName).Count() < 1)
                {
                    return true;
                }

                currentPageCollection = uploadedFiles.Where(k => k.Key == webPageName).FirstOrDefault().Value;

                if (File.Exists(filePath))
                    File.Delete(filePath);

                currentPageCollection.Remove(filePath);
                uploadedFiles.Remove(webPageName);
                uploadedFiles.Add(webPageName, currentPageCollection);

                HttpContext.Current.Session[Constants.USER_UPLOADED_FILES] = uploadedFiles;
            }

            return true;
        }
        catch (Exception exp)
        {
            LogError("Could not add files to Session Collection:" + exp.Message);
            return false;
        }
    }

    /// <summary>
    /// Use to remove the file from session collection of upload control.    
    /// </summary>
    /// <param name="webPageName">The name of webpage where UploadFiles Control is used.</param>
    /// <param name="filePath">File to store in session collection.</param>
    /// <returns>True/False in case of sucdess or failier.</returns>
    public static bool ClearSessionFiles(string webPageName)
    {
        try
        {
            if (string.IsNullOrEmpty(webPageName))
            {
                LogError("Could not find the WebPageName.");
                return false;
            }

            Object locker = new object();

            lock (locker)
            {
                Dictionary<string, List<string>> uploadedFiles = HttpContext.Current.Session[Constants.USER_UPLOADED_FILES] as Dictionary<string, List<string>>;

                if (uploadedFiles == null)
                {
                    return true;
                }

                if (uploadedFiles.Where(k => k.Key == webPageName).Count() < 1)
                {
                    return true;
                }

                uploadedFiles.Remove(webPageName);
                HttpContext.Current.Session[Constants.USER_UPLOADED_FILES] = uploadedFiles;
            }

            return true;
        }
        catch (Exception exp)
        {
            LogError("Could not add files to Session Collection:" + exp.Message);
            return false;
        }
    }

    /// <summary>
    /// Get all the files from session collection of the webpage; uploaded using file upload control.
    /// </summary>
    /// <param name="webPageName">The name of webpage where UploadFiles Control is used.</param>
    /// <returns>True/False in case of sucdess or failier.</returns>
    public static List<string> GetSessionFiles(string webPageName)
    {
        try
        {
            Dictionary<string, List<string>> uploadedFiles = HttpContext.Current.Session[Constants.USER_UPLOADED_FILES] as Dictionary<string, List<string>>;
            return uploadedFiles.Where(k => k.Key == webPageName).FirstOrDefault().Value;
        }
        catch (Exception exp)
        {
            LogError("Could not get the session files : GetSessionFiles(), " + exp.Message);
            return new List<string>();
        }
    }

    public static int GetSessionFilesCount(string webPageName)
    {
        try
        {
            Dictionary<string, List<string>> uploadedFiles = HttpContext.Current.Session[Constants.USER_UPLOADED_FILES] as Dictionary<string, List<string>>;
            return uploadedFiles.Where(k => k.Key == webPageName).FirstOrDefault().Value.Count;
        }
        catch (Exception exp)
        {
            LogError("Could not get the session files count: GetSessionFilesCount(), " + exp.Message);
            return 0;
        }
    }

    public static int GetRemainingAllowedFilesCount(int listingID, string webPageName)
    {
        try
        {
            int totalListingFiles = Listings.GetListingFileCount(Web.RecordID) + Web.GetSessionFilesCount(Web.QueryStringVariables.WebPageName);
            return Web.ConfigVariables.AllowedUploadCount - totalListingFiles;
        }
        catch (Exception exp)
        {
            LogError("Could not get the session files count: GetSessionFilesCount(), " + exp.Message);
            return 0;
        }
    }

    /// <summary>
    /// Get the collective files for seesion and listing.
    /// </summary>
    /// <param name="listingID"></param>
    /// <param name="webPageName"></param>
    /// <returns></returns>
    public static Dictionary<int, string> GetSessionAndListingFiles(int listingID, string webPageName)
    {
        try
        {
            int fileID = 0;
            Dictionary<int, string> allFiles = new Dictionary<int, string>();
            Dictionary<string, List<string>> uploadedFiles = HttpContext.Current.Session[Constants.USER_UPLOADED_FILES] as Dictionary<string, List<string>>;

            if (uploadedFiles != null)
            {
                if (uploadedFiles.Where(k => k.Key == webPageName).Count() > 0)
                {
                    List<string> sessionFiles = uploadedFiles.Where(k => k.Key == webPageName).FirstOrDefault().Value;
                    foreach (string filePath in sessionFiles)
                    {
                        fileID--;
                        allFiles.Add(fileID, filePath);
                    }
                }
            }

            SystemObjectFiles systemObjectFiles = new SystemObjectFiles();
            systemObjectFiles.Where.ObjectID.Value = listingID;
            systemObjectFiles.Query.Load();

            if (systemObjectFiles.RowCount > 0)
            {
                foreach (DataRow row in systemObjectFiles.DefaultView.Table.Rows)
                {
                    string fileUrl = string.Empty;
                    string fileTypeID = row["FileTypeID"].ToString().Trim();

                    if (fileTypeID.Equals("3") || fileTypeID.Equals("4")) // textLink & video link
                    {
                    }
                    else
                    {
                        fileUrl = string.IsNullOrEmpty(row["ThumbnailURL"].ToString()) ? row["URL"].ToString() : row["ThumbnailURL"].ToString();
                        allFiles.Add(Convert.ToInt32(row["SystemObjectFileID"]), fileUrl);
                    }
                }
            }

            return allFiles;
        }
        catch (Exception exp)
        {
            LogError("Could not get the session files : GetSessionFiles(), " + exp.Message);
            return null;
        }
    }

    /// <summary>
    /// Redirect the respose to provided url.
    /// </summary>
    /// <param name="url"></param>
    public static void Redirect(string url)
    {
        try
        {
            HttpContext.Current.Response.Redirect(url, false);
        }
        catch
        {
        }
    }
     
    public static string GetFileType(string fileType,string fileName)
    {
        
        try
        {
            if (fileType.Equals("photo") || fileType.Equals("video") || fileType.Equals("imageurl"))
            {
                return fileType;
            }
            if (fileType.Equals("link"))
            {
                return "url";
            }
            if (fileName.EndsWith(".doc") || fileName.EndsWith(".docx") || fileName.EndsWith(".rtf") || fileName.EndsWith(".txt"))
            {
                return "word";
            }
            if (fileName.EndsWith(".ppt") || fileName.EndsWith(".pptx"))
            {
                return   "powerpoint";
            }
            if (fileName.EndsWith(".xls") || fileName.EndsWith(".xlsx"))
            {
                return "xlsx";
            }
            if (fileName.EndsWith(".pdf"))
            {
                return "pdf";
            }
        }
        catch (Exception exp)
        {
            Web.LogError(exp);
        }
        return "default_file";
    }


}