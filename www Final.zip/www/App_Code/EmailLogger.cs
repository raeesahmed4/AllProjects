﻿using System;
using System.IO;

/// <summary>
/// Summary description for EmailLogger
/// </summary>
public class EmailLogger
{
    public EmailLogger()
    {
        //
        // TODO: Add constructor logic here
        //
    }

   
    public static void LogEmail(int TemplateID, System.Net.Mail.MailMessage EmailMessage)
    {
        try
        {
            string outputFile = @"C:\eOffer_Email_Debug\" + TemplateID.ToString() + ".htm";
            TextWriter output;

            // Create output file
            if (!File.Exists(outputFile))
                output = File.CreateText(outputFile);
            else
                output = File.AppendText(outputFile);

            // Write to output file
            output.Write(String.Format("TemplateID: {0} {1} To: {2} {3} From: {4} {5} Subject: {6} {7} Message: {8}",
                                TemplateID, "<br>", EmailMessage.To, "<br>",
                                EmailMessage.From, "<br>", EmailMessage.Subject, "<br>", EmailMessage.Body));
            output.Close();
        }
        catch (Exception)
        {
        }
    }
}
