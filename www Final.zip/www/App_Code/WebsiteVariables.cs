﻿using System;
using System.Collections.Generic;
using System.Web;
using System.IO;
using CodenameRabbitFoot.BusinessLogic;
using System.Data;
using System.Collections;
using VisualSoft.UserManagement;
using System.Configuration;

/// <summary>
/// Summary description for WebsiteVariables
/// </summary>
public partial class Web
{
    public static class ConfigVariables
    {
        public static int AllowedUploadCount
        {
            get
            {
                try
                {
                    return Convert.ToInt32(ConfigurationManager.AppSettings["AllowedUploadCount"]);
                }
                catch
                {
                    LogError(new Exception(string.Format("Could not get the AllowedUploadCount value from Web.Config File :{0} ", HttpContext.Current.Request.FilePath)));
                    return -1;
                }
            }

        }

        /// <summary>
        /// Get the path of UserTempFiles folder. Defind in web.config
        /// </summary>
        public static string UserTempFiles
        {
            get
            {
                try
                {
                    return System.Configuration.ConfigurationManager.AppSettings["UserTempFiles"].ToString();
                    //return Path.Combine(System.Configuration.ConfigurationManager.AppSettings["UserTempFiles"].ToString(), HttpContext.Current.Session.SessionID);
                }
                catch
                {
                    return string.Empty;
                }
            }
        }
    }
    /// <summary>
    /// This class is used to Get/Set the values in session variables.
    /// </summary>
    public static class SessionVariables
    {  
        /// <summary>
        /// Get/Set the last exception occured in in the web application.
        /// </summary>
        public static string LastErrorMessage
        {
            get
            {
                try
                {
                    return HttpContext.Current.Session["LastErrorMessage"].ToString();
                }
                catch
                {
                    return string.Empty;
                }
            }

            set
            {
                HttpContext.Current.Session["LastErrorMessage"] = value;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public static bool IsAdminSession
        {
            get
            {
                try
                {
                    return (bool)System.Web.HttpContext.Current.Session["IsSystemUserSession"];
                }
                catch
                {
                    return false;
                }
            }
            set
            {
                System.Web.HttpContext.Current.Session["IsSystemUserSession"] = value;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public static SystemUser SessionSystemUser
        {
            get
            {
                try
                {
                    return System.Web.HttpContext.Current.Session["SystemUser"] as SystemUser;
                }
                catch (Exception ex)
                {
                    //Log.Write("err", ex.GetBaseException().ToString(), ex);
                    Web.LogError(ex);
                    return null;
                }
            }

            set
            {
                System.Web.HttpContext.Current.Session["SystemUser"] = value;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public static Hashtable MemberModuleAccess
        {
            get
            {
                try
                {
                    return System.Web.HttpContext.Current.Session["MemberModuleAccess"] as Hashtable;
                }
                catch (Exception ex)
                {
                    //Log.Write("err", ex.GetBaseException().ToString(), ex);
                    Web.LogError(ex);
                    return null;
                }
            }

            set
            {
                System.Web.HttpContext.Current.Session["MemberModuleAccess"] = value;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public static bool IsSecuritySession
        {
            get
            {
                try
                {
                    if (Web.SystemConfigs.GetKey("EnableIdentityCheck").ToString() == "0")
                    {
                        return true;
                    }
                    else
                    {
                        return (bool)System.Web.HttpContext.Current.Session["IsSecuritySession"];
                    }
                }
                catch
                {
                    return false;
                }
            }
            set
            {
                System.Web.HttpContext.Current.Session["IsSecuritySession"] = value;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public static bool IsSystemUserSession
        {
            get
            {
                try
                {
                    return (bool)System.Web.HttpContext.Current.Session["IsSystemUserSession"];
                }
                catch
                {
                    return false;
                }
            }
            set
            {
                System.Web.HttpContext.Current.Session["IsSystemUserSession"] = value;
            }
        }
 
         
    }

    /// <summary>
    /// This class user to manipulate the Query String variables.
    /// </summary>
    public static class QueryStringVariables
    {
        /// <summary>
        /// WebPage name variable in QueryString.
        /// </summary>
        public static string WebPageName
        {
            get
            {
                try
                {
                    return HttpContext.Current.Request.QueryString["WebPageName"].ToString();
                }
                catch
                {
                    LogError(new Exception(string.Format("Could not get the WebPageName value from QueryStirng. File :{0} ", HttpContext.Current.Request.FilePath)));
                    return string.Empty;
                }
            }

        }

        /// <summary>
        /// Get the value of MaxLimit variable defined in QueryStirng.
        /// </summary>
        public static int MaxLimit
        {
            get
            {
                try
                {
                    return Convert.ToInt32(HttpContext.Current.Request.QueryString["MaxLimit"]);
                }
                catch
                {
                    LogError(new Exception(string.Format("Could not get the MaxLimit value from QueryStirng. File :{0} ", HttpContext.Current.Request.FilePath)));
                    return -1;
                }
            }

        }
               
        /// <summary>
        /// Extract RecordString in current query string
        /// </summary>        
        public static string RecordString
        {
            get
            {
                try
                {
                    //int recordString;
                    string recordString = System.Web.HttpContext.Current.Request.QueryString["RecordString"];

                    if (recordString != null || recordString != "")
                    {
                        return Secure.Decrypt(recordString);
                    }
                }
                catch (Exception ex)
                {
                    Web.WriteLog("Get Record String", ex.Message, ex);
                }

                return "";
            }
            set
            {
                try
                {
                    System.Web.HttpContext.Current.Request.QueryString["RecordString"] = value.ToString();
                }
                catch
                { }
            }
        }

    }
}