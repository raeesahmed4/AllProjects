﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;

/// <summary>
/// Summary description for RepositryManager
/// </summary>
public static class RepositryManager
{
    public static Dictionary<string, List<UploaderRepository>> UploadedFiles
    {
        get
        {
            if (System.Web.HttpContext.Current.Session["UploaderRepository"] == null)
                System.Web.HttpContext.Current.Session["UploaderRepository"] = new Dictionary<string, List<UploaderRepository>>();

            return System.Web.HttpContext.Current.Session["UploaderRepository"] as Dictionary<string, List<UploaderRepository>>;
        }
    }

    public static string GetRepositryPath(string repositryKey)
    {
        string folderPath = Path.Combine(Web.ConfigVariables.UserTempFiles, Path.Combine(HttpContext.Current.Session.SessionID, repositryKey));
        if (!Directory.Exists(folderPath))
            Directory.CreateDirectory(folderPath);

        return folderPath;
    }

    public static List<UploaderRepository> GetRepositry(string repositryKey)
    {
        var exists = UploadedFiles.Where(i => i.Key == repositryKey).Count() > 0;
        if (exists)
        {
            return UploadedFiles.Where(i => i.Key == repositryKey).First().Value;
        }
        return new List<UploaderRepository>();
    }

    public static bool ClearRepositry(string repositryKey)
    {
        var exists = UploadedFiles.Where(i => i.Key == repositryKey).Count() > 0;
        if (exists)
        {
            var files = UploadedFiles.Where(i => i.Key == repositryKey).First().Value;
            foreach (var file in files)
            {
                if (File.Exists(file.FilePath))
                    File.Delete(file.FilePath);
            }

            UploadedFiles.Where(i => i.Key == repositryKey).First().Value.Clear();
        }
        return true;
    }


    public static UploaderRepository AddFileToRepositry(string repositryKey, HttpPostedFile file)
    {
        var repositry = new UploaderRepository();
        repositry.FileName = file.FileName;
        repositry.FileExtention = Path.GetExtension(file.FileName);
        repositry.FileType = GetFileType(repositry.FileExtention);
        repositry.FilePath = Path.Combine(GetRepositryPath(repositryKey), repositry.FileId + repositry.FileExtention);
        file.SaveAs(repositry.FilePath);

        var exists = UploadedFiles.Where(i => i.Key == repositryKey).Count() > 0;
        if (!exists)
        {
            UploadedFiles.Add(repositryKey, new List<UploaderRepository>());
        }

        UploadedFiles.Where(i => i.Key == repositryKey).First().Value.Add(repositry);
        return repositry;
    }

    public static UploaderRepository AddFileToRepositry(string repositryKey, string filePath)
    {
        var repositry = new UploaderRepository();
        repositry.FileName =Path.GetFileName( filePath);
        repositry.FileExtention = Path.GetExtension(filePath);
        repositry.FileType =GetFileType(repositry.FileExtention);
        repositry.FilePath = Path.Combine(GetRepositryPath(repositryKey), repositry.FileId + repositry.FileExtention);
        File.Copy(filePath, repositry.FilePath, true);
        
        var exists = UploadedFiles.Where(i => i.Key == repositryKey).Count() > 0;
        if (!exists)
        {
            UploadedFiles.Add(repositryKey, new List<UploaderRepository>());
        }

        UploadedFiles.Where(i => i.Key == repositryKey).First().Value.Add(repositry);
        return repositry;
    }

    public static UploaderRepository AddVideoToRepositry(string repositryKey, string videoTitle, string url)
    {
        var repositry = new UploaderRepository();
        repositry.FileName = videoTitle;
        repositry.FileType = FileTypes.Video;
        repositry.Url = url.Replace("/embed/", "/v/");

        var exists = UploadedFiles.Where(i => i.Key == repositryKey).Count() > 0;
        if (!exists)
        {
            UploadedFiles.Add(repositryKey, new List<UploaderRepository>());
        }

        UploadedFiles.Where(i => i.Key == repositryKey).First().Value.Add(repositry);
        return repositry;
    }

    public static bool RemoveFromRepositry(string repositryKey, string fileId)
    {
        var exists = UploadedFiles.Where(i => i.Key == repositryKey).Count() > 0;
        if (exists)
        {
            var list = UploadedFiles.Where(i => i.Key == repositryKey).First().Value;
            var item = list.Where(l => l.FileId.Equals(fileId)).FirstOrDefault();

            if (item != null)
            {
                UploadedFiles.Where(i => i.Key == repositryKey).First().Value.Remove(item);
                if (File.Exists(item.FilePath))
                    File.Delete(item.FilePath);
            }
        }
        return true;
    }
     
    private static FileTypes GetFileType(string extention)
    {
        extention = extention.ToLower().Replace(".", "");
        if (extention.Equals("png") || extention.Equals("jpg") || extention.Equals("jpeg") || extention.Equals("gif"))
            return FileTypes.Photo;

        if (extention.Equals("txt") || extention.Equals("rtf") || extention.Equals("doc") || extention.Equals("docx") || extention.Equals("pdf"))
            return FileTypes.Document;

        return FileTypes.FileURL;
    }
}