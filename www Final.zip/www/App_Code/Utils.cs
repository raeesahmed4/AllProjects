using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
using System.Collections.Specialized;
using System.Data;
using CodenameRabbitFoot.BusinessLogic;


public static class Utils
{
    /// <summary>
    /// Copies all the field values from <paramref name="source"/> <paramref name="target"/>.
    /// </summary>
    /// <param name="source">The source object.</param>
    /// <param name="target">The target object.</param>
    public static void FieldCopy(object source, object target)
    {

        if (source == null || target == null)
        {
            return;
        }

        foreach (FieldInfo fi in source.GetType().GetFields(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance))
        {
            fi.SetValue(target, fi.GetValue(source));
        }
    }

    public static void SendCouponEmail(object batchNumber)
    {
        //long batchNumber = Convert.ToInt64(batchNumberObj);

        try
        {
            int InvitationID = 0;
            //Logger.Info(string.Format("Sending Coupons to batchnumber:{0}", batchNumber));
            MemberContactList cList = new MemberContactList();
            cList.Where.BatchNumber.Value = batchNumber;
            cList.Query.Load();

            Members contactListOwner = new Members();
            contactListOwner.Where.MemberID.Value = cList.MemberID;
            contactListOwner.Query.Load();

            string htmlHeader = Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER");
            string htmlFooter = Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER");

            // Logger.Info(string.Format("Number of users in list:{0}", cList.RowCount));
            if (cList.RowCount > 0)
            {
                do
                {
                    Members memberToBeregistered = null;
                    bool sendEmail = true;
                    int templateID = 0;
                    Members couponUser = new Members();
                    couponUser.Where.Email.Value = cList.ContactEmail;
                    couponUser.Query.Load();

                    if (couponUser.RowCount == 0) // // Member is not registered yet.
                    {
                        //Logger.Info("Member is not registered.");

                        DataTable alreadyInvited = Invitations.CheckIfInvited(Web.SessionMembers.MemberID, cList.ContactEmail);

                        if (alreadyInvited.Rows.Count > 0)
                        {
                            InvitationID = Convert.ToInt32(alreadyInvited.Rows[0][0]);
                        }
                        else
                        {
                            // send invitation
                            Invitations invitation = new Invitations();
                            invitation.AddNew();
                            invitation.InvitedBy = Web.SessionMembers.MemberID;
                            invitation.InvitationToName = cList.ContactName;
                            invitation.InvitationToEmail = cList.ContactEmail;
                            invitation.InvitationDate = DateTime.Now;
                            invitation.InvitationStatus = 0;
                            invitation.ContactType = 1;
                            invitation.IsPrivate = 1;
                            invitation.IsActive = 1;
                            invitation.Save();

                            InvitationID = invitation.InvitationID;
                        }

                        templateID = 902; // Template for unregistered users.

                    }
                    else // already registered.
                    {
                        //Logger.Info("Member is already registered.");
                        Contacts contacts = new Contacts();
                        contacts.Where.MemberID.Value = cList.MemberID;
                        contacts.Where.ContactMemberID.Value = couponUser.MemberID;
                        contacts.Query.Load();

                        if (contacts.RowCount == 0)// Not in Contacts list 
                        {
                            //Logger.Info(string.Format("Member is not in contactlist of ({0}) {1}.", contactListOwner.MemberID, contactListOwner.Email));
                            DataTable alreadyInvited = Invitations.CheckIfInvited(contactListOwner.MemberID, couponUser.MemberID);
                            if (alreadyInvited.Rows.Count == 0)// Not invited
                            {
                                //1. send invitaion
                                InvitationID = Contacts.AddToContact(couponUser.MemberID, contactListOwner.MemberID, 1, 1);// Contacts.AddToContact(cList.ContactEmail, cList.ContactName, member.CompanyName, cList.MemberID, 1/*cleint*/, 1);
                                if (InvitationID != 0)
                                    templateID = 904;// Template for non-member users. 
                                else
                                    continue;
                                // Send Email.
                            }
                            else
                            {
                                sendEmail = false;
                                // No need to send email here .
                            }
                        }
                        else // Already in contacts list
                        {
                            //Logger.Info(string.Format("Member is found in contactlist of ({0}) {1}.", contactListOwner.MemberID, contactListOwner.Email));
                            // Send Email.
                            templateID = 903; // Template for member users.
                        }

                    }

                    StringDictionary templateKeys = new StringDictionary();

                    templateKeys.Add("#email_header#", htmlHeader);
                    templateKeys.Add("#fullname#", cList.s_ContactName.Split(' ')[0]); // Select the first name only
                    templateKeys.Add("#sid#", Guid.NewGuid().ToString());
                    templateKeys.Add("#company#", contactListOwner.CompanyName);

                    MemberCoupons coupons = new MemberCoupons();
                    coupons.Where.BatchNumber.Value = cList.BatchNumber;
                    coupons.Query.Load();

                    if (coupons.RowCount > 0)
                    {
                        templateKeys.Add("#couponid#", Secure.Encrypt(coupons.ListingID));
                        //templateKeys.Add("#invitationid#", Secure.Encrypt(InvitationID));
                    }
                    if (templateID == 902)
                    {
                        templateKeys.Add("#invitationid#", Secure.Encrypt(InvitationID.ToString()));
                        templateKeys.Add("#profile_link#", Web.SystemConfigs.GetKey("SITE_URL") + "Contacts/ViewProfile.aspx?Action=ViewDealer&RecordID=" + Secure.Encrypt(Web.SessionMembers.MemberID) + "&Invitation=" + Secure.Encrypt(InvitationID));
                        templateKeys.Add("#sender_name#", Web.SessionMembers.FullName);
                    }
                    templateKeys.Add("#email_footer#", htmlFooter);

                    /*  if (memberToBeregistered != null)
                     {
                         Since we are not creating members on invitations :)
                         templateKeys.Add("#code#", memberToBeregistered.RegistrationCode);
                         templateKeys.Add("#sid#", memberToBeregistered.SurrogateID);
                    
                     }
                     else*/
                    //     {
                    if (couponUser.RowCount > 0)
                    {
                        if (couponUser.MemberStatusID == 100)// Pending invitaion
                        {
                            templateKeys.Add("#code#", couponUser.RegistrationCode);
                            templateKeys.Add("#sid#", couponUser.SurrogateID);
                            templateID = 902; // template for unregistered users.
                        }
                    }
                    //  }

                    if (sendEmail)
                    {
                        //Logger.Info("Before Sending Email");
                        Web.SendMail(cList.s_ContactEmail, Web.SystemConfigs.GetKey("REG_EMAIL"), templateID, templateKeys);
                        //Logger.Info("After Sending Email");
                    }
                    templateKeys = null;
                    couponUser = null;
                }
                while (cList.MoveNext());
            }
            //Logger.Info("Coupon Sending process completed. Now exiting function.");
            //return true;
        }
        catch (Exception ex)
        {
            //TODO: send email to user or some message to him/her about coupon send failure

            System.Web.HttpContext.Current.Session["Message"] = "Coupons not sent."
                        + Environment.NewLine + Environment.NewLine +
                        System.Web.HttpContext.Current.Session["Message"];

            throw;
        }
    }

    public static string GetReducedString(string inputString, int maxLength)
    {
        string resut = inputString;
        try
        {
            if (inputString.Length + 1 > maxLength)
            {
                return inputString.Substring(0, maxLength - 1) + "...";
            }
        }
        catch
        {
            resut = inputString;
        }
        return resut;
    }
}


public class ExhibitItem
{
    public string id="", title = "", price = "", quantity = "", description = "", offer = "", fileName = "", tempFilePath = "", fileUrl = "", type = "";
}

public class UploaderRepository
{
    public string FileId { get; private set; }
    public string FileName { get; set; }
    public string FileExtention { get; set; }
    public FileTypes FileType { get; set; }
    public string Url { get; set; }
    public string FilePath { get; set; }

    public UploaderRepository()
    {
        this.FileId = "_" + Guid.NewGuid().ToString().Replace("-", "");
    }

}

public class FeedItem
{
    public FeedItem()
    {
        files = new List<Files>();
        comments = new List<Comments>();
    }
    public string Id, EncryptedItemId,ObjectId, MemberId, UserName, Title,ListingTypeName, Description,ShowLinkUnlink, Date,IsPosting;
    public string ContactAccessibility, Status,ContactStatus;
    public bool HasBuyingItems, HasSellingItems;
    public List<Files> files;
    public List<Comments> comments;

    public class Files
    {
        public string Id, EncryptedFileId, FileName, Url, Thumbnail, Type;
    }

}

public class Comments
{
    public string Id, EncryptedCommentId, Description, Date, CommentBy, UserName;
    public bool AllowDelete = true;
}