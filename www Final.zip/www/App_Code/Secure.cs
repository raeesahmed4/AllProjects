﻿using System;
using System.Security.Cryptography;
using Microsoft.Practices.EnterpriseLibrary.Security.Cryptography;

/// <summary>
/// Summary description for Secure
/// </summary>
public class Secure
{
    public Secure()
    {
        //
        // TODO: Add constructor logic here
        //
    }


    public static string Encrypt(object value)
    {
        //return Cryptographer.EncryptSymmetric("RijndaelManaged", value.ToString().Replace(" ", "+"));
        return eOpenSecurity.Encrypt(value.ToString().Replace(" ", "+"), "Wh0isthis??");
    }

    public static string Decrypt(string value)
    {
        if (value.Length > 5)
        {
            return eOpenSecurity.Decrypt(value.Replace(" ", "+"), "Wh0isthis??");
        }
        else
        {
            return value;
        }
        //return Cryptographer.DecryptSymmetric("RijndaelManaged", value.Replace(" ", "+"));
    }

    public static bool CheckHash(string value, string hash)
    {
        return Cryptographer.CompareHash("MD5CryptoServiceProvider", value, hash);
    }

    public static string CreateHash(string value)
    {
        return Cryptographer.CreateHash("MD5CryptoServiceProvider", value);
    }


   

}
