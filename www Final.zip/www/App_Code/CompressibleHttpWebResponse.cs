using System;
using System.Net;
using System.IO;
using System.Runtime.Serialization;
using System.IO.Compression;

namespace Pajocomo.Net
{
	/// <summary>
	/// Provides a compressibele HTTP-specific implementation of the <see cref="System.Net.WebResponse"/> class.
	/// </summary>
    [Serializable]
    public class CompressibleHttpWebResponse : HttpWebResponse
	{
        /// <summary>
        /// Initializes a new instance of the <see cref="CompressibleHttpWebResponse"/> class.
        /// </summary>
        /// <param name="serializationInfo">A <see cref="T:System.Runtime.Serialization.SerializationInfo"></see> that contains the information required to serialize the new <see cref="T:System.Net.HttpWebRequest"></see>.</param>
        /// <param name="streamingContext">A <see cref="T:System.Runtime.Serialization.StreamingContext"></see> that contains the source of the serialized stream that is associated with the new <see cref="T:System.Net.HttpWebRequest"></see>.</param>
		public CompressibleHttpWebResponse(SerializationInfo serializationInfo, StreamingContext streamingContext) : base(serializationInfo, streamingContext)
		{
		}

        /// <summary>
        /// Gets the stream that is used to read the body of the response from the server.
        /// </summary>
        /// <returns>
        /// A <see cref="T:System.IO.Stream"></see> containing the body of the response.
        /// </returns>
        /// <exception cref="T:System.ObjectDisposedException">The current instance has been disposed. </exception>
        /// <exception cref="T:System.Net.ProtocolViolationException">There is no response stream. </exception>
        /// <PermissionSet>
        ///   <IPermission class="System.Security.Permissions.EnvironmentPermission, mscorlib, Version=2.0.3600.0, Culture=neutral, PublicKeyToken=b77a5c561934e089" version="1" Unrestricted="true"/>
        ///   <IPermission class="System.Security.Permissions.FileIOPermission, mscorlib, Version=2.0.3600.0, Culture=neutral, PublicKeyToken=b77a5c561934e089" version="1" Unrestricted="true"/>
        ///   <IPermission class="System.Security.Permissions.SecurityPermission, mscorlib, Version=2.0.3600.0, Culture=neutral, PublicKeyToken=b77a5c561934e089" version="1" Flags="UnmanagedCode, ControlEvidence"/>
        /// </PermissionSet>
        public override Stream GetResponseStream()
        {
            Stream stream = base.GetResponseStream();

            if (stream == null)
            {
                return Stream.Null;
            }

			if (string.Compare(ContentEncoding, "gzip", true) == 0)
			{
                return new GZipStream(stream, CompressionMode.Decompress);
			}
			else if (string.Compare(ContentEncoding, "deflate", true) == 0)
			{
				return new DeflateStream(stream, CompressionMode.Decompress);
			}
			else
			{
				return stream;
			}
		}
    }
}
