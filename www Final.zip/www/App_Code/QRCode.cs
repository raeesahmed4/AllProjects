﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using ThoughtWorks.QRCode.Codec;
using ThoughtWorks.QRCode.Codec.Data;

/// <summary>
/// Summary description for QRCode
/// </summary>
public static class QRCode
{
    public static System.Drawing.Image EncodeQRCode(string Data, System.Drawing.Image CompanyLogo, System.Drawing.Color BGColor, System.Drawing.Color FGColor)
    {
        QRCodeEncoder qrCodeEncoder = new QRCodeEncoder();
        try
        {
            if (Data == String.Empty)
                throw new Exception("Data must not be empty.");

            if (FGColor == System.Drawing.Color.Transparent || FGColor == System.Drawing.Color.White)
                throw new Exception("Select different color.");

            //String encoding = cboEncoding.Text;
            String encoding = "Byte";
            if (encoding == "Byte")
            {
                qrCodeEncoder.QRCodeEncodeMode = QRCodeEncoder.ENCODE_MODE.BYTE;
            }
            else if (encoding == "AlphaNumeric")
            {
                qrCodeEncoder.QRCodeEncodeMode = QRCodeEncoder.ENCODE_MODE.ALPHA_NUMERIC;
            }
            else if (encoding == "Numeric")
            {
                qrCodeEncoder.QRCodeEncodeMode = QRCodeEncoder.ENCODE_MODE.NUMERIC;
            }
            try
            {
                //int scale = Convert.ToInt16(txtSize.Text);
                int scale = Convert.ToInt16("3");
                qrCodeEncoder.QRCodeScale = scale;
            }
            catch (Exception ex)
            {
                throw new Exception("Invalid size!");
            }
            try
            {
                //int version = Convert.ToInt16(cboVersion.Text);
                int version = Convert.ToInt16("7");
                qrCodeEncoder.QRCodeVersion = version;
            }
            catch (Exception ex)
            {
                throw new Exception("Invalid version !");
            }

            //string errorCorrect = cboCorrectionLevel.Text;
            string errorCorrect = "H";
            if (errorCorrect == "L")
                qrCodeEncoder.QRCodeErrorCorrect = QRCodeEncoder.ERROR_CORRECTION.L;
            else if (errorCorrect == "M")
                qrCodeEncoder.QRCodeErrorCorrect = QRCodeEncoder.ERROR_CORRECTION.M;
            else if (errorCorrect == "Q")
                qrCodeEncoder.QRCodeErrorCorrect = QRCodeEncoder.ERROR_CORRECTION.Q;
            else if (errorCorrect == "H")
                qrCodeEncoder.QRCodeErrorCorrect = QRCodeEncoder.ERROR_CORRECTION.H;

            qrCodeEncoder.QRCodeBackgroundColor = BGColor;
            qrCodeEncoder.QRCodeForegroundColor = FGColor;

            System.Drawing.Bitmap mainImage = qrCodeEncoder.Encode(Data);

            if (CompanyLogo != null) //add logo only if requested
            {
                System.Drawing.Image logo = Web.CreateThumbnail(CompanyLogo, 75, 75);

                int left = (mainImage.Width / 2) - (logo.Width / 2);
                int top = (mainImage.Height / 2) - (logo.Height / 2);

                System.Drawing.Graphics g = System.Drawing.Graphics.FromImage(mainImage);
                g.DrawImage(logo, new System.Drawing.Point(left, top));
            }

            //return Web.imageToByteArray(mainImage);
            return mainImage;
        }
        catch
        {
            throw;
        }
        finally
        {
            qrCodeEncoder = null;
            GC.Collect();
        }
    }

    public static string DecodeQRCode(byte[] QRImage)
    {
        QRCodeDecoder qrCodeDecoder = new QRCodeDecoder();
        try
        {
            return qrCodeDecoder.decode(new QRCodeBitmapImage(Web.byteArrayToImage(QRImage) as System.Drawing.Bitmap));
        }
        catch
        {
            throw;
        }
        finally
        {
            qrCodeDecoder = null;
            GC.Collect();
        }
    }
}