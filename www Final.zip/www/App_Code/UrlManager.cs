﻿using System;
using System.Collections.Generic;
using System.Web;
using CodenameRabbitFoot.BusinessLogic;

/// <summary>
/// Summary description for UrlManager
/// </summary>
public class UrlManager
{
    private static string username = "";
    private static string lastusername = "";

    public UrlManager()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    private static string getPageName(ref string url)
    {
        System.IO.FileInfo oInfo = new System.IO.FileInfo(url);
        return oInfo.Name.Replace(".aspx", "");
    }

    public static string ReWriteProfle(string url)
    {
        string result = string.Empty;
        try
        {
            Members member = new Members();
            member.Query.AddResultColumn(MembersSchema.MemberID);

            lastusername = getPageName(ref url);
            if (username != lastusername)
                username = lastusername;

            else if (username == "")
                username = getPageName(ref url);

            member.Where.UserName.Value = username;
            member.Query.Load();
            result = "/Contacts/ViewProfile.aspx?Action=ViewDealer&RecordID=" + member.MemberID;
        }
        catch (Exception ex)
        {
            username = "";
        }

        return result;
    }

    public static string ReWriteLots(string url)
    {
        string result = string.Empty;
        Lots lot = new Lots();
        lot.Query.AddResultColumn(LotsSchema.LotID);
        lot.Query.AddResultColumn(LotsSchema.LotName);
        lot.Query.Load();

        return result;
    }
}
