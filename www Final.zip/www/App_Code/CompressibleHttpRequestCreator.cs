using System;
using System.Net;
using System.Runtime.Serialization;
using System.Reflection;

namespace Pajocomo.Net
{
	/// <summary>
	/// Provides funcionality for creating <see cref="CompressibleHttpWebRequest"/> instances.
	/// </summary>
	public class CompressibleHttpRequestCreator : IWebRequestCreate
	{
        #region Public instance constructors

		/// <summary>
		/// Initializes a new instance of the <see cref="CompressibleHttpRequestCreator"/> class.
		/// </summary>
		public CompressibleHttpRequestCreator()
		{
        }

        #endregion

        #region IWebRequestCreate Members

		/// <summary>
		/// Creates a <see cref="T:Pajocomo.Net.CompressibleHttpWebRequest"/> instance.
		/// </summary>
		/// <param name="uri">The uniform resource identifier (URI) of the Web resource.</param>
		/// <returns>
		/// A <see cref="T:Pajocomo.Net.CompressibleHttpWebRequest"/> instance.
		/// </returns>
        WebRequest IWebRequestCreate.Create(Uri uri)
        {
            ISerializable httpWebRequest = Activator.CreateInstance(typeof(HttpWebRequest), BindingFlags.CreateInstance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance, null, new object[] { uri, null }, null) as ISerializable;

            if (httpWebRequest == null)
            {
                return null;
            }

            SerializationInfo serializationInfo = new SerializationInfo(typeof(CompressibleHttpWebRequest), new FormatterConverter());
            StreamingContext streamingContext = new StreamingContext(StreamingContextStates.All);
            httpWebRequest.GetObjectData(serializationInfo, streamingContext);

            CompressibleHttpWebRequest compressibleHttpRequest = new CompressibleHttpWebRequest(serializationInfo, streamingContext);
            Utils.FieldCopy(httpWebRequest, compressibleHttpRequest);

            return compressibleHttpRequest;
        }

        #endregion
    }
}
