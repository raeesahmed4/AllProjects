﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.XPath;

using System.Xml;
using System.Data;


public class XMLConfigReader
{

    private DataTable dt = new DataTable();
    private string pageSource = "";
    private string currentPage = "";
    private string currentPageLogo = "";

    public string CurrentPageLogo
    {
        get
        {
            return this.currentPageLogo;
        }
    }

    public DataTable PageLinks
    {
        get
        {
            return this.dt;
        }
    }

    public string XMLPageSource
    {
        get
        {
            return this.pageSource;
        }
        set
        {
            this.pageSource = value;
        }
    }

    public string CurrentPage
    {
        get
        {
            return this.currentPage;
        }
        set
        {
            this.currentPage = value;
        }
    }

    public XMLConfigReader()
    {
        dt.Columns.Add("Src", typeof(string));
        dt.Columns.Add("alt", typeof(string));
        dt.Columns.Add("url", typeof(string));
        dt.Columns.Add("rel", typeof(string));
        dt.Columns.Add("onclick", typeof(string));
    }

    public void ReadXML()
    {
        try
        {
            if (this.pageSource == "")
                throw new Exception("Please specify path to the source XML doucment...");
            XPathDocument doc = new XPathDocument(this.pageSource);
            XPathNavigator docNav = doc.CreateNavigator();

            XPathExpression exp;

            if (this.currentPage == "")
                throw new Exception("Please specify current page name");

            exp = docNav.Compile("//page [@name='" + this.currentPage + "']");
            XPathNodeIterator nodeIterator = docNav.Select(exp);



            while (nodeIterator.MoveNext())
            {


                docNav = nodeIterator.Current.Clone();

                XPathNodeIterator nodeIteratorInternal = docNav.SelectChildren(System.Xml.XPath.XPathNodeType.All);
                if (nodeIteratorInternal.MoveNext())
                {
                    XPathNavigator docNav2 = nodeIteratorInternal.Current.Clone();
                    //MessageBox.Show(docNav2.Value);

                    this.currentPageLogo = docNav2.Value;
                }

                if (this.currentPage == "")
                    throw new Exception("Please specify current page name");

                exp = docNav.Compile("//page [@name='" + this.currentPage + "']/link");
                nodeIterator = docNav.Select(exp);

                Dictionary<int, List<string>> combined = new Dictionary<int, List<string>>();
                int x = 0;
                while (nodeIterator.MoveNext())
                {
                    nodeIteratorInternal = nodeIterator.Current.SelectChildren(XPathNodeType.All);

                    combined.Add(++x, new List<string>());

                    while (nodeIteratorInternal.MoveNext())
                    {
                        docNav = nodeIteratorInternal.Current.Clone();

                        combined[x].Add(docNav.Value);
                    }
                }

                foreach (int key in combined.Keys)
                {
                    DataRow dr = dt.NewRow();
                    dr["Src"] = combined[key][0];
                    dr["alt"] = combined[key][1];
                    dr["url"] = combined[key][2];
                    dr["rel"] = combined[key][3];
                    dr["onclick"] = combined[key][4];
                    dt.Rows.Add(dr);
                }

               


            }


        }
        catch (Exception)
        {
            throw;
        }
    }
}