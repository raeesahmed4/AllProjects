using System;

namespace Pajocomo.Net
{
	/// <summary>
	/// Defines the possible values for the <b>Accept-Encoding</b> HTTP header.
	/// </summary>
    [Flags]
	public enum AcceptEncodings
	{
		/// <summary>
		/// The <b>Identity</b> <b>Accept-Encoding</b> HTTP header.
		/// </summary>
        Identity,
		/// <summary>
		/// The <b>GZip</b> <b>Accept-Encoding</b> HTTP header.
		/// </summary>
        GZip,
		/// <summary>
		/// The <b>Deflate</b> <b>Accept-Encoding</b> HTTP header.
		/// </summary>
        Deflate
	}
}
