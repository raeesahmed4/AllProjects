﻿/// <summary>
/// Summary description for Constants
/// </summary>
public class Constants
{
    public const string USER_UPLOADED_FILES = "USER_UPLOADED_FILES";

    public const string MSG_MY_LINKINGS_EMPTY_GRID = "No linkings exists.";
    public const string MSG_LINKS_TO_ME_EMPTY_GRID = "No links to your account exists.";
    public const string MSG_SEARCH_EMPTY_GRID = "No records exists according to selected criteria.";
    public const string MSG_SEARCH_SUGGESTION_EMPTY_GRID = "No records exists.";
    public const string MSG_MEMBER_CONTACT_LIST_EMPTY_GRID = "No records exists.";

    public const string MSG_CLIENTS_EMPTY_GRID = "No clients exists.";
    public const string MSG_VENDORS_EMPTY_GRID = "No vendor exists.";
    public const string MSG_EXHIBITIONS_EMPTY_GRID = "No exhibitions exists.";
}