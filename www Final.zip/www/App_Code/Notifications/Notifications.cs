﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Quartz;
using CodenameRabbitFoot.BusinessLogic;
using System.Collections.Specialized;
using System.Data;

/// <summary>
/// Summary description for Notifications
/// </summary>
public class Notifications : IJob
{
    public Notifications()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public void Execute(JobExecutionContext context)
    {
        try
        {
            JobDetail detail = context.JobDetail;
            if (detail.Name == "myJobWeekly")
                SendNewsLetterWeekly();
            if (detail.Name == "myJobEmail")
                SendEmail(context.Trigger.Name);

        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }

        try
        {
            SendNotofications_1005_REMINDER_MARK_AS_PAID();
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }

        try
        {
            SendNotofications_1001_REMINDER_MARK_ITEM_RECEIVED();
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }

        try
        {
            SendNotofications_1002_REMINDER_MARK_ITEM_SHIPPED();
        }
        catch (Exception ex)
        {

            Web.LogError(ex);
        }

        try
        {
            SendNotofications_1003_REMINDER_MARK_ITEM_SHIPPED_WARNING();
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }

        try
        {
            SendNotofications_1004_REMINDER_MARK_PAYMENT_RECEIVED();
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }

    private void SendEmail(string batchNumber)
    {
        Utils.SendCouponEmail(Convert.ToInt64(batchNumber));
    }

    /// <summary>
    /// To: Buyer
    /// </summary>
    public void SendNotofications_1005_REMINDER_MARK_AS_PAID()
    {
        List<ListingOffers> listingOffers = Emails.GetListingOffers(200, 1005, 4);

        foreach (ListingOffers offer in listingOffers)
        {
            var listing = new Listings();
            listing.LoadByPrimaryKey(offer.ListingID);
            if (listing.RowCount > 0) // if listing exists
            {
                var title = Listings.GetTitle(offer.ListingID);

                // getting the buyer is so simple...
                var buyer = new Members();
                buyer.LoadByPrimaryKey(offer.OfferBy);

                // getting the seller is so simple...
                var seller = new Members();
                seller.LoadByPrimaryKey(listing.MemberID);

                //// get buyer Address
                //var buyerAddress = ShippingAddresses.LoadByMemberID(buyer.MemberID);

                // get seller Address
                var sellerAddress = ShippingAddresses.LoadByMemberID(seller.MemberID);

                var templateKeys = new StringDictionary();
                templateKeys.Add("#fullname#", buyer.FullName);
                templateKeys.Add("#item#", title);
                templateKeys.Add("#quantity#", offer.Quantity.ToString());
                templateKeys.Add("#offerprice#", offer.OfferPrice.ToString());
                templateKeys.Add("#shippingprice#", offer.IsColumnNull(ListingOffersSchema.ShippingPrice.FieldName) ? "0" : offer.ShippingPrice.ToString());
                templateKeys.Add("#total#", offer.TotalPrice.ToString());
                templateKeys.Add("#seller#", seller.FullName);
                templateKeys.Add("#company#", seller.CompanyName);
                templateKeys.Add("#address#", sellerAddress.Address1);
                templateKeys.Add("#city#", sellerAddress.City);
                templateKeys.Add("#state#", sellerAddress.State);
                templateKeys.Add("#country#", sellerAddress.CountryName);
                templateKeys.Add("#email#", seller.Email);
                templateKeys.Add("#phone#", sellerAddress.Phone.ToString());
                templateKeys.Add("#sellerusername#", seller.UserName);
                templateKeys.Add("#email_header#", Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER"));
                templateKeys.Add("#email_footer#", Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER"));

                Web.SendMail(buyer.Email, Web.SystemConfigs.GetKey("ALERTS_EMAIL"), 1005, templateKeys);

                Emails.AddReminder(offer.ListingOfferID, buyer.MemberID, 1005);
            }
        }

    }

    /// <summary>
    /// To: Buyer
    /// </summary>
    public void SendNotofications_1001_REMINDER_MARK_ITEM_RECEIVED()
    {
        List<ListingOffers> listingOffers = Emails.GetListingOffers(1000, 1001, 14);

        foreach (ListingOffers offer in listingOffers)
        {
            var listing = new Listings();
            listing.LoadByPrimaryKey(offer.ListingID);
            if (listing.RowCount > 0) // if listing exists
            {
                var title = Listings.GetTitle(offer.ListingID);

                // getting the buyer is so simple...
                var buyer = new Members();
                buyer.LoadByPrimaryKey(offer.OfferBy);

                // getting the seller is so simple...
                var seller = new Members();
                seller.LoadByPrimaryKey(listing.MemberID);

                //// get buyer Address
                //var buyerAddress = ShippingAddresses.LoadByMemberID(buyer.MemberID);

                // get seller Address
                var sellerAddress = ShippingAddresses.LoadByMemberID(seller.MemberID);

                var templateKeys = new StringDictionary();
                templateKeys.Add("#fullname#", buyer.FullName);
                templateKeys.Add("#item#", title);
                templateKeys.Add("#quantity#", offer.Quantity.ToString());
                templateKeys.Add("#offerprice#", offer.OfferPrice.ToString());
                templateKeys.Add("#shippingprice#", offer.IsColumnNull(ListingOffersSchema.ShippingPrice.FieldName) ? "0" : offer.ShippingPrice.ToString());
                templateKeys.Add("#total#", offer.TotalPrice.ToString());
                templateKeys.Add("#seller#", seller.FullName);
                templateKeys.Add("#company#", seller.CompanyName);
                templateKeys.Add("#address#", sellerAddress.Address1);
                templateKeys.Add("#city#", sellerAddress.City);
                templateKeys.Add("#state#", sellerAddress.State);
                templateKeys.Add("#country#", sellerAddress.CountryName);
                templateKeys.Add("#email#", seller.Email);
                templateKeys.Add("#phone#", sellerAddress.Phone.ToString());
                templateKeys.Add("#sellerusername#", seller.UserName);
                templateKeys.Add("#email_header#", Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER"));
                templateKeys.Add("#email_footer#", Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER"));
                templateKeys.Add("#myactivities_link#", Web.SystemConfigs.GetKey("SITE_URL") + "Marketplace/MyListings.aspx");

                Web.SendMail(buyer.Email, Web.SystemConfigs.GetKey("ALERTS_EMAIL"), 1001, templateKeys);

                Emails.AddReminder(offer.ListingOfferID, buyer.MemberID, 1001);
            }
        }
    }

    /// <summary>
    /// To: Seller
    /// </summary>
    public void SendNotofications_1002_REMINDER_MARK_ITEM_SHIPPED()
    {
        List<ListingOffers> listingOffers = Emails.GetListingOffers(900, 1002, 4);

        foreach (ListingOffers offer in listingOffers)
        {
            var listing = new Listings();
            listing.LoadByPrimaryKey(offer.ListingID);
            if (listing.RowCount > 0) // if listing exists
            {
                var title = Listings.GetTitle(offer.ListingID);

                // getting the buyer is so simple...
                var buyer = new Members();
                buyer.LoadByPrimaryKey(listing.MemberID);

                // getting the seller is so simple...
                var seller = new Members();
                seller.LoadByPrimaryKey(offer.OfferBy);

                //// get buyer Address
                var buyerAddress = ShippingAddresses.LoadByMemberID(buyer.MemberID);

                // get seller Address
                // var sellerAddress = ShippingAddresses.LoadByMemberID(seller.MemberID);

                var templateKeys = new StringDictionary();
                templateKeys.Add("#fullname#", seller.FullName);
                templateKeys.Add("#item#", title);
                templateKeys.Add("#quantity#", offer.Quantity.ToString());
                templateKeys.Add("#offerprice#", offer.OfferPrice.ToString());
                templateKeys.Add("#shippingprice#", offer.IsColumnNull(ListingOffersSchema.ShippingPrice.FieldName) ? "0" : offer.ShippingPrice.ToString());
                templateKeys.Add("#total#", offer.TotalPrice.ToString());
                templateKeys.Add("#buyer#", buyer.FullName);
                templateKeys.Add("#address#", buyerAddress.Address1);
                templateKeys.Add("#city#", buyerAddress.City);
                templateKeys.Add("#state#", buyerAddress.State);
                templateKeys.Add("#country#", buyerAddress.CountryName);
                templateKeys.Add("#email#", buyer.Email);
                templateKeys.Add("#phone#", buyerAddress.Phone.ToString());
                templateKeys.Add("#buyerusername#", buyer.UserName);
                templateKeys.Add("#email_header#", Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER"));
                templateKeys.Add("#email_footer#", Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER"));
                templateKeys.Add("#myactivities_link#", Web.SystemConfigs.GetKey("SITE_URL") + "Marketplace/MyListings.aspx");

                Web.SendMail(seller.Email, Web.SystemConfigs.GetKey("ALERTS_EMAIL"), 1002, templateKeys);

                Emails.AddReminder(offer.ListingOfferID, seller.MemberID, 1002);
            }
        }
    }

    /// <summary>
    /// To: seller
    /// </summary>
    public void SendNotofications_1003_REMINDER_MARK_ITEM_SHIPPED_WARNING()
    {
        List<ListingOffers> listingOffers = Emails.GetListingOffers(900, 1003, 7);

        foreach (ListingOffers offer in listingOffers)
        {
            var listing = new Listings();
            listing.LoadByPrimaryKey(offer.ListingID);
            if (listing.RowCount > 0) // if listing exists
            {
                var title = Listings.GetTitle(offer.ListingID);

                // getting the buyer is so simple...
                var buyer = new Members();
                buyer.LoadByPrimaryKey(offer.OfferBy);

                // getting the seller is so simple...
                var seller = new Members();
                seller.LoadByPrimaryKey(listing.MemberID);

                //// get buyer Address
                var buyerAddress = ShippingAddresses.LoadByMemberID(buyer.MemberID);

                // get seller Address
                //var sellerAddress = ShippingAddresses.LoadByMemberID(seller.MemberID);

                var templateKeys = new StringDictionary();
                templateKeys.Add("#fullname#", seller.FullName);
                templateKeys.Add("#item#", title);
                templateKeys.Add("#quantity#", offer.Quantity.ToString());
                templateKeys.Add("#offerprice#", offer.OfferPrice.ToString());
                templateKeys.Add("#shippingprice#", offer.IsColumnNull(ListingOffersSchema.ShippingPrice.FieldName) ? "0" : offer.ShippingPrice.ToString());
                templateKeys.Add("#total#", offer.TotalPrice.ToString());
                templateKeys.Add("#buyer#", buyer.FullName);
                templateKeys.Add("#address#", buyerAddress.Address1);
                templateKeys.Add("#city#", buyerAddress.City);
                templateKeys.Add("#state#", buyerAddress.State);
                templateKeys.Add("#country#", buyerAddress.CountryName);
                templateKeys.Add("#email#", buyer.Email);
                templateKeys.Add("#phone#", buyerAddress.Phone.ToString());
                templateKeys.Add("#buyerusername#", buyer.UserName);
                templateKeys.Add("#email_header#", Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER"));
                templateKeys.Add("#email_footer#", Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER"));
                templateKeys.Add("#myactivities_link#", Web.SystemConfigs.GetKey("SITE_URL") + "Marketplace/MyListings.aspx");

                Web.SendMail(seller.Email, Web.SystemConfigs.GetKey("ALERTS_EMAIL"), 1003, templateKeys);

                Emails.AddReminder(offer.ListingOfferID, seller.MemberID, 1003);
            }
        }
    }

    /// <summary>
    /// To: Seller
    /// </summary>
    public void SendNotofications_1004_REMINDER_MARK_PAYMENT_RECEIVED()
    {
        List<ListingOffers> listingOffers = Emails.GetListingOffers(200, 1004, 7);

        foreach (ListingOffers offer in listingOffers)
        {
            var listing = new Listings();
            listing.LoadByPrimaryKey(offer.ListingID);
            if (listing.RowCount > 0) // if listing exists
            {
                var title = Listings.GetTitle(offer.ListingID);

                // getting the buyer is so simple...
                var buyer = new Members();
                buyer.LoadByPrimaryKey(offer.OfferBy);

                // getting the seller is so simple...
                var seller = new Members();
                seller.LoadByPrimaryKey(listing.MemberID);

                //// get buyer Address
                var buyerAddress = ShippingAddresses.LoadByMemberID(buyer.MemberID);

                // get seller Address
                // var sellerAddress = ShippingAddresses.LoadByMemberID(seller.MemberID);

                var templateKeys = new StringDictionary();
                templateKeys.Add("#fullname#", seller.FullName);
                templateKeys.Add("#item#", title);
                templateKeys.Add("#quantity#", offer.Quantity.ToString());
                templateKeys.Add("#offerprice#", offer.OfferPrice.ToString());
                templateKeys.Add("#shippingprice#", offer.IsColumnNull(ListingOffersSchema.ShippingPrice.FieldName) ? "0" : offer.ShippingPrice.ToString());
                templateKeys.Add("#total#", offer.TotalPrice.ToString());
                templateKeys.Add("#buyer#", buyer.FullName);
                templateKeys.Add("#address#", buyerAddress.Address1);
                templateKeys.Add("#city#", buyerAddress.City);
                templateKeys.Add("#state#", buyerAddress.State);
                templateKeys.Add("#company#", buyer.CompanyName);
                templateKeys.Add("#country#", buyerAddress.CountryName);
                templateKeys.Add("#email#", buyer.Email);
                templateKeys.Add("#phone#", buyerAddress.Phone.ToString());
                templateKeys.Add("#buyerusername#", buyer.UserName);
                templateKeys.Add("#email_header#", Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER"));
                templateKeys.Add("#email_footer#", Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER"));
                templateKeys.Add("#myactivities_link#", Web.SystemConfigs.GetKey("SITE_URL") + "Marketplace/MyListings.aspx");

                Web.SendMail(seller.Email, Web.SystemConfigs.GetKey("ALERTS_EMAIL"), 1004, templateKeys);

                Emails.AddReminder(offer.ListingOfferID, seller.MemberID, 1004);
            }
        }
    }

    public void SendNewsLetterWeekly()
    {
        DataTable dTableMembers = Members.GetAllMembersWithStatusNotZero();

        DataTable dtableListings = Listings.GetTopTenListings(100);

        string marketPlace = "<table width=500 >";

        foreach (DataRow row in dtableListings.Rows)
        {
            string placeHolder = @"<tr><td width=100 height=100 valign=top>
                                  <a href='" + Web.SystemConfigs.GetKey("SITE_URL") + "marketplace/ItemDetails.aspx?Action=View&RecordID=" + Secure.Encrypt(row["listingid"].ToString()) + "'><img  src='" + (row["ThumbnailURL"].ToString() == "" ? getDefaultImage(Convert.ToInt32(row["ListingTypeID"].ToString())) : row["ThumbnailURL"]) + @"' /></a>
                                    </td><td width=400 valign=top style='color:black;'>                                    
                                    <b><a href='" + Web.SystemConfigs.GetKey("SITE_URL") + "marketplace/ItemDetails.aspx?Action=View&RecordID=" + Secure.Encrypt(row["listingid"].ToString()) + "'> " + row["Title"] + @"</a></b><br />
                                    Quantity: " + row["Quantity"] + @"<br />
                                    Seller: " + row["username"] + @"<br />
                                    </td></tr>
                                    <div style='clear:both;'></div>";
            marketPlace += placeHolder;
        }
        marketPlace += "</table>";

        //var templateKeys = new StringDictionary();
        //templateKeys.Add("#fullname#", "Fawad Ahsan");
        //templateKeys.Add("#market_place#", marketPlace);
        //templateKeys.Add("#email_header#", Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER"));
        //templateKeys.Add("#email_footer#", Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER"));

        //Web.SendMail("fawad@ensx.com", Web.SystemConfigs.GetKey("ALERTS_EMAIL"), 1100, templateKeys);
        //Web.SendMail("fawad.ahsan@gmail.com", Web.SystemConfigs.GetKey("ALERTS_EMAIL"), 1100, templateKeys);
        //Web.SendMail("fawad.ahsan@hotmail.com", Web.SystemConfigs.GetKey("ALERTS_EMAIL"), 1100, templateKeys);

        foreach (DataRow row in dTableMembers.Rows)
        {
            var templateKeys = new StringDictionary();
            templateKeys.Add("#fullname#", row["fullname"].ToString());
            templateKeys.Add("#market_place#", marketPlace);
            templateKeys.Add("#email_header#", Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER"));
            templateKeys.Add("#email_footer#", Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER"));


            Web.SendMail(row["email"].ToString(), Web.SystemConfigs.GetKey("ALERTS_EMAIL"), 1100, templateKeys);
        }

    }

    private static object getDefaultImage(int listingTypeID)
    {
        switch (listingTypeID)
        {
            case 1:
                return "http://images.eopen.com/images/sale.png";
            case 2:
                return "http://images.eopen.com/images/rent.png";
            case 3:
                return "http://images.eopen.com/images/service.png";
            case 4:
                return "http://images.eopen.com/images/jobs.png";
            case 5:
                return "http://images.eopen.com/images/personal.png";
            case 6:
                return "http://images.eopen.com/images/coupon.png";
            case 7:
                return "http://images.eopen.com/images/coupon.png";
            case 8:
                return "http://images.eopen.com/images/logo_50_50.jpg";
            default:
                return "http://images.eopen.com/images/logo_50_50.jpg";
        }
    }


}