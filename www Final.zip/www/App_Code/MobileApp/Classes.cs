﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


namespace Mobile.App
{
    public class Contact
    {
        public string ContactID { get; set; }
        public string Name { get; set; }
        public string Company { get; set; }
        public ContactTypes Type { get; set; }
        public string Thumbnail { get; set; }
        public string Status { get; set; }
    }

    public class Item
    {
        public string ItemID { get; set; }
        public string ItemTitle { get; set; }
        public string ItemDetail { get; set; }
        public string Price { get; set; }
        
        public string PriceEach { get; set; }
        public bool ShowPriceEach { get; set; }
        public bool ShowMakeOfferButton { get; set; }

        public bool IsMyListing { get; set; }        
        public bool isOffer { get; set; }

        public string Thumbnail { get; set; }
        public string Quantity { get; set; }
        public string ItemStatus { get; set; }
        public string ItemCondition { get; set; }
        public string ItemShippingPrice { get; set; }
        public string TotalOffers { get; set; }
        public string lblListingType { get; set; }
        public string SellerName { get; set; }



        public bool ShowQuantity { get; set; }
        public bool ShowPrice { get; set; }
        public string ItemLocation { get; set; }
        public bool ShowLocation { get; set; }

        public string itemWarranty { get; set; }
        public bool ShowWarranty { get; set; }

        public string Address { get; set; }
        public bool ShowAddress { get; set; }

        public bool ShowCondition { get; set; }
        public int ItemDuration { get; set; }

        public DateTime EndDate { get; set; }

        public bool IsPaymentMethod { get; set; }
        public object paymentMethods { get; set; }

        public bool ShowPayment { get; set; }
        public bool ShowShipping { get; set; }

        public string Shipping { get; set; }
        public object ShippingMethods { get; set; }

        public bool IsShippingMethod { get; set; }
        public string Shippinglocation { get; set; }
    }
     
    public class LinkApp 
    {
        public string Status { get; set; }
        public string Description { get; set; }
        public string Title { get; set; }
        public string URL { get; set; }
        public string Thumbnail { get; set; }
    }

    public class Image
    {
        public string Thumbnail { get; set; }
        public string URL { get; set; }
        public string FileName { get; set; }
    }

}