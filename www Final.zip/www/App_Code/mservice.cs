﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.Script.Services;
using CodenameRabbitFoot.BusinessLogic;
using System.Collections.Specialized;
using System.Data;
using System.Xml.Linq;
using System.Text;
using System.Net;
using System.IO;
using Mobile.App;
using System.Xml;

/// <summary>
/// Summary description for mservice
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
[ScriptService]
public class mservice : System.Web.Services.WebService
{
    #region Service Methods

    [WebMethod(Description = "Authenticate the user with login password and return the session id")]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public string Authenticate(string Login, string Password)
    {
        try
        {
            Login = Login.Trim();
            Password = Password.Trim();

            string secureUserEmail = Web.IsEmailAddress(Login) ? Login : "";
            Members member = Members.AuthenticateAll(Login, Password);
            if (member.RowCount > 0)
                return Secure.Encrypt(member.MemberID);
            else
                return "Incorrect Login/Password";
        }
        catch (Exception ex)
        {
            return ex.Message;
        }
    }

    [WebMethod(Description = "Register the user.")]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public static string RegisterUser(string userName, string userEmail, string userCompany, string userFirstName, string userLastname, string userPassword, string userPostalCode, string userCountryID, string invitationID)
    {
        int orignalInvitaionID = 0;

        if (!int.TryParse(invitationID, out orignalInvitaionID))
        {
            try
            {
                orignalInvitaionID = Convert.ToInt32(Secure.Decrypt(invitationID));
            }
            catch { }
        }

        userName = userName.Trim();
        userEmail = userEmail.Trim();
        userCompany = userCompany.Trim();
        userFirstName = userFirstName.Trim();
        userLastname = userLastname.Trim();
        userPostalCode = userPostalCode.Trim();
        userPassword = userPassword.Trim();

        string companyName = userCompany;
        if (companyName.Contains("Leave blank") || companyName == "")
            companyName = userFirstName + " " + userLastname.Substring(0, 1) + " Company";
        string errorMessage;

        try
        {
            Random rand = new Random();
            Members newMember = new Members();


            //check if email exists
            Members member = new Members();
            member.Where.Email.Value = userEmail;
            member.Query.Load();
            if (member.RowCount < 1)
            {
                bool isvalidusername = true;
                //check if username exists
                SystemConfigKeys configs = new SystemConfigKeys();
                configs.Where.ConfigKey.Value = "RESERVE_WORDS";
                configs.Query.Load();
                if (configs.RowCount > 0)
                {
                    string[] values = configs.Value.Split(',');
                    foreach (string str in values)
                        if (userName == str)
                            isvalidusername = false;
                }
                if (isvalidusername)
                {
                    member = new Members();
                    member.Where.UserName.Value = userName;
                    member.Query.Load();
                    if (member.RowCount < 1)
                    {
                        newMember.AddNew();
                        newMember.Email = userEmail;
                        newMember.CompanyName = userCompany;
                        newMember.FullName = userFirstName + " " + userLastname;
                        newMember.UserName = userName;
                        newMember.Password = userPassword;
                        //newMember.Password = rand.Next(9999).ToString(); //txtPass.Text; 
                        newMember.RequestsToAddContacts = 0;
                        newMember.IsDealerProfileUpdate = 0;

                        //if (string.IsNullOrEmpty(invitationID) || invitationID == "null")
                        if (orignalInvitaionID <= 0)
                        {
                            newMember.MemberStatusID = 102;
                            newMember.RegistrationCode = Web.CalculateRegCode();
                        }
                        else
                        {
                            newMember.MemberStatusID = 200;
                        }

                        newMember.LastProfileUpdate = DateTime.Today;
                        newMember.Save();
                        Web.WriteMemberStatusChangeLog(newMember.MemberID, newMember.MemberStatusID, "System");
                        Web.SessionMembers = newMember;
                        Web.AddActivityLog(1, new StringDictionary()); // ActivityID=1 for joined
                        Web.IsMemberSession = true;
                        ShippingAddresses address = new ShippingAddresses();
                        address.Where.MemberID.Value = newMember.MemberID;
                        address.Query.Load();
                        if (address.RowCount <= 0)
                            address.AddNew();

                        address.City = "";//txtCity.Text;
                        address.State = "";//txtState.Text;
                        address.Zip = userPostalCode;
                        address.s_CountryID = userCountryID;
                        address.MemberID = newMember.MemberID;
                        address.Save();

                        //if (!(string.IsNullOrEmpty(invitationID) || invitationID == "null"))
                        if (orignalInvitaionID > 0)
                        {
                            Contacts.AddToContact(newMember.MemberID, orignalInvitaionID);
                        }


                        //txtEmailActivate.Text = newMember.Email;
                        if (newMember.s_MemberID != null)
                        {

                            try
                            {
                                if (newMember.MemberStatusID != 200)// No verification email in case of coupons :)
                                {
                                    StringDictionary templateKeysVerify = new StringDictionary();
                                    templateKeysVerify.Add("#email_header#", Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER"));
                                    templateKeysVerify.Add("#fullname#", (!String.IsNullOrEmpty(newMember.FullName)) ? newMember.FullName : newMember.Email);
                                    templateKeysVerify.Add("#email_address#", newMember.Email);
                                    templateKeysVerify.Add("#activation_link#", Web.SystemConfigs.GetKey("SITE_URL") + "Account/Verify.aspx?rand=" + rand.Next() + "&Action=Activate&code=" + newMember.RegistrationCode + "&RecordID=" + Secure.Encrypt(newMember.s_MemberID) + "&sid=" + newMember.SurrogateID);
                                    templateKeysVerify.Add("#code#", newMember.RegistrationCode);
                                    templateKeysVerify.Add("#link#", Web.SystemConfigs.GetKey("SITE_URL") + "Account/Verify.aspx?Action=Activate&RecordID=" + Secure.Encrypt(newMember.s_MemberID) + "&sid=" + newMember.SurrogateID);
                                    templateKeysVerify.Add("#site_url#", Web.SystemConfigs.GetKey("SITE_URL"));
                                    templateKeysVerify.Add("#email_footer#", Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER"));

                                    Web.SendMail(newMember.Email, Web.SystemConfigs.GetKey("REG_EMAIL"), 002, templateKeysVerify);
                                }

                                StringDictionary templateKeysWelcome = new StringDictionary();
                                templateKeysWelcome.Add("#email_header#", Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER"));
                                templateKeysWelcome.Add("#fullname#", (!String.IsNullOrEmpty(newMember.FullName)) ? newMember.FullName : newMember.Email);
                                templateKeysWelcome.Add("#email_footer#", Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER"));
                                templateKeysWelcome.Add("#password#", newMember.Password);
                                templateKeysWelcome.Add("#link_log_myeoffer#", Web.SystemConfigs.GetKey("SITE_URL") + "Post.aspx?Action=worldwide");
                                Web.SendMail(newMember.Email, Web.SystemConfigs.GetKey("REG_EMAIL"), 008, templateKeysWelcome);
                            }
                            catch (Exception ex)
                            {
                                Web.LogError(ex);
                            }
                        }
                        else
                        {
                            errorMessage = "Please try again.";
                            return "ERROR`" + errorMessage;
                        }
                    }
                    else
                    {
                        //this.Master.ShowMessage("Username already exists.", "simpleerr"); 
                        errorMessage = "Username already exists.";
                        return "ERROR`" + errorMessage;
                    }
                }
                else
                {
                    errorMessage = "Username is invalid.";
                    return "ERROR`" + errorMessage;
                }
            }
            else
            {
                return "ERROR`Email Address is already registered";

            }
        }
        catch (Exception exp)
        {
            Web.LogError(exp);

            return "ERROR";
        }

        return "success";
    }

    [WebMethod(Description = "Get the Marketplace.")]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public List<Item> GetMarketPlace(int pageIndex, int pageSize)
    {
        string memberID = "0";
        int ListingTypeID = -1, CategoryID = -1;
        List<Item> itemCollection = new List<Item>();
        memberID = Secure.Decrypt(memberID);
        IEnumerable<DataRow> allRows = Listings.FilterListings(ListingTypeID, CategoryID, -1, "", "-1", -1, 0, Convert.ToInt32(memberID)).AsEnumerable();
        IEnumerable<DataRow> dataRows = allRows.Skip((pageIndex - 1) * pageSize).Take(pageSize);

        foreach (DataRow item in dataRows)
        {
            Item newItem = new Item();
            newItem.ItemID = Secure.Encrypt(item["ListingID"]);
            newItem.Quantity = item["Quantity"].ToString();
            newItem.Thumbnail = item["ThumbnailURL"].ToString() == "" ? getDefaultImage(Convert.ToInt32(item["ListingTypeID"].ToString())).ToString() : item["ThumbnailURL"].ToString();
            newItem.ItemTitle = Utils.GetReducedString(item["Title"].ToString(), 35);
            //newItem.ItemStatus = item["StatusName"].ToString();
            newItem.ItemDetail = "";
            string priceText = "";
            try
            {
                if (!string.IsNullOrEmpty(item.ItemArray[10].ToString()))
                    priceText = "$" + item.ItemArray[10].ToString() + " per listing";

                if (!string.IsNullOrEmpty(item.ItemArray[4].ToString()))
                {
                    var listingData = from d in XDocument.Parse("<listings>" + item.ItemArray[4].ToString() + "</listings>").Root.Descendants()
                                      select new
                                      {
                                          FieldID = d.Attribute("FieldID").Value,
                                          FieldName = d.Attribute("FieldName").Value,
                                          Data = d.Attribute("Data") == null ? "" : d.Attribute("Data").Value
                                      };

                    if (listingData.Count() > 0)
                    {
                        bool isOffer = false;

                        foreach (var i in listingData)
                        {
                            if (i.FieldName.Equals("MakeOffer") && Convert.ToBoolean(i.Data))
                            {
                                priceText = "Make an Offer";
                                isOffer = true;
                            }
                            else
                            {
                                if (i.FieldName.Equals("PriceEach") && !isOffer)
                                {
                                    try
                                    {
                                        double priceeach = Convert.ToDouble(i.Data);
                                        if (priceeach == 0)
                                            priceText = "Make an Offer";
                                        else
                                            priceText = "$" + i.Data + " per Item";
                                    }
                                    catch { priceText = ""; }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            newItem.Price = priceText;
            itemCollection.Add(newItem);
        }

        //return "Kadu";
        return itemCollection;
    }

    [WebMethod(Description = "Get the Item Details.")]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public Item GetItemDetails(string memberID, int ItemID)
    {
        return getItemDetails(ItemID, Convert.ToInt32(Secure.Decrypt(memberID)));
    }
     
    [WebMethod(Description = "Get the Item Images.")]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public List<Image> GetItemImages(int ItemID)
    {
        DataTable dt = SystemObjectFiles.GetFiles(600, 5, ItemID);
        List<Image> imgList = new List<Image>();
        foreach (DataRow row in dt.Rows)
        {
            Image img = new Image();
            img.FileName = row["FileName"].ToString();
            img.Thumbnail = row["ThumbnailURL"].ToString();
            img.URL = row["URL"].ToString();

            imgList.Add(img);
        }

        dt.Dispose();
        dt = null;

        return imgList;
    }

    [WebMethod(Description = "Get the LinkApps.")]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public List<LinkApp> GetLinkAppBoard(int pageIndex, int pageSize)
    {
        string type = "warehouse";
        int categoryid = -1;
        string searchcriteria = "";

        List<LinkApp> linkAppsCollection = new List<LinkApp>();

        DataTable dTable = null;

        if (type == "warehouse")
        {
            //if (searchcriteria != "")
            //    dTable = ApplianceStore.SearchApplianceStore(searchcriteria);
            //else if (categoryid == -1)
            //    dTable = ApplianceStore.GetApplianceStoreByStatusAndMember(300, Web.SessionMembers.MemberID);
            //else
            dTable = ApplianceStore.GetTopApplianceStores().Tables[0];//.GetApplianceStoreMostVisitedByCategory(categoryid);

        }
        //else if (type == "MySiteLinkApps")
        //{
        //    if (searchcriteria != "")
        //        dTable = ApplianceStore.SearchApplianceStore(searchcriteria);
        //    else if (categoryid == -1)
        //        dTable = ApplianceStore.GetApplianceStore(Web.SessionMembers.MemberID);
        //    else
        //        dTable = ApplianceStore.SearchApplianceStoreByCategory(categoryid); 
        //}
        //else if (type == "JustAddedAll")
        //{
        //    if (searchcriteria != "")
        //        dTable = ApplianceStore.SearchApplianceStore(searchcriteria);
        //    else if (categoryid == -1)
        //        dTable = ApplianceStore.GetAllApplianceStore();
        //    else
        //        dTable = ApplianceStore.SearchApplianceStoreByCategory(categoryid); 
        //}
        //else if (type == "FeaturedStore")
        //{
        //    dTable = ApplianceStore.GetApplianceStoreFeatured(); 
        //}
        //else if (type == "JustAdded")
        //{
        //    if (categoryid == -1)
        //        dTable = ApplianceStore.GetApplianceStoreJustAddedByStatus(300);
        //    else
        //        dTable = ApplianceStore.GetApplianceStoreMostVisitedByCategory(categoryid); 
        //}
        //else if (type == "MostVisited")
        //{
        //    if (categoryid == -1)
        //        dTable = ApplianceStore.GetApplianceStoreMostVisited();
        //    else
        //        dTable = ApplianceStore.GetApplianceStoreMostVisitedByCategory(categoryid); 
        //}

        IEnumerable<DataRow> allRows = dTable.Select();
        IEnumerable<DataRow> dataRows = allRows.Skip((pageIndex - 1) * pageSize).Take(pageSize);

        foreach (DataRow row in dataRows)
        {
            LinkApp liknApp = new LinkApp();
            liknApp.Title = row["ApplianceName"].ToString();
            liknApp.Thumbnail = "http://beta.eopen.com/ePage/ImageViewer.ashx?Action=ApplianceStoreLogo&RecordID=" + row["ApplianceStoreID"].ToString();
            //liknApp.Status = row["ApplianceStatus"].ToString();
            liknApp.Description = row["Description"].ToString();
            liknApp.URL = row["URL"].ToString();
            linkAppsCollection.Add(liknApp);
        }
        return linkAppsCollection;
    }

    //[Done]
    [WebMethod(Description = "Get the Vendors.")]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public List<Contact> GetVendors(int pageIndex, int pageSize, string memberID)
    {
        string filter = "";
        int memberid = Convert.ToInt32(Secure.Decrypt(memberID));
        return LoadContacts(memberid, "vendors", pageIndex, pageSize, filter);
    }

    [WebMethod(Description = "Get the Clients.")]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public List<Contact> GetClients(int pageIndex, int pageSize, string memberID)
    {
        string filter = "";
        int memberid = Convert.ToInt32(Secure.Decrypt(memberID));
        return LoadContacts(memberid, "clients", pageIndex, pageSize, filter);
    }

    [WebMethod(Description = "Get the Clients Count.")]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public int GetClientsCount(string memberID)
    {
        return Contacts.GetMyContacts(Convert.ToInt32(Secure.Decrypt(memberID)), ContactTypes.Client, ContactView.AllContacts).Select().Count();
    }

    [WebMethod(Description = "Get the Clients Count.")]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public int GetVendorsCount(string memberID)
    {
        return Contacts.GetMyContacts(Convert.ToInt32(Secure.Decrypt(memberID)), ContactTypes.Vendor, ContactView.AllContacts).Select().Count();
    }

    [WebMethod(EnableSession = true)]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public List<FeedItem> LoadFeedItems(int numberItemsToSkip, int numberOfItemsToTake)
    {
        List<FeedItem> items = new List<FeedItem>();
        try
        {
            int counter = 0;
            int feedItemSequenceNumber = 0;
            var feedItems = Contacts.LoadFeedItems(numberItemsToSkip, numberOfItemsToTake, Web.IsMemberSession ? Web.SessionMembers.MemberID : 0);

            if (feedItems != null)
            {
                feedItemSequenceNumber = 1;
                foreach (DataRow row in feedItems.Rows)
                {
                    FeedItem item = new FeedItem();
                    item.Id = feedItemSequenceNumber.ToString();
                    item.EncryptedItemId = Secure.Encrypt(row["ActivityLogID"].ToString());
                    item.MemberId = row["MemberID"].ToString();
                    item.UserName = row["UserName"].ToString();
                    if (Web.IsMemberSession)
                    {
                        item.UserName = item.MemberId.Equals(Web.SessionMembers.MemberID.ToString()) ? "You" : row["UserName"].ToString();
                    }
                    item.Title = HttpContext.Current.Server.HtmlEncode(row["Title"].ToString());
                    item.Date = Convert.ToDateTime(row["ActivityDate"]).ToUniversalTime().ToString();// Convert.ToDateTime(row["ActivityDate"]).Subtract(new DateTime(1970, 1, 1)).Ticks.ToString();
                    item.Description = row["Description"].ToString();
                    item.ShowLinkUnlink = row["ShowLinkUnlink"].ToString();
                    string xmlData = row["Files"].ToString();
                    if (!string.IsNullOrWhiteSpace(xmlData))
                    {
                        XDocument xDocument = XDocument.Parse(xmlData);
                        counter = 1;
                        foreach (var element in xDocument.Root.Descendants())
                        {
                            FeedItem.Files file = new FeedItem.Files();
                            file.Id = counter.ToString();
                            file.EncryptedFileId = Secure.Encrypt(element.Attribute("SystemObjectFileID").Value);
                            file.FileName = element.Attribute("FileName").Value;
                            file.Type = Web.GetFileType(element.Attribute("Type").Value.ToLower().Trim(), file.FileName);
                            file.Url = element.Attribute("Url").Value;
                            file.Thumbnail = element.Attribute("ThumbnailUrl").Value;
                            item.files.Add(file);
                            counter++;
                        }
                    }

                    // Fetch comments
                    xmlData = row["ActivityComments"].ToString();
                    if (!string.IsNullOrWhiteSpace(xmlData))
                    {
                        XDocument xDocument = XDocument.Parse(xmlData);
                        counter = 1;
                        foreach (var element in xDocument.Root.Descendants())
                        {
                            Comments comment = new Comments();
                            comment.Id = counter.ToString();
                            comment.EncryptedCommentId = Secure.Encrypt(element.Attribute("ActivityLogCommentsID").Value);
                            comment.Description = element.Attribute("Comments").Value;
                            comment.Date = Convert.ToDateTime(element.Attribute("CommentsDate").Value).ToUniversalTime().ToString();// Convert.ToDateTime(element.Attribute("CommentsDate").Value).Subtract(new DateTime(1970, 1, 1)).TotalMilliseconds.ToString();
                            comment.CommentBy = element.Attribute("CommentsBy").Value;
                            comment.UserName = element.Attribute("UserName").Value;
                            if (Web.IsMemberSession)
                                comment.UserName = comment.CommentBy.Equals(Web.SessionMembers.MemberID.ToString()) ? "You" : element.Attribute("UserName").Value;
                            item.comments.Add(comment);
                            counter++;
                        }
                    }
                    items.Add(item);
                    feedItemSequenceNumber++;
                }
            }
        }
        catch (Exception exp)
        {
            Web.LogError(exp);
        }
        return items;
    }

    [WebMethod(EnableSession = true)]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public string PostToTheWorld(string memberID, string postText, string postTypeID, string categoryID, string repositryKey, List<string> files)
    {
        int _memberID = Convert.ToInt32(Secure.Decrypt(memberID));

        try
        {
            string activityTitle = "posted ";

            if (postTypeID.Equals("7"))
                activityTitle += "from mobile";
            else if (postTypeID.Equals("8"))
                activityTitle += "from chrome extension";

            //else if (postTypeID.Equals("3"))
            //{
            //    activityTitle += "Event";
            //}

            //insert this activity in MemeberActivityLog table
            Members m = new Members();
            m.LoadByPrimaryKey(_memberID);

            MemberActivityLog log = new MemberActivityLog();
            log.AddNew();
            log.ActivityID = 45;
            log.MemberID = _memberID;
            log.ActivityDate = DateTime.Now;
            log.IsActive = 1;
            log.IsPrivate = 0;
            log.Description = activityTitle;
            log.s_PostTypeID = postTypeID;
            log.s_CategoryID = categoryID;
            log.PrivacyTypeID = 1;
            log.s_IsPosting = "1";
            log.Save();

            var fields = new PostingExtendedFields();
            fields.AddNew();
            fields.Data = Web.GetCleanHTML(postText);
            fields.FieldID = 3;
            fields.EntryTime = DateTime.Now;
            fields.IsActive = 1;

            fields.ObjectID = log.ActivityLogID;
            fields.SystemObjectID = (int)SystemObjects.Posts;
            fields.Save();

            foreach (var file in files)
            {
                string localFilename = Path.Combine(Web.ConfigVariables.UserTempFiles, Path.GetFileName(file));

                using (WebClient client = new WebClient())
                    client.DownloadFile(file, localFilename);

                RepositryManager.AddFileToRepositry(repositryKey, localFilename);
            }

            Web.SaveFiles(_memberID, (int)SystemObjects.Posts, log.ActivityLogID, repositryKey);

        }
        catch (Exception ex)
        {
            Web.LogError(ex);
            return ex.Message;
        }
        return "success";
    }

    [WebMethod(EnableSession = true)]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public static IEnumerable<FeedItem> LoadFeedItems(int numberItemsToSkip, int numberOfItemsToTake,string memberID)
    {
        int intMemberID = string.IsNullOrEmpty(memberID) ? 0 : Convert.ToInt32(Secure.Decrypt(memberID));
        List<FeedItem> items = new List<FeedItem>();
        try
        {
            int counter = 0;
            int feedItemSequenceNumber = 0;
            var resultSet = Fx.ExecuteDataSet("EN_LoadFeed", numberItemsToSkip, numberOfItemsToTake, intMemberID, 0, "ALL");

            if (resultSet == null)
                return items;

            var feedItems = resultSet.Tables[0];
            feedItemSequenceNumber = 1;

            foreach (DataRow row in feedItems.Rows)
            {
                FeedItem item = new FeedItem();
                item.Id = feedItemSequenceNumber.ToString();
                item.EncryptedItemId = Secure.Encrypt(row["ActivityLogID"].ToString());
                item.MemberId = row["MemberID"].ToString();
                item.UserName = row["UserName"].ToString();
                item.UserName = row["UserName"].ToString().Equals(intMemberID.ToString()) ? "You" : row["UserName"].ToString();
                item.IsPosting = row["IsPosting"].ToString();
                item.Title = HttpContext.Current.Server.HtmlEncode(row["Title"].ToString());
                if (item.IsPosting.Equals("0"))
                {
                    var titleParts = item.Title.Split('|');
                    if (titleParts.Count() > 1)
                    {
                        item.Title = titleParts[0];
                        item.ListingTypeName = titleParts[1];
                    }
                }

                item.Date = Convert.ToDateTime(row["ActivityDate"]).ToUniversalTime().ToString();// Convert.ToDateTime(row["ActivityDate"]).Subtract(new DateTime(1970, 1, 1)).Ticks.ToString();
                item.Description = row["Description"].ToString();
                item.ShowLinkUnlink = row["ShowLinkUnlink"].ToString();
                item.ObjectId = row["ObjectID"].ToString();
                if (!item.ObjectId.Equals("0"))
                    item.ObjectId = Secure.Encrypt(item.ObjectId);// Listing ID etc.

                string xmlData = row["Files"].ToString();
                if (!string.IsNullOrWhiteSpace(xmlData))
                {
                    XDocument xDocument = XDocument.Parse(xmlData);
                    counter = 1;
                    foreach (var element in xDocument.Root.Descendants())
                    {
                        FeedItem.Files file = new FeedItem.Files();
                        file.Id = counter.ToString();
                        file.EncryptedFileId = Secure.Encrypt(element.Attribute("SystemObjectFileID").Value);
                        file.FileName = element.Attribute("FileName").Value;
                        file.Type = Web.GetFileType(element.Attribute("Type").Value.ToLower().Trim(), file.FileName);
                        file.Url = element.Attribute("Url").Value;
                        file.Thumbnail = element.Attribute("ThumbnailUrl").Value;
                        item.files.Add(file);
                        counter++;
                    }
                }

                // Fetch comments
                xmlData = row["ActivityComments"].ToString();
                if (!string.IsNullOrWhiteSpace(xmlData))
                {
                    XDocument xDocument = XDocument.Parse(xmlData);
                    counter = 1;
                    foreach (var element in xDocument.Root.Descendants())
                    {
                        Comments comment = new Comments();
                        comment.Id = counter.ToString();
                        comment.EncryptedCommentId = Secure.Encrypt(element.Attribute("ActivityLogCommentsID").Value);
                        comment.Description = element.Attribute("Comments").Value;
                        comment.Date = Convert.ToDateTime(element.Attribute("CommentsDate").Value).ToUniversalTime().ToString();// Convert.ToDateTime(element.Attribute("CommentsDate").Value).Subtract(new DateTime(1970, 1, 1)).TotalMilliseconds.ToString();
                        comment.CommentBy = element.Attribute("CommentsBy").Value;
                        comment.UserName = element.Attribute("UserName").Value;
                        // Item owner can delete every comment. Comment owner can delete his own comments only.
                        comment.AllowDelete = intMemberID.ToString().Equals(item.MemberId) || intMemberID.ToString().Equals(comment.CommentBy);
                        comment.UserName = comment.CommentBy.Equals(intMemberID.ToString()) ? "You" : element.Attribute("UserName").Value;
                        item.comments.Add(comment);
                        counter++;
                    }
                }
                items.Add(item);
                feedItemSequenceNumber++;
            }
        }
        catch (Exception exp)
        {
            Web.LogError(exp);
        }
        return items;
    }

    [WebMethod(EnableSession = true)]
    public static string DeleteItem(string id, string type)
    {
        try
        {
            type = type.ToLower().Trim();
            int decryptedID = Convert.ToInt32(Secure.Decrypt(id));
 
            if (type.Equals("feed"))
                DeleteFeedItem(decryptedID);
            else if (type.Equals("comment"))
                DeleteComment(decryptedID);
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
            return "failed";
        }

        return "success";
    }

    [WebMethod(EnableSession = true)]
    public static string ToggleLinkUnlinkStatus(string id, string type,string memberID)
    {
        try
        {
            int intMemberID = Convert.ToInt32(Secure.Decrypt(memberID));
            type = type.ToLower().Trim();
            int decryptedID = Convert.ToInt32(Secure.Decrypt(id));
            Fx.ExecuteSp("EN_ToggleLinkUnlinkStatus", id, intMemberID, type);
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
            return "failed";
        }
        return "success";
    }

    [WebMethod]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public static Comments AddComment(string itemId, string comment, string memberID)
    {
        Comments feedItemComment = new Comments();
        try
        {
            int intMemberID = Convert.ToInt32(Secure.Decrypt(memberID));
            feedItemComment.Id = "_" + Guid.NewGuid().ToString().Replace("-", "");
            feedItemComment.Description = Web.ConvertToTinyURL(HttpContext.Current.Server.UrlDecode(comment));
            feedItemComment.Date = DateTime.Now.AddSeconds(10).ToUniversalTime().ToString();
            feedItemComment.CommentBy = Web.SessionMembers.MemberID.ToString();
            feedItemComment.UserName = "You";
            int activityLogID = Convert.ToInt32(Secure.Decrypt(itemId));
            var result = Fx.ExecuteSp("EN_AddMemberActivityLogComment", activityLogID, intMemberID, feedItemComment.Description, DateTime.Now);
            feedItemComment.EncryptedCommentId = Secure.Encrypt(result.Tables[0].Rows[0][0]); 
        }
        catch (Exception exp)
        {
            Web.LogError(exp);
        }

        return feedItemComment;
    }

    #endregion

    #region Private Methods

    private static List<Contact> LoadContacts(int memberID, string contactType, int pageIndex, int pageSize, string filter)
    {
        List<Contact> contactCollection = new List<Contact>();
        ContactTypes type = contactType == "clients" ? ContactTypes.Client : ContactTypes.Vendor;

        filter = filter.ToLower();
        ContactView contactTypeFilter = ContactView.AllContacts;

        if (filter.Equals("approved"))
        {
            contactTypeFilter = ContactView.ApprovedContacts;
        }
        else
            if (filter.Equals("pending my approval"))
            {
                contactTypeFilter = ContactView.PendingMyApproval;
            }
            else
                if (filter.Equals("need to approve me"))
                {
                    contactTypeFilter = ContactView.NeedToApproveMe;
                }
                else
                    if (filter.Equals("profile inactive"))
                    {
                        // ToDo : suggestion
                    }

        IEnumerable<DataRow> allRows = Contacts.GetMyContacts(memberID, type, contactTypeFilter).Select();
        IEnumerable<DataRow> dataRows = allRows.Skip((pageIndex - 1) * pageSize).Take(pageSize);

        foreach (DataRow member in dataRows)
        {
            Contact contact = new Contact();
            contact.Company = member["CompanyName"].ToString();
            contact.ContactID = member["ContactMemberID"].ToString();
            contact.Name = member["FullName"].ToString();
            contact.Thumbnail = "http://beta.eopen.com/ePage/ImageViewer.ashx?Action=MembersLogoThumbnail&RecordID=" + contact.ContactID;
            //contact.Status = member["StatusDescription"].ToString();
            contact.Type = type;
            contactCollection.Add(contact);
        }
        return contactCollection;
    }

    private static string GetMemberCompanyName(object companyName)
    {
        try
        {
            if (!companyName.ToString().Trim().ToLower().Contains("leave blank if you do not have"))
            {
                return companyName.ToString();
            }
        }
        catch
        {
        }
        return string.Empty;

    }

    private static object getDefaultImage(int listingTypeID)
    {
        switch (listingTypeID)
        {
            case 1:
                return "../App_Themes/Space/Images/eOpen post_tp_world Icons/sale_50_x_50.png";
            case 2:
                return "../App_Themes/Space/Images/eOpen post_tp_world Icons/rent_50_x_50.png";
            case 3:
                return "../App_Themes/Space/Images/eOpen post_tp_world Icons/service_50_x_50.png";
            case 4:
                return "../App_Themes/Space/Images/eOpen post_tp_world Icons/jobs_50_x_50.png";
            case 5:
                return "../App_Themes/Space/Images/eOpen post_tp_world Icons/personal_50_x_50.png";
            case 6:
                return "../App_Themes/Space/Images/eOpen post_tp_world Icons/coupon_50_x_50.png";
            case 7:
                return "../App_Themes/Space/Images/eOpen post_tp_world Icons/coupon_50_x_50.png";
            case 8:
                return "/Images/noimage.png";
            default:
                return "/Images/noimage.png";
        }
    }

    protected Item getItemDetails(int ListingID, int MemberID)
    {
        DataTable result = new DataTable();
        var xdoc = new XmlDocument();
        string xml = null;
        XmlNodeList _nodelist;

        Item item = new Item();

        try
        {
            if (ListingID > 0)
            {
                Listings listing = new CodenameRabbitFoot.BusinessLogic.Listings();
                listing.LoadByPrimaryKey(ListingID);

                item.ItemID = ListingID.ToString();

                if (listing.ListingTypeID == 2 || listing.ListingTypeID == 3 || listing.ListingTypeID == 4 || listing.ListingTypeID == 5 || listing.ListingTypeID == 6)
                {
                    item.ItemCondition = "n/a";
                    item.ItemShippingPrice = "n/a";
                }

                if (listing.RowCount == 0)
                    throw new Exception("Invalid Listings");
                else
                {
                    if (listing.MemberID == MemberID)
                        item.IsMyListing = true;

                    if (!Web.HasPlacedOffer(ListingID, MemberID))
                        item.ShowMakeOfferButton = true;
                    else
                        item.ShowMakeOfferButton = false;

                    ListingTypes types = new ListingTypes();
                    types.LoadByPrimaryKey(listing.ListingTypeID);
                    item.lblListingType = types.ListingTypeName;

                    List<int> categoryFields = CategoryFields.GetCategoryFields(listing.ListingTypeID, listing.CategoryID);

                    //show seller name (can use other seller/member info on page as needed)
                    Members member = new Members();
                    member.LoadByPrimaryKey(Convert.ToInt32(MemberID));
                    if (member.RowCount > 0)
                        item.SellerName = member.UserName;

                    result = Listings.GetListingDetails(ListingID);
                    foreach (DataRow row in result.Rows)
                    {
                        if (!String.IsNullOrEmpty(row["ThumbnailURL"].ToString()))
                        {
                            item.Thumbnail = row["ThumbnailURL"].ToString();
                        }
                        else
                        {
                            switch (listing.ListingTypeID)
                            {
                                case 1:
                                    item.Thumbnail = "http://beta.eopen.com/App_Themes/Space/Images/eOpen post_tp_world Icons/sale.png";
                                    break;
                                case 2:
                                    item.Thumbnail = "http://beta.eopen.com/App_Themes/Space/Images/eOpen post_tp_world Icons/rent.png";
                                    break;
                                case 3:
                                    item.Thumbnail = "http://beta.eopen.com/App_Themes/Space/Images/eOpen post_tp_world Icons/service.png";
                                    break;
                                case 4:
                                    item.Thumbnail = "http://beta.eopen.com/App_Themes/Space/Images/eOpen post_tp_world Icons/jobs.png";
                                    break;
                                case 5:
                                    item.Thumbnail = "http://beta.eopen.com/App_Themes/Space/Images/eOpen post_tp_world Icons/personal.png";
                                    break;
                                case 6:
                                    item.Thumbnail = "http://beta.eopen.com/App_Themes/Space/Images/eOpen post_tp_world Icons/coupon.png";
                                    break;
                                case 7:
                                    item.Thumbnail = "http://beta.eopen.com/App_Themes/Space/Images/eOpen post_tp_world Icons/coupon.png";
                                    break;
                                case 8:
                                    item.Thumbnail = "http://beta.eopen.com/Images/noimage.png";
                                    break;
                                default:
                                    item.Thumbnail = "http://beta.eopen.com/Images/noimage.png";
                                    break;
                            }
                        }
                        xml = row["ListingData"].ToString();

                        if (!String.IsNullOrEmpty(xml))
                        {
                            var listingData = from d in XDocument.Parse("<listings>" + xml + "</listings>").Root.Descendants()
                                              select new
                                              {
                                                  FieldID = d.Attribute("FieldID").Value,
                                                  FieldName = d.Attribute("FieldName").Value,
                                                  Data = d.Attribute("Data") == null ? "" : d.Attribute("Data").Value
                                              };
                            if (listingData.Count() > 0)
                            {
                                bool isOffer = false;
                                foreach (var listingitem in listingData)
                                {
                                    if (listingitem.FieldName.Equals("MakeOffer"))
                                    {
                                        if (Convert.ToBoolean(listingitem.Data))
                                        {
                                            item.PriceEach = "Make an Offer";
                                            item.Price = "Make an Offer";
                                            item.ShowPriceEach = true;
                                            item.isOffer = true;
                                        }
                                    }
                                    else
                                        if (listingitem.FieldName.Equals("Title"))
                                        {
                                            item.ItemTitle = listingitem.Data;
                                            continue;
                                        }
                                        else if (listingitem.FieldName.Equals("Description"))
                                        {
                                            item.ItemDetail = listingitem.Data;
                                            continue;
                                        }

                                        else if (listingitem.FieldName.Equals("Quantity"))
                                        {
                                            item.Quantity = listingitem.Data;
                                            item.ShowQuantity = (!String.IsNullOrEmpty(item.Quantity)) ? true : false;
                                            continue;
                                        }
                                        else if (listingitem.FieldName.Equals("Price"))
                                        {
                                            if (string.IsNullOrEmpty(listingitem.Data) || listingitem.Data.Equals("0"))
                                            {
                                                item.Price = "Make an Offer";
                                            }
                                            else
                                                item.Price += "$" + listingitem.Data + "<br/>";

                                            item.ShowPrice = (!String.IsNullOrEmpty(item.Price)) ? true : false;
                                            continue;
                                        }
                                        else if (listingitem.FieldName.Equals("PriceEach") && !isOffer)
                                        {
                                            string s_price = listingitem.Data.ToLower();
                                            try
                                            {
                                                double priceeach = Convert.ToDouble(s_price);
                                                item.PriceEach = "$" + s_price + " per Item";
                                                item.ShowPriceEach = true;
                                            }
                                            catch
                                            {
                                                item.PriceEach = "";
                                                item.ShowPriceEach = false;
                                            }
                                            continue;
                                        }
                                        else if (listingitem.FieldName.Equals("Location"))
                                        {
                                            item.ItemLocation += listingitem.Data;
                                            item.ShowLocation = true;

                                        }
                                        else if (listingitem.FieldName.Equals("Warranty"))
                                        {
                                            item.itemWarranty += listingitem.Data + " days";
                                            item.ShowWarranty = true;
                                        }
                                        else if (listingitem.FieldName.Equals("Address"))
                                        {
                                            item.Address = listingitem.Data;
                                            item.ShowAddress = true;
                                        }
                                }
                            }
                        }

                        if (categoryFields.Contains(14))
                        {
                            if (!String.IsNullOrEmpty(row["Condition"].ToString()))
                            {
                                item.ItemCondition = row["Condition"].ToString();
                                item.ShowCondition = true;
                            }
                            else
                                item.ShowCondition = false;
                        }
                        else
                            item.ShowCondition = false;

                        if (!String.IsNullOrEmpty(row["ListingEndDate"].ToString()))
                        {
                            item.ItemDuration = Convert.ToDateTime(row["ListingEndDate"].ToString()).Subtract(DateTime.Now).Days;
                            item.EndDate = Convert.ToDateTime(row["ListingEndDate"].ToString());
                        }


                        if (categoryFields.Contains(13))
                        {
                            if (!String.IsNullOrEmpty(row["PaymentMethods"].ToString()))
                            {
                                xml = row["PaymentMethods"].ToString();
                                xdoc.LoadXml("<Payments>" + xml + "</Payments>");
                                _nodelist = xdoc.SelectNodes("Payments/PaymentMethods");
                                if (_nodelist.Count > 0)
                                {
                                    foreach (XmlNode node in _nodelist)
                                    {
                                        if (node.Attributes.Item(0).Value != null)
                                        {
                                            item.IsPaymentMethod = true;
                                            item.paymentMethods += (item.paymentMethods == "" ? "" : ", ") + node.Attributes.Item(0).Value.Trim();
                                        }
                                        else
                                            item.paymentMethods = "n/a";
                                    }
                                    item.ShowPayment = true;
                                }
                            }
                            else
                                item.ShowPayment = false;
                        }
                        else
                            item.ShowPayment = false;

                        if (categoryFields.Contains(12))
                        {
                            item.ShowShipping = false;
                            if (!String.IsNullOrEmpty(listing.s_ShippingFee))
                            {
                                item.ShowShipping = true;
                                item.Shipping = "$" + listing.ShippingFee + Web.GetListingPriceUnit(listing.s_ShippingFeeUnit);
                            }

                            if (!String.IsNullOrEmpty(row["ShippingMethods"].ToString()))
                            {
                                xml = row["ShippingMethods"].ToString();
                                xdoc.LoadXml("<Shipping>" + xml + "</Shipping>");
                                _nodelist = xdoc.SelectNodes("Shipping/ShippingMethods");
                                if (_nodelist.Count > 0)
                                {
                                    foreach (XmlNode node in _nodelist)
                                    {
                                        if (node.Attributes.Item(0).Value != null)
                                        {
                                            item.ShippingMethods += (item.ShippingMethods == "" ? "" : ", ") + node.Attributes.Item(0).Value.Trim();
                                            item.IsShippingMethod = true;
                                        }
                                        else
                                            item.ShippingMethods = "n/a";
                                    }

                                }

                                item.Shippinglocation = (row["ShippingLocation"].ToString() == "" ? "n/a" : row["ShippingLocation"].ToString());
                                item.ShowShipping = true;
                            }
                        }
                        else
                            item.ShowShipping = false;
                    }
                }

            }
            else
            {
                // Web.Redirect("~/ErrorPage.aspx?status=nolisting");
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }

        return item;
    }

    #endregion

    public static bool DeleteFeedItem(int id)
    {
        Fx.ExecuteSp("EN_DeleteFeedItem", id, Web.SessionMembers.MemberID);
        return true;
    }

    public static bool DeleteComment(int id)
    {
        Fx.ExecuteSp("EN_DeleteComment", id);
        return true;
    }
}
