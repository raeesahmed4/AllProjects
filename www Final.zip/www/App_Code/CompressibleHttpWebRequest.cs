using System;
using System.Net;
using System.Runtime.Serialization;
using System.Reflection;

namespace Pajocomo.Net
{
    /// <summary>
    /// Provides a compressibele HTTP-specific implementation of the <see cref="System.Net.WebRequest"/> class.
    /// </summary>
    [Serializable]
    public class CompressibleHttpWebRequest : HttpWebRequest
    {
        #region Private instance fields

        private AcceptEncodings acceptEncodings = AcceptEncodings.GZip | AcceptEncodings.Deflate | AcceptEncodings.Identity;

        #endregion

        #region Protected internal instance constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="CompressibleHttpWebRequest"/> class.
        /// </summary>
        /// <param name="serializationInfo">A <see cref="T:System.Runtime.Serialization.SerializationInfo"></see> object that contains the information required to serialize the new <see cref="T:System.Net.HttpWebRequest"></see> object.</param>
        /// <param name="streamingContext">A <see cref="T:System.Runtime.Serialization.StreamingContext"></see> object that contains the source and destination of the serialized stream associated with the new <see cref="T:System.Net.HttpWebRequest"></see> object.</param>
        protected internal CompressibleHttpWebRequest(SerializationInfo serializationInfo, StreamingContext streamingContext)
            : base(serializationInfo, streamingContext)
        {
        }

        #endregion

        #region Public instance properties

        /// <summary>
        ///   Gets or sets the accepted encodings.<seealso cref="AcceptEncodings"/>
        /// </summary>
        /// <value>The accepted encodings.</value>
        public AcceptEncodings AcceptEncodings
        {
            get
            {
                return this.acceptEncodings;
            }
            set
            {
                this.acceptEncodings = value;
            }
        }

        #endregion

        #region System.Net.HttpWebRequest members

        /// <summary>
        ///   Begins an asynchronous request to an Internet resource.
        ///   <seealso cref="T:System.Net.HttpWebRequest"/>
        ///   <seealso cref="M:System.Net.HttpWebRequest.BeginGetResponse"/>
        /// </summary>
        ///   <param name="callback">
        ///     The <see cref="T:System.AsyncCallback"></see> delegate
        ///   </param>
        ///   <param name="state">The state object for this request.</param>
        /// <returns>
        ///   An <see cref="T:System.IAsyncResult"></see> that references the asynchronous request for a response.
        /// </returns>
        /// <exception cref="T:System.InvalidOperationException">
        ///   <para>
        ///     The stream is already in use by a previous call to <see cref="M:Pajocomo.Net.CompressibleHttpWebRequest.BeginGetResponse(System.AsyncCallback,System.Object)"></see>
        ///   </para>
        ///   <para>-or-</para>
        ///   <para>
        ///     <see cref="P:Pajocomo.Net.CompressibleHttpWebRequest.TransferEncoding"></see> is set to a value and <see cref="P:Pajocomo.Net.CompressibleHttpWebRequest.SendChunked"></see> is <b>false</b>.
        ///   </para>
        ///   <para>-or-</para>
        ///   <para>
        ///     The thread pool is running out of threads.
        ///   </para>
        /// </exception>
        /// <exception cref="T:System.Net.ProtocolViolationException">
        ///   <para>
        ///     <see cref="P:Pajocomo.Net.CompressibleHttpWebRequest.Method"></see> is GET or HEAD, and either <see cref="P:Pajocomo.Net.CompressibleHttpWebRequest.ContentLength"></see> is greater than zero or <see cref="P:Pajocomo.Net.CompressibleHttpWebRequest.SendChunked"></see> is <b>true</b>.
        ///   </para>
        ///   <para>-or-</para>
        ///   <para>
        ///     <see cref="P:Pajocomo.Net.CompressibleHttpWebRequest.KeepAlive"></see> is <b>true</b>, <see cref="P:Pajocomo.Net.CompressibleHttpWebRequest.AllowWriteStreamBuffering"></see> is <b>false</b>, and either <see cref="P:Pajocomo.Net.CompressibleHttpWebRequest.ContentLength"></see> is -1, <see cref="P:Pajocomo.Net.CompressibleHttpWebRequest.SendChunked"></see> is <b>false</b> and <see cref="P:Pajocomo.Net.CompressibleHttpWebRequest.Method"></see> is POST or PUT.
        ///   </para>
        /// </exception>
        /// <exception cref="T:System.Net.WebException">
        ///   <para>
        ///     <see cref="M:Pajocomo.Net.CompressibleHttpWebRequest.Abort"></see> was previously called.
        ///   </para>
        /// </exception>
        /// <PermissionSet>
        ///   <IPermission class="System.Security.Permissions.EnvironmentPermission, mscorlib, Version=2.0.3600.0, Culture=neutral, PublicKeyToken=b77a5c561934e089" version="1" Unrestricted="true"/>
        ///   <IPermission class="System.Security.Permissions.FileIOPermission, mscorlib, Version=2.0.3600.0, Culture=neutral, PublicKeyToken=b77a5c561934e089" version="1" Unrestricted="true"/>
        ///   <IPermission class="System.Security.Permissions.SecurityPermission, mscorlib, Version=2.0.3600.0, Culture=neutral, PublicKeyToken=b77a5c561934e089" version="1" Unrestricted="true"/>
        ///   <IPermission class="System.Net.DnsPermission, System, Version=2.0.3600.0, Culture=neutral, PublicKeyToken=b77a5c561934e089" version="1" Unrestricted="true"/>
        ///   <IPermission class="System.Net.WebPermission, System, Version=2.0.3600.0, Culture=neutral, PublicKeyToken=b77a5c561934e089" version="1" Unrestricted="true"/>
        ///   <IPermission class="System.Diagnostics.PerformanceCounterPermission, System, Version=2.0.3600.0, Culture=neutral, PublicKeyToken=b77a5c561934e089" version="1" Unrestricted="true"/>
        /// </PermissionSet>
        public override IAsyncResult BeginGetResponse(AsyncCallback callback, object state)
        {
            BeforeGetResponse();
            return base.BeginGetResponse(callback, state);
        }

        /// <summary>
        ///   Returns a response from an Internet resource.
        ///   <seealso cref="T:System.Net.HttpWebRequest"/>
        ///   <seealso cref="M:System.Net.HttpWebRequest.GetResponse"/>
        /// </summary>
        /// <returns>
        ///   A <see cref="T:Pajocomo.Net.CompressibleHttpWebResponse"/> containing the response from the Internet resource.
        /// </returns>
        /// <exception cref="T:System.InvalidOperationException">
        ///   <para>
        ///     The stream is already in use by a previous call to <see cref="M:Pajocomo.Net.CompressibleHttpWebRequest.BeginGetResponse(System.AsyncCallback,System.Object)"></see>.
        ///   </para>
        ///   <para>-or-</para>
        ///   <para>
        ///     <see cref="P:Pajocomo.Net.CompressibleHttpWebRequest.TransferEncoding"></see> is set to a value and <see cref="P:Pajocomo.Net.CompressibleHttpWebRequest.SendChunked"></see> is <b>false</b>.
        ///   </para>
        /// </exception>
        /// <exception cref="T:System.Net.ProtocolViolationException">
        ///   <para>
        ///     <see cref="P:Pajocomo.Net.CompressibleHttpWebRequest.Method"></see> is GET or HEAD, and either <see cref="P:Pajocomo.Net.CompressibleHttpWebRequest.ContentLength"></see> is greater or equal to zero or <see cref="P:Pajocomo.Net.CompressibleHttpWebRequest.SendChunked"></see> is <b>true</b>.
        ///   </para>
        ///   <para>-or-</para>
        ///   <para>
        ///     <see cref="P:Pajocomo.Net.CompressibleHttpWebRequest.KeepAlive"></see> is <b>true</b>, <see cref="P:Pajocomo.Net.CompressibleHttpWebRequest.AllowWriteStreamBuffering"></see> is <b>false</b>, <see cref="P:Pajocomo.Net.CompressibleHttpWebRequest.ContentLength"></see> is -1, <see cref="P:Pajocomo.Net.CompressibleHttpWebRequest.SendChunked"></see> is <b>false</b>, and <see cref="P:Pajocomo.Net.CompressibleHttpWebRequest.Method"></see> is POST or PUT.
        ///   </para>
        /// </exception>
        /// <exception cref="T:System.NotSupportedException">
        ///   <para>
        ///     The request cache validator indicated that the response for this request can be served from the cache; however, this request includes data to be sent to the server. Requests that send data must not use the cache. This exception can occur if you are using a custom cache validator that is incorrectly implemented.
        ///   </para>
        /// </exception>
        /// <exception cref="T:System.Net.WebException">
        ///   <para>
        ///     <see cref="M:Pajocomo.Net.CompressibleHttpWebRequest.Abort"></see> was previously called.
        ///   </para>
        ///   <para>-or-</para>
        ///   <para>The time-out period for the request expired.</para>
        ///   <para>-or-</para>
        ///   <para>
        ///     An error occurred while processing the request.
        ///   </para>
        /// </exception>
        /// <PermissionSet>
        ///   <IPermission class="System.Security.Permissions.EnvironmentPermission, mscorlib, Version=2.0.3600.0, Culture=neutral, PublicKeyToken=b77a5c561934e089" version="1" Unrestricted="true"/>
        ///   <IPermission class="System.Security.Permissions.FileIOPermission, mscorlib, Version=2.0.3600.0, Culture=neutral, PublicKeyToken=b77a5c561934e089" version="1" Unrestricted="true"/>
        ///   <IPermission class="System.Security.Permissions.SecurityPermission, mscorlib, Version=2.0.3600.0, Culture=neutral, PublicKeyToken=b77a5c561934e089" version="1" Unrestricted="true"/>
        ///   <IPermission class="System.Net.DnsPermission, System, Version=2.0.3600.0, Culture=neutral, PublicKeyToken=b77a5c561934e089" version="1" Unrestricted="true"/>
        ///   <IPermission class="System.Net.WebPermission, System, Version=2.0.3600.0, Culture=neutral, PublicKeyToken=b77a5c561934e089" version="1" Unrestricted="true"/>
        ///   <IPermission class="System.Diagnostics.PerformanceCounterPermission, System, Version=2.0.3600.0, Culture=neutral, PublicKeyToken=b77a5c561934e089" version="1" Unrestricted="true"/>
        /// </PermissionSet>
        public override WebResponse GetResponse()
        {
            BeforeGetResponse();
            return AfterGetResponse(base.GetResponse() as ISerializable);
        }

        /// <summary>
        /// Ends an asynchronous request to an Internet resource.
        /// </summary>
        /// <param name="asyncResult">The pending request for a response.</param>
        /// <returns>
        ///   A <see cref="T:System.Net.WebResponse"></see> that contains the response from the Internet resource.
        /// </returns>
        /// <exception cref="T:System.ArgumentNullException">
        ///   <para>
        ///     <paramref name="asyncResult"/> is null.
        ///   </para>
        /// </exception>
        /// <exception cref="T:System.InvalidOperationException">
        ///   <para>
        ///     This method was called previously using <paramref name="asyncResult"/>.
        ///   </para>
        ///   <para>-or-</para>
        ///   <para>
        ///     The <see cref="P:Pajocomo.Net.CompressibleHttpWebRequest.ContentLength"></see> property is greater than 0 but the data has not been written to the request stream.
        ///   </para>
        /// </exception>
        /// <exception cref="T:System.ArgumentException">
        ///   <para>
        ///     <paramref name="asyncResult"/> was not returned by the current instance from a call to <see cref="M:Pajocomo.Net.CompressibleHttpWebRequest.BeginGetResponse(System.AsyncCallback,System.Object)"></see>.
        ///   </para>
        /// </exception>
        /// <exception cref="T:System.Net.WebException">
        ///   <para>
        ///     <see cref="M:Pajocomo.Net.CompressibleHttpWebRequest.Abort"></see> was previously called.
        ///   </para>
        ///   <para>-or-</para>
        ///   <para>
        ///     An error occurred while processing the request.
        ///   </para>
        /// </exception>
        /// <PermissionSet>
        ///   <IPermission class="System.Security.Permissions.EnvironmentPermission, mscorlib, Version=2.0.3600.0, Culture=neutral, PublicKeyToken=b77a5c561934e089" version="1" Unrestricted="true"/>
        ///   <IPermission class="System.Security.Permissions.FileIOPermission, mscorlib, Version=2.0.3600.0, Culture=neutral, PublicKeyToken=b77a5c561934e089" version="1" Unrestricted="true"/>
        ///   <IPermission class="System.Security.Permissions.SecurityPermission, mscorlib, Version=2.0.3600.0, Culture=neutral, PublicKeyToken=b77a5c561934e089" version="1" Flags="UnmanagedCode, ControlEvidence"/>
        /// </PermissionSet>
        public override WebResponse EndGetResponse(IAsyncResult asyncResult)
        {
            return AfterGetResponse(base.EndGetResponse(asyncResult) as ISerializable);
        }

        #endregion

        #region Private instance methods

        /// <summary>
        /// This method is called before getting the response to set the <b>Accept-Encoding</b> to the value determined by <see cref="AcceptEncodings"/>.
        /// </summary>
        private void BeforeGetResponse()
        {
            if (this.acceptEncodings != AcceptEncodings.Identity)
            {
                this.Headers.Add("Accept-Encoding", (this.acceptEncodings & ~AcceptEncodings.Identity).ToString().ToLower());
            }
        }

        /// <summary>
        ///   Afters the get response.
        /// </summary>
        /// <param name="httpWebResponse">The <see cref="HttpWebResponse"/> to derive from.</param>
        /// <returns>The <see cref="CompressibleHttpWebResponse"/> instance created.</returns>
        private WebResponse AfterGetResponse(ISerializable httpWebResponse)
        {
            if (httpWebResponse == null)
            {
                return null;
            }

            SerializationInfo serializationInfo = new SerializationInfo(typeof(CompressibleHttpWebResponse), new FormatterConverter());
            StreamingContext streamingContext = new StreamingContext(StreamingContextStates.All);
            httpWebResponse.GetObjectData(serializationInfo, streamingContext);

            CompressibleHttpWebResponse compressibleHttpWebResponse = new CompressibleHttpWebResponse(serializationInfo, streamingContext);
            Utils.FieldCopy(httpWebResponse, compressibleHttpWebResponse);

            return compressibleHttpWebResponse;
        }

        #endregion
    }
}
