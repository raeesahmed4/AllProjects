﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ContactUs : System.Web.UI.Page
{

    public bool ShowCaptcha = true;

    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnSend_Click(object sender, EventArgs e)
    {
        try
        {

            if (Session["CaptchaImageText"] != null)
            {
                if (txtCaptchaValue.Text.ToLower() != Session["CaptchaImageText"].ToString().ToLower())
                {

                    //this.master.ShowMessage("Code in the image and that you entered doesnot match");
                }

                if (txtCaptchaValue.Text.ToLower() == Session["CaptchaImageText"].ToString().ToLower())
                {
                    string email = "";
                    string name = "";
                    if (Web.IsMemberSession)
                    {
                        email = Web.SessionMembers.Email;
                        name = Web.SessionMembers.s_FullName;
                    }
                    else
                    {
                        email = txtEmail.Text;
                        name = txtYourName.Text;
                    }

                    System.Collections.Specialized.StringDictionary templateKeys = new System.Collections.Specialized.StringDictionary();
                    templateKeys.Add("#email_header#", Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER"));
                    templateKeys.Add("#message#", Server.HtmlEncode(txtComment.Text));
                    templateKeys.Add("#name#", name);
                    templateKeys.Add("#email#", email);
                    templateKeys.Add("#email_footer#", Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER_ADMIN"));
                    Web.SendMail(Web.SystemConfigs.GetKey("ADMIN_EMAIL"), Web.SystemConfigs.GetKey("ALERTS_EMAIL"), 15, templateKeys);
                    txtComment.Text = "";
                    txtEmail.Text = "";
                    txtYourName.Text = "";
                    // master.ShowMessage("Email has been sent successfully.", "info");
                    ClientScript.RegisterStartupScript(Page.GetType(), "toggle", "toggledisplaydiv()", true);
                }
            }
        }
        catch (Exception ex)
        {
            // VisualSoft.VSharp.Utils.Log.Write("Error", ex.GetBaseException().ToString(), ex);
            Web.LogError(ex);
        }
    }
    protected void btnSend_Cancel(object sender, EventArgs e)
    {
        Web.Redirect("index.aspx");
    }
}