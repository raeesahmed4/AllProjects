﻿using System;
using System.Collections.Specialized;
using System.Web;
using System.Web.UI;
using CodenameRabbitFoot.BusinessLogic;
using VisualSoft.VSharp.Utils;
using System.Web.Services;

public partial class Contols_UserRegistration : System.Web.UI.UserControl
{
    public Random rand;

    private string firstName;

    public string FirstName
    {
        set { txtFirstName.Text = value; }
    }
    private string lastName;

    public string LastName
    {
        set { txtLastName.Text = value; }
    }
    private string email;

    public string Email
    {
        set { txtboxEmail.Text = value; }
    }
    public bool IsEmailReadOnly
    {
        get;
        set;
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (this.IsEmailReadOnly)
        {
            this.txtboxEmail.Enabled = false;
        }
        rand = new Random();

        //ReadCookie();

        //txtUserName.Focus();

        if (!IsPostBack)
        {
            LoadLists();

            if (Request["sid"] != null)
            {
                string sid = Request["sid"].ToString();
                Members members = new Members();
                members.Where.SurrogateID.Value = sid;
                members.Query.Load();

                if (members.RowCount > 0)
                    txtboxEmail.Text = members.Email.ToString();
            }

        }
    }

    
    private void LoadLists()
    {
        try
        {
            ddlCountry.DataSource = CodenameRabbitFoot.BusinessLogic.Country.GetCountries();
            ddlCountry.DataValueField = "CountryID";
            ddlCountry.DataTextField = "CountryName";
            ddlCountry.DataBind();
            ddlCountry.SelectedValue = "91";
        }
        catch (Exception ex)
        {
            //Log.Write("Join.aspx: 001", ex.GetBaseException().ToString(), ex);
            Web.LogError(ex);
        }
    }

    private string errorMessage;
    public string ErrorMessage
    {
        get { return errorMessage; }
        set { errorMessage = value; }
    }

    public event System.EventHandler ButtonClicked;

    /// <summary> 
    /// Function that called by button click which
    /// in turns fires the buttonclicked event 
    /// trapped by the client 
    /// </summary> 
    protected virtual void OnClick(object sender)
    {
        // Raise the tabclicked event. 
        if (this.ButtonClicked != null)
            this.ButtonClicked(sender, new EventArgs());
    }

    protected void lnkSignOut_Click(object sender, EventArgs e)
    {
        try
        {
            Web.SessionMembers = null;
            Web.IsMemberSession = false;
            Web.IsAdminSession = false;
            System.Web.Security.FormsAuthentication.SignOut();

            if (!Web.IsSecuritySession)
            {
                Session.RemoveAll();
                Session.Abandon();
            }
            else
            {
                Session.RemoveAll();
                Web.IsSecuritySession = true;
            }

            if (Response.Cookies["loginCookie"] != null)
            {
                HttpCookie eofferCookie = Request.Cookies.Get("loginCookie");
                eofferCookie.Values.Set("login", eofferCookie.Values["login"]);
                eofferCookie.Values.Set("rememberMe", eofferCookie.Values["rememberMe"]);
                eofferCookie.Values.Set("password", "");
                eofferCookie.Values.Set("keepLoggedIn", "False");
                eofferCookie.Expires = DateTime.Now.AddHours(12);
                HttpContext.Current.Response.Cookies.Add(eofferCookie);
            }

            Web.Redirect("/index.aspx");
        } 
        catch (Exception ex)
        {
            Log.Write("444", ex.GetBaseException().ToString(), ex);
        }
    }

    //protected void btnRegistration_Click(object sender, ImageClickEventArgs e)
    //{
    //    try
    //    {
    //        Random rand = new Random();
    //        Members newMember = new Members();
    //        string companyName = txtCompanyName.Text;
    //        if (companyName == "Leave blank if you do not have one")
    //            companyName = txtFirstName.Text + " " + txtLastName.Text.Substring(0, 1) + " Company";

    //        //check if email exists
    //        Members member = new Members();
    //        member.Where.Email.Value = txtboxEmail.Text;
    //        member.Query.Load();
    //        if (member.RowCount < 1)
    //        {
    //            bool isvalidusername = true;
    //            //check if username exists
    //            SystemConfigKeys configs = new SystemConfigKeys();
    //            configs.Where.ConfigKey.Value = "RESERVE_WORDS";
    //            configs.Query.Load();
    //            if (configs.RowCount > 0)
    //            {
    //                string[] values = configs.Value.Split(',');
    //                string username = txtUserName.Text.Trim();
    //                foreach (string str in values)
    //                    if (username == str)
    //                        isvalidusername = false;
    //            }
    //            if (isvalidusername)
    //            {
    //                member = new Members();
    //                member.Where.UserName.Value = txtUserName.Text;
    //                member.Query.Load();
    //                if (member.RowCount < 1)
    //                {
    //                    newMember.AddNew();
    //                    newMember.Email = txtboxEmail.Text;
    //                    newMember.CompanyName = companyName;
    //                    newMember.FullName = txtFirstName.Text + " " + txtLastName.Text;
    //                    newMember.UserName = txtUserName.Text;
    //                    newMember.Password = txtpassword.Text; //rand.Next(9999).ToString();
    //                    newMember.RequestsToAddContacts = 0;
    //                    newMember.IsDealerProfileUpdate = 0;
    //                    newMember.MemberStatusID = 102;
    //                    newMember.RegistrationCode = CalculateRegCode();
    //                    newMember.LastProfileUpdate = DateTime.Today;
    //                    newMember.Save();
    //                    Web.WriteMemberStatusChangeLog(newMember.MemberID, newMember.MemberStatusID, "System");

    //                    ShippingAddresses address = new ShippingAddresses();
    //                    address.Where.MemberID.Value = newMember.MemberID;
    //                    address.Query.Load();
    //                    if (address.RowCount <= 0)
    //                        address.AddNew();
    //                    address.City = "";//txtCity.Text;
    //                    address.State = "";//txtState.Text;
    //                    address.Zip = txtPostalCode.Text;
    //                    address.s_CountryID = ddlCountry.SelectedValue;
    //                    address.MemberID = newMember.MemberID;
    //                    address.Save();
                         
    //                    //txtEmailActivate.Text = newMember.Email;
    //                    if (newMember.s_MemberID != null)
    //                    {
    //                        StringDictionary templateKeys = new StringDictionary();
    //                        try
    //                        {
    //                            templateKeys.Add("#email_header#", Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER"));
    //                            templateKeys.Add("#fullname#", (!String.IsNullOrEmpty(newMember.FullName)) ? newMember.FullName : newMember.Email);
    //                            templateKeys.Add("#email_address#", newMember.Email);
    //                            templateKeys.Add("#activation_link#", Web.SystemConfigs.GetKey("SITE_URL") + "Account/Verify.aspx?rand=" + rand.Next() + "&Action=Activate&code=" + newMember.RegistrationCode + "&RecordID=" + Secure.Encrypt(newMember.s_MemberID) + "&sid=" + newMember.SurrogateID);
    //                            templateKeys.Add("#code#", newMember.RegistrationCode);
    //                            templateKeys.Add("#link#", Web.SystemConfigs.GetKey("SITE_URL") + "Account/Verify.aspx?Action=Activate&RecordID=" + Secure.Encrypt(newMember.s_MemberID) + "&sid=" + newMember.SurrogateID);
    //                            templateKeys.Add("#site_url#", Web.SystemConfigs.GetKey("SITE_URL"));
    //                            templateKeys.Add("#email_footer#", Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER"));

    //                            Web.SendMail(newMember.Email, Web.SystemConfigs.GetKey("REG_EMAIL"), 002, templateKeys);


    //                        }
    //                        catch (Exception ex)
    //                        {
    //                            Web.LogError(ex);
    //                        }
    //                    }
    //                    else
    //                    {
    //                        //this.Master.ShowMessage("Please try again.", "simpleerr");
    //                        errorMessage = "Please try again.";
    //                        OnClick(sender);
    //                    }
    //                }
    //                else
    //                {
    //                    //this.Master.ShowMessage("Username already exists.", "simpleerr"); 
    //                    errorMessage = "Username already exists.";
    //                    OnClick(sender);
    //                }
    //            }
    //            else
    //            {
    //                //this.Master.ShowMessage("Username is invalid.", "simpleerr"); 
    //                errorMessage = "Username is invalid.";
    //                OnClick(sender);
    //            }

    //            //////////////////////////////////////////////////////

    //            //StringDictionary templateKeys2 = new StringDictionary();
    //            //templateKeys2 = new StringDictionary();
    //            //templateKeys2.Add("#user#", member.FullName + " has joined eOpen");

    //            //Web.AddActivityLog(member.MemberID, 1, templateKeys2, 0);

    //            //////////////////////////////////////////////////////

    //            Web.Redirect("~/Account/Verify.aspx?Action=Activate");
    //        }



    //    }
    //    catch (Exception exp)
    //    {
    //        Web.LogError(exp);
    //    }
    //}

     
}

