﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CodenameRabbitFoot.BusinessLogic;
using System.Data;
using System.Web.Services;
using System.Data.SqlClient;

public partial class Controls_ActivityAlerts : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }

    [WebMethod]
    public static JQGrid LoadPendingclients(int pageIndex, int pageSize)
    {

        JQGrid jqGrid = new JQGrid();
        if (!Web.IsMemberSession)
        {
            jqGrid.status = "login";
        }

        DataSet ds = Fx.ExecuteSp("pendingClientVandors", Web.SessionMembers.MemberID);



        IEnumerable<DataRow> allRows = ds.Tables[0].Select();
        jqGrid.total = allRows.Count() == pageSize ? 1 : (allRows.Count() / pageSize) + 1;
        jqGrid.records = pageSize;
        jqGrid.page = pageIndex;
        IEnumerable<DataRow> selectedRows = allRows.Skip((pageIndex - 1) * pageSize).Take(pageSize);
        if (selectedRows.Count() == 0)
        {
            JQGrid.Row row = new JQGrid.Row();
            row.id = 0;
            row.cell.Add("0");
            row.cell.Add("<td style='width:300xp;'><div style='text-align:left; padding:5px; width:400px;'>No records exists.</div></td>");
            jqGrid.rows.Add(row);
            jqGrid.status = "empty";
        }

        foreach (DataRow obj in selectedRows)
        {

            JQGrid.Row row = new JQGrid.Row();
            row.cell.Add(obj["MemberID"].ToString());
            string LogoHtml = string.Format("<div style='padding:5px 0px 5px 0px; margin:0px 0px 0px 5px;' ><a  href='/Contacts/ViewProfile.aspx?Action=ViewDealer&RecordID={0}'><img style='border:5px solid #F1F6F6;' alt='' height='40px' width='40px' src='ePage/ImageViewer.ashx?Action=LotDefaultThumbnail&RecordID={0}'/></a></div>", Secure.Encrypt(obj["MemberID"].ToString()));
            row.cell.Add(LogoHtml);
            row.cell.Add(obj["FullName"].ToString());
            row.cell.Add("<td>Pending</td>"); 
            jqGrid.rows.Add(row);

        }
        return jqGrid;

    }

}