﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CodenameRabbitFoot.BusinessLogic;
using System.Data;

public partial class Controls_Contacts : System.Web.UI.UserControl
{
    public DataTable DataSource
    { get; set; }

    public delegate string MessageDelegate(string message);
    public event MessageDelegate Message;

    protected void Page_Load(object sender, EventArgs e)
    {

    }

    private void BindgrdCustomersupplier()
    {
        try
        {
            grdCustomerandSupplier.DataSource = DataSource;
            grdCustomerandSupplier.DataBind();            
        }
        catch (Exception exp)
        {
            Web.LogError(exp);
        }
    }
    protected void grdCustomerandSupplier_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            grdCustomerandSupplier.PageIndex = e.NewPageIndex;
            if (string.IsNullOrEmpty(Request.QueryString["Action"].ToString()))
            {
                var action = Request.QueryString["Action"];
                if (action != null && action.ToLower() == "search")
                    Search();
                else
                    BindgrdCustomersupplier();
            }
            else
                BindgrdCustomersupplier();

        }
        catch (Exception exp)
        {

            //Log.Write("pageerr", exp.GetBaseException().ToString(), exp);
            Web.LogError(exp);
        }
    }
    protected void grdCustomerandSupplier_OnRowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName.Equals("AddSupplier") || e.CommandName.Equals("AddCustomer"))
        {
            try
            {
                int contactType = (e.CommandName.Equals("AddCustomer")) ? 1 : 2;
                int MemberID = Convert.ToInt32(e.CommandArgument.ToString());
                if (MemberID != Web.SessionMembers.MemberID)
                {
                    //Contacts contact = new Contacts();
                    //contact.Where.MemberID.Value = Web.SessionMembers.MemberID;
                    //contact.Where.ContactMemberID.Value = MemberID;
                    //contact.Query.Load();
                    //if (contact.RowCount < 1)
                    //{
                    int InvitationID = 0;
                    DataTable dt = Invitations.CheckIfInvited(Web.SessionMembers.MemberID, MemberID);
                    if (dt.Rows.Count > 0)
                    {
                        InvitationID = Convert.ToInt32(dt.Rows[0][0].ToString());
                        Invitations invitations = new Invitations();
                        invitations.LoadByPrimaryKey(InvitationID);
                        if (invitations.RowCount > 0)
                        {
                            if (invitations.InvitedBy == Web.SessionMembers.MemberID)
                            {
                                if (invitations.InvitationStatus == 1)
                                    Message("Vendor has already accepted your contact invitation");

                                else if (invitations.InvitationStatus == 2)
                                    Message("Vendor has already rejected your contact invitation.");
                                
                                else
                                    Message("You have already invited the Vendor to your contact list.");
                            }
                            else
                                Message("You have already been invited by the Vendor.");
                        }
                    }
                    else
                    {
                        InvitationID = Contacts.AddToContact(MemberID, Web.SessionMembers.MemberID, contactType, 1);
                        if (InvitationID > 0)
                        {
                            Invitations newInvitation = new Invitations();
                            newInvitation.LoadByPrimaryKey(InvitationID);
                            Members members = new Members();
                            members.LoadByPrimaryKey(MemberID);

                            System.Collections.Specialized.StringDictionary templateKeys = new System.Collections.Specialized.StringDictionary();
                            try
                            {
                                // add activity
                                var newContact = new Contacts();
                                newContact.Where.InvitationID.Value = InvitationID;
                                newContact.Query.Load();
                                if (newContact.RowCount > 0)
                                {
                                    templateKeys.Add("#type#", Web.GetContactType(newContact.ContactType));
                                    templateKeys.Add("#initiatedto#", "#memberid#" + newContact.ContactMemberID + "#endmemberid#");
                                    templateKeys.Add("#profileclass#", "#profileclass#" + newContact.ContactMemberID + "#endprofileclass#");
                                    templateKeys.Add("#initiatedtoprofile#", "/Contacts/ViewProfile.aspx?Action=ViewDealer&RecordID=#encrypt#" + newContact.ContactMemberID + "#endencrypt#");
                                    Web.AddPrivateActivityLog(Web.SessionMembers.MemberID, 33, templateKeys, Web.SessionMembers.MemberID, newContact.ContactID, members.MemberID);
                                }

                                templateKeys = new System.Collections.Specialized.StringDictionary();
                                templateKeys.Add("#email_header#", Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER"));
                                templateKeys.Add("#email_footer#", Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER"));
                                templateKeys.Add("#profile_link#", Web.SystemConfigs.GetKey("SITE_URL") + "contacts/viewprofile.aspx?Action=ViewDealer&status=pending&RecordID=" + Secure.Encrypt(Web.SessionMembers.MemberID) + "&ID=" + Secure.Encrypt(members.MemberID));
                                templateKeys.Add("#company_invitee#", Web.SessionMembers.CompanyName);
                                templateKeys.Add("#fullname_invitee#", Web.SessionMembers.FullName);
                                string[] name = Web.SessionMembers.FullName.Split(' ');
                                templateKeys.Add("#first_name_invitee#", name[0]);
                                templateKeys.Add("#fullname#", members.FullName);
                                templateKeys.Add("#type#", Web.GetContactType(newInvitation.ContactType));
                                templateKeys.Add("#message#", "Please accept my invitation to add you as my " + Web.GetContactType(newInvitation.ContactType) + " to be able to instantly communicate as well as keep up to date with each other's social and business activities.");
                                templateKeys.Add("#link_contact_requests#", Web.SystemConfigs.GetKey("SITE_URL") + "Contacts/Default.aspx");

                                Web.SendMail(members.Email, Web.SystemConfigs.GetKey("CONTACT_EMAIL"), 203, templateKeys);
                                //  Master.ShowMessage("A contact notification has been sent to " + Web.GetContactType(newInvitation.ContactType) + " for approval.", "info");
                            }
                            catch (Exception ex)
                            {
                                Web.LogError(ex);
                            }
                        }
                    }
                    //}
                    //else
                    //    Master.ShowMessage("You have already added this contact to your list", "info");
                }
                //else
                // Master.ShowMessage("You cannot add yourself to your contact list", "info");
            }
            catch (Exception ex)
            {
                Web.LogError(ex);
            }
        }
    }
    protected void grdCustomerandSupplier_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        try
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                int MemberID = Convert.ToInt32((sender as GridView).DataKeys[e.Row.RowIndex].Value);
                if (MemberID > 0)
                {
                    string navigateURL = "/Contacts/ViewProfile.aspx?Action=ViewDealer&RecordID=" + Secure.Encrypt(MemberID);
                    HyperLink lnkViewContact = e.Row.FindControl("lnkViewContact") as HyperLink;
                    lnkViewContact.NavigateUrl = navigateURL;
                    lnkViewContact.CssClass = Web.GetProfileClass(MemberID, Web.SessionMembers.MemberID);

                    // privacy control panels
                    Panel pnlCompany = e.Row.FindControl("pnlCompany") as Panel;
                    Panel pnlContact = e.Row.FindControl("pnlContact") as Panel;
                    Panel pnlLocation = e.Row.FindControl("pnlLocation") as Panel;
                    Panel pnlEmail = e.Row.FindControl("pnlEmail") as Panel;
                    Panel pnlCity = e.Row.FindControl("pnlCity") as Panel;
                    Panel pnlState = e.Row.FindControl("pnlState") as Panel;
                    Panel pnlCountry = e.Row.FindControl("pnlCountry") as Panel;
                    SetPrivacySettings(ref MemberID, ref pnlCompany, ref pnlContact, ref pnlLocation, ref pnlCity, ref pnlCountry, ref pnlEmail, ref pnlState);
                }
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }
    private void SetPrivacySettings(ref int MemberID, ref Panel pnlCompany, ref Panel pnlContact, ref Panel pnlLocation, ref Panel pnlCity, ref Panel pnlCountry, ref Panel pnlEmail, ref Panel pnlState)
    {
        PrivacySettings pSettings = MemberPrivacySetting.GetPrivacySettings(ref MemberID);
        pnlCompany.Visible = pSettings.ShowCompanyName;
        pnlContact.Visible = pSettings.ShowFullName;
        pnlCity.Visible = true;    //pSettings.ShowCity;
        pnlState.Visible = true;   // pSettings.ShowState;
        pnlCountry.Visible = true; // pSettings.ShowCountry;
        pnlEmail.Visible = pSettings.ShowEmail;

        //if (pnlCountry.Visible == false && pnlCity.Visible == false)
        //  pnlLocation.Visible = false;
    }
    private void Search()
    {
        try
        {
            if (!String.IsNullOrEmpty(Request["Name"].ToString()))
            {
                DataTable result = Contacts.SearchContacts(3, 0, Request["Name"].ToString());
                grdCustomerandSupplier.DataSource = result;
                grdCustomerandSupplier.DataBind();
                grdCustomerandSupplier.Visible = true;
                Session["DealersList"] = result;
            }
        }
        catch (Exception exp)
        {
            //Log.Write("error", exp.GetBaseException().ToString(), exp);
            Web.LogError(exp);
        }
    }
    
}