﻿using System;
using System.Web;

using CodenameRabbitFoot.BusinessLogic;

public partial class Contols_NewActivities : System.Web.UI.UserControl
{
    #region Properties
    private int requestsascustomer = 0;
    public int RequestsasCustomer
    {
        get { return requestsascustomer; }
        set { requestsascustomer = value; }
    }

    private int requestsassupplier = 0;
    public int RequestsasSupplier
    {
        get { return requestsassupplier; }
        set { requestsassupplier = value; }
    }

    private int requestsforcustomer = 0;
    public int RequestsForCustomer
    {
        get { return requestsforcustomer; }
        set { requestsforcustomer = value; }
    }

    private int requestsforsupplier = 0;
    public int RequestsForSupplier
    {
        get { return requestsforsupplier; }
        set { requestsforsupplier = value; }
    }

    private int messagesCount = 0;
    public int MessagesCount
    {
        get { return messagesCount; }
        set { messagesCount = value; }
    }

    private int lotOffersCount = 0;
    public int LotOffersCount
    {
        get { return lotOffersCount; }
        set { lotOffersCount = value; }
    }

    private int itemOffersCount = 0;
    public int ItemOffersCount
    {
        get { return itemOffersCount; }
        set { itemOffersCount = value; }
    }

    private int counterOffersCount = 0;
    public int CounterOffersCount
    {
        get { return counterOffersCount; }
        set { counterOffersCount = value; }
    }

    private int ownerID = 0;
    public int OwnerID
    {
        get { return ownerID; }
        set { ownerID = value; }
    }


    private bool showBorder = true;
    public bool ShowBorder
    {
        get { return showBorder; }
        set { showBorder = value; }
    }
    #endregion

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
            if (Web.IsMemberSession)
                LoadData();

        if (HttpContext.Current.Request.QueryString.ToString() == "Action=newactivities")
            ShowBorder = false;
    }

   

    private void LoadData()
    {
        try
        {
            lnkClient_Pending_MyApproval.NavigateUrl = "~/Contacts/Default.aspx?Action=clients&Type=PendingMyApproval";
            lnkVendors_Pending_MyApproval.NavigateUrl = "~/Contacts/Default.aspx?Action=vendors&Type=PendingMyApproval";
            lnkClient_Waiting_to_approve_me.NavigateUrl = "~/Contacts/Default.aspx?Action=clients&Type=WaitingToApproveMe";
            lnkVendors_Waiting_to_approve_me.NavigateUrl = "~/Contacts/Default.aspx?Action=vendors&Type=WaitingToApproveMe";
            lnkMessages.Text = "New Messages" + GetCount(CountTypes.New_Messages);
        }
        catch (Exception exp)
        {
            Web.WriteLog("New Activities - LoadData:", exp.GetBaseException().ToString(), exp);
        }
    }
    protected void lnkMessages_Click(object sender, EventArgs e)
    {
        try
        {
            Session["TabIndex"] = 14;
           
            if (Web.IsMemberSession)
            {
                Counters.ResetCount(CountTypes.New_Messages, Web.SessionMembers.MemberID);
            }
            Web.Redirect("~/Contacts/Multimedia.aspx?Action=messages");
        } 
        catch (Exception exp)
        {
            Web.LogError(exp);
        }
    }

    protected string GetCount(CountTypes type)
    {
 
        string result = "";
        try
        {
            int count = 0;
            if (type == CountTypes.New_Messages)
                count = CodenameRabbitFoot.BusinessLogic.Counters.GetCount(CountTypes.New_Messages, Web.SessionMembers.MemberID);
            else
                count = CodenameRabbitFoot.BusinessLogic.Counters.GetCount(type, Web.IsMemberSession ? Web.SessionMembers.MemberID : 0);
             
                result = " (" + count.ToString() + ")";
        }
        catch (Exception ex) { Web.LogError(ex); }
        return result;
    }
     
}
