﻿using System;

using CodenameRabbitFoot.BusinessLogic;

public partial class Controls_MemberRating : System.Web.UI.UserControl
{
    string _skin = "blue";
    public string Skin
    {
        get { return _skin; }
        set { _skin = value; }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {

            int visitorid = Web.RecordID;

            var score = new MemberTrustScore();

            score.Query.AddResultColumn(MemberTrustScoreSchema.TrustedScore);
            score.Query.AddResultColumn(MemberTrustScoreSchema.TrustByTotal);
            score.Query.AddResultColumn(MemberTrustScoreSchema.UnTrustByTotal);
            score.Query.AddResultColumn(MemberTrustScoreSchema.MemberID);

            if (visitorid == -1)
                score.Where.MemberID.Value = MemberID;
            else
                score.Where.MemberID.Value = visitorid;


            score.Query.Load();
            if (score.RowCount > 0)
            {
                if (visitorid != -1)
                {
                    Members member;
                    if (MemberID != 0)
                        member = Members.GetMemberByID(MemberID);
                    else
                        member = Members.GetMemberByID(visitorid);
                    
                    lblRating.Text = member.CompanyName + " Rating";
                }

                lblTotal.Text = score.s_TrustedScore;
                lblTrustedB.Text = score.s_TrustByTotal;
                lblUntrustedBy.Text = score.s_UnTrustByTotal;
            }

            if (Web.IsMemberSession)
            {
                if (MemberID != Web.SessionMembers.MemberID)
                {
                    MemberTrustLog log = new MemberTrustLog();
                    log.Query.AddResultColumn(MemberTrustLogSchema.IsTrusted);
                    log.Query.AddResultColumn(MemberTrustLogSchema.MemberID);
                    log.Query.AddResultColumn(MemberTrustLogSchema.TrustDate);
                    log.Query.AddResultColumn(MemberTrustLogSchema.TrustedBy);
                    log.Where.MemberID.Value = MemberID;
                    log.Where.TrustedBy.Value = Web.SessionMembers.MemberID;
                    log.Query.Load();
                    if (log.RowCount > 0)
                    {
                        int istrust = MemberTrustLog.GetIsTrusted(MemberID, Web.SessionMembers.MemberID);
                        if (istrust == 1)
                        {
                            lblTrustOrUntrust.Text = "if you don't trust";
                            lblTrustedOrUntrusted.Text = "Trusted by You";

                        }
                        else
                        {
                            lblTrustOrUntrust.Text = "if you don't un-trust";
                            lblTrustedOrUntrusted.Text = "Un-trusted by You";
                        }
                    }
                    else
                    {
                        lblTrustOrUntrust.Text =
                            "if you have not rated yet, and have made transactions with the Vendor, ";
                        lblLinkText.Text = "please enter your vote >>";
                        lblTrustedOrUntrusted.Text = "Not Rated by You";
                    }
                }
            }
            else
            {
                lblLinkText.Visible = false;
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }

    #region Properties
    private int _memberId = 0;


    public int MemberID
    {
        get { return _memberId; }
        set { _memberId = value; }
    }

    private int _sessionMember = 0;
    public int SessionMember
    {
        get { return _sessionMember; }
        set { _sessionMember = value; }
    }
    private bool _showHeading = true;
    public bool ShowHeading
    {
        get { return _showHeading; }
        set { _showHeading = value; }
    }
    #endregion
    
    protected void redirectTrusted_Click(object sender, EventArgs e)
    {
    
    }
    
    protected void redirectUnTrusted_Click(object sender, EventArgs e)
    {
    
    }



}
