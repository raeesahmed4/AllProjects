﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

public partial class Contols_TextBox : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // check if the TextBox's TextMode is Password
        if (isPasswordMode)
            txtBox.TextMode = TextBoxMode.Password;
        txtBox.Width = Width;
        txtBox.Height = Height;
        txtBox.MaxLength = MaxLength;

        // check if the Compare validator
        if (isCompare)
        {
            vld_Compare.Enabled = true;
            vld_Compare.ControlToValidate = controlToValidate;
            vld_Compare.ControlToCompare = controlToCompare;
            vld_Compare.ErrorMessage = compareValidationMessage;
        }

        // check if the control has a range defined
        if (isRangeValidation)
            vld_RangeValidator.Enabled = true;

        // check if the control is a required field
        if (isRequired)
            vld_Required.Enabled = true;

        // check if the control is regular expression driven
        if (isRegularExpression)
        {
            vld_RegularExpression.Enabled = true;
            vld_RegularExpression.ValidationExpression = validationExpression;
        }

    }

    public string ValidationGroup
    {
        set
        {
            vld_Required.ValidationGroup = value;
            vld_RegularExpression.ValidationGroup = value;
            vld_RangeValidator.ValidationGroup = value;
        }
    }

    private bool isRegularExpression = false;
    public bool IsRegularExpression
    {
        get { return isRegularExpression; }
        set { isRegularExpression = value; }
    }

    private bool isRangeValidation = false;
    public bool IsRangeValidation
    {
        get { return isRangeValidation; }
        set { isRangeValidation = value; }
    }
    public string MaximumValue
    {
        get { return vld_RangeValidator.MaximumValue; }
        set { vld_RangeValidator.MaximumValue = value; }
    }
    public string MinimumValue
    {
        get { return vld_RangeValidator.MinimumValue; }
        set { vld_RangeValidator.MinimumValue = value; }
    }
    public ValidationDataType FieldType
    {
        get { return vld_RangeValidator.Type; }
        set { vld_RangeValidator.Type = value; }
    }

    private int maxLength = 50;
    public int MaxLength
    {
        get { return maxLength; }
        set { maxLength = value; }
    }

    private int width = 300;
    public int Width
    {
        get { return width; }
        set { width = value; }
    }

    private Unit height = Unit.Point(12);
    public Unit Height
    {
        get { return height; }
        set { height = value; }
    }

    private bool isRequired = false;
    public bool IsRequired
    {
        get { return isRequired; }
        set { isRequired = value; }
    }

    public string Text
    {
        get { return txtBox.Text; }
        set { txtBox.Text = value; }
    }

    public bool ReadOnly
    {
        get { return txtBox.ReadOnly; }
        set { txtBox.ReadOnly = value; }
    }

    public bool EnableTheming
    {
        get { return txtBox.EnableTheming; }
        set { txtBox.EnableTheming = value; }
    }


    private string requiredFieldMessage = "";
    public string RequiredFieldMessage
    {
        get { return requiredFieldMessage; }
        set { vld_Required.ErrorMessage = value; }

    }

    //@"((\(\d{3}\) ?)|(\d{3}-))?\d{3}-\d{4}";
    private string validationExpression = "";
    public string ValidationExpression
    {
        get { return validationExpression; }
        set { validationExpression = value; }
    }

    private string regularExpressionMessage = "";
    public string RegularExpressionMessage
    {
        get { return regularExpressionMessage; }
        set { vld_RegularExpression.ErrorMessage = value; }
    }

    private string rangeValidationMessage = "";
    public string RangeValidationMessage
    {
        get { return rangeValidationMessage; }
        set { vld_RangeValidator.ErrorMessage = value; }
    }

    private string compareValidationMessage = "";
    public string CompareValidationMessage
    {
        get { return compareValidationMessage; }
        set { vld_Compare.ErrorMessage = value; }
    }


    private string fieldDescription = "";
    public string FieldDescription
    {
        get { return fieldDescription; }
        set { fieldDescription = value; }
    }

    private bool isPasswordMode = false;
    public bool IsPasswordMode
    {
        get { return isPasswordMode; }
        set { isPasswordMode = value; }
    }

    private bool isCompare = false;
    public bool IsCompare
    {
        get { return isCompare; }
        set { isCompare = value; }
    }
    private string controlToCompare = "";
    public string ControlToCompare
    {
        get { return controlToCompare; }
        set { controlToCompare = value; }
    }
    private string controlToValidate = "";
    public string ControlToValidate
    {
        get { return controlToValidate; }
        set { controlToValidate = value; }
    }
}
