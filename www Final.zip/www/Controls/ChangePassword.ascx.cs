﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using VisualSoft.VSharp.Utils;
using System.Drawing;

public partial class Controls_ChangePassword : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            if (VerifyPassword(txtOldPassword.Text))
            {
                if (CodenameRabbitFoot.BusinessLogic.Members.ChangePassword(Web.SessionMembers.MemberID, txtConfirmPassword.Text))
                {
                    Web.SessionMembers.Password = txtConfirmPassword.Text;

                    //pnlChangePassword.Visible = true;
                    //pnlReviewProfile.Visible = false;

                    try
                    {
                        System.Collections.Specialized.StringDictionary templateKeys = new System.Collections.Specialized.StringDictionary();
                        templateKeys.Add("#email_header#", Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER"));
                        templateKeys.Add("#email_footer#", Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER"));
                        templateKeys.Add("#fullname#", Web.SessionMembers.FullName);
                        templateKeys.Add("#link_log_myeoffer#", Web.SystemConfigs.GetKey("SITE_URL") + "Account/UpdatePublicProfile.aspx?Action=ContactInfo");
                        //templateKeys.Add("#link_report_account_compromised#", Web.SystemConfigs.GetKey("SITE_URL") + "MyAccount/Verify.aspx?Action=View&RecordID=" + Secure.Encrypt(Web.SessionMembers.MemberID));

                        Web.SendMail(Web.SessionMembers.Email, Web.SystemConfigs.GetKey("ACCOUNTS_EMAIL"), 009, templateKeys);
                    }
                    catch (VException vex)
                    {
                        //Log.Write("Email Error", vex.GetBaseException().ToString(), vex);
                        Web.LogError(vex);
                    }
                    catch (Exception ex)
                    {
                        //Log.Write("Email Error", ex.GetBaseException().ToString(), ex);
                        Web.LogError(ex);
                    }
                }

                string javascript = "javascript:alert('Password Changed Successfully'); javascript:window.parent.tb_remove();";
                Page.ClientScript.RegisterStartupScript(GetType(), "Javascript", javascript, true);
                //Web.Redirect("~/Live.aspx", false);
                Session["Message"] = "Password Changed Successfully";
            }
            else
            {
                // master.ShowMessage("Wrong Old Password", "error");
                txtOldPassword.BorderColor = Color.Red;
            }
        }
        catch (Exception ex)
        {
            //master.ShowMessage(ex.Message, "error");
            //Log.Write("001", ex.GetBaseException().ToString(), ex);
            Web.LogError(ex);
        }
    }

    private bool VerifyPassword(string password)
    {
        bool verified = false;
        try
        {
            CodenameRabbitFoot.BusinessLogic.Members member = new CodenameRabbitFoot.BusinessLogic.Members();
            member.Query.AddResultColumn(CodenameRabbitFoot.BusinessLogic.MembersSchema.UserName);
            member.Query.AddResultColumn(CodenameRabbitFoot.BusinessLogic.MembersSchema.Password);
            member.Where.MemberID.Value = Web.SessionMembers.MemberID;
            member.Where.Password.Value = txtOldPassword.Text;

            member.Query.Load();
            if (member.RowCount > 0)
            {
                if (member.Password == password)
                    verified = true;
            }
        }
        catch (Exception ex)
        {
            //Log.Write("001", ex.GetBaseException().ToString(), ex);
            Web.LogError(ex);
        }
        return verified;
    }

    protected void btncancel_Click(object sender, EventArgs e)
    {
        Web.Redirect("../index.aspx");
    }

}