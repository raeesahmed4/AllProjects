﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;

public partial class Controls_Uploader : System.Web.UI.UserControl
{  
    /// <summary>
    /// This field is used as key for repositry. i.e. user can upload multiple files on multiple pages for signle session.
    /// </summary>
    public string WebPageName { get; set; }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (string.IsNullOrWhiteSpace(WebPageName))
        {
            throw new Exception("WebPageName is not specified.");
        }
    }
}