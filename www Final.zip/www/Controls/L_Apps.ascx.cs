﻿using System;
using System.Web.UI.WebControls;
using CodenameRabbitFoot.BusinessLogic;

public partial class UserContols_L_Apps : System.Web.UI.UserControl
{
    #region Properties

    private LAppsType type;
    public LAppsType Type
    {
        get { return type; }
        set { type = value; }
    }

    private int ownerID = 0;
    public int OwnerID
    {
        get { return ownerID; }
        set { ownerID = value; }
    }

    private string controlTitle = "";
    public string ControlTitle
    {
        get
        {
            return controlTitle;
        }
        set { controlTitle = value; }
    }

    private bool isvisible = false;
    public bool IsVisible
    {
        get { return isvisible; }
        set { isvisible = value; }
    }

    private bool hasLApp = false;
    public bool HasLApp
    {
        get { return hasLApp; }
        set { hasLApp = value; }
    }
    #endregion

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindrptApplianceStore();
            CheckIfHasLApp();
        }
    }

    private void BindrptApplianceStore()
    {
        try
        {
            
            bool ShowControl = false;
            int Total = 0, count = 0;
            var ds = new System.Data.DataSet();
            if (Type == LAppsType.Warehouse)
            {
                ds = ApplianceStore.GetTopApplianceStoreByStatusAndMember(300, OwnerID);
                count = ds.Tables[0].Rows.Count;
                gvLApps.DataSource = ds.Tables[0];
                
                //if (Web.IsMemberSession)
                //    this.ControlTitle = (OwnerID == Web.SessionMembers.MemberID) ? "My LinkApps Warehouse" : "Vendor's LinkApps Warehouse";
                //else
                //    this.ControlTitle = "Vendor's LinkApps Warehouse";
                
                lnkViewAll.NavigateUrl = "~/ApplianceStore/Default.aspx?Action=ViewWarehouse&RecordID=" + Secure.Encrypt(OwnerID);
                lnkViewAllMyLinkApps.NavigateUrl = "~/ApplianceStore/Default.aspx?Action=ViewLinkApps&RecordID=" + Secure.Encrypt(OwnerID);
            }
            else if (Type == LAppsType.Common)
            {
                if (Web.IsMemberSession)
                    ds = ApplianceStore.GetTopCommonAppliances(Web.SessionMembers.MemberID, OwnerID);

                count = ds.Tables[0].Rows.Count;
                gvLApps.DataSource = ds.Tables[0];
                this.ControlTitle = "LinkApp in Common";
                lnkViewAll.NavigateUrl = "~/ApplianceStore/Default.aspx?Action=ViewCommon&RecordID=" + Secure.Encrypt(OwnerID);
            }
            else if (Type == LAppsType.Mine)
            {
                if (OwnerID > 0)
                {
                    ds = ApplianceStore.GetTopApplianceStore(OwnerID);
                    count = ds.Tables[0].Rows.Count;
                    gvLApps.DataSource = ds.Tables[0];

                    if (Web.IsMemberSession)
                        this.ControlTitle = (OwnerID == Web.SessionMembers.MemberID) ? "My Site LinkApps" : "Vendor's Site LinkApp";
                    else this.ControlTitle = "Vendor's Site LinkApp";

                    lnkViewAll.NavigateUrl = "~/ApplianceStore/Default.aspx?Action=ViewLinkApps&RecordID=" + Secure.Encrypt(OwnerID);
                    //lnkEdit.NavigateUrl = "~/ApplianceStore/Default.aspx?Action=ViewLinkApps&RecordID=" + Secure.Encrypt(OwnerID);
                    lnkStatistics.NavigateUrl = "~/ApplianceStore/Statistics.aspx?Action=View&RecordID=" + Secure.Encrypt(OwnerID);
                }
                else
                {
                    gvLApps.DataSource = null;
                    this.ControlTitle = "My Site LinkApps";
                    IsVisible = true;
                    lnkViewAll.Visible = false;
                }
            }
            else
            {
                ds = ApplianceStore.GetTopApplianceStores();
                gvLApps.DataSource = ds.Tables[0];
                this.ControlTitle = "New LinkApps";
                lnkViewAll.NavigateUrl = "~/ApplianceStore/Default.aspx";
                ShowControl = true;
            }
            gvLApps.DataBind();

            if (OwnerID > 0)
            {
                Total = Convert.ToInt32(ds.Tables[1].Rows[0][0].ToString());
                lnkViewAll.Visible = (Total > 0) ? true : false;

                if (count == 0)
                    IsVisible = (!Web.IsMemberSession) ? false : ((OwnerID != Web.SessionMembers.MemberID) ? false : true);
                else
                    IsVisible = true;
            }
            if (ShowControl)
            {
                Total = Convert.ToInt32(ds.Tables[1].Rows[0][0].ToString());
                lnkViewAll.Visible = (Total > 0) ? true : false;
                IsVisible = true;
            }
        }
        catch (Exception exp)
        {
            Web.LogError(exp);
        }
    }

    protected void gvLApps_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvLApps.PageIndex = e.NewPageIndex;
        BindrptApplianceStore();
    }

    protected void gvLApps_Command(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            if (e.CommandName.Equals("Remove"))
            {
                ApplianceStoreSubscriptions subscriptions = new ApplianceStoreSubscriptions();
                subscriptions.Where.ApplianceStoreID.Value = e.CommandArgument;
                subscriptions.Where.MemberID.Value = Web.SessionMembers.MemberID;
                subscriptions.Query.Load();
                if (subscriptions.RowCount > 0)
                {
                    do
                    {
                        subscriptions.MarkAsDeleted();
                        subscriptions.Save();
                    }
                    while (subscriptions.MoveNext());
                }
            }
            else if (e.CommandName.Equals("Rate"))
            {
              
            }
            Type = LAppsType.Warehouse;
            BindrptApplianceStore();
        }
        catch (Exception exp)
        {
            Web.LogError(exp);
        }
    }

    protected void gvLApps_RowDataBound(object sender, GridViewRowEventArgs e)
    {

        foreach (GridViewRow row in gvLApps.Rows)
        {
            Image img = (Image)row.FindControl("imgpopup");
            if (img != null)
            {
                string appstoreid = gvLApps.DataKeys[row.RowIndex].Values[0].ToString();
                img.Attributes.Add("onclick", "openWin(" + appstoreid + ")");

                ////img.Attributes.Add("onmouseout", "Out(this)");

                //img.Attributes.Add("onmousemov", "Move(this,event)");

            }
        }
        Image img1 = e.Row.FindControl("imgpopup") as Image;
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            if (Web.IsMemberSession)
            {
                int appliancestoreid = Convert.ToInt32(gvLApps.DataKeys[e.Row.RowIndex].Values[0].ToString());
                ApplianceRatings apprating = new ApplianceRatings();
                apprating.Where.ApplianceStoreID.Value = appliancestoreid;
                apprating.Where.MemberID.Value = Web.SessionMembers.MemberID;
                apprating.Query.Load();

                //if (apprating.RowCount > 0)
                //    img1.Visible = false;
                //else
                //    img1.Visible = true;
            }
            else
                img1.Visible = false;
        }
    }

    protected void btnRate_Click(object sender, EventArgs e)
    {

        try
        {
            int appstoreID = Convert.ToInt32(hfAppstoreID.Value);
            if (appstoreID > 0)
            {
                if (!string.IsNullOrEmpty(txtcomment.Text.ToString()))
                {
                    ApplianceRatings applianceRating = new ApplianceRatings();
                    applianceRating.AddNew();
                    applianceRating.ApplianceStoreID = appstoreID;
                    applianceRating.MemberID = Web.SessionMembers.MemberID;
                    applianceRating.Rate = (byte)(ApplianceRating.CurrentRating);
                    applianceRating.RateDate = DateTime.Now;
                    applianceRating.Comments = txtcomment.Text;
                    applianceRating.Save();
                    txtcomment.Text = "";
                    Repeater rptApplianceStore = this.Parent.FindControl("rptApplianceStore") as Repeater;
                    if (rptApplianceStore != null)
                    {
                        BindrptApplianceStore();
                    }
                }

            }

            hfAppstoreID.Value = "0";


        }
        catch (Exception exp)
        {

            Web.LogError(exp);
        }
    }

    protected void ApplianceRating_Changed(object sender, AjaxControlToolkit.RatingEventArgs e)
    {

        try
        {
            e.CallbackResult = "Upate done. Value = " + e.Value + " Tag = " + e.Tag;
        }
        catch (Exception exp)
        {

            Web.LogError(exp);
        }

    }

    public void Rebind()
    {
        try
        {
            BindrptApplianceStore();
        }
        catch (Exception exp)
        {
            Web.LogError(exp);
        }
    }
    private void CheckIfHasLApp()
    {
        try
        {
            if (Web.RecordID > 0 && Web.IsAction("ViewLinkApps"))
            {
                ApplianceStore stores = new ApplianceStore();
                stores.Where.MemberID.Value = Web.SessionMembers.MemberID;
                stores.Query.Load();
                HasLApp = (stores.RowCount > 0) ? true : false;
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }
}
