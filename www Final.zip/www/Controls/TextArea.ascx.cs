using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Drawing;

public partial class Controls_TextArea : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // txtContent.Attributes.Add("OnKeyDown", "checkMaxLimit(" + txtContent.ClientID + "," + lblCounter.ClientID + "," + maxLength + ")");
        // lblCounter.Text = maxLength.ToString() + " chars left";

        txtContent.Width = Width;
        txtContent.Height = Height;
        txtContent.Rows = Rows;
        txtContent.MaxLength = MaxLength;
        //MultiLineTextBoxValidator.MaxLength = MaxLength;
        txtContent.Font.Size = new FontUnit(FontSize);
        if (isEnable == false)
            txtContent.Enabled = false;

        if (isReadOnly)
            txtContent.ReadOnly = true;

        if (showCounter)
        {
            lblCounter.Text = MaxLength.ToString() + " chars left";
        }
        else
        {
            //MultiLineTextBoxValidator.ShowCharacterCount = false;
            lblCounter.Visible = false;
        }

        // check if the control is a required field
        if (isRequired)
            vld_Required.Enabled = true;

        // check if the control is regular expression driven
        if (isRegularExpression)
            vld_ReqularExpression.Enabled = true;

        if (ShowRequiredAsterisk)
            lblRequired.Visible = true;
        else
            lblRequired.Visible = false;
    }

    #region Properties

    private int fontSize = 10;
    public int FontSize
    {
        get { return fontSize; }
        set { fontSize = value; }
    }
     
    public string Text
    {
        get { return txtContent.Text; }
        set { txtContent.Text = value; }
    }

    private int maxLength;
    public int MaxLength
    {
        get { return maxLength; }
        set { maxLength = value; }
    }

    private string fieldDescription = "";
    public string FieldDescription
    {
        get { return fieldDescription; }
        set { fieldDescription = value; }
    }

    private string requiredFieldMessage = "";
    public string RequiredFieldMessage
    {
        get { return requiredFieldMessage; }
        set { vld_Required.ErrorMessage = value; }
    }

    private string validationExpression = "";
    public string ValidationExpression
    {
        get { return validationExpression; }
        set { vld_ReqularExpression.ValidationExpression = value; }
    }

    private string reqularExpressionMessage = "";
    public string ReqularExpressionMessage
    {
        get { return reqularExpressionMessage; }
        set { vld_ReqularExpression.ErrorMessage = "<font color='Black'>" + value + "</font>"; }
    }

    public string ValidationGroup
    {
        set
        {
            vld_Required.ValidationGroup = value;
            vld_ReqularExpression.ValidationGroup = value;
        }
    }

    private bool isRegularExpression = false;
    public bool IsRegularExpression
    {
        get { return isRegularExpression; }
        set { isRegularExpression = value; }
    }

    private bool isRequired = false;
    public bool IsRequired
    {
        get { return isRequired; }
        set { isRequired = value; }
    }

    private bool showRequiredAsterisk = false;
    public bool ShowRequiredAsterisk
    {
        get { return showRequiredAsterisk; }
        set { showRequiredAsterisk = value; }
    }

    private bool showCounter = false;
    public bool ShowCounter
    {
        get { return showCounter; }
        set { showCounter = value; }
    }

    private Unit width = Unit.Pixel(300);
    public Unit Width
    {
        get { return width; }
        set { width = value; }
    }

    private Unit height = Unit.Pixel(50);
    public Unit Height
    {
        get { return height; }
        set { height = value; }
    }

    private int rows = 2;
    public int Rows
    {
        get { return rows; }
        set { rows = value; }
    }

    private bool isEnable = true;
    public bool IsEnable
    {
        get { return isEnable; }
        set { isEnable = value; }
    }

    private bool isReadOnly = false;
    public bool IsReadOnly
    {
        get { return isReadOnly; }
        set { isReadOnly = value; }
    }

    private bool isWaterMark = false;

    public bool IsWaterMark
    {
        get { return isWaterMark; }
        set { isWaterMark = value; }
    }
    #endregion
}
