﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using CodenameRabbitFoot.BusinessLogic;
using Telerik.Web.UI;
using System.Configuration;

public partial class Post : System.Web.UI.Page
{
    #region members
    public static string MemberID;
    public static int EditorID;

    private string ddlpostvalue = "";
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        Web.CheckSession();

        Web.SystemConfigs = SystemManager.GetConfigurations(ConfigurationManager.AppSettings["ApplicationAccessKey"].ToString());

        try
        {

            ddlPost.Attributes.Add("onchange", "clearCon();");
            this.Master.HideLinkApps();
            string action = Request["Action"] ?? string.Empty;
            Web.CheckSession();

            Label lblheading = (Label)Page.Master.FindControl("lblHeading");

            if (!Page.IsPostBack)
            {
                //txtVideoLink.Attributes.Add("onclick", "GetMetaData();");

                // lowercontentdiv.Visible = false;

                MemberID = null;
                if (action.ToLower() == "tomembercoupons")
                {
                    //ddlMemberContacList.Visible = true;
                    ddlCategory.Enabled = false;
                    ddlPost.Visible = false;
                    LoadMemberContactsList();


                    // TDDynamicContents.InnerHtml = LoadDatanGenerateControls("7", 4679);

                    //  Page.ClientScript.RegisterClientScriptBlock(typeof(Page), "SRC", "showControlsforCoupons();", true);

                }
                else
                {
                    LoadPostingTypes();
                    LoadConditions();
                    LoadShippingTypes();
                    LoadPaymentOptions();
                    LoadShippingLocation();
                    LoadrdbCity();
                }

                if (HttpContext.Current.Request.Browser.Cookies)
                    LoadCookies();

                ddlCategory.Attributes.Add("onchange", "CallLoadControls();");

                if (Web.IsMemberSession)
                    MemberID = Web.SessionMembers.MemberID.ToString();
                //ddlCategory.OnClientSelectedIndexChanged = "LoadControls";
                //ddlCategory.Items.Insert(0, new RadComboBoxItem("----choose any category----", "-1"));
                // ddlCategory.Items.Insert(0, new ListItem("----choose any category----", "-1"));
                ///////setting page title

                if (!string.IsNullOrEmpty(action))
                {
                    switch (action.ToLower())
                    {
                        case "worldwide":
                            litPageTitle.Text = "Post to the World";
                            break;
                        case "toallvendors":
                            litPageTitle.Text = "Post to all Vendors";
                            break;
                        case "toallclients":
                            litPageTitle.Text = "Post to all Clients";
                            break;
                        case "tolinkings":
                            litPageTitle.Text = "Post to all Linkings";
                            break;
                        case "tomembercoupons":
                            litPageTitle.Text = "Member Coupons";
                            break;
                    }

                }
                else
                {
                    litPageTitle.Text = "Post to the World";
                }
            }
        }
        catch (Exception ex)
        {

            Web.LogError(ex);
        }
    }

    protected void Page_LoadComplete(object sender, EventArgs e)
    {
        try
        {
            if (this.ddlPost.SelectedItem.Value.ToUpper().StartsWith("L_"))
            {
                this.ddlCategory.Enabled = ContactInformationExists().Equals("yes");
            }
            else
            {
                this.ddlCategory.Enabled = true;
            }
        }
        catch
        {
        }
    }

    [WebMethod]
    public static string ContactInformationExists()
    {
        string result = "no";
        try
        {
            if (Web.IsMemberSession)
            {
                result = (string.IsNullOrEmpty(Web.SessionMembers.shippingAddress.City)
                    || string.IsNullOrEmpty(Web.SessionMembers.shippingAddress.State)
                    || string.IsNullOrEmpty(Web.SessionMembers.shippingAddress.Zip)
                    || string.IsNullOrEmpty(Web.SessionMembers.shippingAddress.Address1)) ? "no" : "yes";
            }
        }
        catch (Exception exp)
        {
        }
        return result;
    }

    [WebMethod]
    public static string LoadDatanGenerateControls(string PostTypeID, int CategoryID)
    {
        string sb = "";
        try
        {
            if (PostTypeID.Contains("L_")) // is a listing....
            {
                sb = GenerateListingFields(PostTypeID, CategoryID);
            }
            else // is a posting
            {
                sb = GeneratePostingFields(PostTypeID, CategoryID);
            }
        }
        catch (Exception ex) { Web.LogError(ex); }
        return sb;
    }

    [WebMethod]
    public static string LoadLowerContentDiv(string ddlpostSelectedValue)
    {

        return ddlpostSelectedValue;

    }


    public static string LoadFieldValues(int FieldID, string FieldName)
    {
        DataTable dtField = new DataTable();
        dtField = ListingExtendedFields.GetFieldValues(FieldID);
        StringBuilder sb = new StringBuilder();
        foreach (DataRow dr in dtField.Rows)
        {
            if (FieldName == "Duration" && dr["Value"].ToString() == "14")
            {
                sb.Append("<option selected='true' value='" + dr["Value"].ToString() + "'>");
                sb.Append(dr["Name"].ToString());
                sb.Append("</option>");
            }
            else
            {
                sb.Append("<option value='" + dr["Value"].ToString() + "'>");
                sb.Append(dr["Name"].ToString());
                sb.Append("</option>");
            }
        }
        return sb.ToString();
    }
    public static string LoadFieldValues(int FieldID)
    {
        DataTable dtField = new DataTable();
        dtField = ListingExtendedFields.GetFieldValues(FieldID);
        StringBuilder sb = new StringBuilder();
        foreach (DataRow dr in dtField.Rows)
        {
            sb.Append("<option value='" + dr["Value"].ToString() + "'>");
            sb.Append(dr["Name"].ToString());
            sb.Append("</option>");
        }
        return sb.ToString();
    }
    private static string GeneratePostingFields(string PostTypeID, int CategoryID)
    {
        StringBuilder sb = new StringBuilder();
        try
        {
            DataTable dtControls = new DataTable();
            int TypeID = Convert.ToInt32(PostTypeID); EditorID = 0;
            dtControls = PostingExtendedFields.GetExtendedDFields(TypeID, CategoryID, 1);
            sb.Append("<table>");
            foreach (DataRow dr in dtControls.Rows)
            {
                sb.Append("<tr><td>");
                if (dr["FieldTypeID"].ToString() == "1")//textbox
                {
                    if (dr["IsRequired"].ToString() == "1")
                        sb.Append("<input title='" + dr["FieldDescription"].ToString() + "' value='" + dr["FieldDescription"].ToString() + "' class='InnerTextBox' type='text'  id='txt_Required_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'  style='width:400px;' onfocus =\"Focus(this,'" + dr["FieldDescription"].ToString() + "');\" onblur=\"Blur(this,'" + dr["FieldDescription"].ToString() + "','" + dr["RegularExpression"].ToString() + "','" + dr["ValidationError"].ToString() + "');\" />&nbsp;<span style='color: #ff002a;'>*</span><span style='color: #ff002a;' id='sp_txt_Required_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'></span><span style='color: #ff002a;display:none' id='sp_error_txt_Required_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'>" + dr["RequiredError"].ToString() + "</span>");
                    else
                        sb.Append("<input title='" + dr["FieldDescription"].ToString() + "' value='" + dr["FieldDescription"].ToString() + "' class='InnerTextBox' type='text'  id='txt_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'  style='width:400px;' onfocus =\"Focus(this,'" + dr["FieldDescription"].ToString() + "');\" onblur=\"Blur(this,'" + dr["FieldDescription"].ToString() + "','" + dr["RegularExpression"].ToString() + "','" + dr["ValidationError"].ToString() + "');\" />&nbsp;<span style='color: #ff002a;' id='sp_txt_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'></span>");
                }
                else if (dr["FieldTypeID"].ToString() == "2")//combobox
                {
                    if (dr["IsRequired"].ToString() == "1")
                    {
                        sb.Append("<select id='dynamic_ddl_Required_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "' style='width:403px' class='mycombo' title='" + dr["FieldDescription"].ToString() + "' onfocus =\"Focus(this,'" + dr["FieldDescription"].ToString() + "');\" >");
                        sb.Append("<option>" + dr["FieldDescription"].ToString() + "</option>");
                        //load combobox values
                        sb.Append(LoadFieldValues(Convert.ToInt32(dr["FieldID"])));
                        sb.Append("</select> ");
                        sb.Append("&nbsp;<span style='color: #ff002a;'>*</span><span style='color: #ff002a;' id='sp_cbx_Required_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'></span><span style='color: #ff002a;display:none' id='sp_error_dynamic_ddl_Required_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'>" + dr["RequiredError"].ToString() + "</span>");
                    }
                    else
                    {
                        sb.Append("<select id='dynamic_ddl_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "' style='width:403px' class='mycombo' title='" + dr["FieldDescription"].ToString() + "' onfocus =\"Focus(this,'" + dr["FieldDescription"].ToString() + "');\" >");
                        sb.Append("<option>" + dr["FieldDescription"].ToString() + "</option>");
                        //load combobox values
                        sb.Append(LoadFieldValues(Convert.ToInt32(dr["FieldID"])));
                        sb.Append("</select> ");
                    }
                }
                else if (dr["FieldTypeID"].ToString() == "3")//checkbox
                    sb.Append("<input type='checkbox' id='chk_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "' title='" + dr["FieldDescription"].ToString() + "' />" + dr["FieldDescription"].ToString());
                else if (dr["FieldTypeID"].ToString() == "4")//textarea
                {
                    // if (dr["IsRequired"].ToString() == "1")
                    //   sb.Append("<div style='display:none'> <textarea style=visibility:hidden;' title='" + dr["FieldDescription"].ToString() + "' id='txt_Required_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'  class='InnerTextBox' rows='0' cols='5' style='width:397px;font-size:15px;' onfocus =\"Focus(this,'" + dr["FieldDescription"].ToString() + "');\" onblur=\"Blur(this,'" + dr["FieldDescription"].ToString() + "','" + dr["RegularExpression"].ToString() + "','" + dr["ValidationError"].ToString() + "');\" >" + dr["FieldDescription"].ToString() + "</textarea>&nbsp;<span style='color: #ff002a;'>*</span><span style='color: #ff002a;' id='sp_txt_Required_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'></span><span style='color: #ff002a;display:none' id='sp_error_txt_Required_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'>" + dr["RequiredError"].ToString() + "</span></div>");
                    //  else
                    sb.Append("<div style='display:none'><textarea style=visibility:hidden;' title='" + dr["FieldDescription"].ToString() + "' id='txt_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'  class='InnerTextBox' rows='7' cols='5' style='width:397px;font-size:15px;' onfocus =\"Focus(this,'" + dr["FieldDescription"].ToString() + "');\" onblur=\"Blur(this,'" + dr["FieldDescription"].ToString() + "','" + dr["RegularExpression"].ToString() + "','" + dr["ValidationError"].ToString() + "');\" >" + dr["FieldDescription"].ToString() + "</textarea>&nbsp;<span style='color: #ff002a;' id='sp_txt_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'></span></div>");
                }
                else if (dr["FieldTypeID"].ToString() == "6")//Formated TextArea
                {
                    sb.Append("<input type='hidden' id='hdshowEditor' value='true'/>");
                    EditorID = Convert.ToInt32(dr["FieldID"].ToString());
                }
                else if (dr["FieldTypeID"].ToString() == "5")//attachments
                {
                    sb.Append("<input type='hidden' id='hdattachments' value='true'/>");
                }
                sb.Append("</td></tr>");
            }
            sb.Append("</table>");

            //scripts
            sb.Append("<script type=\"text/javascript\"> ");
            //onfocus event
            sb.Append("function Focus(obj,title) {");
            sb.Append("var id = obj.id;  ");
            sb.Append("$('#sp_'+ id).html('');");
            sb.Append("$('#sp_error_'+ id).hide('');");
            sb.Append("if ($('#' + id).val() == title) {");
            sb.Append("$('#' + id).val('');");
            sb.Append("$('#' + id).removeClass('red');");
            sb.Append("$('#' + id).removeClass('InnerTextBox');");
            sb.Append("}");
            sb.Append(" }");
            //on blur event
            sb.Append("function Blur(obj, title, regex, message) {");
            sb.Append("var id = obj.id;");
            sb.Append("if ($('#' + id).val() == '') {");
            sb.Append("$('#' + id).val(title);");
            sb.Append("$('#' + id).addClass('InnerTextBox');");
            sb.Append("}");
            //regex 
            sb.Append("var Expression = new RegExp(regex);");//using its Regex
            sb.Append("if ($('#' + id).val().match(Expression) == null) {");
            sb.Append("if($('#' + id).val()!=title){");
            sb.Append("$('#sp_'+ id).html(message);");
            sb.Append("return false;");
            sb.Append("}");
            sb.Append("}");
            sb.Append(" }");
            sb.Append("</script>");

        }
        catch (Exception ex) { Web.LogError(ex); }
        return sb.ToString();
    }
    private static string GenerateListingFields(string listingTypeID, int CategoryID)
    {

        StringBuilder sb = new StringBuilder();
        string result = "";
        StringBuilder oneRowHTML = new StringBuilder();
        try
        {
            DataTable dtControls = new DataTable();
            string[] str = Regex.Split(listingTypeID, "_");
            int TypeID = Convert.ToInt32(str[1]);
            dtControls = ListingExtendedFields.GetExtendedFields(TypeID, CategoryID);


            //if (listingTypeID != "L_5")
            {
                /*sb.Append("<table width='100%' style='margin-top: 10px' cellspacing:'10px' border='0'>");
                 sb.Append("<tr><td>");
                // sb.Append("<hr class='lineConnector' />");
                sb.Append(" </td><td class='redText'>");
                sb.Append("Lot Specifics:");
                sb.Append("</td></tr></table>");
                */
                sb.Append("<table cellspaciing=3 cellpadding=3 border=0 bordercolor=red><tr><td>");

                //to set price each, quantity and Sell separately ddl in a single row
                int count = 0;
                string txtControl = "";
                string makeOfferBlock = "";
                //string containerID = Guid.NewGuid().ToString().Replace("-", "");




                foreach (DataRow dr in dtControls.Rows)
                {
                    txtControl = dr["FieldID"].ToString();

                    if (txtControl == "4" || txtControl == "10" || txtControl == "24")// 4=Quantity, 10=PriceEach, 23=SellSeprately
                    {
                        if (count == 0)
                            sb.Append("##REPLACE##");

                        if (dr["FieldTypeID"].ToString() == "1") //textbox
                        {
                            oneRowHTML.Append("<Tr>");

                            string priceEach = "";

                            if (txtControl == "10")
                            {
                                priceEach = "&nbsp;<span style='font-size:13px;'>$</span>";
                                makeOfferBlock = "#makeofferblock#";
                            }

                            if (dr["IsRequired"].ToString() == "1")
                            {
                                oneRowHTML.Append("<td width=120>" + dr["FieldDescription"].ToString() + ":</td>");
                                oneRowHTML.Append("<td height=30><div style='display:inline;' id=PRICE_EACH_" + dr["FieldID"].ToString() + "><input title='" + dr["FieldDescription"].ToString() + "' value='" + dr["FieldDescription"].ToString()
                                    + "' class='InnerTextBox' type='text'  id='txt_Required_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString()
                                    + "'  style='width:180px;' onfocus =\"Focus(this,'" + dr["FieldDescription"].ToString() + "');\" onblur=\"Blur(this,'" + dr["FieldDescription"].ToString() + "','" + dr["RegularExpression"].ToString() + "','" + dr["ValidationError"].ToString() + "');\" />"
                                    + priceEach + "&nbsp;<span style='color: #ff002a;'>*</span><span style='color: #ff002a;' id='sp_txt_Required_" +
                                    dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'></span><span style='color: #ff002a;display:none' id='sp_error_txt_Required_"
                                    + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'>" + dr["RequiredError"].ToString() + "</span></div>&nbsp;");

                                oneRowHTML.Append(makeOfferBlock);
                            }
                            else
                            {
                                oneRowHTML.Append("<Td><input title='" + dr["FieldDescription"].ToString() + "' value='" + dr["FieldDescription"].ToString() + "' class='InnerTextBox' type='text'  id='txt_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'  style='width:110px;' onfocus =\"Focus(this,'" + dr["FieldDescription"].ToString() + "');\" onblur=\"Blur(this,'" + dr["FieldDescription"].ToString() + "','" + dr["RegularExpression"].ToString() + "','" + dr["ValidationError"].ToString() + "');\" />" + priceEach + "&nbsp;<span style='color: #ff002a;' id='sp_txt_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'></span>");
                            }


                            oneRowHTML.Append("</td></tr>");
                        }
                        else if (dr["FieldTypeID"].ToString() == "3") //checkbox
                        {
                            oneRowHTML.Append("<td valign='middle'  align=\"center\">");
                            if (dr["FieldName"].ToString().Equals("MakeOffer"))
                            {
                                if (TypeID == 1)
                                {
                                    oneRowHTML.Replace("#makeofferblock#", "<input type='checkbox' id='chk_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "' title='" + dr["FieldDescription"].ToString() + "' onclick='CheckBoxSelectionChanged(this);' />&nbsp;" + dr["FieldDescription"].ToString());
                                    //oneRowHTML.Append("<input type='checkbox' id='chk_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "' title='" + dr["FieldDescription"].ToString() + "' onclick='CheckBoxSelectionChanged(this);' />&nbsp;" + dr["FieldDescription"].ToString());
                                }
                            }
                            else
                            {
                                oneRowHTML.Append("<input type='checkbox' id='chk_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "' title='" + dr["FieldDescription"].ToString() + "'  />&nbsp;" + dr["FieldDescription"].ToString());
                            }
                            oneRowHTML.Append("</td>");
                        }
                        count++;

                    }
                    else
                    {
                        if (dr["FieldTypeID"].ToString() == "1")//textbox
                        {
                            sb.Append("<tr><td colspan='2'>");

                            if (dr["IsRequired"].ToString() == "1")
                                sb.Append("<div><input title='" + dr["FieldDescription"].ToString() + "' value='" + dr["FieldDescription"].ToString() + "' class='InnerTextBox' type='text'  id='txt_Required_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'  style='width:400px;' onfocus =\"Focus(this,'" + dr["FieldDescription"].ToString() + "');\" onblur=\"Blur(this,'" + dr["FieldDescription"].ToString() + "','" + dr["RegularExpression"].ToString() + "','" + dr["ValidationError"].ToString() + "');\" />&nbsp;<span style='color: #ff002a;'>*</span><span style='color: #ff002a;' id='sp_txt_Required_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'></span><span style='color: #ff002a;display:none' id='sp_error_txt_Required_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'>" + dr["RequiredError"].ToString() + "</span>");
                            else
                                sb.Append("<input title='" + dr["FieldDescription"].ToString() + "' value='" + dr["FieldDescription"].ToString() + "'e  class='InnerTextBox' type='text'  id='txt_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'  style='width:400px;' onfocus =\"Focus(this,'" + dr["FieldDescription"].ToString() + "');\" onblur=\"Blur(this,'" + dr["FieldDescription"].ToString() + "','" + dr["RegularExpression"].ToString() + "','" + dr["ValidationError"].ToString() + "');\" />&nbsp;<span style='color: #ff002a;' id='sp_txt_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'></span>");
                            sb.Append("</td></tr>");
                        }
                        else if (dr["FieldTypeID"].ToString() == "2")//combobox
                        {
                            sb.Append("<tr><td>" + dr["FieldDescription"].ToString() + ":</td><Td>");

                            if (dr["IsRequired"].ToString() == "1")
                            {
                                sb.Append("<select style=\"width: 190px\" id='dynamic_ddl_Required_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "' style='width:120px' class='InnerTextBox' title='" + dr["FieldDescription"].ToString() + "' onfocus =\"Focus(this,'" + dr["FieldDescription"].ToString() + "');\" >");
                                //sb.Append("<option>" + dr["FieldDescription"].ToString() + "</option>");
                                //load combobox values
                                sb.Append(LoadFieldValues(Convert.ToInt32(dr["FieldID"]), dr["FieldName"].ToString()));
                                sb.Append("</select> ");
                                sb.Append("&nbsp;<span style='color: #ff002a;'>*</span><span style='color: #ff002a;' id='sp_cbx_Required_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'></span><span style='color: #ff002a;display:none' id='sp_error_dynamic_ddl_Required_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'>" + dr["RequiredError"].ToString() + "</span>");
                            }
                            else
                            {
                                sb.Append("<select id='dynamic_ddl_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "' style='width:120px' class='mycombo' title='" + dr["FieldDescription"].ToString() + "' onfocus =\"Focus(this,'" + dr["FieldDescription"].ToString() + "');\" >");
                                //sb.Append("<option>" + dr["FieldDescription"].ToString() + "</option>");
                                //load combobox values
                                sb.Append(LoadFieldValues(Convert.ToInt32(dr["FieldID"]), dr["FieldName"].ToString()));
                                sb.Append("</select> ");
                            }

                            sb.Append("</td></tr>");

                        }
                        else if (dr["FieldTypeID"].ToString() == "3")//checkbox
                        {
                            if (dr["FieldName"].ToString().Equals("MakeOffer"))
                            {
                                if (TypeID == 1)
                                {
                                    sb.Append("<input  type='checkbox' id='chk_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "' title='" + dr["FieldDescription"].ToString() + "' onclick='CheckBoxSelectionChanged(this);' />" + dr["FieldDescription"].ToString());
                                }
                            }
                            else
                            {
                                sb.Append("<input  type='checkbox' id='chk_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "' title='" + dr["FieldDescription"].ToString() + "'  />" + dr["FieldDescription"].ToString());
                            }
                        }
                        else if (dr["FieldTypeID"].ToString() == "4")//textarea
                        {
                            if (dr["IsRequired"].ToString() == "1")
                                sb.Append("<textarea style=visibility:hidden;'  title='" + dr["FieldDescription"].ToString() + "' id='txt_Required_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'  class='InnerTextBox' rows='7' cols='5' style='width:397px;font-size:15px;' onfocus =\"Focus(this,'" + dr["FieldDescription"].ToString() + "');\" onblur=\"Blur(this,'" + dr["FieldDescription"].ToString() + "','" + dr["RegularExpression"].ToString() + "','" + dr["ValidationError"].ToString() + "');\" >" + dr["FieldDescription"].ToString() + "</textarea>&nbsp;<span style='color: #ff002a;'>*</span><span style='color: #ff002a;' id='sp_txt_Required_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'></span><span style='color: #ff002a;display:none' id='sp_error_txt_Required_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'>" + dr["RequiredError"].ToString() + "</span>");
                            else
                                sb.Append("<textarea style=visibility:hidden;'  title='" + dr["FieldDescription"].ToString() + "' id='txt_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'  class='InnerTextBox' rows='7' cols='5' style='width:397px;font-size:15px;' onfocus =\"Focus(this,'" + dr["FieldDescription"].ToString() + "');\" onblur=\"Blur(this,'" + dr["FieldDescription"].ToString() + "','" + dr["RegularExpression"].ToString() + "','" + dr["ValidationError"].ToString() + "');\" >" + dr["FieldDescription"].ToString() + "</textarea>&nbsp;<span style='color: #ff002a;' id='sp_txt_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'></span>");

                            // sb.Append("</td></tr>");

                        }
                        else if (dr["FieldTypeID"].ToString() == "6")//Formated TextArea
                        {
                            sb.Append("<input type='hidden' id='hdshowEditor' value='true'/>");
                            EditorID = Convert.ToInt32(dr["FieldID"].ToString());
                        }
                        else if (dr["FieldTypeID"].ToString() == "5")//attachments
                        {
                            sb.Append("<input type='hidden' id='hdattachments' value='true'/>");
                            // attachments = true;
                        }

                        else if (dr["FieldTypeID"].ToString() == "10") //conditions
                        {
                            sb.Append("<input type='hidden' id='hdconditions' value='true'/>");
                            sb.Append("<input type= 'hidden' id='hdconditionFieldid' value='" + dr["FieldID"].ToString() + "'/>");
                        }

                        else if (dr["FieldTypeID"].ToString() == "11") //payment
                        {
                            sb.Append("<input type='hidden' id='hdpayment' value='true'/>");
                        }

                        else if (dr["FieldTypeID"].ToString() == "13") //shipping
                        {
                            sb.Append("<input type='hidden' id='hdshipping' value='true'/>");
                        }

                        else if (dr["FieldTypeID"].ToString() == "21") //warranty
                        {
                            sb.Append("<input type='hidden' id='hdwarranty' value='true'/>");
                        }

                        else if (dr["FieldTypeID"].ToString() == "22") //location
                        {
                            sb.Append("<input type='hidden' id='hdlocation' value='true'/>");
                        }

                        //put the hidden out of it
                        sb.Append("</td></tr>");
                    }
                }

                oneRowHTML.Replace("#makeofferblock#", ""); // In the end if there any placeholder exists...just remove it
                sb.Append("</table>");
            }
            //scripts
            sb.Append("<script type=\"text/javascript\"> ");
            //onfocus event
            sb.Append("function Focus(obj,title) {");
            sb.Append("var id = obj.id;");
            sb.Append("$('#sp_'+ id).html('');");
            sb.Append("$('#sp_error_'+ id).hide('');");
            sb.Append("if ($('#' + id).val() == title) {");
            sb.Append("$('#' + id).val('');");
            sb.Append("$('#' + id).removeClass('red');");
            //sb.Append("$('#' + id).removeClass('InnerTextBox');");
            sb.Append("}");
            sb.Append(" }");
            //on blur event
            sb.Append("function Blur(obj, title, regex, message) {");
            sb.Append("var id = obj.id;");
            sb.Append("if ($('#' + id).val() == '') {");
            sb.Append("$('#' + id).val(title);");
            //sb.Append("$('#' + id).addClass('InnerTextBox');");
            sb.Append("}");
            //regex 
            sb.Append("var Expression = new RegExp(regex);");//using its Regex
            sb.Append("if ($('#' + id).val().match(Expression) == null) {");
            sb.Append("if($('#' + id).val()!=title){");
            sb.Append("$('#sp_'+ id).html(message);");
            sb.Append("return false;");
            sb.Append("}");
            sb.Append("}");
            sb.Append(" }");
            sb.Append("</script>");
        }
        catch (Exception ex) { Web.LogError(ex); }
        result = sb.ToString();
        result = result.Replace("##REPLACE##", "<tr>" + oneRowHTML.ToString() + "</tr>");
        return result;
    }
    private void LoadCookies()
    {
        try
        {
            if (Web.IsMemberSession)
            {
                int MemberID = Web.SessionMembers.MemberID;
                string temp = "", cookieName = "PostingPreferences_" + MemberID;
                if (Request.Cookies[cookieName] != null)
                {
                    if (HttpContext.Current.Request.Browser.Cookies)
                    {
                        if (Request.Cookies[cookieName]["PostingType"] != null)
                        {
                            temp = Web.DecryptRijndaelManaged(Request.Cookies[cookieName]["PostingType"].ToString());
                            if (ddlPost.Items.FindByValue(temp) != null)
                            {
                                ddlPost.SelectedValue = temp;
                                if (temp.Contains("L_"))
                                {
                                    string[] str = Regex.Split(ddlPost.SelectedItem.Value, "_");
                                    int TypeID = Convert.ToInt32(str[1]);
                                    LoadListingCategories(TypeID);
                                }
                                else
                                    LoadCats(Convert.ToInt32(temp));
                                this.ddlCategory.Enabled = true;
                            }
                        }
                        if (Request.Cookies[cookieName]["CategoryID"] != null)
                        {
                            temp = Web.DecryptRijndaelManaged(Request.Cookies[cookieName]["CategoryID"].ToString());
                            if (ddlCategory.Items.FindByValue(temp) != null)
                            {
                                ddlCategory.SelectedValue = temp;
                                string script = "javascript: CallLoadControlsFromCookies('" + ddlPost.SelectedValue + "', '" + ddlCategory.SelectedValue + "'); ";
                                ClientScript.RegisterStartupScript(GetType(), "Javascript", script, true);
                            }
                        }

                        string type = ddlPost.SelectedValue;
                        if (type.Contains("L_"))
                        {
                            if (Request.Cookies[cookieName]["PaymentTypes"] != null)
                            {
                                ckhPaymentTypes.ClearSelection();
                                string strPaymentTypes = Request.Cookies[cookieName]["PaymentTypes"];
                                string[] PaymentTypes = Web.SplitByComma(strPaymentTypes);
                                foreach (string str in PaymentTypes)
                                {
                                    foreach (ListItem item in ckhPaymentTypes.Items)
                                    {
                                        if (item.Value == Web.DecryptRijndaelManaged(str))
                                            item.Selected = true;
                                    }
                                }
                            }

                            if (Request.Cookies[cookieName]["ShippingTypes"] != null)
                            {
                                chkShippingTypes.ClearSelection();
                                string strShippingTypes = Request.Cookies[cookieName]["ShippingTypes"];
                                string[] ShippingTypes = Web.SplitByComma(strShippingTypes);
                                foreach (string str in ShippingTypes)
                                {
                                    foreach (ListItem item in chkShippingTypes.Items)
                                    {
                                        if (item.Value == Web.DecryptRijndaelManaged(str))
                                            item.Selected = true;
                                    }
                                }
                            }

                            if (Request.Cookies[cookieName]["ShippingFee"] != null)
                                txtShippingFee.Text = Web.DecryptRijndaelManaged(Request.Cookies[cookieName]["ShippingFee"].ToString());
                            if (Request.Cookies[cookieName]["ShippingFeeUnit"] != null)
                                rdlShippingFeeUnitOrLot.SelectedIndex = Convert.ToInt32(Web.DecryptRijndaelManaged(Request.Cookies[cookieName]["ShippingFeeUnit"].ToString()));
                            if (Request.Cookies[cookieName]["AdditionalShippingFee"] != null)
                                txtAdditionalShippingFee.Text = Web.DecryptRijndaelManaged(Request.Cookies[cookieName]["AdditionalShippingFee"].ToString());
                            if (Request.Cookies[cookieName]["ShipTo"] != null)
                            {
                                temp = Web.DecryptRijndaelManaged(Request.Cookies[cookieName]["ShipTo"].ToString());
                                if (ddlShippingLocations.Items.FindByValue(temp) != null)
                                    ddlShippingLocations.SelectedValue = temp;
                            }
                        }
                    }
                    else
                        this.Master.ShowMessage("In order to save your selections, you need to enable cookies in your browser.", "");
                }
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }
    public void LoadrdbCity()
    {
        try
        {
            string country = null;

            if (Web.IsMemberSession)
            {
                string state = Web.SessionMembers.shippingAddress.State;
                string city = Web.SessionMembers.shippingAddress.City;

                // Specify the city, state and country of currnt user
                country = Country.GetCountry(Web.SessionMembers.shippingAddress.CountryID);
                city = string.Concat(city, ", ", state, ", ", country);
                //rdbCity.Text = city;
                lblShippingLocation.Text = country;
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }
    public void LoadShippingLocation()
    {
        DataTable result = null;
        try
        {
            result = ShippingLocationTypes.GetShippingLocations(1);
            ddlShippingLocations.DataSource = result;
            ddlShippingLocations.DataTextField = "ShippingLocationName";
            ddlShippingLocations.DataValueField = "ShippingLocationID";
            ddlShippingLocations.DataBind();
            //ddlShippingLocations.Items.Insert(0, new RadComboBoxItem("...Shipping Location...", "-1"));
            ddlShippingLocations.Items.Insert(0, new ListItem("...Shipping Location...", "-1"));

            ddlShippingLocations.Items.FindByText("See Description").Selected = true;
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }
    public void LoadPaymentOptions()
    {
        try
        {
            PaymentTypes paymentTypes = new PaymentTypes();
            paymentTypes.Query.AddOrderBy(PaymentTypesSchema.PaymentName);
            paymentTypes.Query.AddResultColumn(PaymentTypesSchema.PaymentName);
            paymentTypes.Query.AddResultColumn(PaymentTypesSchema.PaymentTypeID);
            paymentTypes.Query.AddResultColumn(PaymentTypesSchema.IsActive);
            paymentTypes.Where.IsActive.Value = 1;
            paymentTypes.Query.Load();

            ckhPaymentTypes.DataSource = paymentTypes.DefaultView.Table;
            ckhPaymentTypes.DataTextField = "PaymentName";
            ckhPaymentTypes.DataValueField = "PaymentTypeID";
            ckhPaymentTypes.DataBind();
            //ckhPaymentTypes.SelectedIndex = ckhPaymentTypes.Items.Count - 4;
            //ckhPaymentTypes.Items[3].Selected = true;

            for (int i = 0; i < ckhPaymentTypes.Items.Count; i++)
            {
                if (ckhPaymentTypes.Items[i].Text == "See Description")
                    ckhPaymentTypes.Items[i].Selected = true;
            }

        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }
    public void LoadShippingTypes()
    {
        try
        {
            ShippingTypes shippingTypes = new ShippingTypes();
            shippingTypes.Query.AddOrderBy(ShippingTypesSchema.ShippingName);
            shippingTypes.Query.AddResultColumn(ShippingTypesSchema.ShippingName);
            shippingTypes.Query.AddResultColumn(ShippingTypesSchema.ShippingTypeID);
            shippingTypes.Query.AddResultColumn(ShippingTypesSchema.IsActive);
            shippingTypes.Query.AddOrderBy(ShippingTypesSchema.ShippingTypeID, NCI.EasyObjects.WhereParameter.Dir.ASC);
            shippingTypes.Where.IsActive.Value = 1;
            shippingTypes.Query.Load();

            chkShippingTypes.DataSource = shippingTypes.DefaultView.Table;


            chkShippingTypes.DataTextField = "ShippingName";
            chkShippingTypes.DataValueField = "ShippingTypeID";
            chkShippingTypes.DataBind();
            chkShippingTypes.SelectedIndex = chkShippingTypes.Items.Count - 3;
            // ckhPaymentTypes.Items[7].Selected = true;

        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }
    public void LoadConditions()
    {
        try
        {
            if (!this.ddlPost.SelectedValue.ToUpper().StartsWith("L_"))
            {
                dvConditions.Visible = false;
                return;
            }
            DataTable conditions = new DataTable();
            if (!string.IsNullOrEmpty(this.ddlCategory.SelectedValue))
            {
                conditions = Conditions.GetCategoryConditions(Convert.ToInt32(this.ddlCategory.SelectedValue));
            }
            if (conditions.Rows.Count > 0)
            {
                ddlCondition.DataSource = conditions.DefaultView.Table;
                ddlCondition.DataTextField = "ConditionName";
                ddlCondition.DataValueField = "ConditionID";
                ddlCondition.DataBind();
                ddlCondition.Items.Insert(0, new ListItem("...Condition of the Item...", "-1"));
                dvConditions.Visible = true;
            }
            else
            {
                dvConditions.Visible = false;
            }

        }
        catch (Exception ex)
        {
            Web.LogError(ex);
            dvConditions.Visible = false;
        }
    }
    public void LoadMemberContactsList()
    {
        MemberContactList mList = new MemberContactList();
        mList.Where.MemberID.Value = Web.SessionMembers.MemberID;
        mList.Query.AddResultColumn(MemberContactListSchema.BatchNumber);
        mList.Query.AddResultColumn(MemberContactListSchema.ContactListName);
        mList.Query.Distinct = true;
        mList.Query.Load();

        //this.ddlMemberContacList.DataSource = mList.DefaultView;
        //this.ddlMemberContacList.DataTextField = "ContactListName";
        //this.ddlMemberContacList.DataValueField = "BatchNumber";
        //this.ddlMemberContacList.DataBind();
    }
    public void LoadPostingTypes()
    {
        try
        {
            ddlPost.Items.Clear();
            DataTable dtTypes = new DataTable();
            dtTypes = PostingTypes.GetPostingTypes();

            ddlPost.Items.Insert(0, new ListItem("----Choose a post type----", "-1"));

            //ddlPost.Items.Insert(0, new  RadComboBoxItem("----Choose a post type----", "-1"));
            foreach (DataRow dr in dtTypes.Rows)
            {
                //ddlPost.Items.Add(new RadComboBoxItem(dr["PostTypeName"].ToString(), dr["PostTypeID"].ToString()));
                ddlPost.Items.Add(new ListItem(dr["PostTypeName"].ToString(), dr["PostTypeID"].ToString()));
            }


            ddlPost.Items.Insert(4, new ListItem("===================================="));


            ddlPost.DataBind();
            LoadListingTypes();
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }
    public void LoadListingTypes()
    {
        try
        {
            DataTable LType = new DataTable();
            LType = ListingTypes.GetListingTypes();
            if (LType.Rows.Count > 0)
            {
                ListItem item = new ListItem("======================", "50000000");
                //RadComboBoxItem item = new RadComboBoxItem("======================", "50000000");
                item.Enabled = false;
                ddlPost.Items.Add(item);


                foreach (DataRow dR in LType.Rows)
                {
                    //ddlPost.Items.Add(new RadComboBoxItem(dR["ListingTypeName"].ToString(), "L_" + dR["ListingTypeID"].ToString()));

                    ddlPost.Items.Add(new ListItem(dR["ListingTypeName"].ToString(), "L_" + dR["ListingTypeID"].ToString()));
                }
            }
            ddlPost.DataBind();
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }
    public void LoadListingCategories(int ListTypeID)
    {
        try
        {
            ddlCategory.Items.Clear();
            DataTable dtCats = new DataTable();
            dtCats = CategorizedListingTypes.GetAllListingTypeCategories(ListTypeID);

            foreach (DataRow dr in dtCats.Rows)
            {
                //ddlCategory.Items.Add(new RadComboBoxItem(dr["CategoryName"].ToString(), dr["CategoryID"].ToString()));
                ddlCategory.Items.Add(new ListItem(dr["CategoryName"].ToString(), dr["CategoryID"].ToString()));
            }
            //ddlCategory.Items.Insert(0, new RadComboBoxItem("...Choose a Category...", "-1"));
            ddlCategory.Items.Insert(0, new ListItem("...Choose a Category...", "-1"));
            ddlCategory.SelectedIndex = 0;
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }


    public void LoadCats(int PostTypeID)
    {
        this.ddlCategory.Items.Clear();
        int cycle = 0;
        DataSet dsCats = new DataSet();
        dsCats = CategorizedPostingTypes.GetCategorizedPostingTypes(PostTypeID, Web.SessionMembers.MemberID);
        foreach (DataTable dt in dsCats.Tables)
        {
            foreach (DataRow dr in dt.Rows)
            {
                //ddlCategory.Items.Add(new RadComboBoxItem(dr["CategoryName"].ToString(), dr["CategoryID"].ToString()));
                ddlCategory.Items.Add(new ListItem(dr["CategoryName"].ToString(), dr["CategoryID"].ToString()));
            }
            if (cycle == 0)
            {
                //RadComboBoxItem item = new RadComboBoxItem("======================", "50000000");
                ListItem item = new ListItem("======================", "50000000");
                item.Enabled = false;
                ddlCategory.Items.Add(item);
            }
            cycle++;
        }
        //ddlCategory.Items.Insert(0, new RadComboBoxItem("...Choose a Category...", "-1"));
        ddlCategory.Items.Insert(0, new ListItem("...Choose a Category...", "-1"));
        ddlCategory.DataBind();
    }
    protected void ddlPost_SelectedIndexChanged(object o, RadComboBoxSelectedIndexChangedEventArgs e)
    {
        try
        {
            if (ddlPost.SelectedItem.Value.Contains("L_"))
            {
                string[] str = Regex.Split(ddlPost.SelectedItem.Value, "_");
                int TypeID = Convert.ToInt32(str[1]);
                LoadListingCategories(TypeID);
            }
            else
            {
                LoadCats(Convert.ToInt32(ddlPost.SelectedItem.Value));
            }
            this.ddlCategory.Enabled = true;
        }
        catch (Exception ex) { Web.LogError(ex); }
    }
    protected void chkShippingTypes_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            txtShippingFee.Enabled = rdlShippingFeeUnitOrLot.Enabled = txtAdditionalShippingFee.Enabled = true;
            foreach (ListItem item in chkShippingTypes.Items)
                item.Enabled = true;

            if (chkShippingTypes.SelectedItem != null)
            {
                if (chkShippingTypes.SelectedItem.Text.Contains("buyer") || chkShippingTypes.SelectedItem.Text.Contains("Buyer"))
                {
                    if (chkShippingTypes.SelectedItem.Selected == true)
                    {
                        foreach (ListItem item in chkShippingTypes.Items)
                            if (!(item.Text.Contains("buyer") || item.Text.Contains("Buyer")))
                                item.Enabled = item.Selected = false;

                        txtShippingFee.Enabled = rdlShippingFeeUnitOrLot.Enabled = txtAdditionalShippingFee.Enabled = false;
                        txtShippingFee.Text = txtAdditionalShippingFee.Text = "";
                    }
                }
            }
        }
        catch (Exception ex) { Web.LogError(ex); }
    }
    protected void btnPost_Click(object sender, EventArgs e)
    {
        try
        {
            string type = ddlPost.SelectedValue;
            if (!type.Contains("L_")) // posting
            {
                SavePosting();
            }
        }
        catch (Exception ex) { Web.LogError(ex); }
    }
    private void SavePosting()
    {
        //    Response.End();

        try
        {
            //string PostTo = Request["Action"];
            int PrivacyTypeID = GetPrivacyTypeID(Request["Action"]);

            string data = this.hdData.Value;


            //if Formated Text Area is not null
            if (this.txtFormatedText.Text.Length > 0)
            {
                var dat = Server.HtmlEncode(this.txtFormatedText.Text);

                dat = dat.Replace(",", "~");
                data = dat + "_" + this.hdData.Value.Split('_')[1];
            }

            string strObjID = "";
            if (!string.IsNullOrEmpty(data))
            {
                int memberID = Web.SessionMembers.MemberID;
                try
                {
                    string activityTitle = "";
                    if (Web.IsAction("tomembercoupons"))
                    {
                        activityTitle = "Member Coupons";
                    }
                    else
                    {
                        activityTitle = ddlPost.SelectedItem.Text;
                        if (activityTitle.ToLower().StartsWith("a") || activityTitle.ToLower().StartsWith("o") || activityTitle.ToLower().StartsWith("i") || activityTitle.ToLower().StartsWith("e") || activityTitle.ToLower().StartsWith("u"))
                            activityTitle = " added an " + ddlPost.SelectedItem.Text;
                        else
                            activityTitle = " added a " + ddlPost.SelectedItem.Text;
                    }

                    //insert this activity in MemeberActivityLog table
                    Members m = new Members();
                    m.LoadByPrimaryKey(memberID);

                    MemberActivityLog log = new MemberActivityLog();
                    log.AddNew();
                    log.ActivityID = 45;
                    log.MemberID = memberID;
                    log.ActivityDate = DateTime.Now;
                    log.IsActive = 1;
                    log.IsPrivate = 0;
                    log.Description = activityTitle;

                    if (Web.IsAction("tomembercoupons"))
                    {
                        log.s_PostTypeID = "7";
                        log.s_CategoryID = "4679";
                    }
                    else
                    {
                        log.s_PostTypeID = ddlPost.SelectedItem.Value;
                        log.s_CategoryID = ddlCategory.SelectedItem.Value;
                    }

                    //post to..
                    log.PrivacyTypeID = PrivacyTypeID;
                    //log.Description = m.UserName + activityTitle; 
                    log.s_IsPosting = "1";

                    //separat the value and id from data comming from ajax call
                    //to insert into PostingExtendedFields table
                    string[] values = { };
                    values = Regex.Split(data, ",");
                    int fieldID;
                    string value;
                    PostingExtendedFields fields = null;
                    foreach (var item in values)
                    {
                        if (item == "") break;
                        string[] splitIDnValue = { };
                        splitIDnValue = Regex.Split(item, "_");
                        fieldID = Convert.ToInt32(splitIDnValue[1]);
                        value = splitIDnValue[0].ToString();
                        try
                        {
                            if (value.Contains("~"))
                                value = value.Replace("~", ",");

                            value = value.Replace("^", "'");
                            value = value.Replace("*", ",");
                            value = value.Trim();
                            if (!String.IsNullOrEmpty(value))
                            {
                                log.Save();
                                int objID = log.ActivityLogID;
                                //convert if there is url
                                value = Web.ConvertToTinyURL(value);
                                value = value.Replace("\r\n", "</br>");
                                fields = new PostingExtendedFields();
                                fields.AddNew();
                                fields.Data = Web.GetCleanHTML(value);
                                fields.FieldID = fieldID;
                                fields.EntryTime = DateTime.Now;
                                fields.IsActive = 1;

                                fields.ObjectID = objID;
                                fields.SystemObjectID = (int)SystemObjects.Posts;
                                fields.Save();

                                strObjID = fieldID.ToString();

                                //call none static method save file
                                Web.SaveFiles(Convert.ToInt32(SystemObjects.Posts), objID, fupPhoto, fupDocument, txtLink, txtURL, PrivacyTypeID);

                                AddCookie();



                                Web.Redirect("~/Live.aspx");
                            }
                            else
                            {
                                this.Master.ShowMessage("Please add Posting Description.", "");
                                string script = "javascript: CallLoadControlsFromCookies('" + ddlPost.SelectedValue + "', '" + ddlCategory.SelectedValue + "'); ";
                                ClientScript.RegisterStartupScript(GetType(), "Javascript", script, true);
                            }

                        }
                        catch (Exception exp)
                        {
                            Web.LogError(exp);
                        }
                    }
                }
                catch (Exception ee)
                {
                    Web.LogError(ee);
                }
            }
        }

        catch (System.Threading.ThreadAbortException ex)
        {
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
            Session["Message"] = "There was some problem while saving the post, please try again.";
            Web.Redirect("~/Post.aspx");
        }

        Web.Redirect("~/Live.aspx");
    }
    private static int GetPrivacyTypeID(string action)
    {
        int PrivacyTypeID = 0;
        switch (action)
        {
            case "worldwide":
                {
                    PrivacyTypeID = 1;
                    break;
                }
            case "toallvendors":
                {
                    PrivacyTypeID = 2;
                    break;
                }
            case "toallclients":
                {
                    PrivacyTypeID = 3;
                    break;
                }
            case "tolinkings":
                {
                    PrivacyTypeID = 4;
                    break;
                }
            case "tomembercoupons":
                {
                    PrivacyTypeID = 4;
                    break;
                }

            default:
                break;
        }

        return PrivacyTypeID;
    }
    private void AddCookie()
    {
        try
        {
            if (Web.IsMemberSession)
            {
                string cookieName = "PostingPreferences_" + Web.SessionMembers.MemberID;
                if (chkRememberShipping.Checked || chkRememberPayment.Checked)
                {
                    if (HttpContext.Current.Request.Browser.Cookies)
                    {
                        if (Request.Cookies[cookieName] == null)
                        {
                            HttpCookie listingPreferences = new HttpCookie(cookieName);
                            listingPreferences.Values["PostingType"] = Web.EncryptRijndaelManaged(ddlPost.SelectedValue);
                            listingPreferences.Values["CategoryID"] = Web.EncryptRijndaelManaged(ddlCategory.SelectedValue);

                            string type = ddlPost.SelectedValue;
                            if (type.Contains("L_"))
                            {
                                if (chkRememberPayment.Checked)
                                {
                                    listingPreferences.Values["PaymentTypes"] = GetSelectedPaymentTypes();
                                }
                                if (chkRememberShipping.Checked)
                                {
                                    listingPreferences.Values["ShippingTypes"] = GetSelectedShippingTypes();
                                    listingPreferences.Values["ShippingFee"] = Web.EncryptRijndaelManaged(txtShippingFee.Text);
                                    listingPreferences.Values["ShippingFeeUnit"] = Web.EncryptRijndaelManaged(rdlShippingFeeUnitOrLot.SelectedIndex.ToString());
                                    listingPreferences.Values["AdditionalShippingFee"] = Web.EncryptRijndaelManaged(txtAdditionalShippingFee.Text);
                                    listingPreferences.Values["ShipTo"] = Web.EncryptRijndaelManaged(ddlShippingLocations.SelectedValue);
                                }
                            }
                            listingPreferences.Expires = DateTime.MaxValue;
                            Response.Cookies.Add(listingPreferences);
                        }
                        else
                        {
                            Response.Cookies[cookieName]["PostingType"] = Web.EncryptRijndaelManaged(ddlPost.SelectedValue);
                            Response.Cookies[cookieName]["CategoryID"] = Web.EncryptRijndaelManaged(ddlCategory.SelectedValue);

                            string type = ddlPost.SelectedValue;
                            if (type.Contains("L_"))
                            {
                                if (chkRememberPayment.Checked)
                                {
                                    Response.Cookies[cookieName]["PaymentTypes"] = GetSelectedPaymentTypes();
                                }
                                else
                                {
                                    if (Request.Cookies[cookieName]["PaymentTypes"] != null)
                                        Response.Cookies[cookieName]["PaymentTypes"] = Request.Cookies[cookieName]["PaymentTypes"];
                                }

                                if (chkRememberShipping.Checked)
                                {
                                    Response.Cookies[cookieName]["ShippingTypes"] = GetSelectedShippingTypes();
                                    Response.Cookies[cookieName]["ShippingFee"] = Web.EncryptRijndaelManaged(txtShippingFee.Text);
                                    Response.Cookies[cookieName]["ShippingFeeUnit"] = Web.EncryptRijndaelManaged(rdlShippingFeeUnitOrLot.SelectedIndex.ToString());
                                    Response.Cookies[cookieName]["AdditionalShippingFee"] = Web.EncryptRijndaelManaged(txtAdditionalShippingFee.Text);
                                    Response.Cookies[cookieName]["ShipTo"] = Web.EncryptRijndaelManaged(ddlShippingLocations.SelectedValue);
                                }
                                else
                                {
                                    if (Request.Cookies[cookieName]["ShippingTypes"] != null)
                                        Response.Cookies[cookieName]["ShippingTypes"] = Request.Cookies[cookieName]["ShippingTypes"];
                                    if (Request.Cookies[cookieName]["ShippingFee"] != null)
                                        Response.Cookies[cookieName]["ShippingFee"] = Request.Cookies[cookieName]["ShippingFee"];
                                    if (Request.Cookies[cookieName]["ShippingFeeUnit"] != null)
                                        Response.Cookies[cookieName]["ShippingFeeUnit"] = Request.Cookies[cookieName]["ShippingFeeUnit"];
                                    if (Request.Cookies[cookieName]["AdditionalShippingFee"] != null)
                                        Response.Cookies[cookieName]["AdditionalShippingFee"] = Request.Cookies[cookieName]["AdditionalShippingFee"];
                                    if (Request.Cookies[cookieName]["ShipTo"] != null)
                                        Response.Cookies[cookieName]["ShipTo"] = Request.Cookies[cookieName]["ShipTo"];
                                }
                            }
                            Response.Cookies[cookieName].Expires = DateTime.MaxValue;
                        }
                    }
                    else
                        this.Master.ShowMessage("In order to save your selections for future listings, you need to enable cookies on your browser.", "");
                }
                else Web.ExpireCookie(cookieName);
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }
    private string GetSelectedPaymentTypes()
    {
        System.Text.StringBuilder paymentTypes = new System.Text.StringBuilder();
        foreach (ListItem item in ckhPaymentTypes.Items)
        {
            if (item.Selected)
            {
                paymentTypes.Append(Web.EncryptRijndaelManaged(item.Value));
                paymentTypes.Append(",");
            }
        }
        string types = paymentTypes.ToString();
        types = types.Substring(0, types.Length - 1);
        return types;
    }
    private string GetSelectedShippingTypes()
    {
        System.Text.StringBuilder shippingTypes = new System.Text.StringBuilder();
        foreach (ListItem item in chkShippingTypes.Items)
        {
            if (item.Selected)
            {
                shippingTypes.Append(Web.EncryptRijndaelManaged(item.Value));
                shippingTypes.Append(",");
            }
        }
        string types = shippingTypes.ToString();
        types = types.Substring(0, types.Length - 1);
        return types;
    }
    protected void btnList_Click(object sender, EventArgs e)
    {
        try
        {
            string type = ddlPost.SelectedValue;
            if (type.Contains("L_")) // listing
            {
                SaveListing(type);
            }
        }
        catch (Exception ex) { Web.LogError(ex); }
    }
    private void SaveListing(string type)
    {

        //   Response.End();

        try
        {
            string[] str = Regex.Split(type, "_");
            int TypeID = Convert.ToInt32(str[1]);

            string duration = hdDdlDuration.Value;
            string strObjID = "";
            int memberID = Web.SessionMembers.MemberID;

            string data = this.hdData.Value;

            //if Formated Text Area is not null
            if (this.txtFormatedText.Text.Length > 0)
            {
                var dat = this.txtFormatedText.Text;
                dat = dat.Replace(",", "~");
                data += dat + "_" + EditorID;
            }
            if (!string.IsNullOrEmpty(data))
            {
                bool ApprovedMember = ApprovedMembers.CheckIfApproved(Web.SessionMembers.MemberID);
                int CategoryID = Convert.ToInt32(ddlCategory.SelectedValue);
                List<int> categoryFields = CategoryFields.GetCategoryFields(TypeID, CategoryID);

                Listings list = new Listings();
                list.AddNew();
                list.ListingEndDate = (!String.IsNullOrEmpty(duration)) ? DateTime.Now.AddDays(Convert.ToInt32(duration)) : DateTime.Now.AddDays(14);
                list.MemberID = memberID;
                list.IsActive = 1;
                list.StatusCode = (ApprovedMember) ? 100 : 200;
                list.CategoryID = CategoryID;
                list.ListingTypeID = TypeID;

                if (categoryFields.Contains(14))
                {
                    if (ddlCondition.Visible == true)
                    {
                        if (ddlCondition.SelectedItem.Text != "...Condition of the Item...")
                        {
                            list.ConditionID = Convert.ToInt32(ddlCondition.SelectedValue);
                        }
                    }
                }

                if (categoryFields.Contains(12))
                {
                    if (ddlShippingLocations.Visible == true)
                    {
                        if (ddlShippingLocations.SelectedItem.Text != "...Shipping Location...")
                        {
                            list.ShippingLocationID = Convert.ToInt32(ddlShippingLocations.SelectedValue);
                        }
                    }

                    // if(Payment.Visible==true)

                    if (txtShippingFee.Text != "")
                    {
                        if (rdlShippingFeeUnitOrLot.SelectedValue == "1")
                        {
                            list.ShippingFeeUnit = 1;
                            list.ShippingFee = Convert.ToDecimal(txtShippingFee.Text);
                        }

                        else if (rdlShippingFeeUnitOrLot.SelectedValue == "0")
                        {
                            list.ShippingFeeUnit = 0;
                            list.ShippingFee = Convert.ToDecimal(txtShippingFee.Text);
                        }

                    }

                    if (txtAdditionalShippingFee.Text != "")
                    {
                        list.AdditionalFee = Convert.ToDecimal(txtAdditionalShippingFee.Text);
                    }
                }

                list.ListingDate = DateTime.Now;
                list.IsPrivate = 0;
                list.Save();

                //separate the value and id from data comming from ajax call
                //to insert into ListingExtendedFields table
                string title = "";
                int objectID = list.ListingID;
                string[] values = { };
                values = Regex.Split(data, ",");
                int fieldID;
                string value;
                ListingExtendedFields LFields = null;
                bool isZeroPrice = false;
                foreach (var item in values)
                {

                    if (item == "") break;
                    string[] splitIDnValue = { };
                    splitIDnValue = Regex.Split(item, "_");
                    fieldID = Convert.ToInt32(splitIDnValue[splitIDnValue.Length - 1]);

                    if (categoryFields.Contains(fieldID))
                    {
                        value = item.Substring(0, item.Length - (item.Length - item.IndexOf("_" + fieldID)));
                        value = value.Trim();
                        if (!String.IsNullOrEmpty(value))
                        {
                            try
                            {
                                if (fieldID == 20)
                                    title = value;
                                if (fieldID == 10 && value == "0")
                                    isZeroPrice = true;

                                value = value.Replace("^", "'");
                                value = value.Replace("*", ",");
                                LFields = new ListingExtendedFields();
                                LFields.AddNew();

                                if (fieldID == 24 && isZeroPrice)
                                    LFields.Data = "True";
                                else
                                    LFields.Data = Web.GetCleanHTML(value);

                                LFields.FieldID = fieldID;
                                LFields.EntryTime = DateTime.Now;
                                LFields.IsActive = 1;

                                LFields.ObjectID = objectID;
                                LFields.SystemObjectID = (int)SystemObjects.Listings;
                                LFields.Save();

                                strObjID = fieldID.ToString();
                            }

                            catch (Exception exp)
                            {
                                Web.LogError(exp);
                            }
                        }
                    }
                }

                SaveAdditionalInfo(list.ListingID, categoryFields);
                AddCookie();

                if (ApprovedMember)
                {
                    Session["Message"] = "Listing " + "\"" + title + "\"" + " has been posted successfully.";
                    var templateKeys = new System.Collections.Specialized.StringDictionary();
                    templateKeys.Add("#listingtype#", ListingTypes.GetTypeName(list.ListingTypeID));
                    templateKeys.Add("#listingname#", title);
                    templateKeys.Add("#viewlink#", "../MarketPlace/ItemDetails.aspx?Action=View&RecordID=#encrypt#" + list.ListingID + "#endencrypt#");

                    Web.AddActivityLog(Web.SessionMembers.MemberID, 46, templateKeys, list.ListingID, list.ListingTypeID, false, GetPrivacyTypeID(Request["Action"]));

                    try
                    {
                        var TemplateKeys = new System.Collections.Specialized.StringDictionary();
                        TemplateKeys.Add("#email_header#", Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER"));
                        TemplateKeys.Add("#fullname#", Web.SessionMembers.FullName);
                        TemplateKeys.Add("#lot_title#", title);
                        TemplateKeys.Add("#dealing_floor_summary#", Web.SystemConfigs.GetKey("SITE_URL") + "MarketPlace/");
                        TemplateKeys.Add("#link_log_myeoffer#", Web.SystemConfigs.GetKey("SITE_URL"));
                        TemplateKeys.Add("#email_footer#", Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER"));
                        Web.SendMail(Web.SessionMembers.Email, Web.SystemConfigs.GetKey("REG_EMAIL"), 308, TemplateKeys);
                    }
                    catch (Exception ex)
                    {
                        Web.LogError(ex);
                    }
                }
                else
                {
                    Session["POST_MESSAGE"] = @"Success! Your new listing is being reviewed by the administrator and will post to the Marketplace shortly.<br /><br />Please note: If you would like to be preapproved for automatic posting, please complete your company profile. Upon clearance, all your listings will immediately appear in the Marketplace";

                    Session["Message"] = "The listing " + "\"" + title + "\"" + " is under review, it will be posted live shortly after administrative approval.";
                }

                Web.Redirect("~/MarketPlace/Default.aspx");
            }
        }
        catch (System.Threading.ThreadAbortException ee)
        {
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
            Session["Message"] = "There was some problem while saving the post, please try again.";
            Web.Redirect("~/Post.aspx?" + Request.Url.Query);
        }
    }
    private void SaveAdditionalInfo(int ListingID, List<int> categoryFields)
    {
        try
        {
            if (categoryFields.Contains(12))
            {
                ListingShippingTypes ShipTypes = null;
                foreach (ListItem sTypes in chkShippingTypes.Items)
                {
                    if (sTypes.Selected == true)
                    {
                        ShipTypes = new ListingShippingTypes();
                        ShipTypes.AddNew();
                        ShipTypes.ShippingTypeID = Convert.ToInt32(sTypes.Value);
                        ShipTypes.ListingID = ListingID;
                        ShipTypes.Save();
                    }
                }
            }

            if (categoryFields.Contains(13))
            {
                ListingPaymentTypes PaymentTypes = null;
                foreach (ListItem pTypes in ckhPaymentTypes.Items)
                {
                    if (pTypes.Selected == true)
                    {
                        PaymentTypes = new ListingPaymentTypes();
                        PaymentTypes.AddNew();
                        PaymentTypes.ListingID = ListingID;
                        PaymentTypes.PaymentTypeID = Convert.ToInt32(pTypes.Value);
                        PaymentTypes.Save();
                    }
                }
            }

            if (categoryFields.Contains(15))
            {
                Web.SaveFiles(Convert.ToInt32(SystemObjects.Listings), ListingID, fupPhoto, fupDocument, txtLink, txtURL, 1);
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }

    protected void ddlPost_SelectedIndexChanged1(object sender, EventArgs e)
    {
        try
        {
            dvConditions.Visible = false;

            if (ddlPost.SelectedItem.Value == "L_1")
            {
                imageselectedpost.ImageUrl = "App_Themes/Space/Images/eOpen post_tp_world Icons/sell.png";
                lblselectepost.Text = ddlPost.SelectedItem.Text;
            }
            else if (ddlPost.SelectedItem.Value == "L_2")
            {
                imageselectedpost.ImageUrl = "App_Themes/Space/Images/eOpen post_tp_world Icons/rent.png";
                lblselectepost.Text = ddlPost.SelectedItem.Text;
            }
            else if (ddlPost.SelectedItem.Value == "L_3")
            {
                imageselectedpost.ImageUrl = "App_Themes/Space/Images/eOpen post_tp_world Icons/service.png";
                lblselectepost.Text = ddlPost.SelectedItem.Text;
            }
            else if (ddlPost.SelectedItem.Value == "L_4")
            {
                imageselectedpost.ImageUrl = "App_Themes/Space/Images/eOpen post_tp_world Icons/jobs.png";
                lblselectepost.Text = ddlPost.SelectedItem.Text;
            }
            else if (ddlPost.SelectedItem.Value == "L_5")
            {
                imageselectedpost.ImageUrl = "App_Themes/Space/Images/eOpen post_tp_world Icons/personal.png";
                lblselectepost.Text = ddlPost.SelectedItem.Text;
            }
            else if (ddlPost.SelectedItem.Value == "L_6")
            {
                imageselectedpost.ImageUrl = "App_Themes/Space/Images/eOpen post_tp_world Icons/sale.png";
                lblselectepost.Text = ddlPost.SelectedItem.Text;
            }
            else if (ddlPost.SelectedItem.Value == "1")
            {
                imageselectedpost.ImageUrl = "App_Themes/Space/Images/eOpen post_tp_world Icons/1335619303_TextEdit.png";
                lblselectepost.Text = ddlPost.SelectedItem.Text;
            }
            else if (ddlPost.SelectedItem.Value == "2")
            {
                imageselectedpost.ImageUrl = "App_Themes/Space/Images/eOpen post_tp_world Icons/newsticker.png";
                lblselectepost.Text = ddlPost.SelectedItem.Text;
            }
            else if (ddlPost.SelectedItem.Value == "4")
            {
                imageselectedpost.ImageUrl = "App_Themes/Space/Images/eOpen post_tp_world Icons/event.png";
                lblselectepost.Text = ddlPost.SelectedItem.Text;
            }

            imageselectedpost.Visible = true;
            lblselectepost.Visible = true;
            lowercontentdiv.Visible = true;


            if (ddlPost.SelectedItem.Value.Contains("L_"))
            {
                string[] str = Regex.Split(ddlPost.SelectedItem.Value, "_");
                int TypeID = Convert.ToInt32(str[1]);
                LoadListingCategories(TypeID);
            }
            else
            {
                LoadCats(Convert.ToInt32(ddlPost.SelectedItem.Value));


            }
            this.ddlCategory.Enabled = true;

        }
        catch (Exception ex) { Web.LogError(ex); }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Web.Redirect("Live.aspx");
    }
    protected void ddlCategory_SelectedIndexChanged(object sender, EventArgs e)
    {
        LoadConditions();
    }
    protected void img_Click(object sender, CommandEventArgs e)
    {
        try
        {
            string[] command = e.CommandArgument.ToString().Split('&');

            ddlPost.SelectedValue = command[0];

            lowercontentdiv.Style.Add("display", "block");

            lblselectepost.Visible = true;
            lblselectepost.Text = ddlPost.SelectedItem.Text;

            imageselectedpost.Visible = true;
            imageselectedpost.ImageUrl = command[1];




            if (command[0].Contains("L_"))
            {
                string[] str = Regex.Split(command[0], "_");
                int TypeID = Convert.ToInt32(str[1]);
                LoadListingCategories(TypeID);
            }
            else
            {
                LoadCats(Convert.ToInt32(command[0]));
            }
            this.ddlCategory.Enabled = true;
            SearchForLinkAppdiv.Visible = false;

        }
        catch (Exception ex) { Web.LogError(ex); }
    }


}