﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Mobile.App;
using CodenameRabbitFoot.BusinessLogic;
using System.Data;
using System.Xml.Linq;

public partial class M_Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    public static IEnumerable<Item> GetMarketPlace(int pageIndex, int pageSize)
    {
        string memberID = "0";
        int ListingTypeID = -1, CategoryID = -1;
        List<Item> itemCollection = new List<Item>();
        memberID = Secure.Decrypt(memberID);
        IEnumerable<DataRow> allRows = Listings.FilterListings(ListingTypeID, CategoryID, -1, "", "-1", -1, 0, Convert.ToInt32(memberID)).AsEnumerable();
        IEnumerable<DataRow> dataRows = allRows.Skip((pageIndex - 1) * pageSize).Take(pageSize);

        foreach (DataRow item in dataRows)
        {
            Item newItem = new Item();
            newItem.ItemID = Secure.Encrypt(item["ListingID"]);
            newItem.Quantity = item["Quantity"].ToString();
            newItem.Thumbnail = item["ThumbnailURL"].ToString() == "" ? getDefaultImage(Convert.ToInt32(item["ListingTypeID"].ToString())).ToString() : item["ThumbnailURL"].ToString();
            newItem.ItemTitle = Utils.GetReducedString(item["Title"].ToString(), 35);
            newItem.ItemStatus = item["StatusName"].ToString();
            newItem.ItemDetail = "";
            string priceText = "";
            try
            {
                if (!string.IsNullOrEmpty(item.ItemArray[10].ToString()))
                    priceText = "$" + item.ItemArray[10].ToString() + " per listing";

                if (!string.IsNullOrEmpty(item.ItemArray[4].ToString()))
                {
                    var listingData = from d in XDocument.Parse("<listings>" + item.ItemArray[4].ToString() + "</listings>").Root.Descendants()
                                      select new
                                      {
                                          FieldID = d.Attribute("FieldID").Value,
                                          FieldName = d.Attribute("FieldName").Value,
                                          Data = d.Attribute("Data") == null ? "" : d.Attribute("Data").Value
                                      };

                    if (listingData.Count() > 0)
                    {
                        bool isOffer = false;

                        foreach (var i in listingData)
                        {
                            if (i.FieldName.Equals("MakeOffer") && Convert.ToBoolean(i.Data))
                            {
                                priceText = "Make an Offer";
                                isOffer = true;
                            }
                            else
                            {
                                if (i.FieldName.Equals("PriceEach") && !isOffer)
                                {
                                    try
                                    {
                                        double priceeach = Convert.ToDouble(i.Data);
                                        if (priceeach == 0)
                                            priceText = "Make an Offer";
                                        else
                                            priceText = "$" + i.Data + " per Item";
                                    }
                                    catch { priceText = ""; }
                                }
                            }
                        }
                    }
                }
            }
            catch { }
            newItem.Price = priceText;
            itemCollection.Add(newItem);
        }

        return itemCollection;
    }

    private static object getDefaultImage(int listingTypeID)
    {
        switch (listingTypeID)
        {
            case 1:
                return "../App_Themes/Space/Images/eOpen post_tp_world Icons/sale_50_x_50.png";
            case 2:
                return "../App_Themes/Space/Images/eOpen post_tp_world Icons/rent_50_x_50.png";
            case 3:
                return "../App_Themes/Space/Images/eOpen post_tp_world Icons/service_50_x_50.png";
            case 4:
                return "../App_Themes/Space/Images/eOpen post_tp_world Icons/jobs_50_x_50.png";
            case 5:
                return "../App_Themes/Space/Images/eOpen post_tp_world Icons/personal_50_x_50.png";
            case 6:
                return "../App_Themes/Space/Images/eOpen post_tp_world Icons/coupon_50_x_50.png";
            case 7:
                return "../App_Themes/Space/Images/eOpen post_tp_world Icons/coupon_50_x_50.png";
            case 8:
                return "/Images/noimage.png";
            default:
                return "/Images/noimage.png";
        }
    }

}