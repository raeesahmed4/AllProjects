﻿function printdoc() {
    window.print();
}

 function SelectAllCheckboxes(spanChk) {
    var oItem = spanChk.children;
    var theBox = (spanChk.type == "checkbox") ? spanChk : spanChk.children.item[0];
    xState = theBox.checked;
    elm = theBox.form.elements;
    for (i = 0; i < elm.length; i++) {
        if (elm[i].type == "checkbox" && elm[i].id != theBox.id) {
            if (elm[i].checked != xState) { elm[i].click(); } 
        } 
    }
}
function loginShow() 
{
   $("#loginpaneid").show();
   $("#loginbtn").hide();
}

function OpenBillboardCommentBox() {
    try {
        var div_ = document.getElementById('NewBillboardComment');
        if (document.getElementById(div_.id).style.display == "none") {
            document.getElementById(div_.id).style.display = "block";
        }
        var txt = document.getElementById('ctl00_ContentBody_txtBillboardComment_txtContent');
        txt.focus();
    }
    catch (e) {
        document.getElementById('NewBillboardComment').style.display = "none";
    }
}
function OpenCommentBox(ID) {
    try {
        displayCommentBox('CommentDiv_' + ID, ID, '<%# ((GridViewRow)Container).FindControl("txtComments").ClientID %>');
    } catch (e) {}
}
function displayCommentBox(commentDiv, ID, txt) {
    if (document.getElementById(commentDiv).style.display == "block") {
        document.getElementById(commentDiv).style.display = "none";
    }
    else {
        var textdiv = document.getElementById(commentDiv);
        textdiv.style.display = "block";
        var txtbox = document.getElementById(txt);
        document.getElementById(txt + "_txtContent").focus();
        document.getElementById(txt + "_txtContent").select(); 
    }
}
function ToggleEnabling(ControlID) {
    if (document.getElementById(ControlID).disabled == false)
        document.getElementById(ControlID).disabled = true;
    else
        document.getElementById(ControlID).disabled = false;
}
function ToggleDisplay(ControlID) {
    if (document.getElementById(ControlID).style.display == "none")
        document.getElementById(ControlID).style.display = "block";
    else
        document.getElementById(ControlID).style.display = "none";
}
function Show(ControlID) {
    document.getElementById(ControlID).style.display = "block";
}
function Hide(ControlID)
{ document.getElementById(ControlID).style.display = "none"; }
function ShowHide(ControlID1, ControlID2) {
    document.getElementById(ControlID1).style.display = "none";
    document.getElementById(ControlID2).style.display = "block";
}
function ShowHideInline(ControlID1, ControlID2) {
    document.getElementById(ControlID1).style.display = "none";
    document.getElementById(ControlID2).style.display = "inline";
}
function showDiv(DivID) {
    if (document.getElementById(DivID + "Panel").style.display == "none") {
        document.getElementById(DivID + "Panel").style.display = "block";
        document.getElementById(DivID + "Collapse").style.display = "block";
        document.getElementById(DivID + "Expand").style.display = "none";
    }
    else {
        document.getElementById(DivID + "Panel").style.display = "none";
        document.getElementById(DivID + "Collapse").style.display = "none";
        document.getElementById(DivID + "Expand").style.display = "block";
    }
}
function SelectAllCheckboxes(spanChk) {
    var oItem = spanChk.children;
    var theBox = (spanChk.type == "checkbox") ? spanChk : spanChk.children.item[0];
    xState = theBox.checked;
    elm = theBox.form.elements;
    for (i = 0; i < elm.length; i++)
        if (elm[i].type == "checkbox" && elm[i].id != theBox.id) {
        if (elm[i].checked != xState)
            elm[i].click();
    }
}
function SelectAllCheckboxes(spanChk,name,length) {
    var oItem = spanChk.children;
    var theBox = (spanChk.type == "checkbox") ? spanChk : spanChk.children.item[0];
    xState = theBox.checked;
    elm = theBox.form.elements;
    for (i = 0; i < elm.length; i++)
        if (elm[i].type == "checkbox" && elm[i].id != theBox.id) {
            var index = elm[i].id.length - length;
        if (elm[i].id.substring(index, index + length) == name)
            if (elm[i].checked != xState)
            elm[i].click();
    }
}
function OnTreeClick(evt) {
    var src = window.event != window.undefined ? window.event.srcElement : evt.target;
    var isChkBoxClick = (src.tagName.toLowerCase() == "input" && src.type == "checkbox");
    if (isChkBoxClick) {
        var parentTable = GetParentByTagName("table", src);
        var nxtSibling = parentTable.nextSibling;
        if (nxtSibling && nxtSibling.nodeType == 1)
        {
            if (nxtSibling.tagName.toLowerCase() == "div")
            {
                CheckUncheckChildren(parentTable.nextSibling, src.checked);
            }
        }
        CheckUncheckParents(src, src.checked);
    }
}
function CheckUncheckChildren(childContainer, check) {
    var childChkBoxes = childContainer.getElementsByTagName("input");
    var childChkBoxCount = childChkBoxes.length;
    for (var i = 0; i < childChkBoxCount; i++) {
        childChkBoxes[i].checked = check;
    }
}
function CheckUncheckParents(srcChild, check) {
    var parentDiv = GetParentByTagName("div", srcChild);
    var parentNodeTable = parentDiv.previousSibling;
    if (parentNodeTable) {
        var checkUncheckSwitch;
        if (check)
        {
            var isAllSiblingsChecked = AreAllSiblingsChecked(srcChild);
            if (isAllSiblingsChecked)
                checkUncheckSwitch = true;
            else
                return;
        }
        else
        {
            checkUncheckSwitch = false;
        }

        var inpElemsInParentTable = parentNodeTable.getElementsByTagName("input");
        if (inpElemsInParentTable.length > 0) {
            var parentNodeChkBox = inpElemsInParentTable[0];
            parentNodeChkBox.checked = checkUncheckSwitch;
            CheckUncheckParents(parentNodeChkBox, checkUncheckSwitch);
        }
    }
}
function AreAllSiblingsChecked(chkBox) {
    var parentDiv = GetParentByTagName("div", chkBox);
    var childCount = parentDiv.childNodes.length;
    for (var i = 0; i < childCount; i++) {
        if (parentDiv.childNodes[i].nodeType == 1)
        {
            if (parentDiv.childNodes[i].tagName.toLowerCase() == "table") {
                var prevChkBox = parentDiv.childNodes[i].getElementsByTagName("input")[0];
                if (!prevChkBox.checked) {
                    return false;
                }
            }
        }
    }
    return true;
}
function GetParentByTagName(parentTagName, childElementObj) {
    var parent = childElementObj.parentNode;
    while (parent.tagName.toLowerCase() != parentTagName.toLowerCase()) {
        parent = parent.parentNode;
    }
    return parent;
}
function SelectAllChildNodes() {
    var obj = window.event.srcElement;
    var treeNodeFound = false;

    var checkedState;
    if (obj.tagName == "INPUT" && obj.type == "checkbox") {
        var treeNode = obj;
        checkedState = treeNode.checked;
        do {
            obj = obj.parentElement;
        } while (obj.tagName != "TABLE")

        var parentTreeLevel = obj.rows[0].cells.length;
        var parentTreeNode = obj.rows[0].cells[0];
        var tables = obj.parentElement.getElementsByTagName("TABLE");
        var numTables = tables.length;
        if (numTables >= 1) {
            for (iCount = 0; iCount < numTables; iCount++) {
                if (tables[iCount] == obj) {
                    treeNodeFound = true;
                    iCount++;
                    if (iCount == numTables) {
                        return;
                    }
                }
                if (treeNodeFound == true) {
                    var childTreeLevel = tables[iCount].rows[0].cells.length;
                    if (childTreeLevel > parentTreeLevel) {
                        var cell = tables[iCount].rows[0].cells[childTreeLevel - 1];
                        var inputs = cell.getElementsByTagName("INPUT");
                        inputs[0].checked = checkedState;
                    }
                    else {
                        return;
                    }
                }
            }
        }
    }
}
function OpenEPage(URL) {
    window.open(URL, null, '', '');
}
function OnClientclose1(oWnd) {
    var arg = oWnd.argument;
    if (arg) {
        var buttonID = arg.buttonID;
        if (buttonID == 's') {
            var navLoc = location.href;
            if (navLoc.indexOf("&loc=") > 0)
            { navLoc = navLoc.replace("&loc=1", "&loc=0"); }
            else
            { navLoc += "&loc=0"; }
            document.location.href = navLoc;
        }
    }
}
function OnClientclose2(oWnd) {
    var arg = oWnd.argument;
    if (arg) {
        var buttonID = arg.buttonID;
        if (buttonID == 's') {
            var navLoc = location.href;
            if (navLoc.indexOf("&loc=") > 0)
            { navLoc = navLoc.replace("&loc=1", "&loc=0"); }
            else
            { navLoc += "&loc=0"; }
            document.location.href = navLoc;
        }
    }
}
function OnClientclose3(oWnd) {
    var arg = oWnd.argument;
    if (arg) {
        var buttonID = arg.buttonID;
        if (buttonID == 's') {
            var navLoc = location.href;
            if (navLoc.indexOf("&loc=") > 0)
            { navLoc = navLoc.replace("&loc=0", "&loc=1"); }
            else
            { navLoc += "&loc=1"; }
            document.location.href = navLoc;
        }
    }
}
function OnClientclose4(oWnd) {
    var arg = oWnd.argument;
    if (arg) {
        var buttonID = arg.buttonID;
        if (buttonID == 's') {
            var navLoc = location.href;
            if (navLoc.indexOf("&loc=") > 0)
            { navLoc = navLoc.replace("&loc=0", "&loc=1"); }
            else
            { navLoc += "&loc=1"; }
            document.location.href = navLoc;
        }
    }
}
function JSFX_FloatTopLeft() {
    var size;
    var variable;
    var startX, startY, width, height;
    var ns;
    var d;
    var px;

    function initVal() {
        size = alertSize();
        variable = size.split("/");
        width = variable[0];
        height = variable[1];
        startX = 5;
        startY = 5;

        ns = (navigator.appName.indexOf("Netscape") != -1);
        d = document;
        px = document.layers ? "" : "px";
    }
    function ml(id) {
        initVal();

        var el = d.getElementById ? d.getElementById(id) : d.all ? d.all[id] : d.layers[id];
        if (d.layers) el.style = el;
        el.sP = function(x, y) { this.style.left = x + px; this.style.top = y + px; };
        el.x = startX; el.y = startY;
        return el;
    }
    window.stayTopLeft = function() {
        initVal();

        var pX = ns ? pageXOffset : document.documentElement && document.documentElement.scrollLeft ?

		document.documentElement.scrollLeft : document.body.scrollLeft;
        ftlObj.x += (pX + startX - ftlObj.x) / 8;

        var pY = ns ? pageYOffset : document.documentElement && document.documentElement.scrollTop ?

        document.documentElement.scrollTop : document.body.scrollTop;
        ftlObj.y += (pY + startY - ftlObj.y) / 8;

        ftlObj.sP(ftlObj.x, ftlObj.y);
        setTimeout("stayTopLeft()", 0);
    }
    ftlObj = ml("divStayTopLeft");
    stayTopLeft();
}
function alertSize() {
    var myWidth = 0, myHeight = 0;
    if (typeof (window.innerWidth) == 'number') {
        myWidth = window.innerWidth;
        myHeight = window.innerHeight;
    } else if (document.documentElement && (document.documentElement.clientWidth || document.documentElement.clientHeight)) {
        myWidth = document.documentElement.clientWidth;
        myHeight = document.documentElement.clientHeight;
    } else if (document.body && (document.body.clientWidth || document.body.clientHeight)) {
        myWidth = document.body.clientWidth;
        myHeight = document.body.clientHeight;
    }
    return myWidth + '/' + myHeight;
}
