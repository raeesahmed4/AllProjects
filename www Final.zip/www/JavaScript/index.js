﻿
$(document).ready(function () {

    GetTopCount();
    

    var par = $('#Alert_divrating');
    $(par).hide();

    $('#Alertpg').click(function (e) {
        $(par).slideToggle('fast');
        e.preventDefault();
        });

});

$(document).mouseup(function (e) {
    var par = $('#Alert_divrating');

    if (!par.is(':hidden')) {
        if (!par.is(':hover')) {
            $(par).hide();
        } 
    }
});

function GetTopCount() {
    
    $.ajax({
        type: "POST",
        url: "/WebMethods.aspx/GetNewActivitiesCount",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) {
            $(".InnerCounter").html(msg.d);
        },
        async: true,
        error: function (xhr, status) {
            alert("GetNewActivitiesCount():" + xhr.responseText);
        }        
    });

    
}

$(document).keypress(function (event) {
    var keycode = (event.keyCode ? event.keyCode
    : event.which); if (keycode == '13') {
        doLogin();
    } 
});

$(document).ready(function () {
    $("#txtLogin").keydown(function (event) {
        if (event.keyCode == 32) {
            event.preventDefault();
        }
    });
});



function ShowLogin() {
    Hide('LoginButtons');
    Show('loginpaneid');

//   $('#txtLogin').focus();
    $("#txtPassword").watermark("Password");
    $("#txtLogin").watermark("Username or email");


  //  $(document).ready(function () {
  
//     $('#txtLogin').focus();
    //  });
        
}

function HideLogin() {
    Show('LoginButtons');
    Hide('loginpaneid');
}

function CloseAlert() {
    $("#msgBox").fadeOut(1000);
}


 