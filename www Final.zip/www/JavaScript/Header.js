﻿// -- Loading Div Display --
function DisplayLoadingDiv()
{
    var size; 
    var variable;
	var startX, startY, width, height;
	var ns;
	var d;
	var px;
	
	function initVal()
	{
	    size = alertSize();
        variable = size.split("/");
        width = variable[0];
	    height = variable[1];
	    startX = (width) - 100;
	    startY = 0;
	    
	    ns = (navigator.appName.indexOf("Netscape") != -1);
	    d = document;
	    px = document.layers ? "" : "px";
	}
	
	function ml(id)
	{
	    initVal();
	
		var el=d.getElementById?d.getElementById(id):d.all?d.all[id]:d.layers[id];
		if(d.layers)el.style=el;
		el.sP=function(x,y){this.style.left=x+px;this.style.top=y+px;};
		el.x = startX; el.y = startY;
		return el;
	}
	window.stayTopLeft=function()
	{
	    initVal();
		
		var pX = ns ? pageXOffset : document.documentElement && document.documentElement.scrollLeft ? 
		
		document.documentElement.scrollLeft : document.body.scrollLeft;
		ftlObj.x += (pX + startX - ftlObj.x)/8;

        var pY = ns ? pageYOffset : document.documentElement && document.documentElement.scrollTop ?

        document.documentElement.scrollTop : document.body.scrollTop;
		ftlObj.y += (pY + startY - ftlObj.y)/8;
				
		ftlObj.sP(ftlObj.x, ftlObj.y);
		setTimeout("stayTopLeft()", 0);
	}
	ftlObj = ml("divStayTopLeft");
	stayTopLeft();
}
/*-------------------------------------------/Dynamic Div---------------------------------------------*/
 
 /*--------------------------------------- Detect Browser Area -------------------------------------------*/
 function alertSize() {
  var myWidth = 0, myHeight = 0;
  if( typeof( window.innerWidth ) == 'number' ) {
    //Non-IE
    myWidth = window.innerWidth;
    myHeight = window.innerHeight;
  } else if( document.documentElement && ( document.documentElement.clientWidth || document.documentElement.clientHeight ) ) {
    //IE 6+ in 'standards compliant mode'
    myWidth = document.documentElement.clientWidth;
    myHeight = document.documentElement.clientHeight;
  } else if( document.body && ( document.body.clientWidth || document.body.clientHeight ) ) {
    //IE 4 compatible
    myWidth = document.body.clientWidth;
    myHeight = document.body.clientHeight;
  }
return myWidth+'/'+myHeight;
}
/*---------------------------------------/ Detect Browser Area-------------------------------------------*/
