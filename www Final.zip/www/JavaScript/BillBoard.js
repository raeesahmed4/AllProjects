﻿
//get biilboard and its comments
function getBillBoard(mode) {
    var dvComment = document.getElementById("billboard");
    //dvComment.innerHTML = '';
    //$(dvComment).slideUp('slow');
    $.ajax({
        type: "POST",
        url: "/WebMethods.aspx/LoadBillboard",
        data: "{'mode':'" + mode + "'}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) {
            if (msg.d.length > 0) {
                if (msg == 'No Billboard') {
                    $('#').val() = '0';
                } else {
                    dvComment.innerHTML = msg.d;
                    //$(dvComment).slideDown('slow');
                }
            }
        },
        async: true,
        error: function (xhr, status, error) {
            // alert(xhr.statusText);
        }
    });
}
////show biilboard Box to replace the existing billboard and write a new one
function NewBillboard(obj) {
    if (obj == 'new1') {
        $('#billInput').show('slow');
        $('#biilText').hide('slow');
        setTimeout("focusBillboard('txtbillboardUpdate')", 1000);
    }
    if (obj == 'can') {
        $('#billInput').hide('slow');
        $('#biilText').show('slow');
    }
    if (obj == 'new11') {
        $('#billInput').show('slow');
        $('#NoBillboard').hide('slow');
        $('#txtbillboard').val('');
        setTimeout("focusBillboard('txtbillboard')", 1000);
    }
    if (obj == 'can1') {
        $('#billInput').hide('slow');
        $('#NoBillboard').show('slow');
    }
}

///////method used to show the comment box for billboard
function openBillboardCommentBox(obj) {
    $('#DvBillboard').toggle('slow');
    setTimeout("focusBillboard('txtbillboardComment')", 1000);
}
function focusBillboard(txt) {
    $('#' + txt).focus();
    $('#' + txt).select();

}
//New biilboard
function SaveNewBillboard() {
    var txt = document.getElementById('txtbillboard');

    if (txt.value == '') {
        parent.showMessage('Please enter some comments to post!');
        return;
    }
    if (txt.value.indexOf('<') > 0 || txt.value.indexOf('>') > 0) {
        parent.showMessage('Invalid comments entered!');
        return;
    }
    var billText = txt.value.replace(/'/g, "^");

    $.ajax({
        type: "POST",
        url: "Live.aspx/NewBillboard",
        data: "{'newBillboard':'" + billText + "'}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) {
            if (msg.d.length > 0) {
                if (msg.d == 'pass') {
                    $('#NoBillboard').hide('slow');
                    getBillBoard('less');
                }
            }
        },
        async: false,
        error: function (xhr, status, error) {
            //alert(xhr.statusText);
        }
    });

    getBillBoard('less');
    NewBillboard('can');
}


//Update biilboard
function UpdateBillboard(actID) {
    var txt = document.getElementById('txtbillboardUpdate');

    if (txt.value == '') {
        parent.showMessage('Please enter your billboard!!');
        return;
    }
    if (txt.value.indexOf('<') > 0 || txt.value.indexOf('>') > 0) {
        parent.showMessage('Invalid billboard text!');
        return;
    }
    var billText = txt.value.replace(/'/g, "^");

    //-------------------------ajax
    $.ajax({
        type: "POST",
        url: "Live.aspx/UpdateBillboardText",
        data: "{'actID':'" + actID + "','newBillboard':'" + billText + "'}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) {
            if (msg.d == 'success') {
                //alert('ok');
            }
        },
        async: false,
        error: function (xhr, status, error) {
            //alert(xhr.statusText);
        }
    });
    getBillBoard('less');
    NewBillboard('can');
}

//save biilboard comments
function SaveBillboardComment(actID) {
    var txt = document.getElementById('txtbillboardComment');

    if (txt.value == '') {
        parent.showMessage('Please enter some comments to post!!');
        return;
    }
    if (txt.value.indexOf('<') > 0 || txt.value.indexOf('>') > 0) {
        parent.showMessage('Invalid comments entered!');
        return;
    }
    var comment = txt.value.replace(/'/g, "^");
    $.ajax({
        type: "POST",
        url: "Live.aspx/SaveBillboardComments",
        data: "{'comment':'" + comment + "','actID':'" + actID + "'}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) {
            if (msg.d.length > 0) {
                var str = msg.d;
                if (str == 'already')
                    parent.showMessage('Comment already posted!');
            }
        },
        async: false,
        error: function (xhr, status, error) {
            //alert(xhr.statusText);
        }
    });

    getBillBoard('less');
    NewBillboard('can');
}

//View All Bollboard Comments
function ViewAllBollboardComments() {
    getBillBoard('more');
}
//View Less Bollboard Comments
function ViewLessBollboardComments() {
    getBillBoard('less');
}
