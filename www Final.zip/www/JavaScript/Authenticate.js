﻿function AuthenticateUser(user, Pass, IsRememberMeChecked, authmsgbox, errorspan,redirectUrl) {
    var userProfile = user.val();
    var userPass = Pass.val();
    var strValues = '';

   // window.alert(userPass);

    var currentPageUrl = window.location;
    
    var chkKeepSignedIn = 1;
    var chkRememberMe = 1;

    var IsKeepSignedInChecked = $("#chkRememberME").is(":checked"); // chkKeepSignedIn.attr('checked');
    if (IsKeepSignedInChecked==false)
    {
      IsKeepSignedInChecked=  $("#ctl00_ContentPlaceHolder1_chkRememberMe").is(":checked"); 
    }
     
    if ((userProfile.length > 0) && (userPass.length > 0)) {
         
        $.ajax({
            type: "POST",
            url: "/WebMethods.aspx/AuthenticateUser",
            data: "{'userName':'" + userProfile + "', 'userPass':'" + userPass + "', 'chkKeepSignedIn':'" + IsKeepSignedInChecked + "', 'chkRememberMe':'" + IsRememberMeChecked + "', 'currentPageUrl':'" + currentPageUrl + "'}",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (msg)
            {
                authmsgbox.ajaxComplete(function (event, request)
                {

                    var d = msg;
                    var str = msg.d;

                    strValues = str.split("`");

                    if (strValues.length > 0)
                    {
                        if (strValues[0] == 'OK')
                        {
                            user.removeClass("textbox_error");
                            Pass.removeClass("textbox_error");
                            if (errorspan != null)
                            {
                                errorspan.html('');
                            }
                            authmsgbox.html('<img src="App_Themes/Space/Images/ajax-loader.gif" height="18px"; width="18px"; >');                              
                            var hreLocation = strValues[1].replace("~", "");                                                                                   
                            window.location.href = redirectUrl;

                        }

                        else
                        {
                            if (strValues[1] == "102" || strValues[1] == "103")
                            {
                                // $(window.location).attr('href', "/Account/Verify.aspx&code=" + strValues[2] + "&RecordID=" + strValues[3] + "&sid=" + strValues[4]);
                            }
                            else
                            {
                                user.addClass("textbox_error");
                                Pass.addClass("textbox_error");

                                //authmsgbox.html('');
                                if (errorspan != null)
                                {
                                    errorspan.html('<div class="errorspan"><font color="#cc0000">' + strValues[1] + "</font></div>");
                                }
                                else
                                {
                                    //                                
                                    $(window.location).attr('href', "/Account/Login.aspx?login=" + userProfile + "&Action=error&sid=" + strValues[4]);
                                }
                                  
                            }
                        }
                    }
                });
            },
            error: function (xhr, status, error)
            {
                authmsgbox.html('');
                alert("Page Error!:" + xhr.responseText);
            }
        });
    }
    else {
        user.addClass("textbox_error");
        authmsgbox.html('');
    }
}