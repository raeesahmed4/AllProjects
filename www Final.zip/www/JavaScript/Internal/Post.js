﻿function GetMetaData(txtURL) {
    $('#videothumb').show();
    document.body.style.cursor = 'wait';

    var txtlink = document.getElementById('txtVideoLink').value;
    $("a#videolink").attr("href", txtlink);
    $("a#videolink").embedly({}, function (oembed, dict) {
        if (oembed == null)
        { return; }
        else {
            //To save OEmbed info.
            $("img#videothumb").attr("src", oembed.thumbnail_url);
            var tempdetail = "<br /><b>" + oembed.title + "</b><br />" + txtlink + "<br /><br />" + oembed.description;
            $("p#videodetail").html(tempdetail);

            //To save Embeded URL. 
            var temp = oembed.html;
            var url = $(temp).attr("src");
            if (url == null) {
                url = $(temp).find("embed").attr("src");
            }
            if (url != null) {
                document.getElementById(txtURL).value = url;
            }
        }

    });

    document.body.style.cursor = "default";
    // alert("Done");
}

function LoadControls(type, Cat, Cond, ship) {

    var success = false;
    var editor = false;

    try {

        $('#error').html("");
        $('#TDDynamicContents').html('');

        var isListing = false;
        //var type = $("#<%= ddlPost.ClientID %>");
        //window.alert(type.toString());
        var typeID = type.val();  //.get_value();

        if (typeID.toString().length > 2) {
            if (typeID.toString().substring(0, 1) == "L") {
                document.getElementById('btnList').style.display = 'block';
                document.getElementById('btnPost').style.display = 'none';
                isListing = true;

                $('#tabs').tabs().slideDown();

            }
            else {
                document.getElementById('btnList').style.display = 'none';
                document.getElementById('btnPost').style.display = 'block';
            }
        }
        else {
            document.getElementById('btnList').style.display = 'none';
            document.getElementById('btnPost').style.display = 'block';

            $('#tabs').tabs().hide();
        }

        //var Cat = $("#<%= ddlCategory.ClientID %>");
        var CatID = Cat.val(); //.get_value();

        ///web method 
        $('#TDDynamicContents').html('');
        $.ajax({
            type: "POST",
            url: "/Post.aspx/LoadDatanGenerateControls",
            data: "{'PostTypeID':'" + typeID + "','CategoryID':'" + CatID + "'}",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (msg) {
                if (msg.d.length > 0) {
                    $('#TDDynamicContents').html(msg.d);
                    success = true;
                    editor = true;

                    if (success) {//show the attachments DIV
                        {
                            document.getElementById("dynamicContent").style.display = 'block';

                            document.getElementById("tdradeditor").style.display = 'block';

                            if ($('#hdattachments').val() == 'true')
                                document.getElementById('attachments').style.display = 'block';
                            else
                                document.getElementById('attachments').style.display = 'none';


                            if (isListing) {

                                if ($('#hdpayment').val() == 'true')
                                    document.getElementById('Payment').style.display = 'block';
                                else
                                    document.getElementById('Payment').style.display = 'none';


                                //window.alert('HD CONDITIONS' + $('#hdconditions').val());

                                if ($('#hdconditions').val() == 'true') {

                                    document.getElementById('Conditions').style.display = 'block';
                                    // var Cond = $find("<%= ddlCondition.ClientID %>");
                                    if (Cond != null) {
                                        Cond.set_visible(true);
                                        var sItem = Cond.findItemByValue("-1");
                                        sItem.select();
                                    }
                                }
                                else {
                                    // var Cond = $find("<%= ddlCondition.ClientID %>");
                                    if (Cond != null)
                                        Cond.set_visible(false);
                                    document.getElementById('Conditions').style.display = 'none';

                                }


                                if ($('#hdshipping').val() == 'true') {
                                    document.getElementById('Shipping').style.display = 'block';
                                    // var ship = $find("<%= ddlShippingLocations.ClientID %>");
                                    if (ship != null)
                                        ship.set_visible(true);
                                }
                                else {
                                    document.getElementById('Shipping').style.display = 'none';
                                    // var ship = $find("<%= ddlShippingLocations.ClientID %>");
                                    if (ship != null)
                                        ship.set_visible(false);
                                }
                            }
                            if ($('#hdshowEditor').val() == 'true') {
                                document.getElementById('Editor').style.display = 'block';
                                $('#hdEditor').val("1");
                            }
                            else
                                document.getElementById('Editor').style.display = 'block';
                        }
                    }
                }
            },
            async: true,
            error: function (xhr, status, error) {
                // alert(xhr.statusText);
            }
        });
    } catch (e) { alert(e); }

}

// show approperate  controls on selected index changed  of the Category Dropdown
/*
function LoadControls(type, Cat, Cond, ship) {
if (editor) {//show formated html editor 
if ($('#hdshowEditor').val() == 'true') {
document.getElementById("dynamicContent").style.display = 'block';
document.getElementById('Editor').style.display = 'block';
$('#hdEditor').val("1");
}
}
}
*/


function LoadControlsFromCookie(typeID, CatID, Cond, ship) {
    var success = false;
    var editor = false;
    try {
        $('#error').html("");
        $('#TDDynamicContents').html('');

        var isListing = false;
        if (typeID.length > 2) {
            if (typeID.substring(0, 1) == "L") {
                document.getElementById('btnList').style.display = 'block';
                document.getElementById('btnPost').style.display = 'none';
                isListing = true;
            }
            else {
                document.getElementById('btnList').style.display = 'none';
                document.getElementById('btnPost').style.display = 'block';
            }
        }
        else {
            document.getElementById('btnList').style.display = 'none';
            document.getElementById('btnPost').style.display = 'block';
        }

        ///web method 
        $('#TDDynamicContents').html('');
        $.ajax({
            type: "POST",
            url: "Post.aspx/LoadDatanGenerateControls",
            data: "{'PostTypeID':'" + typeID + "','CategoryID':'" + CatID + "'}",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (msg) {
                if (msg.d.length > 0) {
                    $('#TDDynamicContents').html(msg.d);
                    success = true;
                    editor = true;
                }
            },
            async: true,
            error: function (xhr, status, error) {
                //  alert(xhr.statusText);
            }
        });
    } catch (e) { alert(e); }

    if (success) {//show the attachments DIV
        {

            //window.alert("Now i m here");

            document.getElementById("dynamicContent").style.display = 'block';

            if ($('#hdattachments').val() == 'true')
                document.getElementById('attachments').style.display = 'block';


            if (isListing) {

                if ($('#hdpayment').val() == 'true')
                    document.getElementById('Payment').style.display = 'block';
                else
                    document.getElementById('Payment').style.display = 'none';

                if ($('#hdconditions').val() == 'true') {
                    document.getElementById('Conditions').style.display = 'block';
                    // var Cond = $find("<%= ddlCondition.ClientID %>");
                    if (Cond != null) {
                        Cond.set_visible(true);
                        var sItem = Cond.findItemByValue("-1");
                        sItem.select();
                    }
                }
                else {
                    // var Cond = $find("<%= ddlCondition.ClientID %>");
                    if (Cond != null)
                        Cond.set_visible(false);
                    document.getElementById('Conditions').style.display = 'none';
                }

                if ($('#hdshipping').val() == 'true') {
                    document.getElementById('Shipping').style.display = 'block';
                    //var ship = $find("<%= ddlShippingLocations.ClientID %>");
                    if (ship != null)
                        ship.set_visible(true);
                }
                else {
                    document.getElementById('Shipping').style.display = 'none';
                    //var ship = $find("<%= ddlShippingLocations.ClientID %>");
                    if (ship != null)
                        ship.set_visible(false);
                }
            }
            if ($('#hdshowEditor').val() == 'true') {
                document.getElementById('Editor').style.display = 'block';
                $('#hdEditor').val("1");
            }
            else
                document.getElementById('Editor').style.display = 'block';
        }
    }
    /*
    if (editor) {//show formated html editor 
    if ($('#hdshowEditor').val() == 'true') {
    document.getElementById("dynamicContent").style.display = 'block';
    document.getElementById('Editor').style.display = 'block';
    $('#hdEditor').val("1");
    }
    }*/
}

function clearCon() {
    document.getElementById('tdradeditor').style.display = 'none';
    document.getElementById("dynamicContent").style.display = 'none';
    document.getElementById("TDDynamicContents").innerHTML = "";
    document.getElementById("uniquename3").style.display = 'none';
}



// validate form

function ValidateForm(type, Cat, editor, hdData, btn, popup) {
    
    setTimeout("hideError()", 10000);
    var IsValidate = true;

    $('#error').html("");
    $('#error').show();

    var typeID = type.val(); //.get_value();
    var CatID = Cat.val(); //.get_value();            
       

    /*
    if (typeID == '-1') {
        $('#error').append("Choose any type of post.<br />");
        IsValidate = false
    }

    if (CatID == '-1') {
        $('#error').append("Choose any category.<br />");
        IsValidate = false
    }
    */
        
    //find all text boxes
    var inputList = $("input[id^='txt_']");
    
    var element;
    var id;
    for (var i = 0; i < inputList.length; i++) {
        element = inputList[i].id;

        if (element.indexOf('Required_') > 0) {
            //window.alert("checking requird..");
            //element = element.replace('Required_', '');
            if ($('#' + element).val() == $('#' + element).attr("title")) {

                //window.alert("Show error");

                $('#sp_error_' + element).show();                
                $('#' + element).addClass("red");
                IsValidate = false
            }
        }
    }


    

    // TEXTAREA BULLSHIT...
    //find text area
    /*
    var data = $('textarea');
    $.each(data, function (i) {
        element = data[i].id;
        if (element.indexOf('Required') > 0) {

            

            if ($('#' + element).val() == $('#' + element).attr("title")) {
                $('#sp_error_' + element).show();
                $('#' + element).addClass("red");
                IsValidate = false
            }
        }
    });
    */
    
    //////find all combobox   
    var selectList = $("select[id^='dynamic_ddl_']");
    
    
    for (var i = 0; i < selectList.length; i++) {
        element = selectList[i].id;
        if (element.indexOf('Required_') > 0) {
            if ($("select[id$='" + element + "'] :selected").text() == $('#' + element).attr("title")) {
                $('#sp_error_' + element).show();
                $('#' + element).addClass("red");
                IsValidate = false

               // window.alert("select list error checking...");

            }
        }
    }


 

    var invalid = true;
    ///////check formated Editor
    //window.alert($('#hdEditor').val());

    if ($('#hdEditor').val() == 1) {
        /*content = editor.get_html();
        if (content == '') {
            $('#sp_txt_Eror_editor').html('please enter description here.');
            IsValidate = false
        }
        if (content.indexOf('&gt;') > 0 || content.indexOf('&lt;') > 0) {
            $('#sp_txt_Eror_editor').html('Invalid Description.');
            IsValidate = false
            invalid = false;
        }
        if (IsValidate && invalid)
            $('#hdEditor').val('0');
            
            */
    }

    //window.alert("after checking error...");


    var span = $("span[id^='sp_txt_']");

    for (var j = 0; j < span.length; j++) {
        var id2 = span[j].id;
        if ($('#' + id2).html() != '') {
            //alert($('#' + id2).html());
            $('#error').html('please correct the above errors.');
            IsValidate = false;
            invalid = false;
        }
    }


    if (invalid && IsValidate) $('#error').html("");
    /////when every thing is validated
    if (IsValidate) {
        var finalData = '';
        //start saving data to DataBase
        //--------------------------------------
        //first get values of input fields
        var inpList = $("input[id^='txt_']");
        var txt;
        var fieldId;
        var fieldValue;
        for (var i = 0; i < inpList.length; i++) {
            txt = inpList[i].id;
            fieldId = txt.substring(txt.lastIndexOf("_") + 1);
            fieldValue = $('#' + txt).val();

            if (fieldValue == $('#' + txt).attr('title')) {
                fieldValue = 'See Description';
            }
            //replace apostaphi and comma
            fieldValue = fieldValue.replace(/'/g, "^");
            fieldValue = fieldValue.replace(/\,/g, "*");
            finalData += fieldValue + "_" + fieldId + ",";
        }

        //get values of textarea fields
        var txtArea = $('textarea');
        var val;
        var txtAreaId;
        var descVal;
        $.each(txtArea, function (i) {
            val = txtArea[i].id;
            txtAreaId = val.substring(val.lastIndexOf("_") + 1);
            //replace ' and ,
            descVal = $('#' + val).val();
            if (val.indexOf('txtFormatedText') < 0) {
                if (descVal == $('#' + val).attr('title')) {
                    descVal = 'See Description';
                }

                descVal = descVal.replace(/'/g, "^");
                descVal = descVal.replace(/\,/g, "*");
                finalData += descVal + "_" + txtAreaId + ",";
            }
        });

        //get combo box values
        var selList = $("select[id^='dynamic_ddl_']");

        var SelectedText;
        var ItemID;
        var comboID;
        for (var i = 0; i < selList.length; i++) {
            ItemID = selList[i].id;
            comboID = ItemID.substring(ItemID.lastIndexOf("_") + 1);
            SelectedText = $("select[id$='" + element + "'] :selected").text();

            if (SelectedText == $('#' + element).attr('title')) {
                SelectedText = 'See Description';
            }

            SelectedText = SelectedText.replace(/'/g, "^");
            SelectedText = SelectedText.replace(/\,/g, "*");
            finalData += SelectedText + "_" + comboID + ",";
        }

        //get check box values

        var chkList = $("input[id^='chk_']");
        var ItemID;
        var chkID;
        for (var i = 0; i < chkList.length; i++) {
            ItemID = chkList[i].id;
            chkID = ItemID.substring(ItemID.lastIndexOf("_") + 1);
            if ($('#' + ItemID).is(':checked')) {
                finalData += "True_" + chkID + ",";
            }
            else {
                finalData += "False_" + chkID + ",";
            }
        }


        //--------------------------------------------------------------------------------
        //send to post                
        $('#' + hdData).val(finalData);
        ///showing popup

        $('#' + btn).hide();

        this._popup = popup;
        this._popup.show();


        return true;
    }
    else {
        return false;
    }

    return false;
}


function ShowDiv(ID) {
    switch (ID) {
        case "photoDiv":
            {

                document.getElementById('photoDiv').style.display = "block";
                document.getElementById('documentDiv').style.display = "none";
                document.getElementById('linkDiv').style.display = "none";
                document.getElementById('videoDiv').style.display = "none";
                break;
            }
        case "documentDiv":
            {
                document.getElementById('photoDiv').style.display = "none";
                document.getElementById('documentDiv').style.display = "block";
                document.getElementById('linkDiv').style.display = "none";
                document.getElementById('videoDiv').style.display = "none";

                break;
            }
        case "linkDiv":
            {
                document.getElementById('photoDiv').style.display = "none";
                document.getElementById('documentDiv').style.display = "none";
                document.getElementById('linkDiv').style.display = "block";
                document.getElementById('videoDiv').style.display = "none";

                break;
            }
        case "videoDiv":
            {
                document.getElementById('photoDiv').style.display = "none";
                document.getElementById('documentDiv').style.display = "none";
                document.getElementById('linkDiv').style.display = "none";
                document.getElementById('videoDiv').style.display = "block";

                break;
            }
    }
}


function HideAll() {

    document.getElementById('photoDiv').style.display = "none";
    document.getElementById('documentDiv').style.display = "none";
    document.getElementById('linkDiv').style.display = "none";
    document.getElementById('videoDiv').style.display = "none";
}


function validateExtensions(radControl, radUpload, args) {
    var inputs = radControl.getFileInputs();
    var i = inputs.length - 1;
    if (!radControl.isExtensionValid(inputs[i].value)) {
        radUpload.clearFileInputAt(i);
        window.alert("Files with invalid extensions are not allowed.");
    }
}

function CheckBoxSelectionChanged(e) {
    if ($(e).attr("title") == "Make an Offer") {

        if ($(e).is(":checked") == true) {
            //ToggleDisplay("txt_Required_PriceEach_10");
            $("#txt_Required_PriceEach_10").val("0");
            $("#PRICE_EACH_10").hide(); //.css("display","none");
        }
        else {
            $("#txt_Required_PriceEach_10").val("Price Each");
            $("#PRICE_EACH_10").show(); //.css("display", "block");
        }
    }
}
       

