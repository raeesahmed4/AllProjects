$(function(){
    $('#file').customFileInput();	
});