﻿var memberID = "2898";// Get the login member id here 
var DefaultPageSize = 4;
var viewModel = null;
var SessionMemberID = "";
var DownloadFeedInProgress = false;
var CurrentTime = ko.observable((new Date()).getTime());
var SERVICE_URL = "http://beta.eopen.com/m/mservice.asmx";

$(document).ready(function ()
{
    SessionMemberID = $(".SessionMemberID").val();
    viewModel = new ViwModel();
    ko.applyBindings(viewModel);
    LoadFeedItems(viewModel);
    UpdateTime();
    $(".write-comment").watermark("Write a comment...");
    $("#txtPost").watermark("Enter something to Post...");
    $("#txtPost").autosize();
    $(".autosize").autosize();
    $("#txtPost").val(""); // for chroom issue.
    BindCategoryDropDown($(".ddl-post-type").val());
    ConfigureEventHandlers();
    if (SessionMemberID.length > 0)
    {
        viewModel.IsMemberSession(true);
    }
});

$(window).scroll(function ()
{
    if (DownloadFeedInProgress)
        return;

    if (IsScrollBottom())
    { 
        LoadFeedItems(viewModel);
    }
});

function IsScrollBottom()
{
    var pos = '.8';
    var documentHeight = $(document).height();
    var scrollPosition = $(window).height() + $(window).scrollTop();
    return (scrollPosition >= (documentHeight * pos));
}

function UpdateTime()
{
    CurrentTime((new Date()).getTime());
    setTimeout("UpdateTime()", 15000);
}
function ViwModel()
{
    var self = this;
    self.FeedItems = ko.observableArray([]);
    self.IsMemberSession = ko.observable(false);
    self.ToggleLinkStatus = function (item)
    {
        if (item.ShowLinkUnlink() == "link" || item.ShowLinkUnlink() == "unlink")
        {
            var currentStatus = item.ShowLinkUnlink();
            ToggleLinkUnlinkStatus(item.EncryptedItemId, item.ShowLinkUnlink());

            // Perform same action on all items in model for that member.

            for (var i = 0; i < self.FeedItems().length; i++)
            {
                if (self.FeedItems()[i].ShowLinkUnlink() == "link" || self.FeedItems()[i].ShowLinkUnlink() == "unlink")
                {
                    if (self.FeedItems()[i].MemberId == item.MemberId)
                    {
                        if (currentStatus == "link")
                            self.FeedItems()[i].ShowLinkUnlink("unlink");
                        else if (currentStatus == "unlink")
                            self.FeedItems()[i].ShowLinkUnlink("link");
                    }
                }
            }
        }
    };
    self.DeleteFeedItem = function (item)
    {
        var result = DeleteItem(item.EncryptedItemId, "feed");
        if (result == "success")
        {
            self.FeedItems.remove(item);
        }
    };
};

function ParseFeedItems(resultData, self)
{
    for (var i = 0; i < resultData.length; i++)
    {
        var item = resultData[i];
        var comments = ParseComments(item.comments);
        var newItem = new FeedItem(item.Id, item.EncryptedItemId, item.MemberId, item.UserName, item.Title, item.Description, item.Date, item.files, comments, item.ShowLinkUnlink, item.ListingTypeName, item.IsPosting, item.ObjectId);
        self.FeedItems.push(newItem);
        newItem.SetCommentsVisibility(4);
    }

}
function ParseComments(input)
{
    var comments = new Array();
    for (var i = 0; i < input.length; i++)
    {
        var item = input[i];
        comments.push(new Comment(item.Id, item.EncryptedCommentId, item.Description, item.Date, item.CommentBy, item.UserName,item.AllowDelete));
    }
    return comments;
}
function AddCommentToViewModel(encryptedItemId, comment)
{
    var selectItem = null;

    for (var i = 0; i < viewModel.FeedItems().length; i++)
    {
        if (viewModel.FeedItems()[i].EncryptedItemId == encryptedItemId)
        {
            viewModel.FeedItems()[i].AddComment(comment);
        }
    }
}

function FeedItem(Id, EncryptedItemId, MemberId, UserName, Title, Description, DateCreated, Files, Comments, showLinkUnlink, ListingTypeName, IsPosting, ObjectId)
{
    var self = this;
    self.Id = Id;
    self.EncryptedItemId = EncryptedItemId;
    self.MemberId = MemberId;
    self.UserName = UserName;
    self.Title = unescape(Title);
    self.Description =unescape( Description);
    self.CreatedOn = DateCreated;
    self.Files = Files;
    self.ShowLinkUnlink = ko.observable(showLinkUnlink);
    self.Comments = ko.observableArray(Comments);
    self.ListingTypeName = ListingTypeName;
    self.IsPosting = IsPosting;
    self.ObjectId = ObjectId;
    self.HiddenCommentCount = ko.computed(function ()
    {
        var counter = 0;
        for (var i = 0; i < self.Comments().length; i++)
        {
            if (self.Comments()[i].IsVisible() == false)
            {
                counter++;
            }
        }
        return counter;
    });
    self.AddComment = function (comment)
    {
        self.Comments.push(comment);
    }
    self.DeleteComment = function (comment)
    {
        var result = DeleteItem(comment.EncryptedCommentId, "comment");
        if (result == "success")
        {
            self.Comments.remove(comment);
        }
    }
    self.TimeEllapsed = ko.computed(function ()
    {
        return GetElapsedTime(self.CreatedOn);
    });
    self.ShowAllComments = function ()
    {
        if (self.Comments().length == 0)
        {
            return;
        }

        for (var i = 0; i < self.Comments().length; i++)
        {
            self.Comments()[i].IsVisible(true);
        }
    };
    self.SetCommentsVisibility = function (showCommentCount)
    {
        if (self.Comments().length == 0 || self.Comments().length <= showCommentCount)
        {
            return;
        }

        for (var i = 0; i < self.Comments().length; i++)
        {
            if (i < self.Comments().length - showCommentCount)
            {
                self.Comments()[i].IsVisible(false);
            }
        }
    }

} // End Feed Item Creation

function Comment(Id, EncryptedCommentId, Description, DateCreated, CommentBy, UserName,allowDelete)
{
    var self = this;
    self.Id = Id;
    self.EncryptedCommentId = EncryptedCommentId;
    self.Description =unescape( Description);
    self.CreatedOn = DateCreated;
    self.CommentBy = CommentBy;
    self.UserName = UserName;
    self.AllowDelete = allowDelete;
    self.IsVisible = ko.observable(true);
    self.TimeEllapsed = ko.computed(function ()
    {
        return GetElapsedTime(self.CreatedOn);
    });
}
function GetElapsedTime(inputTime)
{
    var ellapsed = '';
    var timeStampDiff = parseInt(CurrentTime()) - parseInt((new Date(inputTime + ' UTC')).getTime());
    var s = Math.round(parseInt(timeStampDiff / 1000));
    var m = Math.round(parseInt(s / 60));
    var h = Math.round(parseInt(m / 60));
    var d = Math.round(parseInt(h / 24));

    if (d > 1)
    {
        var month = Math.round(parseInt(d / 30));
        if (month >= 1)
        {
            ellapsed = month + ' month' + (month > 1 ? 's' : '');
        }
        else
        {
            ellapsed = d + ' days';
        }
    }
    else if (d == 1)
    {
        ellapsed = d + ' day';
    }
    else if (h >= 1)
    {
        ellapsed = h + ' hour' + (h > 1 ? 's' : '');
    }
    else if (m >= 1)
    {
        ellapsed = m + ' minute' + (m > 1 ? 's' : '');
    }
    else
    {
        ellapsed = (s > 10 ? s : 'few') + ' seconds';
    }

    return ellapsed + ' ago';
}
function ConfigureEventHandlers()
{
    $(".write-comment").live("keypress", function (event)
    {
        var keyCode = (event.keyCode ? event.keyCode : event.which);
        if (keyCode == '13')
        {
            AddComment($(this).attr("name"), $(this).val());
            $(this).val('');
            event.preventDefault();
            return false;
        }
    });

    $("#txtPost").click(function ()
    {
        $(".post-controls").fadeIn();
        HidePostError();
    });


    $(".ddl-post-type").change(function ()
    {
        BindCategoryDropDown($(this).val());
    });

    $("#btnPost").click(function ()
    {
        PostData();
    });

    $("#btnCancelPost").click(function ()
    {
        $("#txtPost").val("");
        $(".post-controls").fadeOut();
        HidePostError();
    });
}
function ShowPostError(message)
{  
    $("#dvLiveErrorMessage").html(message).fadeIn('slow');
   // $(".error-message").fadeIn('slow');
}
function HidePostError()
{
    $("#dvLiveErrorMessage").fadeOut('slow');
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////            Ajax Calls         /////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function LoadFeedItems(self)
{
    if (DownloadFeedInProgress)
        return;

    DownloadFeedInProgress = true;

    $.ajax({
        type: "POST",
        url:  SERVICE_URL +"/LoadFeedItems",
        data: "{ 'numberItemsToSkip':'" + self.FeedItems().length + "','numberOfItemsToTake':'" + DefaultPageSize + "' ,'memberID':'" + memberID + "'}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        async: true,
        success: function (data)
        {
            var resultData = ko.toJS(data.d);
            ParseFeedItems(resultData, self);
            $(".autosize").autosize();
            $(".write-comment").watermark("Write a comment...");
            DownloadFeedInProgress = false;
        },
        error: function (x, r)
        {
            alert(x.responseText);
        }
    });
}
//Delete FeedItem
function DeleteItem(id, type)
{
    if (!confirm('Are you sure you want to delete?'))
    {
        return "failed";
    }
    $.ajax({
        type: "POST",
        url: SERVICE_URL + "/DeleteItem",
        data: "{'id':'" + id + "','type':'" + type + "'}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        async: true,
        success: function (msg) { },
        error: function (xhr, status, error)
        {
            alert(xhr.responseText);
        }
    });
    return "success";
}

function ToggleLinkUnlinkStatus(id, type)
{
    $.ajax({
        type: "POST",
        url: SERVICE_URL + "/ToggleLinkUnlinkStatus",
        data: "{'id':'" + id + "','type':'" + type + "','memberID':'" + memberID + "'}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        async: true,
        success: function (msg) { },
        error: function (xhr, status, error)
        {
            alert(xhr.responseText);
        }
    });
    return "success";
}

function AddComment(itemId, comment)
{
    var commentText = comment;
    commentText = escape(commentText);
    if (commentText.length > 1000)
        commentText = commentText.substr(0, 1000);

    if (TrimText(commentText) == '')
    {
        ShowMessageBox('Error', 'Please enter some comment(s) to post!');
        return false;
    }

    if (commentText.indexOf('<') > 0 || commentText.indexOf('>') > 0)
    {
        ShowMessageBox('Error', 'Invalid comments entered!');
        return false;
    }

    $.ajax({
        type: "POST",
        url: SERVICE_URL + "/AddComment",
        data: "{'itemId':'" + itemId + "','comment':'" + commentText + "','memberID':'" + memberID + "'}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        async: true,
        success: function (data)
        {
            var resultData = ko.toJS(data.d);
            var comment = new Comment(resultData.Id, resultData.EncryptedCommentId, resultData.Description, resultData.Date, resultData.CommentBy, resultData.UserName,true);
            AddCommentToViewModel(itemId, comment);
        },
        error: function (xhr, status, error)
        {
            // alert(xhr.responseText);
        }
    });
}


 
 
