﻿function IsValidEmailAddress(emailAddress)
{
    var pattern = new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);
    return pattern.test(emailAddress);
};
function HtmlEncode(str)
{
    return String(str)
            .replace(/&/g, '&amp;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;');
}
function TrimText(result)
{
    return result.replace(/^\s+|\s+$/g, "");
}
function showMessage(val)
{
 
    ShowMessageBox("Error", val); 
    //$.jGrowl(val);
    return false;

}
function ShowMessageBox(title, message) {
    ShowMessageBox(title, message, "");
}
function ShowMessageBox(title, message,redirectURL)
{      
    var comfirmed = false;
    var firstPart = "<p class='confirmation'><span ";
    var lastPart = " style='float:left; margin:0 7px 0px 0px'></span><p style='text-align:left;top-align:center'>" + message + "</p></p>";

    $('#divCommonDialog').html(firstPart + "class='ui-icon ui-icon-circle-check'" + lastPart);
     
    $('#divCommonDialog').dialog({
        autoOpen: false,
        resizable: false,
        title: title,
        modal: true,
        buttons: {
            "OK": function ()
            {
                if (redirectURL == "" || redirectURL==null || redirectURL=="undefind")
                    $(this).dialog("close");
                else 
                    window.location.href = redirectURL;
            }
        }
    });

    $('#divCommonDialog').dialog('open');
}


function getQueryStringParameValue(name)
{

    var match = RegExp('[?&]' + name + '=([^&]*)')
                    .exec(window.location.search);

    return match && decodeURIComponent(match[1].replace(/\+/g, ' '));

}

function SelectMenuItem(item)
{
    $(".leftMenu li").each(function ()
    {
        if ($(this).hasClass("selectedMenuItem"))
        {
            $(this).removeClass("selectedMenuItem");
            $(this).addClass("menuItem");
        }
    });

    $(item).removeClass("menuItem");
    $(item).addClass("selectedMenuItem");

}

function SetJqGridHeader(grid, column, align, tooltip,padding)
{
    if (padding == "" || padding == "undefined" || padding == null)
        padding = "0";

    jQuery(grid).jqGrid('setLabel', '' + column + '', '' + column + '', { 'text-align': '' + align + '','padding':''+padding+'px' },
                                { 'title': '' + tooltip + '' });
}
 