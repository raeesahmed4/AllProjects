﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using VisualSoft.VSharp.Utils;

public partial class SignOut : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            Web.SessionMembers = null;
            Web.IsMemberSession = false;
            Web.SessionVariables.IsAdminSession = false;
            System.Web.Security.FormsAuthentication.SignOut();

            if (!Web.SessionVariables.IsSecuritySession)
            {
                Session.RemoveAll();
                Session.Abandon();
            }
            else
            {
                Session.RemoveAll();
                Web.SessionVariables.IsSecuritySession = true;
            }

            var eofferCookie = Request.Cookies.Get("loginCookie");
            if (eofferCookie != null)
            {
                eofferCookie.Values.Set("keepLoggedIn", "False");
                HttpContext.Current.Response.Cookies.Add(eofferCookie);
            }

            Web.Redirect("index.aspx");
        }
        catch (Exception ex)
        {
            Log.Write("444", ex.GetBaseException().ToString(), ex);
        }
    }
}