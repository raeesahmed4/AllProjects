﻿using System;
using System.Configuration;
using CodenameRabbitFoot.BusinessLogic;
using System.Collections.Generic;
using System.Data;
using System.IO;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        

        try
        {
            Web.Redirect("index.aspx");
        } 
        catch (Exception exp)
        {
            Web.LogError(exp);
        }
    }
}
