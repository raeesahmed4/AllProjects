﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using CodenameRabbitFoot.BusinessLogic;
using System.Collections.Specialized;
using System.Web.Services;
using System.Text;
using System.Web.Script.Services;

public partial class Contacts_Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Web.CheckSession();

        // this.Master.HideLinkApps();

        var action = Request.QueryString["Action"] == null ? string.Empty : Request.QueryString["Action"].ToString().ToLower();

        if (Request.QueryString["Action"] != null && Request.QueryString["BatchNumber"] != null && Request.QueryString["Type"] != null)
        {
            this.hdnSelectContactList.Value = (Request.QueryString["BatchNumber"]);
            string script = " javascript: selectTab('tabs-4'); ";
            Page.ClientScript.RegisterStartupScript(GetType(), "JavascriptMsg", script, true);

            return;
        }
        else

            if (Request.QueryString["Action"] != null && Request.QueryString["RecordID"] != null)
            {
                string result = AddToContact(Request.QueryString["RecordID"].ToString(), Request.QueryString["Action"].ToString());
                string script = " javascript: ShowMessageBox('Add " + (Request.QueryString["Action"].ToString().ToLower().Equals("clients") ? ContactTypes.Client.ToString() : ContactTypes.Vendor.ToString()) + "', '" + result.Replace("'", "") + "' ); selectTab('tabs-3'); ";
                Page.ClientScript.RegisterStartupScript(GetType(), "JavascriptMsg", script, true);
                return;
            }


        if (action == "clients")
        {
            this.hdnSelectContactList.Value = Web.RecordID.ToString();// Secure.Decrypt(Request.QueryString["RecordID"].ToString());             
        }

    }

    #region Contacts / Vendors / Clients

    //[Done]
    [WebMethod(EnableSession = true)]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public static JQGrid LoadContactsSearchResult(string contactType, string name, string company, string country, string category, int pageIndex, int pageSize)
    {
        JQGrid jqGrid = new JQGrid();
        ContactTypes type = contactType == "clients" ? ContactTypes.Client : ContactTypes.Vendor;
        IEnumerable<DataRow> dataRows = Contacts.SearchContacts(pageIndex, pageSize, Web.SessionMembers.MemberID, (int)type, name, company, Convert.ToInt32(country), Convert.ToInt32(category)).Select();

        // all filterign is made abov 
        int totalRows = Convert.ToInt32(dataRows.First()["TotalRows"]);
        jqGrid.total = totalRows == pageSize ? 1 : (totalRows / pageSize) + 1;
        jqGrid.records = pageSize;
        jqGrid.page = pageIndex;
        //IEnumerable<DataRow> dataRows = allRows.Skip((pageIndex - 1) * pageSize).Take(pageSize);
        if (dataRows.Count() == 0)
        {
            //if (allRows.Count() > 0)
            //{
            //    dataRows = allRows.Skip((pageIndex - 2) * pageSize).Take(pageSize);
            //    jqGrid.page = pageIndex - 1;
            //    if (jqGrid.total > 1)
            //        jqGrid.total = jqGrid.total - 1;
            //}
            //else
            //{
            JQGrid.Row row = new JQGrid.Row();
            row.id = 0;
            row.cell.Add("0");
            row.cell.Add("<div style='text-align:left; padding:5px;'>" + Constants.MSG_SEARCH_EMPTY_GRID + "</div>");
            jqGrid.rows.Add(row);
            jqGrid.status = "empty";
            //}
        }
        foreach (DataRow member in dataRows)
        {
            string rowTemplate = @"
                            <table cellpadding='0' cellspacing='0'   border='0' class='tblGridRow' style='padding-top:9px; padding-bottom:9px;' >
                            <tr><td rowspan='3' valign='top' class='imgContainer'  style='width:50px; border-right-width:0px; border-left-width:0px; border-bottom-width:0px; border-top-width:0px'>#IMAGE#</td><td class='defaultCell'  style='width:350px; border-right-width:0px; border-left-width:0px; border-bottom-width:0px; border-top-width:0px'>#NAME#</td><td rowspan='3' valign='top' class='imgContainer'  style='border-right-width:0px; border-left-width:0px; border-bottom-width:0px; border-top-width:0px'>#BUTTON# #HIDDEN#</td></tr>
                            <tr> <td class='defaultCell' style='border-right-width:0px; border-left-width:0px; border-bottom-width:0px; border-top-width:0px'>#ADDRESS#</td></tr>
                            <tr> <td class='defaultCell'  style='border-right-width:0px; border-left-width:0px; border-bottom-width:0px; border-top-width:0px'>#EMAIL#</td></tr>
                            </table>
                            ";
            object encryptedMemberID = Secure.Encrypt(member["MemberID"]);
            JQGrid.Row row = new JQGrid.Row();
            row.id = Convert.ToInt32(member["MemberID"]);
            row.cell.Add(member["MemberID"].ToString());
            rowTemplate = rowTemplate.Replace("#IMAGE#", GetImageUrl(encryptedMemberID));
            rowTemplate = rowTemplate.Replace("#NAME#", member["FullName"].ToString());
            rowTemplate = rowTemplate.Replace("#ADDRESS#", GetContactInfoUrl(encryptedMemberID, GetMemberCompanyName(member["CompanyName"])));
            rowTemplate = rowTemplate.Replace("#EMAIL#", GetContactInfoUrl(encryptedMemberID, member["Email"]));

            string buttonHtml = string.Format("<input type=button class=InnerGridButton value='Add' onclick='AddToContact(this);' />");
            rowTemplate = rowTemplate.Replace("#BUTTON#", buttonHtml);
            rowTemplate = rowTemplate.Replace("#HIDDEN#", string.Format("<input type='hidden' value='{0}' />", encryptedMemberID));
            row.cell.Add(rowTemplate);
            jqGrid.rows.Add(row);
        }
        return jqGrid;
    }

    //[ToDo]
    [WebMethod(EnableSession = true)]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public static JQGrid LoadContactsSearchSuggestionsResult(string contactType, int pageIndex, int pageSize)
    {
        JQGrid jqGrid = new JQGrid();
        ContactTypes type = contactType == "clients" ? ContactTypes.Client : ContactTypes.Vendor;
        IEnumerable<DataRow> allRows = Contacts.SearchContacts(1, 5, Web.SessionMembers.MemberID, (int)type, "", "", 0, 0).Select();

        // all filterign is made abov 
        jqGrid.total = allRows.Count() == pageSize ? 1 : (allRows.Count() / pageSize) + 1;
        jqGrid.records = pageSize;
        jqGrid.page = pageIndex;
        IEnumerable<DataRow> dataRows = allRows.Skip((pageIndex - 1) * pageSize).Take(pageSize);

        if (dataRows.Count() == 0)
        {
            if (allRows.Count() > 0)
            {
                dataRows = allRows.Skip((pageIndex - 2) * pageSize).Take(pageSize);
                jqGrid.page = pageIndex - 1;
                if (jqGrid.total > 1)
                    jqGrid.total = jqGrid.total - 1;
            }
            else
            {
                JQGrid.Row row = new JQGrid.Row();
                row.id = 0;
                row.cell.Add("0");
                row.cell.Add("<div style='text-align:left; padding:5px;'>" + Constants.MSG_SEARCH_SUGGESTION_EMPTY_GRID + "</div>");
                jqGrid.rows.Add(row);
                jqGrid.status = "empty";
            }
        }

        foreach (DataRow member in dataRows)
        {
            if (member["MemberID"].ToString().Equals(Web.SessionMembers.MemberID.ToString()))
                continue;

            string rowTemplate = @"
                            <table cellpadding='0' cellspacing='0'   border='0' class='tblGridRow' style='padding-top:9px; padding-bottom:9px;' >
                            <tr><td rowspan='3' valign='top' class='imgContainer'  style='width:50px; border-right-width:0px; border-left-width:0px; border-bottom-width:0px; border-top-width:0px'>#IMAGE#</td><td class='defaultCell'  style='width:350px; border-right-width:0px; border-left-width:0px; border-bottom-width:0px; border-top-width:0px'>#NAME#</td><td rowspan='3' valign='top' class='imgContainer'  style='border-right-width:0px; border-left-width:0px; border-bottom-width:0px; border-top-width:0px'>#BUTTON# #HIDDEN#</td></tr>
                            <tr> <td class='defaultCell' style='border-right-width:0px; border-left-width:0px; border-bottom-width:0px; border-top-width:0px'>#ADDRESS#</td></tr>
                            <tr> <td class='defaultCell'  style='border-right-width:0px; border-left-width:0px; border-bottom-width:0px; border-top-width:0px'>#EMAIL#</td></tr>
                            </table>
                            ";
            object encryptedMemberID = Secure.Encrypt(member["MemberID"]);
            JQGrid.Row row = new JQGrid.Row();
            row.id = Convert.ToInt32(member["MemberID"]);
            row.cell.Add(member["MemberID"].ToString());
            rowTemplate = rowTemplate.Replace("#IMAGE#", GetImageUrl(encryptedMemberID));
            rowTemplate = rowTemplate.Replace("#NAME#", member["FullName"].ToString());
            rowTemplate = rowTemplate.Replace("#ADDRESS#", GetContactInfoUrl(encryptedMemberID, GetMemberCompanyName(member["CompanyName"])));
            rowTemplate = rowTemplate.Replace("#EMAIL#", GetContactInfoUrl(encryptedMemberID, member["Email"]));

            string buttonHtml = string.Format("<input type=button class=InnerGridButton value='Add' onclick='AddToContact(this);' />");
            rowTemplate = rowTemplate.Replace("#BUTTON#", buttonHtml);
            rowTemplate = rowTemplate.Replace("#HIDDEN#", string.Format("<input type='hidden' value='{0}' />", encryptedMemberID));
            row.cell.Add(rowTemplate);
            jqGrid.rows.Add(row);
        }
        return jqGrid;
    }

    //[Done]
    [WebMethod(EnableSession = true)]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public static JQGrid LoadMemberContactList(string batchNumber, int pageIndex, int pageSize)
    {
        JQGrid jqGrid = new JQGrid();

        MemberContactList mList = new MemberContactList();
        mList.Where.BatchNumber.Value = batchNumber;
        mList.Where.MemberID.Value = Web.SessionMembers.MemberID;
        mList.Query.Load();

        IEnumerable<DataRow> allRows = mList.DefaultView.Table.Select();

        // all filterign is made abov 
        jqGrid.total = allRows.Count() == pageSize ? 1 : (allRows.Count() / pageSize) + 1;
        jqGrid.records = pageSize;
        jqGrid.page = pageIndex;
        IEnumerable<DataRow> dataRows = allRows.Skip((pageIndex - 1) * pageSize).Take(pageSize);
        if (dataRows.Count() == 0)
        {
            if (allRows.Count() > 0)
            {
                dataRows = allRows.Skip((pageIndex - 2) * pageSize).Take(pageSize);
                jqGrid.page = pageIndex - 1;
                if (jqGrid.total > 1)
                    jqGrid.total = jqGrid.total - 1;
            }
            else
            {
                JQGrid.Row row = new JQGrid.Row();
                row.id = 0;
                row.cell.Add("0");
                row.cell.Add("<div style='text-align:left; padding:5px;'>" + Constants.MSG_MEMBER_CONTACT_LIST_EMPTY_GRID + "</div>");
                jqGrid.rows.Add(row);
                jqGrid.status = "empty";
            }
        }
        foreach (DataRow member in dataRows)
        {
            JQGrid.Row row = new JQGrid.Row();
            row.id = Convert.ToInt32(member["MemberContactListID"]);
            row.cell.Add(member["MemberContactListID"].ToString());
            row.cell.Add("<span style='padding: 5px;'>" + member["ContactName"].ToString() + "</span>");
            row.cell.Add("<span style='padding: 5px;'>" + member["ContactEmail"].ToString() + "</span>");
            row.cell.Add("<span style='padding: 5px;'><a href=# onclick=PerformContactAction(this,'EditContactListItem');><img title='Edit' src='../images/contacts/editcontact.png' /></a> <a href=# onclick=PerformContactAction(this,'DeleteContactListItem');><img title='Delete' src='../images/contacts/delete.png' /></a></span><input type='hidden' value='" + Secure.Encrypt(member["MemberContactListID"]) + "' />");

            jqGrid.rows.Add(row);
        }
        return jqGrid;
    }

    //[Done]
    [WebMethod(EnableSession = true)]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public static JQGrid LoadContacts(string contactType, int pageIndex, int pageSize, string filter)
    {
        JQGrid jqGrid = new JQGrid();
        if (!Web.IsMemberSession)
        {
            jqGrid.status = "login";
        }
        ContactTypes type = contactType == "clients" ? ContactTypes.Client : ContactTypes.Vendor;
        filter = filter.ToLower();
        ContactView contactTypeFilter = ContactView.AllContacts;

        if (filter.Equals("approved"))
        {
            contactTypeFilter = ContactView.ApprovedContacts;
        }
        else
            if (filter.Equals("pending my approval"))
            {
                contactTypeFilter = ContactView.PendingMyApproval;
            }
            else
                if (filter.Equals("need to approve me"))
                {
                    contactTypeFilter = ContactView.NeedToApproveMe;
                }
                else
                    if (filter.Equals("profile inactive"))
                    {
                        // ToDo : suggestion
                    }

        IEnumerable<DataRow> allRows = Contacts.GetMyContacts(Web.SessionMembers.MemberID, type, contactTypeFilter).Select();
        jqGrid.totalRecords = allRows.Count();
        // all filterign is made above 
        jqGrid.total = allRows.Count() == pageSize ? 1 : (allRows.Count() / pageSize) + 1;
        jqGrid.records = pageSize;
        jqGrid.page = pageIndex;
        IEnumerable<DataRow> dataRows = allRows.Skip((pageIndex - 1) * pageSize).Take(pageSize);

        if (dataRows.Count() == 0)
        {
            if (allRows.Count() > 0)
            {
                dataRows = allRows.Skip((pageIndex - 2) * pageSize).Take(pageSize);
                jqGrid.page = pageIndex - 1;
                if (jqGrid.total > 1)
                    jqGrid.total = jqGrid.total - 1;
            }
            else
            {
                string msg = contactType == "clients" ? Constants.MSG_CLIENTS_EMPTY_GRID : Constants.MSG_VENDORS_EMPTY_GRID;
                JQGrid.Row row = new JQGrid.Row();
                row.id = 0;
                row.cell.Add("0");
                row.cell.Add("<div style='text-align:left; padding:5px;'>" + msg + "</div>");
                jqGrid.rows.Add(row);
                jqGrid.status = "empty";
            }
        }

        foreach (DataRow member in dataRows)
        {
            bool showDeleteButton = true;
            string rowTemplate = @"
                            <table cellpadding='0' cellspacing='0'   border='0' class='tblGridRow' style='padding-top:9px; padding-bottom:9px;' >
                            <tr><td rowspan='3' valign='top' class='imgContainer'  style='width:50px; border-right-width:0px; border-left-width:0px; border-bottom-width:0px; border-top-width:0px'>#IMAGE#</td><td class='defaultCell'  style='width:350px; border-right-width:0px; border-left-width:0px; border-bottom-width:0px; border-top-width:0px'>#NAME#</td><td rowspan='3' valign='middle' class='imgContainer'  style='border-right-width:0px; border-left-width:0px; border-bottom-width:0px; border-top-width:0px; '>
                            <div style='text-align:right;width:250px;'>#BUTTON#</div> #HIDDEN#</td></tr>
                            <tr> <td class='defaultCell' style='border-right-width:0px; border-left-width:0px; border-bottom-width:0px; border-top-width:0px'>#ADDRESS#</td></tr>
                            <tr> <td class='defaultCell'  style='border-right-width:0px; border-left-width:0px; border-bottom-width:0px; border-top-width:0px'>#EMAIL#</td></tr>
                            </table>
                            ";
            //  <div><img style='width:30px;height:60px;vertical-align:middle'><span >Works.</span></div>

            object encryptedMemberID = Secure.Encrypt(member["MemberID"]);

            JQGrid.Row row = new JQGrid.Row();
            row.id = Convert.ToInt32(member["MemberID"]);
            string billBoard = string.Empty;

            DataTable DtBillBoard = MemberActivityLog.LoadBillboard(row.id);

            if (DtBillBoard.Rows.Count > 0)

                billBoard = DtBillBoard.Rows[0]["Description"].ToString();

            row.cell.Add(member["MemberID"].ToString());
            if (member["MemberStatusID"].ToString().Equals("200"))
            {
                rowTemplate = rowTemplate.Replace("#IMAGE#", GetImageUrl(encryptedMemberID));
            }
            else
            {
                rowTemplate = rowTemplate.Replace("#IMAGE#", GetImageUrl(0));
            }
            rowTemplate = rowTemplate.Replace("#NAME#", member["FullName"].ToString());

            if (member["MemberStatusID"].ToString().Equals("200"))
            {
                rowTemplate = rowTemplate.Replace("#ADDRESS#", GetContactInfoUrl(encryptedMemberID, GetMemberCompanyName(member["CompanyName"])));
                rowTemplate = rowTemplate.Replace("#EMAIL#", GetContactInfoUrl(encryptedMemberID, billBoard));
                //rowTemplate = rowTemplate.Replace("#Billboardtxt#", GetContactInfoUrl(encryptedMemberID,billBoard));
            }
            else
            {
                rowTemplate = rowTemplate.Replace("#ADDRESS#", GetMemberCompanyName(member["CompanyName"].ToString()));
                rowTemplate = rowTemplate.Replace("#EMAIL#", member["Email"].ToString());
            }

            int mySellingItemsPosted = 0, myBuyingItems = 0;

            mySellingItemsPosted = Counters.GetCount(CountTypes.Selling_Lots, Web.SessionMembers.MemberID);
            myBuyingItems = Counters.GetCount(CountTypes.Buying_Items_Posted, Web.SessionMembers.MemberID);
            StringBuilder buttonHtml = new StringBuilder();


            if (member["MemberStatusID"].ToString().Equals("200")) // Live
            {

                if (member["ContactStatusID"].ToString().Equals("1"))// Approved
                {

                    string contactAccessiblity = member["ContactAccessibilityID"].ToString().ToLower();
                    //1. public
                    //2. private
                    buttonHtml.Append(GetPrivacyButtonHtml(contactAccessiblity.Equals("1") ? "MakePrivate" : "MakePublic"));
                    buttonHtml.Append("&nbsp");
                    buttonHtml.Append(GetSendMessageButtonHtml(encryptedMemberID));
                    buttonHtml.Append("&nbsp");
                    buttonHtml.Append(GetPrivateLotForSaleButtonHtml(encryptedMemberID));
                    buttonHtml.Append("&nbsp");

                    if (myBuyingItems > 0)
                    {
                        buttonHtml.Append(GetSendPrivateWantToBuyButtonHtml(encryptedMemberID));
                        buttonHtml.Append("&nbsp");
                    }
                    if (mySellingItemsPosted > 0)
                    {
                        buttonHtml.Append(GetSendLinkToPostedLotForSaleButtonHtml(encryptedMemberID));
                        buttonHtml.Append("&nbsp");
                    }
                }
                else

                    if (member["ContactStatusID"].ToString().Equals("2"))// Pending for Approval
                    {
                        // if (contactTypeFilter == ContactView.PendingMyApproval)
                        // {
                        // Approve Decline Buttons Html
                        Contacts theContact = new Contacts();
                        theContact.LoadByPrimaryKey(Convert.ToInt32(member["ContactID"]));
                        if (theContact.MemberID == Web.SessionMembers.MemberID)
                        {
                            buttonHtml.Append("<span style='color:#AAAAAA;'>Need To Approve Me</span>");
                            buttonHtml.Append("&nbsp");
                        }
                        else
                        {
                            buttonHtml.Append(GetApproveButtonHtml());
                            buttonHtml.Append("&nbsp");
                            buttonHtml.Append(GetDeclineButtonHtml());
                            buttonHtml.Append("&nbsp");
                            showDeleteButton = false;

                            rowTemplate = rowTemplate.Replace("#HIDDEN#", string.Format("<input type='hidden' value='{0}' />", Secure.Encrypt(member["ContactID"])));
                        }
                    }
                    else
                    {
                        buttonHtml.Append("<span style='color:#AAAAAA;'>Need To Approve Me</span>");
                        buttonHtml.Append("&nbsp");
                    }
                if (showDeleteButton)
                    buttonHtml.Append(GetDeleteContacctButtonHtml());
                buttonHtml.Append("&nbsp");
                rowTemplate = rowTemplate.Replace("#HIDDEN#", string.Format("<input type='hidden' value='{0}' />", encryptedMemberID));
            }
            else
            {
                // Member profile not activated
                buttonHtml.Append("<span style='color:#AAAAAA;'>Profile inactive</span>");
                buttonHtml.Append("&nbsp");

                buttonHtml.Append(GetDeleteInvitationButtonHtml());
                buttonHtml.Append("&nbsp");
                rowTemplate = rowTemplate.Replace("#HIDDEN#", string.Format("<input type='hidden' value='{0}' />", Secure.Encrypt(member["ContactID"])));
            }


            //  

            rowTemplate = rowTemplate.Replace("#BUTTON#", buttonHtml.ToString());


            row.cell.Add(rowTemplate);
            jqGrid.rows.Add(row);
        }

        return jqGrid;
    }

    [WebMethod(EnableSession = true)]
    public static string AddToContact(string encryptedMemberID, string type)
    {
        string result = "success";

        try
        {
            int memberID = 0;

            bool checkReusult = int.TryParse(encryptedMemberID, out memberID);
            if (checkReusult == false)
            {
                memberID = Convert.ToInt32(Secure.Decrypt(encryptedMemberID));
            }
            ContactTypes contactType = type.ToLower().Equals("clients") ? ContactTypes.Client : ContactTypes.Vendor;

            if (memberID != Web.SessionMembers.MemberID)
            {
                int InvitationID = 0;
                DataTable dt = Invitations.CheckIfInvited(Web.SessionMembers.MemberID, memberID);
                if (dt.Rows.Count > 0)
                {
                    InvitationID = Convert.ToInt32(dt.Rows[0][0].ToString());
                    Invitations invitations = new Invitations();
                    invitations.LoadByPrimaryKey(InvitationID);
                    if (invitations.RowCount > 0)
                    {
                        if (invitations.InvitedBy == Web.SessionMembers.MemberID)
                        {
                            if (invitations.InvitationStatus == 1)
                                result = "Vendor has already accepted your contact invitation";
                            else if (invitations.InvitationStatus == 2)
                                result = "Vendor has already rejected your contact invitation.";
                            else
                                result = "You have already invited the " + contactType.ToString() + " to your contact list.";
                        }
                        else
                            result = "You have already been invited by the Vendor.";
                    }
                }
                else
                {
                    InvitationID = Contacts.AddToContact(memberID, Web.SessionMembers.MemberID, (int)contactType, 1);
                    if (InvitationID > 0)
                    {
                        Invitations newInvitation = new Invitations();
                        newInvitation.LoadByPrimaryKey(InvitationID);
                        Members members = new Members();
                        members.LoadByPrimaryKey(memberID);

                        System.Collections.Specialized.StringDictionary templateKeys = new System.Collections.Specialized.StringDictionary();
                        try
                        {
                            // add activity
                            var newContact = new Contacts();
                            newContact.Where.InvitationID.Value = InvitationID;
                            newContact.Query.Load();
                            if (newContact.RowCount > 0)
                            {
                                templateKeys.Add("#type#", Web.GetContactType(newContact.ContactType));
                                templateKeys.Add("#initiatedto#", "#memberid#" + newContact.ContactMemberID + "#endmemberid#");
                                templateKeys.Add("#profileclass#", "#profileclass#" + newContact.ContactMemberID + "#endprofileclass#");
                                templateKeys.Add("#initiatedtoprofile#", "/Contacts/ViewProfile.aspx?Action=ViewDealer&RecordID=#encrypt#" + newContact.ContactMemberID + "#endencrypt#");
                                Web.AddPrivateActivityLog(Web.SessionMembers.MemberID, 33, templateKeys, Web.SessionMembers.MemberID, newContact.ContactID, members.MemberID);
                            }

                            templateKeys = new System.Collections.Specialized.StringDictionary();
                            templateKeys.Add("#email_header#", Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER"));
                            templateKeys.Add("#email_footer#", Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER"));
                            templateKeys.Add("#profile_link#", Web.SystemConfigs.GetKey("SITE_URL") + "Contacts/ViewProfile.aspx?Action=ViewDealer&status=pending&RecordID=" + Secure.Encrypt(Web.SessionMembers.MemberID) + "&ID=" + Secure.Encrypt(members.MemberID));
                            templateKeys.Add("#company_invitee#", Web.SessionMembers.CompanyName);
                            templateKeys.Add("#fullname_invitee#", Web.SessionMembers.FullName);
                            string[] name = Web.SessionMembers.FullName.Split(' ');
                            templateKeys.Add("#first_name_invitee#", name[0]);
                            templateKeys.Add("#fullname#", members.FullName);
                            templateKeys.Add("#type#", Web.GetContactType(newInvitation.ContactType));
                            templateKeys.Add("#message#", "Please accept my invitation to add you as my " + Web.GetContactType(newInvitation.ContactType) + " to be able to instantly communicate as well as keep up to date with each other's social and business activities.");
                            templateKeys.Add("#link_contact_requests#", Web.SystemConfigs.GetKey("SITE_URL") + "Contacts");

                            Web.SendMail(members.Email, Web.SystemConfigs.GetKey("CONTACT_EMAIL"), 203, templateKeys);
                            result = "A contact notification has been sent to " + Web.GetContactType(newInvitation.ContactType) + " for approval.";
                        }
                        catch (Exception ex)
                        {
                            Web.LogError(ex);
                        }
                    }
                }
            }
            else
                result = "You cannot add yourself to your contact list";
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }

        return result;
    }

    [WebMethod(EnableSession = true)]
    public static string UdateContactListItem(string recordID, string name, string email)
    {
        string result = "success";
        int id = Convert.ToInt32(Secure.Decrypt(recordID));
        MemberContactList contactItem = new MemberContactList();
        contactItem.Where.MemberContactListID.Value = id;
        contactItem.Query.Load();
        if (contactItem.RowCount > 0)
        {
            contactItem.ContactName = name;
            contactItem.ContactEmail = email;
            contactItem.Save();
        }

        return result;
    }

    //[Done]
    [WebMethod(EnableSession = true)]
    public static string AddNewContact(string email, string company, string name, string message, string type)
    {
        try
        {
            email = email.Trim();
            company = company.Trim();
            name = name.Trim();
            message = message.Trim();
            ContactTypes contactType = type.ToLower().Equals("clients") ? ContactTypes.Client : ContactTypes.Vendor;

            if (email == Web.SessionMembers.Email)
            {
                return "You cannot add yourself in your contact list.";
            }

            if (Invitations.CheckIfInvited(Web.SessionMembers.MemberID, email).Rows.Count > 0)
            {
                return "Contact Already Invited";
            }

            Members member = new Members();
            member.Where.Email.Value = email;
            member.Query.Load();
            if (member.RowCount > 0) // the case when Email already registed user
            {
                int InvitationID = Contacts.AddToContact(member.MemberID, Web.SessionMembers.MemberID, (int)contactType, 1);
                if (InvitationID > 0)
                {
                    Invitations newInvitation = new Invitations();
                    newInvitation.LoadByPrimaryKey(InvitationID);
                    Members members = new Members();
                    members.LoadByPrimaryKey(member.MemberID);

                    System.Collections.Specialized.StringDictionary templateKeys = new System.Collections.Specialized.StringDictionary();
                    try
                    {
                        // add activity
                        var newContact = new Contacts();
                        newContact.Where.InvitationID.Value = InvitationID;
                        newContact.Query.Load();
                        if (newContact.RowCount > 0)
                        {
                            templateKeys.Add("#type#", Web.GetContactType(newContact.ContactType));
                            templateKeys.Add("#initiatedto#", "#memberid#" + newContact.ContactMemberID + "#endmemberid#");
                            templateKeys.Add("#profileclass#", "#profileclass#" + newContact.ContactMemberID + "#endprofileclass#");
                            templateKeys.Add("#initiatedtoprofile#", "/Contacts/ViewProfile.aspx?Action=ViewDealer&RecordID=#encrypt#" + newContact.ContactMemberID + "#endencrypt#");
                            Web.AddPrivateActivityLog(Web.SessionMembers.MemberID, 33, templateKeys, Web.SessionMembers.MemberID, newContact.ContactID, members.MemberID);
                        }

                        templateKeys = new System.Collections.Specialized.StringDictionary();
                        templateKeys.Add("#email_header#", Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER"));
                        templateKeys.Add("#email_footer#", Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER"));
                        templateKeys.Add("#profile_link#", Web.SystemConfigs.GetKey("SITE_URL") + "Contacts/ViewProfile.aspx?Action=ViewDealer&status=pending&RecordID=" + Secure.Encrypt(Web.SessionMembers.MemberID) + "&ID=" + Secure.Encrypt(member.MemberID));
                        templateKeys.Add("#company_invitee#", Web.SessionMembers.CompanyName);
                        templateKeys.Add("#fullname_invitee#", Web.SessionMembers.FullName);
                        string[] names = Web.SessionMembers.FullName.Split(' ');
                        templateKeys.Add("#first_name_invitee#", names[0]);
                        templateKeys.Add("#fullname#", members.FullName);
                        templateKeys.Add("#type#", Web.GetContactType(newInvitation.ContactType));
                        templateKeys.Add("#message#", (!String.IsNullOrEmpty(message)) ? message : "Please accept my invitation to add you as my " + Web.GetContactType(newInvitation.ContactType) + " to be able to instantly communicate as well as keep up to date with each other's social and business activities.");
                        templateKeys.Add("#link_contact_requests#", Web.SystemConfigs.GetKey("SITE_URL") + "Live.aspx");

                        Web.SendMail(members.Email, Web.SystemConfigs.GetKey("CONTACT_EMAIL"), 203, templateKeys);

                        return "A contact notification has been sent to " + Web.GetContactType(newInvitation.ContactType) + " for approval.";
                    }
                    catch (Exception ex)
                    {
                        Web.LogError(ex);
                    }
                }
            }
            else // the case when email is not registered 
            {
                int InvitationID = Contacts.AddToContact(email, name, company, Web.SessionMembers.MemberID, (int)contactType, 1);
                if (InvitationID > 0)
                {
                    Invitations invitation = new Invitations();
                    invitation.LoadByPrimaryKey(InvitationID);

                    System.Collections.Specialized.StringDictionary templateKeys = new System.Collections.Specialized.StringDictionary();
                    try
                    {
                        Random rand = new Random();

                        templateKeys = new System.Collections.Specialized.StringDictionary();
                        templateKeys.Add("#site_url#", Web.SystemConfigs.GetKey("SITE_URL"));
                        templateKeys.Add("#email_header#", Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER"));
                        templateKeys.Add("#fullname_invitee#", Web.SessionMembers.FullName);
                        templateKeys.Add("#company_invitee#", Web.SessionMembers.CompanyName);
                        templateKeys.Add("#type#", type.ToLower());
                        templateKeys.Add("#code#", "");
                        templateKeys.Add("#fullname#", "Dear User");
                        string names = Web.SessionMembers.FullName;
                        string[] namesplit = names.Split(' ');
                        templateKeys.Add("#first_name_invitee#", namesplit[0]);
                        templateKeys.Add("#email#", email);
                        templateKeys.Add("#message#", (!String.IsNullOrEmpty(message)) ? message.Replace("Client/Vendor", type.ToLower()) : "Please accept my invitation to add you as my " + type.ToLower() + " in order to keep up to date with your " + Web.GetActivityType(invitation.ContactType) + " activities, and communicate to you instantly on " + Web.SystemConfigs.GetKey("SITE_NAME") + ".com.");
                        templateKeys.Add("#activation_link#", Web.SystemConfigs.GetKey("SITE_URL") + "Index.aspx?Type=NonMember&InvitationID=" + Secure.Encrypt(InvitationID));
                        templateKeys.Add("#homepage_link#", Web.SystemConfigs.GetKey("SITE_URL") + "Index.aspx?Type=RegisterNonMember");
                        //templateKeys.Add("#profile_link#", Web.SystemConfigs.GetKey("SITE_URL") + "Contacts/ViewProfile.aspx?Action=ViewDealer&status=pending&RecordID=" + Secure.Encrypt(Web.SessionMembers.MemberID) + "&ID=" + "Secure.Encrypt(member.MemberID)");
                        templateKeys.Add("#profile_link#", Web.SystemConfigs.GetKey("SITE_URL") + "Contacts/ViewProfile.aspx?Action=ViewDealer&status=pending&RecordID=" + Secure.Encrypt(Web.SessionMembers.MemberID));
                        templateKeys.Add("#tutorial_link#", Web.SystemConfigs.GetKey("SITE_URL") + "HelpAndTutorial.aspx");
                        templateKeys.Add("#help_link#", Web.SystemConfigs.GetKey("SITE_URL") + "HelpAndTutorial.aspx");
                        templateKeys.Add("#email_footer#", Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER"));

                        Web.SendMail(email, Web.SystemConfigs.GetKey("REG_EMAIL"), 303, templateKeys);


                    }
                    catch (Exception ex)
                    {
                        Web.LogError(ex);
                    }

                    return "A contact notification has been sent to " + contactType.ToString() + " for approval.";
                }
                else
                    return "The person you requested to add in contact is blocked.";
            }

        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }

        return "success";
    }

    private static string GetMemberCompanyName(object companyName)
    {
        try
        {
            if (!companyName.ToString().Trim().ToLower().Contains("leave blank if you do not have"))
            {
                return companyName.ToString();
            }
        }
        catch
        {
        }
        return string.Empty;

    }

    private static string GetImageUrl(object memberID)
    {
        return "<img width='48' height='48' src='/ePage/ImageViewer.ashx?Action=MembersLogoThumbnail&RecordID=" + memberID + "' />";
    }

    private static string GetContactInfoUrl(object memberID, object companyName)
    {
        return string.Format("<a href='/Contacts/ViewProfile.aspx?Action=ViewDealer&RecordID={0}' title='{1}'>{2}</a>", memberID, companyName, GetReducedString(companyName.ToString(), 30));
    }

    private static string GetReducedString(string inputString, int maxLength)
    {
        try
        {
            if (inputString.Length <= maxLength)
                return inputString;

            return inputString.Substring(0, maxLength - 2) + "...";
        }
        catch
        {
            return inputString;
        }
    }

    private static string GetPrivacyButtonHtml(string privacyType)
    {
        string html = "<span style='vertical-align:middle;padding:0px; margin:0px;'>";
        if (privacyType == "MakePublic")
        {
            //html += "<a onclick=\"PerformContactAction(this,'MakePublic');\" href='#' >Make Public</a>";
            //html += "<a onclick=\"PerformContactAction(this,'MakePrivate');\" style='display:none;' href='#' >Make Private</a>";
            html += "<a onclick=\"PerformContactAction(this,'MakePublic');\" href='#' ><img style='vertical-align:top;' title='Make Public' src='../Images/Contacts/makepublic.png' alt='Send Message' style='border-width:0px;' /></a>";
            html += "<a onclick=\"PerformContactAction(this,'MakePrivate');\" style='display:none;' href='#' ><img  title='Make Private' src='../Images/Contacts/makeprivate.png' alt='Send Message' style='border-width:0px;' /></a>";
        }
        else
        {
            //html += "<a onclick=\"PerformContactAction(this,'MakePrivate');\" href='#' >Make Private</a>";
            //html += "<a onclick=\"PerformContactAction(this,'MakePublic');\" style='display:none;' href='#' >Make Public</a>";
            html += "<a onclick=\"PerformContactAction(this,'MakePrivate');\" href='#' ><img style='vertical-align:top;' title='Make Private' src='../Images/Contacts/makeprivate.png' alt='Send Message' style='border-width:0px;' /></a>";
            html += "<a onclick=\"PerformContactAction(this,'MakePublic');\" style='display:none;' href='#' ><img  title='Make Public' src='../Images/Contacts/makepublic.png' alt='Send Message' style='border-width:0px;' /></a>";
        }

        return html + "</span>";// "<a onclick=\"PerformContactAction(this,'" + privacyType + "')\" href='#' >Make Public</a>";
    }

    //private static string GetSendMessageButtonHtml(object memberID)
    //{
    //    return "&nbsp;<a href='MessageToSelected.aspx?Action=MessageToOne&RecordID=" + memberID + "'><img height='16' width='16' style='vertical-align:top;'  title='Send Message' src='/App_Themes/Space/Images/eOpen 16X16 Icons/sentmessage.png' alt='Send Message' style='border-width:0px;' /> </a>";
    //}
    private static string GetSendMessageButtonHtml(object memberID)
    {
        return "&nbsp;<a href='/MailBox/Default.aspx?Action=MessageToOne&MessageType=New&RecordID=" + memberID + "'><img height='16' width='16' style='vertical-align:top;'  title='Send Message' src='/App_Themes/Space/Images/eOpen 16X16 Icons/sentmessage.png' alt='Send Message' style='border-width:0px;' /> </a>";
    }

    private static string GetSendPrivateWantToBuyButtonHtml(object memberID)
    {
        //return string.Empty;
        // ToDo
        return "<a href='/MarketPlace/WTB/Add.aspx?action=private_WTB&Recordid=" + memberID + "'><img style='vertical-align:top;' alt='WTB' height='16' width='16' title='Send a Private Want to Buy' src='../Images/Contacts/want%20to%20buy/16.gif'></a>";
    }

    private static string GetPrivateLotForSaleButtonHtml(object memberID)
    {
        return string.Empty;
        // ToDo
        //return "<a href='/MarketPlace/WTS/Add.aspx?action=private_WTS&recordid=" + memberID + "'><img style='vertical-align:top;' alt='WTB'  title='Private Lot for Sale' src='../Images/Contacts/privatelotforsale.png'></a>";
    }

    private static string GetSendLinkToPostedLotForSaleButtonHtml(object memberID)
    {
        //return string.Empty;
        // ToDo
        return "<a href='/MarketPlace/AddressBook/UserActions.aspx?Action=PostedWTS&RecordID=" + memberID + "'><img style='vertical-align:top;' alt='Lot for Sale' height='16' width='16' title='Send Link to Posted  Lot for Sale' src='../Images/Contacts/lotforsale.png' /></a>";
    }

    private static string GetApproveButtonHtml()
    {
        return "<a><img style='vertical-align:top;' title='Approve' src='../Images/Contacts/approve.png' alt='Delete' onclick=\"PerformContactAction(this,'Approve')\"; style='height:16px;width:16px;border-width:0px;' tabindex='0' /></a>";
    }

    private static string GetDeclineButtonHtml()
    {
        return "<a><img style='vertical-align:top;' title='Decline' src='../Images/Contacts/decline.png' alt='Delete' onclick=\"PerformContactAction(this,'Decline')\"; style='height:16px;width:16px;border-width:0px;' tabindex='0' /></a>";
    }

    private static string GetDeleteContacctButtonHtml()
    {
        return "<a href='#'><img style='vertical-align:top;' title='Delete' src='../Images/Contacts/delete.png' alt='Delete' onclick=\"PerformContactAction(this,'Delete')\"; style='height:16px;width:16px;border-width:0px;' tabindex='0' /></a>";
    }

    private static string GetDeleteInvitationButtonHtml()
    {
        return "<a href='#'><img style='vertical-align:top;' title='Delete' src='../Images/Contacts/delete.png' alt='Delete' onclick=\"PerformContactAction(this,'DeleteInvitation')\"; style='height:16px;width:16px;border-width:0px;' tabindex='0' /></a>";
    }

    #endregion


    [WebMethod(EnableSession = true)]
    public static string DeleteContactList(long batchNumber)
    {
        string result = "success";

        NCI.EasyObjects.TransactionManager transactionManager = new NCI.EasyObjects.TransactionManager();
        transactionManager.BeginTransaction();
        try
        {
            MemberContactList memberContactList = new MemberContactList();
            memberContactList.Where.BatchNumber.Value = batchNumber;
            memberContactList.Query.Load();

            if (memberContactList.RowCount > 0)
            {
                do
                {
                    memberContactList.MarkAsDeleted();
                } while (memberContactList.MoveNext());

                memberContactList.Save();
                transactionManager.CommitTransaction();
            }
        }
        catch (Exception ex)
        {
            result = "error";
            transactionManager.RollbackTransaction();

            Web.LogError(ex);
        }

        return result;
    }
}