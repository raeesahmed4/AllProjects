﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Data;
using System.Web.Script.Services;
using System.Web.Services;
using CodenameRabbitFoot.BusinessLogic;

public partial class Contacts_Links : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    #region My Linkings / Links to Me

    [WebMethod(EnableSession = true)]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public static JQGrid LoadMyLinkings(string contactType, int pageIndex, int pageSize, string filter)
    {

        JQGrid jqGrid = new JQGrid();
        if (!Web.IsMemberSession)
        {
            jqGrid.status = "login";
        }

        IEnumerable<DataRow> allRows = MembersWatchListDealers.GetWatchlistDealers(Web.SessionMembers.MemberID).Select();

        // all filterign is made above 
        jqGrid.total = allRows.Count() == pageSize ? 1 : (allRows.Count() / pageSize) + 1;
        jqGrid.records = pageSize;
        jqGrid.page = pageIndex;
        IEnumerable<DataRow> dataRows = allRows.Skip((pageIndex - 1) * pageSize).Take(pageSize);

        if (dataRows.Count() == 0)
        {
            JQGrid.Row row = new JQGrid.Row();
            row.id = 0;
            row.cell.Add("0");
            row.cell.Add("<div style='text-align:left; padding:5px;'>" + Constants.MSG_MY_LINKINGS_EMPTY_GRID + "</div>");
            jqGrid.rows.Add(row);
            jqGrid.status = "empty";
        }

        foreach (DataRow member in dataRows)
        {
            //if (member["MemberID"].ToString().Equals(Web.SessionMembers.MemberID.ToString()))
            //    continue;

            string rowTemplate = @"
                            <table cellpadding='0' cellspacing='0'   border='0' class='tblGridRow' style='padding-top:9px; padding-bottom:9px;' >
                            <tr><td rowspan='3' valign='top' class='imgContainer'  style='width:50px; border-right-width:0px; border-left-width:0px; border-bottom-width:0px; border-top-width:0px'>#IMAGE#</td><td class='defaultCell'  style='width:350px; border-right-width:0px; border-left-width:0px; border-bottom-width:0px; border-top-width:0px'>#NAME#</td><td rowspan='3' valign='middle' class='imgContainer'  style='border-right-width:0px; border-left-width:0px; border-bottom-width:0px; border-top-width:0px; '>
                            <div style='text-align:right;width:250px;'>#BUTTON#</div> #HIDDEN#</td></tr>
                            <tr> <td class='defaultCell' style='border-right-width:0px; border-left-width:0px; border-bottom-width:0px; border-top-width:0px'>#ADDRESS#</td></tr>
                            <tr> <td class='defaultCell'  style='border-right-width:0px; border-left-width:0px; border-bottom-width:0px; border-top-width:0px'>#EMAIL#</td></tr>
                            </table>
                            ";
            /*
            object encryptedMemberID = Secure.Encrypt(member["MemberID"]);
            JQGrid.Row row = new JQGrid.Row();
            row.id = Convert.ToInt32(member["MemberID"]);
            row.cell.Add(member["MemberID"].ToString());
            rowTemplate = rowTemplate.Replace("#IMAGE#", GetImageUrl(encryptedMemberID));
            rowTemplate = rowTemplate.Replace("#NAME#", member["FullName"].ToString());
            rowTemplate = rowTemplate.Replace("#ADDRESS#", GetContactInfoUrl(encryptedMemberID, member["CompanyName"]));
            rowTemplate = rowTemplate.Replace("#EMAIL#", GetContactInfoUrl(encryptedMemberID, member["Email"]));
            */
            Members currentMember = new Members();
            currentMember.LoadByPrimaryKey(Convert.ToInt32(member["MemberID"]));

            object encryptedMemberID = Secure.Encrypt(currentMember.MemberID);
            JQGrid.Row row = new JQGrid.Row();
            row.id = currentMember.MemberID;
            row.cell.Add(currentMember.MemberID.ToString());
            rowTemplate = rowTemplate.Replace("#IMAGE#", GetImageUrl(encryptedMemberID));
            rowTemplate = rowTemplate.Replace("#NAME#", currentMember.FullName);
            rowTemplate = rowTemplate.Replace("#ADDRESS#", GetContactInfoUrl(encryptedMemberID, currentMember.CompanyName));
            rowTemplate = rowTemplate.Replace("#EMAIL#", GetContactInfoUrl(encryptedMemberID,currentMember.Email));

            StringBuilder buttonHtml = new StringBuilder();

            if (MembersWatchListDealers.CheckIfWatched(Web.SessionMembers.MemberID, currentMember.MemberID))
            {
                buttonHtml.Append(GetLinkUnlinkButtonHtml("unlink"));
            }
            else
            {
                buttonHtml.Append(GetLinkUnlinkButtonHtml("link"));
            }
            buttonHtml.Append("&nbsp");

            //check if already invited then dont display buttons
            bool isInvited = false;
            if (Web.SessionMembers.MemberID != currentMember.MemberID)
            {
                int InvitationID = 0;
                DataTable dt = Invitations.CheckIfInvited(Web.SessionMembers.MemberID, currentMember.MemberID);
                if (dt.Rows.Count > 0)
                {
                    InvitationID = Convert.ToInt32(dt.Rows[0][0].ToString());
                    Invitations invitations = new Invitations();
                    invitations.LoadByPrimaryKey(InvitationID);
                    if (invitations.RowCount > 0)
                    {
                        isInvited = true;                      
                    }
                }
            }

            if (!isInvited)
            {
                buttonHtml.Append(GetAddClientButtonHtml(encryptedMemberID));
                buttonHtml.Append("&nbsp");
                buttonHtml.Append(GetAddVendorButtonHtml(encryptedMemberID));
                buttonHtml.Append("&nbsp");
            }

            buttonHtml.Append(GetRemoveFromWatchListButtonHtml());
            buttonHtml.Append("&nbsp");
            //  

            rowTemplate = rowTemplate.Replace("#BUTTON#", buttonHtml.ToString());
            rowTemplate = rowTemplate.Replace("#HIDDEN#", string.Format("<input type='hidden' value='{0}' />", encryptedMemberID));
            row.cell.Add(rowTemplate);
            jqGrid.rows.Add(row);
        }

        return jqGrid;
    }

    [WebMethod(EnableSession = true)]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public static JQGrid LoadLinksToMe(string contactType, int pageIndex, int pageSize, string filter)
    {

        JQGrid jqGrid = new JQGrid();
        if (!Web.IsMemberSession)
        {
            jqGrid.status = "login";
        }

        IEnumerable<DataRow> allRows = MembersWatchListDealers.GetDealersLinkedToMe(Web.SessionMembers.MemberID).Select();

        // all filterign is made above 
        jqGrid.total = allRows.Count() == pageSize ? 1 : (allRows.Count() / pageSize) + 1;
        jqGrid.records = pageSize;
        jqGrid.page = pageIndex;
        IEnumerable<DataRow> dataRows = allRows.Skip((pageIndex - 1) * pageSize).Take(pageSize);
        if (dataRows.Count() == 0)
        {
            JQGrid.Row row = new JQGrid.Row();
            row.id = 0;
            row.cell.Add("0");
            row.cell.Add("<div style='text-align:left; padding:5px;'>" + Constants.MSG_LINKS_TO_ME_EMPTY_GRID + "</div>");
            jqGrid.rows.Add(row);
            jqGrid.status = "empty";
        }
        foreach (DataRow member in dataRows)
        {
            //if (member["MemberID"].ToString().Equals(Web.SessionMembers.MemberID.ToString()))
            //    continue;
            Members currentMember = new Members();
            currentMember.LoadByPrimaryKey(Convert.ToInt32(member["MemberID"]));


            string rowTemplate = @"
                            <table cellpadding='0' cellspacing='0'   border='0' class='tblGridRow' style='padding-top:9px; padding-bottom:9px;' >
                            <tr><td rowspan='3' valign='top' class='imgContainer'  style='width:50px; border-right-width:0px; border-left-width:0px; border-bottom-width:0px; border-top-width:0px'>#IMAGE#</td><td class='defaultCell'  style='width:350px; border-right-width:0px; border-left-width:0px; border-bottom-width:0px; border-top-width:0px'>#NAME#</td><td rowspan='3' valign='middle' class='imgContainer'  style='border-right-width:0px; border-left-width:0px; border-bottom-width:0px; border-top-width:0px; '>
                            <div style='text-align:right;width:250px;'>#BUTTON#</div> #HIDDEN#</td></tr>
                            <tr> <td class='defaultCell' style='border-right-width:0px; border-left-width:0px; border-bottom-width:0px; border-top-width:0px'>#ADDRESS#</td></tr>
                            <tr> <td class='defaultCell'  style='border-right-width:0px; border-left-width:0px; border-bottom-width:0px; border-top-width:0px'>#EMAIL#</td></tr>
                            </table>
                            ";

           /* object encryptedMemberID = Secure.Encrypt(member["MemberID"]);
            JQGrid.Row row = new JQGrid.Row();
            row.id = Convert.ToInt32(member["MemberID"]);
            row.cell.Add(member["MemberID"].ToString());
            rowTemplate = rowTemplate.Replace("#IMAGE#", GetImageUrl(encryptedMemberID));
            rowTemplate = rowTemplate.Replace("#NAME#", member["FullName"].ToString());
            rowTemplate = rowTemplate.Replace("#ADDRESS#", GetContactInfoUrl(encryptedMemberID, member["CompanyName"]));
            rowTemplate = rowTemplate.Replace("#EMAIL#", GetContactInfoUrl(encryptedMemberID, member["Email"]));
            */
            object encryptedMemberID = Secure.Encrypt(currentMember.MemberID);
            JQGrid.Row row = new JQGrid.Row();
            row.id = currentMember.MemberID;
            row.cell.Add(currentMember.MemberID.ToString());
            rowTemplate = rowTemplate.Replace("#IMAGE#", GetImageUrl(encryptedMemberID));
            rowTemplate = rowTemplate.Replace("#NAME#", currentMember.FullName);
            rowTemplate = rowTemplate.Replace("#ADDRESS#", GetContactInfoUrl(encryptedMemberID, currentMember.CompanyName));
            rowTemplate = rowTemplate.Replace("#EMAIL#", GetContactInfoUrl(encryptedMemberID, currentMember.Email));

            StringBuilder buttonHtml = new StringBuilder();

            //if (MembersWatchListDealers.CheckIfWatched(Web.SessionMembers.MemberID, Convert.ToInt32(member["MemberID"])))
            //{
            //    buttonHtml.Append(GetLinkUnlinkButtonHtml("unlink"));
            //}
            //else
            //{
            //    buttonHtml.Append(GetLinkUnlinkButtonHtml("link"));
            //}
            //buttonHtml.Append("&nbsp");

            buttonHtml.Append(GetAddClientButtonHtml(encryptedMemberID));
            buttonHtml.Append("&nbsp");
            buttonHtml.Append(GetAddVendorButtonHtml(encryptedMemberID));
            buttonHtml.Append("&nbsp");
            buttonHtml.Append(GetRemoveLinkToMeButtonHtml());
            buttonHtml.Append("&nbsp");
            //  

            rowTemplate = rowTemplate.Replace("#BUTTON#", buttonHtml.ToString());
            rowTemplate = rowTemplate.Replace("#HIDDEN#", string.Format("<input type='hidden' value='{0}' />", encryptedMemberID));
            row.cell.Add(rowTemplate);
            jqGrid.rows.Add(row);
        }

        return jqGrid;
    }

    private static string GetImageUrl(object memberID)
    {
        return "<img width='48' height='48' src='../../ePage/ImageViewer.ashx?Action=MembersLogoThumbnail&RecordID=" + memberID + "' />";
    }
    private static string GetContactInfoUrl(object memberID, object companyName)
    {
        return string.Format("<a target='_blank' href='../contacts/viewprofile.aspx?Action=ViewDealer&RecordID={0}'>{1}</a>", memberID, companyName);
    }

    private static string GetLinkUnlinkButtonHtml(string type)
    {
        StringBuilder html = new StringBuilder();
        html.Append("<span style='vertical-align:middle;padding:0px; margin:0px;'>");
        if (type == "link")
        {
            html.Append("<a onclick=\"PerformContactAction(this,'Link');\" href='#' ><img style='vertical-align:top;' title='Link' src='../Images/Linkings/Link-15.png' alt='Link' style='border-width:0px;' /></a>");
            html.Append("<a onclick=\"PerformContactAction(this,'UnLink');\" style='display:none;' href='#' ><img  title='Unlink' src='../Images/Linkings/Unlink-15.png' alt='Unlink' style='border-width:0px;' /></a>");
        }
        else
        {
            html.Append("<a onclick=\"PerformContactAction(this,'UnLink');\" href='#' ><img style='vertical-align:top;' title='Unlink' src='../Images/Linkings/Unlink-15.png' alt='Unlink' style='border-width:0px;' /></a>");
            html.Append("<a onclick=\"PerformContactAction(this,'Link');\" style='display:none;' href='#' ><img  title='Link' src='../Images/Linkings/Link-15.png' alt='Link' style='border-width:0px;' /></a>");
        }

        html.Append("</span>");
        return html.ToString();
    }
    private static string GetAddClientButtonHtml(object memberID)
    {
        return "<a href='Default.aspx?Action=clients&ContactType=1&RecordID=" + memberID + "'> <img height='16' width='16' style='vertical-align:top;'  title='Add as Client' src='../App_Themes/Space/Images/eOpen 16X16 Icons/eo_panel_icon_clients_blue.png' alt='Add as Client' style='border-width:0px;' /> </a>";
    }

    private static string GetAddVendorButtonHtml(object memberID)
    {
        return "<a href='Default.aspx?Action=vendors&ContactType=2&RecordID=" + memberID + "'> <img height='16' width='16' style='vertical-align:top;'  title='Add as Vendor' src='../App_Themes/Space/Images/eOpen 16X16 Icons/eo_panel_icon_vendors.png' alt='Add as Vendor' style='border-width:0px;' /> </a>";
    }

    private static string GetRemoveFromWatchListButtonHtml()
    {
        return "<a href='#'><img style='vertical-align:top;' title='Remove from watchlist' src='../Images/Contacts/delete.png' alt='Remove from watchlist' onclick=\"PerformContactAction(this,'RemoveFromWatchList')\"; style='height:16px;width:16px;border-width:0px;' tabindex='0' /></a>";
    }
    private static string GetRemoveLinkToMeButtonHtml()
    {
        return "<a href='#'><img style='vertical-align:top;' title='Remove from watchlist' src='../Images/Contacts/delete.png' alt='Remove from watchlist' onclick=\"PerformContactAction(this,'removelinktome')\"; style='height:16px;width:16px;border-width:0px;' tabindex='0' /></a>";
    }


    #endregion
}