﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using CodenameRabbitFoot.BusinessLogic;
using System.Web.Services;
using System.Text.RegularExpressions;
using System.Text;
using System.Web.Script.Services;
using System.Xml.Linq;

public partial class Contacts_ViewProfile : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Web.IsMemberSession)
            this.Master.ShowAddToContaccts = true;
    }

    protected void Page_LoadComplete(object sender, EventArgs e)
    {
        try
        {
            if (Request.QueryString["RecordID"] != null)
            {
                this.Master.MemberID = Web.RecordID;
                Members member = new Members();
                member.LoadByPrimaryKey(Web.RecordID);
                if (member.RowCount > 0)
                    this.Master.ViewContactInfo = !Convert.ToBoolean(member.IsPrivate);
            }
        }
        catch (Exception exp)
        {
            Web.LogError(exp);
        }
    }

    [WebMethod(EnableSession = true)]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public static IEnumerable<FeedItem> LoadFeedItems(int numberItemsToSkip, int numberOfItemsToTake, string memberID, string type)
    {
        if (type.Equals("Clients", StringComparison.InvariantCultureIgnoreCase) || type.Equals("Vendors", StringComparison.InvariantCultureIgnoreCase))
            return LoadContacts(type, numberItemsToSkip, numberOfItemsToTake, memberID);

        if (type.Equals("Exhibits", StringComparison.InvariantCultureIgnoreCase))
            return LoadExhibitions(numberItemsToSkip, numberOfItemsToTake, memberID);

        if (type.Equals("L-Apps", StringComparison.InvariantCultureIgnoreCase))
            return LoadLinkApps(numberItemsToSkip, numberOfItemsToTake, memberID);

        int feedMemberID = 0;
        if (!int.TryParse(memberID, out feedMemberID))
            feedMemberID = Convert.ToInt32(Secure.Decrypt(memberID));

        List<FeedItem> items = new List<FeedItem>();
        try
        { 
            int counter = 0;
            int feedItemSequenceNumber = 0;
            var resultSet = Fx.ExecuteDataSet("EN_LoadFeed", numberItemsToSkip, numberOfItemsToTake, (Web.IsMemberSession ? Web.SessionMembers.MemberID : 0), feedMemberID, type);

            if (resultSet == null)
                return items;

            var feedItems = resultSet.Tables[0];
            feedItemSequenceNumber = 1;

            foreach (DataRow row in feedItems.Rows)
            {
                FeedItem item = new FeedItem();
                item.Id = feedItemSequenceNumber.ToString();
                item.EncryptedItemId = Secure.Encrypt(row["ActivityLogID"].ToString());
                item.MemberId = row["MemberID"].ToString();
                item.UserName = row["UserName"].ToString();

                if (Web.IsMemberSession)
                    item.UserName = item.MemberId.Equals(Web.SessionMembers.MemberID.ToString()) ? "You" : row["UserName"].ToString();
                
                item.IsPosting = row["IsPosting"].ToString();
                item.Title = HttpContext.Current.Server.HtmlEncode(row["Title"].ToString());
                if (item.IsPosting.Equals("0"))
                {
                    var titleParts = item.Title.Split('|');
                    if (titleParts.Count() > 1)
                    {
                        item.Title = titleParts[0];
                        item.ListingTypeName = titleParts[1];
                    }
                }

                item.Date = Convert.ToDateTime(row["ActivityDate"]).ToUniversalTime().ToString();// Convert.ToDateTime(row["ActivityDate"]).Subtract(new DateTime(1970, 1, 1)).Ticks.ToString();
                item.Description = row["Description"].ToString();
                item.ShowLinkUnlink = row["ShowLinkUnlink"].ToString();
                item.ObjectId = row["ObjectID"].ToString();
                if (!item.ObjectId.Equals("0"))
                    item.ObjectId = Secure.Encrypt(item.ObjectId);// Listing ID etc.

                string xmlData = row["Files"].ToString();
                if (!string.IsNullOrWhiteSpace(xmlData))
                {
                    XDocument xDocument = XDocument.Parse(xmlData);
                    counter = 1;
                    foreach (var element in xDocument.Root.Descendants())
                    {
                        FeedItem.Files file = new FeedItem.Files();
                        file.Id = counter.ToString();
                        file.EncryptedFileId = Secure.Encrypt(element.Attribute("SystemObjectFileID").Value);
                        file.FileName = element.Attribute("FileName").Value;
                        file.Type = Web.GetFileType(element.Attribute("Type").Value.ToLower().Trim(), file.FileName);
                        file.Url = element.Attribute("Url").Value;
                        file.Thumbnail = element.Attribute("ThumbnailUrl").Value;
                        item.files.Add(file);
                        counter++;
                    }
                }

                // Fetch comments
                xmlData = row["ActivityComments"].ToString();
                if (!string.IsNullOrWhiteSpace(xmlData))
                {
                    XDocument xDocument = XDocument.Parse(xmlData);
                    counter = 1;
                    foreach (var element in xDocument.Root.Descendants())
                    {
                        Comments comment = new Comments();
                        comment.Id = counter.ToString();
                        comment.EncryptedCommentId = Secure.Encrypt(element.Attribute("ActivityLogCommentsID").Value);
                        comment.Description = element.Attribute("Comments").Value;
                        comment.Date = Convert.ToDateTime(element.Attribute("CommentsDate").Value).ToUniversalTime().ToString();// Convert.ToDateTime(element.Attribute("CommentsDate").Value).Subtract(new DateTime(1970, 1, 1)).TotalMilliseconds.ToString();
                        comment.CommentBy = element.Attribute("CommentsBy").Value;
                        comment.UserName = element.Attribute("UserName").Value;
                        // Item owner can delete every comment. Comment owner can delete his own comments only.
                        if (Web.IsMemberSession)
                            comment.AllowDelete = Web.SessionMembers.MemberID.ToString().Equals(item.MemberId) || Web.SessionMembers.MemberID.ToString().Equals(comment.CommentBy);

                        if (Web.IsMemberSession)
                            comment.UserName = comment.CommentBy.Equals(Web.SessionMembers.MemberID.ToString()) ? "You" : element.Attribute("UserName").Value;
                        item.comments.Add(comment);
                        counter++;
                    }
                }
                items.Add(item);
                feedItemSequenceNumber++;
            }
        }
        catch (Exception exp)
        {
            Web.LogError(exp);
        }
        return items;
    }

    [WebMethod(EnableSession = true)]
    public static string DeleteItem(string id, string type)
    {
        try
        {
            type = type.ToLower().Trim();
            int decryptedID = Convert.ToInt32(Secure.Decrypt(id));

            if (!Web.IsMemberSession)
                return "login";

            if (type.Equals("feed"))
                DeleteFeedItem(decryptedID);
            else if (type.Equals("comment"))
                DeleteComment(decryptedID);
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
            return "failed";
        }

        return "success";
    }

    [WebMethod(EnableSession = true)]
    public static string ToggleLinkUnlinkStatus(string id, string type)
    {
        try
        {
            if (!Web.IsMemberSession)
                return "login";

            type = type.ToLower().Trim();
            int decryptedID = Convert.ToInt32(Secure.Decrypt(id));
            Fx.ExecuteSp("EN_ToggleLinkUnlinkStatus", id, Web.SessionMembers.MemberID, type);
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
            return "failed";
        }
        return "success";
    }

    [WebMethod]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public static Comments AddComment(string itemId, string comment)
    {
        Comments feedItemComment = new Comments();
        try
        {
            feedItemComment.Id = "_" + Guid.NewGuid().ToString().Replace("-", "");
            feedItemComment.Description = Web.ConvertToTinyURL(HttpContext.Current.Server.UrlDecode(comment));
            feedItemComment.Date = DateTime.Now.AddSeconds(10).ToUniversalTime().ToString();
            feedItemComment.CommentBy = Web.SessionMembers.MemberID.ToString();
            feedItemComment.UserName = "You";
            int activityLogID = Convert.ToInt32(Secure.Decrypt(itemId));
            var result = Fx.ExecuteSp("EN_AddMemberActivityLogComment", activityLogID, Web.SessionMembers.MemberID, feedItemComment.Description, DateTime.Now);
            feedItemComment.EncryptedCommentId = Secure.Encrypt(result.Tables[0].Rows[0][0]);
            // Web.EmailonComment(activityLogID, Web.SessionMembers.UserName, feedItemComment.Description, Web.SessionMembers.MemberID);
        }
        catch (Exception exp)
        {
            Web.LogError(exp);
        }

        return feedItemComment;
    }

    [WebMethod(EnableSession = true)]
    public static string GetLeftMenuHtml(string invitationID)
    {
        StringBuilder html = new StringBuilder(@"<ul class='leftMenu'>");
        bool isValidInvitation = false;

        if (invitationID != "null")
        {
            try
            {
                var invitaions = new Invitations();
                invitaions.LoadByPrimaryKey(Convert.ToInt32(Secure.Decrypt(invitationID)));
                isValidInvitation = invitaions.RowCount > 0;
            }
            catch (Exception ex)
            { Web.LogError(ex); }
        }

        if (Web.IsMemberSession || isValidInvitation)
        {
            html.Append(@" <li id='liHome' class='menuItem'><span class='liHome'></span><a href='../live.aspx'><span>Live Exhibit Floor</span></a></li>
                                <li id='liHome0' class='selectedMenuItem'><span class='liPost'></span><a onclick=OnMenuItemClicked(this)><span>Global Posts</span></a></li>
                                <li id='liHome1' class='menuItem'><span class='liList'></span><a onclick=OnMenuItemClicked(this)><span>Activity Posts</span></a></li>
                                <li id='liHome3' class='menuItem hidden'><span class='liStats'></span><a onclick=OnMenuItemClicked(this)><span>Notes/Logs</span></a></li>
                                <li id='liHome7' class='menuItem'><span class='liPhoto'></span><a onclick=OnMenuItemClicked(this)><span>Photos</span></a></li>
                                <li id='liHome8' class='menuItem'><span class='liVideo'></span><a onclick=OnMenuItemClicked(this)><span>Videos</span></a></li>
                                <li id='liHome9' class='menuItem'><span class='liStats'></span><a onclick=OnMenuItemClicked(this)><span>Documents</span></a></li>                                                              
                                <li id='liHome2' class='menuItem'><span class='liMessage'></span><a onclick=OnMenuItemClicked(this)><span>Messages</span></a></li>                                
                                <li id='liHome4' class='menuItem'><span class='liLinkBoard'></span><a onclick=OnMenuItemClicked(this)><span>L-Apps</span></a></li>
                                <li id='liHome5' class='menuItem'><span class='liVendors'></span><a onclick=OnMenuItemClicked(this)><span>Vendors</span></a></li>
                                <li id='liHome6' class='menuItem'><span class='liClients'></span><a onclick=OnMenuItemClicked(this)><span>Clients</span></a></li>
                                <li id='liHome10' class='menuItem'><span class='liExhibitTools'></span><a onclick=OnMenuItemClicked(this)><span>Exhibits</span></a></li>                              
                        ");
        }
        else
        {
            html.Append(@" <li id='liHome' class='menuItem'><span class='liHome'></span><a href='../live.aspx'><span>Live Exhibit Floor</span></a></li>
                                <li id='liHome0' class='selectedMenuItem'><span class='liPost'></span><a onclick=OnMenuItemClicked(this)><span>Global Posts</span></a></li>
                                <li id='liHome4' class='menuItem'><span class='liLinkBoard'></span><a onclick=OnMenuItemClicked(this)><span>L-Apps</span></a></li>
                        ");

        }

        html.Append(@"</ul>");

        return html.ToString();
    }

    public static bool DeleteFeedItem(int id)
    {
        Fx.ExecuteSp("EN_DeleteFeedItem", id, Web.SessionMembers.MemberID);
        return true;
    }

    public static bool DeleteComment(int id)
    {
        Fx.ExecuteSp("EN_DeleteComment", id);
        return true;
    }

    public static IEnumerable<FeedItem> LoadLinkApps(int numberOfRowsToSkip, int numberOfRowsToTake, string recordID)
    {
        List<FeedItem> contacts = new List<FeedItem>();
        try
        {
            int memberID = 0;

            if (!int.TryParse(recordID, out memberID))
                memberID = Convert.ToInt32(Secure.Decrypt(recordID));

            IEnumerable<DataRow> allRows = ApplianceStore.GetApplianceStore(memberID).Select();
            int counter = 1;
            foreach (DataRow member in allRows)
            {
                FeedItem item = new FeedItem();
                item.Id = counter.ToString();
                item.EncryptedItemId = Secure.Encrypt(member["ApplianceStoreID"]);
                item.MemberId = Secure.Encrypt(member["MemberID"]);
                item.Title = member["ApplianceName"].ToString();
                item.Description = member["Description"].ToString();
                item.Status = member["ApplianceStatus"].ToString();
                contacts.Add(item);
                counter++;
            }
        }
        catch (Exception)
        {
        }
        return contacts.Skip(numberOfRowsToSkip).Take(numberOfRowsToTake);
    }

    public static IEnumerable<FeedItem> LoadContacts(string contactType, int numberOfRowsToSkip, int numberOfRowsToTake, string recordID)
    {
        List<FeedItem> contacts = new List<FeedItem>();
        try
        {
            ContactTypes type = contactType.Equals("clients", StringComparison.InvariantCultureIgnoreCase) ? ContactTypes.Client : ContactTypes.Vendor;
            int memberID = 0;

            if (!int.TryParse(recordID, out memberID))
                memberID = Convert.ToInt32(Secure.Decrypt(recordID));

            IEnumerable<DataRow> allRows = Contacts.GetMyContacts(Web.SessionMembers.MemberID, type, ContactView.AllContacts).Select();// Contacts.GetSharedContacts(memberID, type, ContactView.ApprovedContacts).Select();
            int counter = 1;
            foreach (DataRow member in allRows)
            {
                FeedItem item = new FeedItem();
                item.Id = counter.ToString();
                item.MemberId = Secure.Encrypt(member["ContactMemberID"]);
                item.Title = member["FullName"].ToString();
                item.Description = member["CompanyName"].ToString();
                item.EncryptedItemId = Secure.Encrypt(member["ContactID"]);
                //item.ListingTypeName = "TYpe ";
                item.Status = member["MemberStatusID"].ToString().Equals("200") ? "Live" : "ProfileInactive";
                item.ContactAccessibility = member["ContactAccessibilityID"].ToString() == "1" ? "MakePrivate" : "MakePublic";
                if (member["ContactStatusID"].ToString().Equals("1"))
                {
                    item.ContactStatus = "Approved";
                }
                else if (member["ContactStatusID"].ToString().Equals("2"))
                {
                    item.ContactStatus = "Pending for Approval";
                }
                item.HasBuyingItems = Counters.GetCount(CountTypes.Buying_Items_Posted, Web.SessionMembers.MemberID) > 0;
                item.HasSellingItems = Counters.GetCount(CountTypes.Selling_Lots, Web.SessionMembers.MemberID) > 0;
                contacts.Add(item);
                counter++;
            }
        }
        catch (Exception)
        {           
        }
        return contacts.Skip(numberOfRowsToSkip).Take(numberOfRowsToTake);
    }

    public static IEnumerable<FeedItem> LoadExhibitions(int numberOfRowsToSkip, int numberOfRowsToTake, string recordID)
    {
        List<FeedItem> exhibitions = new List<FeedItem>();
        try
        {           
            int memberID = 0;

            if (!int.TryParse(recordID, out memberID))
                memberID = Convert.ToInt32(Secure.Decrypt(recordID));

            IEnumerable<DataRow> allRows = Contacts.GetExhibitions(memberID).Select();
            int counter = 1;
            foreach (DataRow member in allRows)
            {
                FeedItem item = new FeedItem();
                item.Id = counter.ToString();
                item.MemberId = Secure.Encrypt(member["MemberID"]);
                item.Title = member["Name"].ToString();
                item.EncryptedItemId = Secure.Encrypt(member["ExhibitionID"]);
                item.Date = Convert.ToDateTime(member["DateAdded"]).ToUniversalTime().ToString();
                string xmlData = member["ExhibitionFiles"].ToString();
                if (!string.IsNullOrWhiteSpace(xmlData))
                {
                    XDocument xDocument = XDocument.Parse(xmlData);
                    counter = 1;
                    foreach (var element in xDocument.Root.Descendants())
                    {
                        FeedItem.Files file = new FeedItem.Files();
                        file.Id = counter.ToString();
                        file.EncryptedFileId = Secure.Encrypt(element.Attribute("SystemObjectFileID").Value);
                        file.FileName = element.Attribute("FileName").Value;
                        file.Type = Web.GetFileType(element.Attribute("Type").Value.ToLower().Trim(), file.FileName);
                        file.Url = element.Attribute("Url").Value;
                        file.Thumbnail = element.Attribute("ThumbnailUrl").Value;
                        item.files.Add(file);
                        counter++;
                    }
                }

                exhibitions.Add(item);
                counter++;
            }
        }
        catch (Exception)
        {
        }
        return exhibitions.Where(e => e.files.Count > 0).Skip(numberOfRowsToSkip).Take(numberOfRowsToTake);
    }

   
}