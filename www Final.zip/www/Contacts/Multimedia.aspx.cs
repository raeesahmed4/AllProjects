﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using CodenameRabbitFoot.BusinessLogic;
using System.Web.Services;
using System.Text.RegularExpressions;
using System.Text;

public partial class Contacts_Multimedia : System.Web.UI.Page
{
    public static Dictionary<int, int> linkIds = new Dictionary<int, int>();
    public static bool IsReply;
    public static string UserID;

    protected void Page_Load(object sender, EventArgs e)
    {
        Web.CheckSession();

        if (Web.SessionMembers == null) //!Web.IsMemberSession)
            Web.Redirect("../index.aspx");
        if (Web.SessionMembers != null)
            UpdateMessageStatus();

        if (Request.QueryString["Action"] != null)
        {
            if (Request.QueryString["Action"].ToLower() == "messages")
            {
                this.Page.Title = "My Messages";
            }
            else
                if (Request.QueryString["Action"].ToLower() == "videos")
                {
                    this.Page.Title = "My Videos";
                }
                else
                    if (Request.QueryString["Action"].ToLower() == "photos")
                    {
                        this.Page.Title = "My Photos";
                    }
        }
    }

    private void UpdateMessageStatus()
    {
        // ContactMessages.UpdateNewMessageStatus(Web.SessionMembers.MemberID);
    }

    [WebMethod]
    public static string LoadData(string type)
    {
        string strComment = "";
        type = type.ToLower();
        UserID = Web.SessionMembers.MemberID.ToString();

        try
        {

            if (type.Equals("inboxmessages"))
            {
                ExhibitLog.UpdateExhibitLog(Web.SessionMembers.MemberID, ExhibitViews.Message);                
                //DataTable dt = Contacts.GetInboxMessages(Web.SessionMembers.MemberID);
                DataTable dt = Contacts.GetSentnInboxMessages(Web.SessionMembers.MemberID, false);

                if (dt.Rows.Count > 0)
                    strComment = GenerateHTML(dt);
                else
                    strComment = "<div class='feedItem' style='padding:5px 0px 5px 0px;width:550px;'>&nbsp;&nbsp; No inbox messages exists.</div>";

            }
            else if (type.Equals("sentmessages"))
            {
                ExhibitLog.UpdateExhibitLog(Web.SessionMembers.MemberID, ExhibitViews.Message);                
                //DataTable dt = Contacts.GetInboxMessages(Web.SessionMembers.MemberID);
                DataTable dt = Contacts.GetSentnInboxMessages(Web.SessionMembers.MemberID, true);
                if (dt.Rows.Count > 0)
                    strComment = GenerateHTML(dt);
                else
                    strComment = "<div class='feedItem' style='padding:5px 0px 5px 0px;width:550px;'>&nbsp;&nbsp; No sent messages exists.</div>";

            }

            else
                if (type.Equals("videos"))
                { 
                    strComment = GenerateHTML(Contacts.GetVideos(Web.SessionMembers.MemberID));
                    if (string.IsNullOrEmpty(strComment))
                    {
                        strComment = "<div class='feedItem' style='padding:5px 0px 5px 0px;width:550px;'>&nbsp;&nbsp; No videos exists.</div>";
                    }
                }
                else
                    if (type.Equals("photos"))
                    {
                        strComment = GenerateHTML(Contacts.GetPhotos(Web.SessionMembers.MemberID));
                        if (string.IsNullOrEmpty(strComment))
                        {
                            strComment = "<div class='feedItem' style='padding:5px 0px 5px 0px;width:550px;'>&nbsp;&nbsp; No photos exists.</div>";
                        }
                    }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }

        return strComment;
    }

    [WebMethod]
    public static string LoadInboxMessages()
    {
        string strComment = "";
        DataTable dt = Contacts.GetSentnInboxMessages(Web.SessionMembers.MemberID, false);
        if (dt.Rows.Count > 0)
            strComment = GenerateHTML(dt);
        else
            strComment = "<div class='feedItem' style='padding:5px 0px 5px 0px;'>&nbsp;&nbsp; No messages exists.</div>";

        return strComment;
    }

    [WebMethod]
    public static string LoadSentMessages()
    {
        string strComment = "";
        DataTable dt = Contacts.GetSentnInboxMessages(Web.SessionMembers.MemberID, true);
        if (dt.Rows.Count > 0)
            strComment = GenerateHTML(dt);
        else
            strComment = "<div class='feedItem' style='padding:5px 0px 5px 0px;'>&nbsp;&nbsp; No messages exists.</div>";

        return strComment;
    }

    public static string GenerateHTML(DataTable dt)
    {
        string strComment = "";
        string replyHTML = "";
        string message, activityTitle;
        int logID;
        string refID, actID, memID, date_, xml, related, user, title, posttypeid, xmlComments;


        StringBuilder sb = new StringBuilder();
        try
        {
            if (dt.Rows.Count > 0)
            {
                //DataTable temp = Web.SummarizeFeed(dt.Copy());

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    IsReply = false;
                    logID = Convert.ToInt32(dt.Rows[i]["ActivityLogID"]);
                    user = Convert.ToString(dt.Rows[i]["UserName"]);
                    actID = Convert.ToString(dt.Rows[i]["ActivityID"]);
                    xml = Convert.ToString(dt.Rows[i]["Details"]);
                    xmlComments = Convert.ToString(dt.Rows[i]["ActivityComments"]);
                    memID = Convert.ToString(dt.Rows[i]["MemberID"]);
                    date_ = Convert.ToString(dt.Rows[i]["ActivityDate"]);
                    refID = Convert.ToString(dt.Rows[i]["ReferenceID"]);
                    message = dt.Rows[i]["Description"].ToString();
                    related = dt.Rows[i]["RelatedToContact"].ToString();
                    title = Convert.ToString(dt.Rows[i]["ActivityTitle"]);
                    posttypeid = "";// Convert.ToString(dt.Rows[i]["PostTypeID"]);
                    //------------------------------------------------------------------------------
                    // go to to netxt iteration of the for loop as reply will not shown as a posts 
                    if (actID == "19")
                    {
                        continue;
                    }
                    //------------------------------------------------------------------------------
                    if (!message.Contains(" ") && message.Length > 70)
                    {
                        message = Web.SplitString(message, 70);
                    }
                    activityTitle = Web.GetActivityTitle(memID, related, actID, title, message, refID, xml);

                    ///
                    activityTitle = activityTitle.Replace("posted a comment to all", "posted a comment to the world");
                    ////////get xml for new post (from post to the world) if activityID=45
                    if (actID == "45")
                    {
                        title = message;
                    }
                    message = Web.GetActivityDescription(true, logID.ToString(), actID, xml, message, refID, memID, date_, posttypeid);

                    if (actID == "40")
                    {
                        message = message.Replace("width: 468px;", "width: 433px;");
                    }

                    //-----------------------------------------------------------------------------
                    //if a message is sent

                    //generate reply html 
                    DataTable dtReply = ContactMessages.LoadMessageReply(Convert.ToInt32(refID));
                    if (dtReply.Rows.Count == 1 && actID == "4")
                    {
                        IsReply = true;
                        string newXML = dtReply.Rows[0][0].ToString();
                        replyHTML = loadFeeds(logID.ToString(), actID, refID, memID, 3, newXML, false);
                    }
                    //-----------------------------------------------------------------------------

                    //foreach (DataRow row in dt.Rows)
                    //{
                    sb.Append("<table class='feedItem'><tr><td id='Feed_" + logID + "'>");
                    sb.Append("<div style='width: 8%; float: left; text-align: left;'>");
                    sb.Append("<div style='padding: 0px;'>");
                    sb.Append("<img id='Img1' src='../../ePage/ImageViewer.ashx?Action=MembersLogoThumbnail&amp;RecordID=" + Secure.Encrypt(memID) + "' alt='eOpen' title='eOpen' style='border: 1px solid white;' width='32' height='32'>");
                    sb.Append("</div>");
                    sb.Append("</div>");
                    sb.Append("<div style='width: 92%; float: left; text-align: left;'>");
                    if (actID != "33")
                    {
                        sb.Append("<a href='/contacts/ViewProfile.aspx?Action=ViewDealer&amp;RecordID=" + Secure.Encrypt(memID) + "'>");
                        //set user name color 
                        string profileclass;
                        if (Web.IsMemberSession)
                            profileclass = Web.GetProfileClass(Convert.ToInt32(memID), Web.SessionMembers.MemberID);
                        else
                            profileclass = "Unknown";
                        sb.Append("<span class='" + profileclass + "'>");
                        sb.Append(Web.GetUserName(Convert.ToInt32(memID), user));
                        sb.Append("</span>");
                        sb.Append("</a>");
                    }
                    sb.Append("&nbsp;<span class='details'>");

                    //setting title
                    if (actID == "45")
                        sb.Append(title + "</span><br />");
                    else
                        sb.Append(activityTitle + "</span><br />");




                    sb.Append("<div class='feed_TimeStamp'>");
                    sb.Append(Web.GetTime(Convert.ToDateTime(date_)));
                    sb.Append("</span>&nbsp;</div>");
                    //actions buttons
                    if (Web.IsMemberSession)
                        sb.Append("<div style='float:right; padding-right:10px;'>");//moved the action buttons to right


                    if (!Web.IsMemberSession)
                    {
                        sb.Append("<div style='display: inline;' class='feed_actionLinks'>");
                        sb.Append("<a href='../index.aspx?Action=signup'>");
                        sb.Append("<img src='../../Images/LiveFeed/comment.png' alt='Comment' title='Comment' width='15' height='10'>&nbsp;&nbsp;&nbsp;&gt;Sign up to start exhibiting</a></div>");
                    }
                    if (Web.IsMemberSession)
                    {

                        sb.Append("<div style='display: inline;' class='feed_actionLinks'>");
                        sb.Append("<a href='javascript:void(0);' onclick='openCommentBox(" + logID + ");'>");
                        sb.Append("<img src='../../Images/LiveFeed/comment.png' alt='Comment' title='Comment' width='15' height='10'>");

                        sb.Append("</a></div>");
                        if (Web.ShowMessageIcon(memID, related) && (IsMyContactOrMe(memID)))
                        {
                            sb.Append("<div style='display: inline;' class='feed_actionLinks'>");
                            sb.Append("<a href='/contacts/MessageToSelected.aspx?Action=messagetoone&amp;RecordID=" + Secure.Encrypt(memID) + "'>");
                            sb.Append("<img src='../../Images/LiveFeed/mail.png' id='Img4' alt='Send Message' title='Send Message' width='13' height='10'>");
                            sb.Append("</a></div>");
                        }
                        if ((Web.ShowReply(actID, refID)) && (IsMyContactOrMe(memID)))
                        {
                            sb.Append("<div style='display: inline;' class='feed_actionLinks'>");
                            sb.Append("<a href='/contacts/MessageToSelected.aspx?Action=replytomessage&amp;RecordID=" + Secure.Encrypt(refID) + "'>");
                            sb.Append("<img src='../../Images/LiveFeed/reply_private_message_big.png' id='Img4' alt='Reply' title='Reply' width='13' height='10'>");
                            sb.Append("</a></div>");
                        }
                        if (Web.SessionMembers.MemberID.ToString() != memID && actID == "144")
                        {
                            sb.Append("<div class='feed_actionLinks' style='display: inline;'>");
                            sb.Append("<a href='../WTS/ViewLot.aspx?Action=View&amp;RecordID=" + Secure.Encrypt(refID) + "'>");
                            sb.Append("<img src='../../Images/LiveFeed/dollar_bag.png' id='Img2' alt='Make Offer' title='Make Offer' width='15' height='11'>");
                            sb.Append("</a></div>");
                        }
                        if (Web.SessionMembers.MemberID.ToString() != memID && actID == "3")
                        {
                            sb.Append("<div class='feed_actionLinks' style='display: inline;'>");
                            sb.Append("<a href='../WTB/ViewDetails.aspx?Action=View&amp;RecordID=" + Secure.Encrypt(refID) + "'>");
                            sb.Append("<img src='../../Images/LiveFeed/dollar_bag.png' id='Img5' alt='Make Offer' title='Make Offer' width='15' height='11'>");
                            sb.Append("</a></div>");
                        }
                        ///////////to update the link / unlink icon for the purticular user
                        if (linkIds.ContainsKey(Convert.ToInt32(memID)))
                            linkIds[Convert.ToInt32(memID)]++;
                        else
                            linkIds.Add(Convert.ToInt32(memID), 0);


                        if (Web.ShowLink(memID, actID))
                        {
                            //link
                            sb.Append("<div id='link_" + memID + "_" + linkIds[Convert.ToInt32(memID)] + "' class='feed_actionLinks' style='display: inline;'>");
                            sb.Append("<a href='javascript:void();' onclick='Link(" + memID + "," + logID + ");' >");
                            sb.Append("<img src='../../Images/Linkings/Link-15.png'  title='Link' alt='Link'  style='border-width: 0px;' />");
                            sb.Append("</a></div>");
                            //unlink
                            sb.Append("<div id='Unlink_" + memID + "_" + linkIds[Convert.ToInt32(memID)] + "' class='feed_actionLinks' style='display: none;'>");
                            sb.Append("<a href='javascript:void();'onclick='Unlink(" + memID + "," + logID + ");' >");
                            sb.Append("<img src='../../Images/Linkings/Unlink-15.png'  title='Unlink'  alt='Unlink' style='border-width: 0px;'/></a></div>");

                        }
                        if (Web.ShowUnlink(memID, actID))
                        {
                            //link
                            sb.Append("<div id='link_" + memID + "_" + linkIds[Convert.ToInt32(memID)] + "' class='feed_actionLinks' style='display: none;'>");
                            sb.Append("<a href='javascript:void();' onclick='Link(" + memID + "," + logID + ");' >");
                            sb.Append("<img src='../../Images/Linkings/Link-15.png'  title='Link' alt='Link'  style='border-width: 0px;' /></a></div>");
                            //unlink
                            sb.Append("<div id='Unlink_" + memID + "_" + linkIds[Convert.ToInt32(memID)] + "' class='feed_actionLinks' style='display: inline;'>");
                            sb.Append("<a href='javascript:void();'onclick='Unlink(" + memID + "," + logID + ");' >");
                            sb.Append("<img src='../../Images/Linkings/Unlink-15.png'  title='Unlink'  alt='Unlink' style='border-width: 0px;'/>");
                            sb.Append("</a></div>");
                        }
                        //end linking
                        sb.Append("<div class='feed_actionLinks' style='display: inline;'>");
                        sb.Append("<a href='javascript:void(0);' onclick='DeleteMessage(" + logID + ");'>");
                        sb.Append("<img src='../../Images/LiveFeed/cross.png' alt='Remove' title='Remove'></a>");
                        sb.Append("</div>");
                        if (memID != Web.SessionMembers.MemberID.ToString())
                        {
                            if (Web.ShowReportAbuse(actID))
                            {
                                sb.Append("<div class='feed_actionLinks' style='display: inline;'>");
                                sb.Append(" <a href='javascript:void(0);' onclick=\"openblockMemberWindow('ReportAbuse.aspx?Action=" + Secure.Encrypt(1) + "&RecordID=" + Secure.Encrypt(logID) + "');\">");
                                sb.Append("Report inappropriate> </a>");
                                sb.Append("</div>");
                            }
                        }
                    }

                    if (Web.IsMemberSession)
                        sb.Append("</div>");//end moved div

                    //'''''''''''''''''''''''''''''''''''''''''''''
                    sb.Append("</div>");
                    sb.Append("<table style='margin-bottom:10px;float:left;padding-left:18px; margin-left:15px; border-left:0px solid #febe10;border-bottom:0px solid #febe10;'");
                    sb.Append("<tr><td>&nbsp;");
                    sb.Append("</td></tr>");
                    sb.Append("<tr><td style='padding-right:10px;'>");
                    //'''''''''''''''''''''''''''''               
                    sb.Append(message);
                    if (IsReply)
                        sb.Append(replyHTML);
                    //activity comments  
                    sb.Append("<div id='TD_" + logID + "' style='width:445px;'>");
                    if (xmlComments != "")
                    {
                        sb.Append(loadFeeds(logID.ToString(), actID, refID, memID, 3, "", false));
                    }
                    sb.Append("</div>");

                    sb.Append("</div>");
                    if (Web.IsMemberSession)
                    {
                        sb.Append("<div style='display:none; border:0px solid #cccccc; overflow:hidden; padding:10px; width:422px;' id='CommentDiv_" + logID + "''>");
                        sb.Append("<textarea id='txtComment_" + logID + "' rows='3' cols='5' style='width:415px;'></textarea><br />");
                        sb.Append("<div style='float:right;'>");
                        sb.Append("<input type='button' class='InnerButtonGray' onclick=OnHide('CommentDiv_" + logID + "');  value='Cancel' /> &nbsp;");
                        sb.Append("<input type='button' id='btnPost' value='Post' class='InnerGridButton' onclick=\"SaveUserComments(" + Web.SessionMembers.MemberID.ToString() + "," + logID + "," + actID + "," + refID + ",'" + user + "'," + memID + ");\" />");
                        sb.Append("</div>");
                        sb.Append("</div>");
                    }
                    sb.Append("</div>");
                    sb.Append("</td></tr></table><br />");
                    sb.Append("</td></tr></table>");

                    //} 
                    strComment = sb.ToString();
                }
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
        return strComment;
    }

    public static string loadFeeds(string logID, string actID, string refID, string membID, int count, string xmlDtl, bool isBill)
    {
        StringBuilder sb = new StringBuilder();
        string activityComments;
        string username, comment;
        string commentDate;
        string activitLogID, activityCommentID;
        string[] subComments;
        string memberID;
        int counter = 0;
        string xml = xmlDtl;
        string jsMethod = "openBillboardCommentBox";
        string css = "defaultBillboard_Comments";

        if (xml == "")
        {
            //  xml = ViewAllFeeds(logID, membID); ToDo
            css = "feed_Comments";
            jsMethod = "openCommentBox";
        }
        //Activity comments
        sb.Append("<div  id='DV_" + logID.ToString() + "'>");

        //if it is a reply then do not show the arrow 
        if (!IsReply)
            sb.Append("<div class='feed_Comments_arrow'></div>");
        //-------------------------------------------------------
        activityComments = xml;
        subComments = Regex.Split(activityComments, "/>");

        try
        {
            foreach (var item in subComments)
            {
                if (item == "") break;

                if (count != 0)
                {
                    if (counter >= 3)
                    { break; }
                    counter++;
                }

                if (IsReply)//if this is a reply to any message then
                {
                    css = "feed_Comments";

                    username = item.Substring(item.IndexOf("UserName=\"") + 10);
                    username = username.Remove(username.IndexOf("\""));
                    //get the original reply
                    comment = ContactMessages.GetMessageReply(Convert.ToInt32(refID));

                    string[] chunks = { };
                    chunks = Regex.Split(comment, " ");
                    foreach (var str in chunks)
                    {
                        if (str.Length > 40)
                            if ((!str.Contains("www.")) && (!str.Contains("http")))
                                comment = Web.SplitString(comment, 60);
                    }

                    // memberID = item.Substring(item.IndexOf("RelatedToContact=\"") + 18);
                    memberID = item.Substring(item.IndexOf("MemberID=\"") + 10);
                    memberID = memberID.Remove(memberID.IndexOf("\""));
                    commentDate = item.Substring(item.IndexOf("ActivityDate=\"") + 14);
                    commentDate = commentDate.Remove(commentDate.IndexOf("\""));
                    commentDate = Web.GetTime(Convert.ToDateTime(commentDate));
                    activitLogID = item.Substring(item.IndexOf("ActivityLogID=\"") + 15);
                    activitLogID = activitLogID.Remove(activitLogID.IndexOf("\""));
                    activityCommentID = item.Substring(item.IndexOf("ReferenceID=\"") + 13);
                    activityCommentID = activityCommentID.Remove(activityCommentID.IndexOf("\""));
                }
                else
                {
                    username = item.Substring(item.IndexOf("UserName=\"") + 10);
                    username = username.Remove(username.IndexOf("\""));
                    comment = item.Substring(item.IndexOf("Comments=\"") + 10);
                    comment = comment.Remove(comment.IndexOf("\""));

                    string[] chunks = { };
                    chunks = Regex.Split(comment, " ");
                    foreach (var str in chunks)
                    {
                        if (str.Length > 40)
                            if ((!str.Contains("www.")) && (!str.Contains("http")))
                                comment = Web.SplitString(comment, 60);
                    }

                    memberID = item.Substring(item.IndexOf("CommentsBy=\"") + 12);
                    memberID = memberID.Remove(memberID.IndexOf("\""));
                    commentDate = item.Substring(item.IndexOf("CommentsDate=\"") + 14);
                    commentDate = commentDate.Remove(commentDate.IndexOf("\""));
                    commentDate = Web.GetTime(Convert.ToDateTime(commentDate));
                    activitLogID = item.Substring(item.IndexOf("ActivityLogID=\"") + 15);
                    activitLogID = activitLogID.Remove(activitLogID.IndexOf("\""));
                    activityCommentID = item.Substring(item.IndexOf("ActivityLogCommentsID=\"") + 23);
                    activityCommentID = activityCommentID.Remove(activityCommentID.IndexOf("\""));

                }
                //if there is no space or breaks in the comment
                if (!comment.Contains(" ") && comment.Length > 280)
                {
                    comment = Web.SplitString(comment, 70);
                }
                //if (comment.Length > 280 && actID == "40")
                //    isBill = true;

                sb.Append("<div id=\"DV_Del_" + activityCommentID + "\">");
                sb.Append("<div class='" + css + "' style=' text-align: left;padding-right:10px;margin-right:5px;'> ");
                sb.Append("<table style='margin: 2px; width: 100%; text-align: left;' border='0' cellpadding='0' cellspacing='0'>");
                sb.Append("<tr><td rowspan='2' valign='top' width='5%'>");
                sb.Append("<img src='../../ePage/ImageViewer.ashx?Action=MembersLogoThumbnail&amp;RecordID=" + Secure.Encrypt(memberID) + "' title='Logo' alt='Logo' width='24' height='24'>");
                sb.Append("</td><td align='left' valign='top' width='95%'>");
                sb.Append("<table border='0' cellpadding='1' width='100%'>");
                sb.Append("<tr><td align='left' width='50%'>");
                sb.Append("<span style='font-size: 7.5pt;'>");
                sb.Append("<a href='/contacts/ViewProfile.aspx?Action=ViewDealer&amp;RecordID=" + Secure.Encrypt(memberID) + "'>");
                //set user name class 
                string profileclass;
                if (Web.IsMemberSession)
                    profileclass = Web.GetProfileClass(Convert.ToInt32(memberID), Web.SessionMembers.MemberID);
                else
                    profileclass = "Unknown";
                sb.Append("<span class='" + profileclass + "'>");
                sb.Append(Web.GetUserName(Convert.ToInt32(memberID), username));
                sb.Append("</span></a>&nbsp;");
                sb.Append("<span class='details' style='font-size: 7.5pt;'>");

                if (IsReply)
                    sb.Append("replied&nbsp;");
                else
                    sb.Append("posted a comment&nbsp;");

                sb.Append("</span>");
                sb.Append("</span></td><td align='right'>");
                sb.Append("<span id='feed_TimeStamp" + activityCommentID + "' class='feed_TimeStamp' style='font-weight:200;'>");
                sb.Append(commentDate + "</span> ");

                sb.Append("<div class='feed_actionLinks' style='display: inline;>");
                //if this is reply to message then
                if (IsReply)
                {
                    //no comment button for reply post
                }
                else
                {
                    sb.Append("<a href='javascript:void(0);' onclick='" + jsMethod + "(" + activitLogID + ");' style='cursor:pointer;'>");
                    sb.Append("<img src='../../Images/LiveFeed/comment.png' alt='Comment' title='Comment' width='15' height='10'  style='cursor:pointer;'>");
                }
                //using (StringWriter sw = new StringWriter(sb))
                //{
                //    using (HtmlTextWriter tw = new HtmlTextWriter(sw))
                //    {
                //        sprite.RenderControl(tw);
                //    }
                //}
                sb.Append("</a></div>");
                if (Web.ShowReply(actID, refID) && (IsMyContactOrMe(memberID)))
                {
                    sb.Append("<div class='feed_actionLinks' style='display: inline;'>");
                    sb.Append("<a target='_top' href='/contacts/MessageToSelected.aspx?Action=MessageToOne&amp;RecordID=" + Secure.Encrypt(memberID) + "'>");
                    sb.Append("<img src='../../Images/LiveFeed/mail.png' alt='Send Message' title='Send Message' width='11' height='8'>");
                    //using (StringWriter sw = new StringWriter(sb))
                    //{
                    //    using (HtmlTextWriter tw = new HtmlTextWriter(sw))
                    //    {
                    //        spriteMessage.RenderControl(tw);
                    //    }
                    //}
                    sb.Append("</a></div>");
                }
                sb.Append("<div class='feed_actionLinks' style='display: inline;'>");

                //---------------if reply message  activityCommentID
                if (IsReply)
                {
                    sb.Append("<a href='javascript:void(0);' onclick='DeleteReply(" + activityCommentID + ");'>");
                    sb.Append("<img src='../../Images/LiveFeed/cross.png' alt='Remove' title='Remove'></a>");
                }
                else
                {
                    sb.Append("<a href='javascript:void(0);' onclick='DeleteSubComment(" + activityCommentID + "," + actID + "," + refID + "," + UserID + "," + activitLogID + ");'>");
                    sb.Append("<img src='../../Images/LiveFeed/cross.png' alt='Remove' title='Remove'></a>");
                }
                //using (StringWriter sw = new StringWriter(sb))
                //{
                //    using (HtmlTextWriter tw = new HtmlTextWriter(sw))
                //    {
                //        spriteDel.RenderControl(tw);
                //    }
                //}
                sb.Append("</div></td></tr></table>");
                sb.Append("</td></tr>");
                sb.Append("<tr><td style='font-size: 8pt; font-weight: normal; padding-left: 5px; text-align: justify; ");
                sb.Append("width: 415px; overflow: hidden;'>");

                //activity comment short.....
                comment = HttpUtility.HtmlDecode(comment);
                sb.Append("<div id='short_" + activityCommentID + "'>");
                bool isURL = false;
                Regex regx = new Regex("http(s)?://([\\w+?\\.\\w+])+([a-zA-Z0-9\\~\\!\\@\\#\\$\\%\\^\\&amp;\\*\\(\\)_\\-\\=\\+\\\\\\/\\?\\.\\:\\;\\'\\,]*)?", RegexOptions.IgnoreCase);
                MatchCollection mactches = regx.Matches(comment);
                foreach (Match match in mactches)
                {
                    isURL = true;
                }

                if (!isURL)
                    sb.Append(Web.ShortenComment(comment, Convert.ToInt32(activityCommentID)));
                else
                    sb.Append(comment);

                sb.Append("</div>");
                sb.Append("<div id=\"full_" + activityCommentID + "\" style=\"display: none;overflow: hidden; padding-right:3px;\">");
                sb.Append(Web.MakeLinksClickable(Web.BreakLongString(comment, 70)));
                sb.Append("<br />");
                sb.Append("<a href=\"javascript:void(0);\" onclick=\"Hide('full_" + activityCommentID + "');Show('short_" + activityCommentID + "');\">");
                sb.Append("View less>></a></div>");

                sb.Append("</div>");
                sb.Append("</td></tr></table>");
                sb.Append("</div>");
                sb.Append("</div>");
                /////////////////////////////////////////
                //string shortComment = "";
                //shortComment = sb.ToString();
                if (isBill)
                {
                    sb.Replace("short_", "bill_short_");
                    sb.Replace("full_", "bill_full_");
                }

                // sb.Append(shortComment);
            }
            if (xmlDtl == "")//not billboard comments
            {
                if (count == 0)
                {
                    sb.Append("<div id='less_" + logID + "' style='float:right;'><a href='javascript:void(0);' onclick='ViewLessComments(" + logID + "," + actID + "," + refID + "," + membID + ");'>View Less Comments>></a>");
                    sb.Append("</div>");
                }
                if (count != 0 && subComments.Length > 4)
                {
                    sb.Append("<div id='more_" + logID + "' style='float:right;'><a href='javascript:void(0);' onclick='ViewAllComments(" + logID + "," + actID + "," + refID + "," + membID + ");'>View All Comments>></a>");
                    sb.Append("</div>");
                }
            }
            else
            {
                if (count == 0)
                {
                    sb.Append("<div id='billboard_less_" + logID + "' style='float:right;'><a href='javascript:void(0);' onclick='ViewLessBollboardComments();'>View Less Comments>></a>");
                    sb.Append("</div>");
                }
                if (count != 0 && subComments.Length > 4)
                {
                    sb.Append("<div id='billboard_more_" + logID + "' style='float:right;'><a href='javascript:void(0);' onclick='ViewAllBollboardComments();'>View All Comments>></a>");
                    sb.Append("</div>");
                }
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
        return sb.ToString();
    }

    protected static bool IsMyContactOrMe(string s_MemberID)
    {
        bool result = false;
        try
        {
            if (s_MemberID != Web.SessionMembers.MemberID.ToString())
            {
                Contacts contact = new Contacts();
                contact.Where.MemberID.Value = Web.SessionMembers.MemberID;
                contact.Where.ContactMemberID.Value = s_MemberID;
                contact.Query.Load();
                if (contact.RowCount > 0)
                    result = true;
            }
        }
        catch (Exception ex)
        {
            //Log.Write("Error", ex.GetBaseException().ToString(), ex);
            Web.LogError(ex);
        }
        return result;
    }


    /*
    public static bool IsMyContact = false;
    public static JQGrid LoadMessages()
    { 
        JQGrid jqGrid = new JQGrid();
        if (!Web.IsMemberSession)
        {
            jqGrid.status = "login";
        }
        else
        {
            IsMyContact = CheckMyContact();
            DataTable dt = new DataTable();

            try
            {

                dt = Contacts.GetPrivateMessages(Web.RecordID, Web.SessionMembers.MemberID);

            }
            catch (Exception ex)
            {
                Web.LogError(ex);
            }
        }
        return jqGrid;
    }

    private static bool CheckMyContact()
    {
        bool result = false;
        try
        {
            if (Web.IsMemberSession)
            {
                Contacts contacts = new Contacts();
                contacts.Where.ContactMemberID.Value = Web.RecordID;
                contacts.Where.MemberID.Value = Web.SessionMembers.MemberID;
                contacts.Where.ContactStatusID.Value = 1;
                contacts.Query.Load();
                result = (contacts.RowCount > 0) ? true : false;

                if (!result)
                {
                    contacts = new Contacts();
                    contacts.Where.ContactMemberID.Value = Web.SessionMembers.MemberID;
                    contacts.Where.MemberID.Value = Web.RecordID;
                    contacts.Where.ContactStatusID.Value = 1;
                    contacts.Query.Load();
                    result = (contacts.RowCount > 0) ? true : false;
                }
            }
        }
        catch (Exception ex) { throw ex; }
        return result;
    }

    */
}