﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CodenameRabbitFoot.BusinessLogic;
using System.Data;
using System.Text;
using Telerik.Web.UI;
using System.IO;
using System.Drawing;
using System.Collections;

public partial class Tools_Exhibit_Default : System.Web.UI.Page
{
    public string RepositryKey
    {
        get
        {
            return Request.Url.AbsolutePath.Replace("/", "").TrimEnd(".aspx".ToCharArray());
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        this.uploaderControl.WebPageName = this.RepositryKey;
        // this.Master.HideLinkApps();
        try
        {
            Web.CheckSession();

            if (!Page.IsPostBack)
            {
                //  this.Master.PageHeading = "Make Your Exhibit";
                BindDurationDropdown();
            }
        }
        catch
        {
        }
    }

    string ExhibitionName = string.Empty;

    protected void btnNext_Click(object sender, EventArgs e)
    {
        var repositryFiles = RepositryManager.GetRepositry(this.RepositryKey);

        if (repositryFiles.Count > 0)
        {
            this.mvExhibition.ActiveViewIndex = 1;
            this.Master.HideLinkApps();
            string tempFolder = Web.SystemConfigs.GetKey("ATTACHMENTS_PHYSICAL_PATH") + "\\ExhibitTempFiles";
            tempFolder = Path.Combine(tempFolder, Session.SessionID);
            if (!Directory.Exists(tempFolder))
            {
                Directory.CreateDirectory(tempFolder);
            }
            List<ExhibitItem> uploadedFiles = new List<ExhibitItem>();
            ExhibitionName = txtExhibitionName.Text.Trim();
            if (ExhibitionName.Equals(null) || ExhibitionName.Equals(""))
            {
                litPageTitle.Text = "Exhibit";
            }
            else
            {
                litPageTitle.Text = txtExhibitionName.Text.Trim();
            }

            //foreach (UploadedFile file in fupPhoto.UploadedFiles)
            foreach (UploaderRepository file in repositryFiles)
            {
                string filePath = "", imageName = "", realPath = "";

                if (file.FileType == FileTypes.Photo)
                {
                    imageName = string.Format("{0}{1}", Math.Abs(Guid.NewGuid().GetHashCode()), Path.GetExtension(file.FilePath));// Math.Abs(Guid.NewGuid().GetHashCode()) + file.FileExtention;
                    filePath = Path.Combine(tempFolder, imageName);

                    //file.SaveAs(filePath, true);
                    File.Copy(file.FilePath, filePath, true);
                    //save the file in real location without changing dimensions
                    string realFolder = Web.SystemConfigs.GetKey("ATTACHMENTS_PHYSICAL_PATH") + "/Exhibit/Real/";
                    if (!Directory.Exists(realFolder))
                    {
                        Directory.CreateDirectory(realFolder);
                    }
                    realPath = Path.Combine(realFolder, imageName);
                    //file.SaveAs(realPath, true);
                    File.Copy(file.FilePath, realPath, true);
                    if (File.Exists(filePath))
                        File.Delete(filePath);

                    ////save the thumbnail
                    System.Drawing.Image logoImage = System.Drawing.Image.FromFile(realPath);
                    string thumbnailFolder = Web.SystemConfigs.GetKey("ATTACHMENTS_PHYSICAL_PATH") + "/Exhibit/Thumbnail/";
                    if (!Directory.Exists(thumbnailFolder))
                    {
                        Directory.CreateDirectory(thumbnailFolder);
                    }
                    string thumbnailPath = Path.Combine(thumbnailFolder, imageName);
                    Web.CreateThumbnail(logoImage, 220, 160).Save(thumbnailPath);


                    ////save the Slide Image
                    System.Drawing.Image thImage = System.Drawing.Image.FromFile(realPath);
                    string slideFolder = Web.SystemConfigs.GetKey("ATTACHMENTS_PHYSICAL_PATH") + "/Exhibit/Slide";
                    if (!Directory.Exists(slideFolder))
                    {
                        Directory.CreateDirectory(slideFolder);
                    }
                    string slidePath = Path.Combine(slideFolder, imageName);
                    Web.CreateThumbnail(thImage, 880, 500).Save(slidePath);
                }
                // Get Image Height And Width

                //using (Bitmap originalImage = new Bitmap(file.InputStream))
                //{
                //    int width = originalImage.Width;
                //    int height = originalImage.Height;
                //}
                ExhibitItem item = new ExhibitItem();
                item.id = Path.GetFileNameWithoutExtension(filePath);
                item.tempFilePath = realPath;
                item.fileName = Path.GetFileName(filePath);
                item.type = file.FileType.ToString().ToLower();
                // FOR LATER - ROMEO MUST DO OR DIE
                //string ATTACHMENTS_PATH = Web.SystemConfigs.GetKey("ATTACHMENTS_PATH");
                if (file.FileType == FileTypes.Video)
                {
                    item.fileUrl = file.Url;
                }
                else
                {
                    item.fileUrl = string.Format(Web.SystemConfigs.GetKey("ATTACHMENTS_PATH") + "/Exhibit/Thumbnail/{0}", Path.GetFileName(filePath));
                }
                //item.fileUrl = string.Format("http://localhost:8081/Systemobjectfiles/UserTempFiles/{0}/{1}", Session.SessionID, Path.GetFileName(filePath));
                uploadedFiles.Add(item);
            }
            Session["UploadedImageFiles"] = uploadedFiles;
        }
        else
        {
            Page.ClientScript.RegisterClientScriptBlock(Page.GetType(), "errorMessage", "alert('Please select file')", true);
            return;
        }
        //1. Generate Html for Controls
        DataTable extendedFields = ListingExtendedFields.GetExtendedFields(8, 4680);
        this.dvStep2.InnerHtml = GenerateHtmlControls(extendedFields);
        RepositryManager.ClearRepositry(this.RepositryKey);
    }

    protected void btnPerviousStep2_Click(object sender, EventArgs e)
    {
        this.Master.ShowLinkApps();
        litPageTitle.Text = "Exhibit";
        this.mvExhibition.ActiveViewIndex = 0;
    }
    protected void btnNextStep2_Click(object sender, EventArgs e)
    {
        this.mvExhibition.ActiveViewIndex = 2;
        LoadShippingTypes();
        LoadPaymentOptions();
        LoadShippingLocation();
    }
    protected void btnPreviousStep3_Click(object sender, EventArgs e)
    {
        this.mvExhibition.ActiveViewIndex = 1;
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            // 1. Create exhibition.
            int duration = Convert.ToInt32(this.ddlDuration.SelectedValue);
            Exhibitions exhibition = new Exhibitions();
            exhibition.AddNew();
            exhibition.MemberID = Web.SessionMembers.MemberID;
            exhibition.Name = this.txtExhibitionName.Text;
            exhibition.EndDate = DateTime.Now.AddDays(duration == 0 ? 14 : duration);
            exhibition.DateAdded = DateTime.Now;
            exhibition.DateUpdated = DateTime.Now;
            exhibition.Save();

            //2. Create Activity log  
            bool ApprovedMember = ApprovedMembers.CheckIfApproved(Web.SessionMembers.MemberID);

            Session["Message"] = "Exhibition " + "\"" + this.txtExhibitionName.Text + "\"" + " has been posted successfully.";
            string link = @"/Tools/Exhibit/View.aspx?Action=View&RecordID=#encrypt#" + exhibition.ExhibitionID + "#endencrypt#";

            var templateKeys = new System.Collections.Specialized.StringDictionary();
            templateKeys.Add("#listingname#", this.txtExhibitionName.Text);
            templateKeys.Add("#viewlink#", link);


            //Web.AddActivityLog(Web.SessionMembers.MemberID, 46, templateKeys, list.ListingID, list.ListingTypeID, false, GetPrivacyTypeID(Request["Action"]));
            // Made Exhibit (Activities table)=52

            Dictionary<FileTypes, string> imageList = SaveImages(exhibition.ExhibitionID);
            int _imageCount = imageList.Count();
            _imageCount -= imageList.Where(l => l.Key == FileTypes.Video).Count();
            int imagecounter = 1;
            StringBuilder items = new StringBuilder();
            foreach (var item in imageList)
            {
                if (item.Key == FileTypes.Video)
                {
                    items.AppendFormat("<div class=\"uiMediaThumb\"><object width='250' height='200'><param name='movie' value='" + item.Value + "'><param name='type' value='application/x-shockwave-flash'><param name='allowfullscreen' value='true'><param name='allowscriptaccess' value='always'><param name=\"wmode\" value=\"opaque\" /><embed width='250' height='200' src='" + item.Value + "' type='application/x-shockwave-flash' allowfullscreen='true' allowscriptaccess='always' wmode=\"opaque\"></embed></object></div>");

                }
                else
                {
                    if (_imageCount.Equals(1))
                    {
                        items.AppendFormat("<div style=\"padding: 10px;\"><img width=\"380\" height=\"340\"  src = '{0}'  style=\"padding-left:5px;\" class=\"uiMediaThumb\"  /></div>", item);
                    }
                    else if (_imageCount.Equals(2))
                    {
                        items.AppendFormat("<div style=\"float:left; width:210px; height:210px; padding: 10px;\" ><img width=\"200\" height=\"200\" class=\"uiMediaThumb\"  src = '{0}'  style=\"padding-left:5px;\"  /></div>", item);
                    }
                    else if (_imageCount.Equals(3))
                    {
                        if (imagecounter.Equals(1))
                        {
                            items.AppendFormat("<div style=\"width: 280px; height: 370px; padding-right: 10px; padding-bottom: 10px; float: left;\" ><img width=\"275\" height=\"365\" class=\"uiMediaThumb\"  src = '{0}'  style=\"padding-left:5px;\"  /></div>", item);
                            items.AppendFormat("<div style=\"float:left; width:220px; height:370px;\" >");
                        }
                        else
                        {
                            items.AppendFormat("<div style=\"height: 175px; padding-bottom: 15px; padding-left: 0px; float: left; \" ><img width=\"210\" height=\"175\" class=\"uiMediaThumb\"  src = '{0}'  style=\"padding-left:5px;\"  /></div>", item);
                        }
                        if (imagecounter.Equals(3))
                        {
                            items.AppendFormat("</div>");
                        }
                        imagecounter++;
                    }
                    else if (_imageCount.Equals(4))
                    {
                        if (imagecounter.Equals(1))
                        {
                            //items.AppendFormat("<div style=\"float:left; width:300px; height:420px;\" ><img width=\"250\" height=\"420\" class=\"uiMediaThumb\" > src = '{0}'  style=\"padding-left:5px;\"  /></div>", img);
                            items.AppendFormat("<div style=\"float:left; width:250px; height:470px;\" >");
                            items.AppendFormat("<div style=\"float:left; width:220px; height:210px; padding: 10px; padding-left:0px;\" ><img width=\"210\" height=\"210\" class=\"uiMediaThumb\"  src = '{0}'  style=\"padding-left:5px;\"  /></div>", item);
                        }

                        else if (imagecounter.Equals(2))
                        {
                            //items.AppendFormat("<div style=\"float:left; width:300px; height:420px;\" ><img width=\"250\" height=\"420\" class=\"uiMediaThumb\" > src = '{0}'  style=\"padding-left:5px;\"  /></div>", img);
                            items.AppendFormat("<div style=\"float:left; width:220px; height:210px; padding: 10px; padding-left:0px;\" ><img width=\"210\" height=\"210\" class=\"uiMediaThumb\"  src = '{0}'  style=\"padding-left:5px;\"  /></div>", item);
                            items.AppendFormat("</div>");
                            items.AppendFormat("<div style=\"float:left; width:250px; height:470px; \" >");
                        }
                        else
                        {
                            items.AppendFormat("<div style=\"float:left; width:220px; height:210px; padding: 10px; padding-left:0px;\" ><img width=\"210\" height=\"210\" class=\"uiMediaThumb\"  src = '{0}'  style=\"padding-left:5px;\"  /></div>", item);
                        }
                        if (imagecounter.Equals(4))
                        {
                            items.AppendFormat("</div>");
                        }
                        imagecounter++;
                    }

                }
            }

            if (ApprovedMember)
            {
                templateKeys.Add("#exhibitimages#", "<div  align=\"center\" style=\"float:left; width:530px;  padding: 10px;\" align=\"center\"><a href = " + link + ">" + items + "</a></div>");
                Web.AddActivityLog(52, templateKeys);
            }
            else
            {
                Session["Message"] = "The Exhibition " + "\"" + this.txtExhibitionName.Text + "\"" + " is under review, it will be posted live shortly after administrative approval.";
            }
            Web.Redirect("Default.aspx");
        }
        catch (Exception exp)
        {
            Web.LogError(exp);
        }
    }

    protected void chkShippingTypes_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            txtShippingFee.Enabled = rdlShippingFeeUnitOrLot.Enabled = txtAdditionalShippingFee.Enabled = true;
            foreach (ListItem item in chkShippingTypes.Items)
                item.Enabled = true;

            if (chkShippingTypes.SelectedItem != null)
            {
                if (chkShippingTypes.SelectedItem.Text.Contains("buyer") || chkShippingTypes.SelectedItem.Text.Contains("Buyer"))
                {
                    if (chkShippingTypes.SelectedItem.Selected == true)
                    {
                        foreach (ListItem item in chkShippingTypes.Items)
                            if (!(item.Text.Contains("buyer") || item.Text.Contains("Buyer")))
                                item.Enabled = item.Selected = false;

                        txtShippingFee.Enabled = rdlShippingFeeUnitOrLot.Enabled = txtAdditionalShippingFee.Enabled = false;
                        txtShippingFee.Text = txtAdditionalShippingFee.Text = "";
                    }
                }
            }
        }
        catch (Exception ex) { Web.LogError(ex); }
    }

    #region Methods

    public void LoadShippingTypes()
    {
        try
        {
            ShippingTypes shippingTypes = new ShippingTypes();
            shippingTypes.Query.AddOrderBy(ShippingTypesSchema.ShippingName);
            shippingTypes.Query.AddResultColumn(ShippingTypesSchema.ShippingName);
            shippingTypes.Query.AddResultColumn(ShippingTypesSchema.ShippingTypeID);
            shippingTypes.Query.AddResultColumn(ShippingTypesSchema.IsActive);
            shippingTypes.Query.AddOrderBy(ShippingTypesSchema.ShippingTypeID, NCI.EasyObjects.WhereParameter.Dir.ASC);
            shippingTypes.Where.IsActive.Value = 1;
            shippingTypes.Query.Load();
            chkShippingTypes.DataSource = shippingTypes.DefaultView.Table;
            chkShippingTypes.DataTextField = "ShippingName";
            chkShippingTypes.DataValueField = "ShippingTypeID";
            chkShippingTypes.DataBind();
            //chkShippingTypes.SelectedIndex = chkShippingTypes.Items.Count - 3;

        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }

    public void LoadPaymentOptions()
    {
        try
        {
            PaymentTypes paymentTypes = new PaymentTypes();
            paymentTypes.Query.AddOrderBy(PaymentTypesSchema.PaymentName);
            paymentTypes.Query.AddResultColumn(PaymentTypesSchema.PaymentName);
            paymentTypes.Query.AddResultColumn(PaymentTypesSchema.PaymentTypeID);
            paymentTypes.Query.AddResultColumn(PaymentTypesSchema.IsActive);
            paymentTypes.Where.IsActive.Value = 1;
            paymentTypes.Query.Load();

            ckhPaymentTypes.DataSource = paymentTypes.DefaultView.Table;
            ckhPaymentTypes.DataTextField = "PaymentName";
            ckhPaymentTypes.DataValueField = "PaymentTypeID";
            ckhPaymentTypes.DataBind();
            //ckhPaymentTypes.SelectedIndex = ckhPaymentTypes.Items.Count - 4;
            //ckhPaymentTypes.Items[3].Selected = true;
            //ckhPaymentTypes.Items[5].Selected = true;
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }

    public void LoadShippingLocation()
    {
        DataTable result = null;
        try
        {

            result = ShippingLocationTypes.GetShippingLocations(1);
            ddlShippingLocations.DataSource = result;
            ddlShippingLocations.DataTextField = "ShippingLocationName";
            ddlShippingLocations.DataValueField = "ShippingLocationID";
            ddlShippingLocations.DataBind();
            //ddlShippingLocations.Items.Insert(0, new RadComboBoxItem("...Shipping Location...", "-1"));
            ddlShippingLocations.Items.Insert(0, new ListItem("...Shipping Location...", "-1"));
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }
    private static string GenerateHtmlControls(DataTable catagoryFields)
    {
        List<ExhibitItem> uploadedFiles = HttpContext.Current.Session["UploadedImageFiles"] as List<ExhibitItem>;
        StringBuilder sb = new StringBuilder();
        string result = "";
        StringBuilder oneRowHTML = new StringBuilder();
        try
        {
            //sb.Append("<table width='100%' style='margin-top: 10px' border='0' >");
            //sb.Append(" </td> <td class='redText' style='padding-left:12px'>");
            //sb.Append("&nbsp;Exhibition Items:");
            //sb.Append("</td></tr></table>");
            //sb.Append("<div class=\"emptyDiv\" style=\"display:block;\">All exhibtion items updated. <a href='Default.aspx'>Create new Exhibition</a></div>");
            int counter = 0;
            foreach (ExhibitItem file in uploadedFiles)
            {
                counter++;
                sb.Append("<div class=\"exhibitItemDiv\">");
                string html = GenerateCatagoryFieldHtml(catagoryFields, file);
                sb.Append(html.Replace("#URL#", file.fileUrl));
                sb.Append("</div>");
                //if (counter < uploadedFiles.Count)
                //    sb.Append("<div class='hrDiv'><hr/></div>");
            }
            //scripts
            /*
            sb.Append("<script type=\"text/javascript\"> ");            
            sb.Append("function Focus(obj,title) {");
            sb.Append("var id = obj.id;");
            sb.Append("$('#sp_'+ id).html('');");
            sb.Append("$('#sp_error_'+ id).hide('');");
            sb.Append("if ($('#' + id).val() == title) {");
            sb.Append("$('#' + id).val('');");
           
            sb.Append("}");
            sb.Append(" }");
            //on blur event
            sb.Append("function Blur(obj, title, regex, message) {");
            sb.Append("var id = obj.id;");
            sb.Append("if ($('#' + id).val() == '') {");
            sb.Append("$('#' + id).val(title);");
            sb.Append("$('#' + id).addClass('InnerTextBox');");
            sb.Append("}");
            //regex 
            sb.Append("var Expression = new RegExp(regex);");//using its Regex
            sb.Append("if ($('#' + id).val().match(Expression) == null) {");
            sb.Append("if($('#' + id).val()!=title){");
            sb.Append("$('#sp_'+ id).html(message);");
            sb.Append("return false;");
            sb.Append("}");
            sb.Append("}");
            sb.Append(" }");
            sb.Append("</script>");
             */
        }
        catch (Exception ex) { Web.LogError(ex); }
        result = sb.ToString();
        result = result.Replace("##REPLACE##", "<tr>" + oneRowHTML.ToString() + "</tr>");
        return result;
    }
    private static string GenerateCatagoryFieldHtml(DataTable catagoryFields, ExhibitItem item)
    {
        string uniqueID = item.id;// item.fileName;
        string txtTitleID = "", txtQuantityID = "", txtPriceID = "", txtDescriptionID = "", chkMakeOfferID = "";
        string tableTemplate = @"<table cellpadding='1' cellspacing='1'>
                            <tr><td rowspan='4' valign='top' class='imgContainer'>#IMAGE##VIDEO#</td><td class='defaultCell'>#TITLE#</td></tr>
                            <tr> <td class='defaultCell'>#QUANTITY#</td></tr>
                            <tr> <td class='defaultCell'>#PRICE# #OFFER#</td></tr>
                            <tr> <td class='defaultCell' style='overflow-y:hidden;'>#DESCRIPTION#</td></tr>
                            <tr><td class='defaultCell'></td><td align='right' class='defaultCell'><input type='button' onclick='javascript:SaveExtendedFieldValues(#PARAMS#);' value='&gt; Save' class='hiddenButton' style='display:none;' /></td></tr>
                            </table>";
        foreach (DataRow dr in catagoryFields.Rows)
        {
            string itemHtml = string.Empty;
            switch (dr["FieldID"].ToString())
            {
                case "20":// Title
                    {
                        if (dr["IsRequired"].ToString() == "1")
                        {
                            txtTitleID = "txt_Required_" + uniqueID + "_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString();
                            itemHtml = "<input title='" + dr["FieldDescription"].ToString() + "' value='" + dr["FieldDescription"].ToString() + "' class='InnerTextBox' type='text'  id='txt_Required_" + uniqueID + "_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'  style='width:350px;' onfocus =\"Focus(this,'" + dr["FieldDescription"].ToString() + "');\" onblur=\"Blur(this,'" + dr["FieldDescription"].ToString() + "','" + dr["RegularExpression"].ToString() + "','" + dr["ValidationError"].ToString() + "');\" />&nbsp;<span style='color: #ff002a;'>*</span><span style='color: #ff002a;' id='sp_txt_Required_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'></span><span style='color: #ff002a;display:none' id='sp_error_txt_Required_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'>" + dr["RequiredError"].ToString() + "</span>";
                        }
                        else
                        {
                            txtTitleID = "txt_" + uniqueID + "_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString();
                            itemHtml = "<input title='" + dr["FieldDescription"].ToString() + "' value='" + dr["FieldDescription"].ToString() + "' class='InnerTextBox' type='text'  id='txt_" + uniqueID + "_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'  style='width:350px;' onfocus =\"Focus(this,'" + dr["FieldDescription"].ToString() + "');\" onblur=\"Blur(this,'" + dr["FieldDescription"].ToString() + "','" + dr["RegularExpression"].ToString() + "','" + dr["ValidationError"].ToString() + "');\" />&nbsp;<span style='color: #ff002a;' id='sp_txt_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'></span>";
                        }
                        tableTemplate = tableTemplate.Replace("#TITLE#", itemHtml);
                        break;
                    }
                case "4":// Quantity
                    {
                        if (dr["IsRequired"].ToString() == "1")
                        {
                            txtQuantityID = "txt_Required_" + uniqueID + "_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString();
                            itemHtml = "<input title='" + dr["FieldDescription"].ToString() + "' value='" + dr["FieldDescription"].ToString() + "' class='InnerTextBox Numaric' type='text'  id='txt_Required_" + uniqueID + "_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'  style='width:110px;' onfocus =\"Focus(this,'" + dr["FieldDescription"].ToString() + "');\" onblur=\"Blur(this,'" + dr["FieldDescription"].ToString() + "','" + dr["RegularExpression"].ToString() + "','" + dr["ValidationError"].ToString() + "');\" />&nbsp;<span style='color: #ff002a;'>*</span><span style='color: #ff002a;' id='sp_txt_Required_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'></span><span style='color: #ff002a;display:none' id='sp_error_txt_Required_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'>" + dr["RequiredError"].ToString() + "</span>";
                        }
                        else
                        {
                            txtQuantityID = "txt_" + uniqueID + "_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString();
                            itemHtml = "<input title='" + dr["FieldDescription"].ToString() + "' value='" + dr["FieldDescription"].ToString() + "' class='InnerTextBox Numaric' type='text'  id='txt_" + uniqueID + "_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'  style='width:110px;' onfocus =\"Focus(this,'" + dr["FieldDescription"].ToString() + "');\" onblur=\"Blur(this,'" + dr["FieldDescription"].ToString() + "','" + dr["RegularExpression"].ToString() + "','" + dr["ValidationError"].ToString() + "');\" />&nbsp;<span style='color: #ff002a;' id='sp_txt_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'></span>";
                        }
                        tableTemplate = tableTemplate.Replace("#QUANTITY#", itemHtml);
                        break;
                    }
                case "10":// Price each
                    {
                        if (dr["IsRequired"].ToString() == "1")
                        {
                            txtPriceID = "txt_Required_" + uniqueID + "_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString();
                            itemHtml = "<input title='" + dr["FieldDescription"].ToString() + "' value='" + dr["FieldDescription"].ToString() + "' class='InnerTextBox Decimal' type='text'  id='txt_Required_" + uniqueID + "_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'  style='width:110px;' onfocus =\"Focus(this,'" + dr["FieldDescription"].ToString() + "');\" onblur=\"Blur(this,'" + dr["FieldDescription"].ToString() + "','" + dr["RegularExpression"].ToString() + "','" + dr["ValidationError"].ToString() + "');\" />&nbsp;<span style='color: #ff002a;'>*</span><span style='color: #ff002a;' id='sp_txt_Required_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'></span><span style='color: #ff002a;display:none' id='sp_error_txt_Required_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'>" + dr["RequiredError"].ToString() + "</span>";
                        }
                        else
                        {
                            txtPriceID = "txt_" + uniqueID + "_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString();
                            itemHtml = "<input title='" + dr["FieldDescription"].ToString() + "' value='" + dr["FieldDescription"].ToString() + "' class='InnerTextBox Decimal' type='text'  id='txt_" + uniqueID + "_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'  style='width:110px;' onfocus =\"Focus(this,'" + dr["FieldDescription"].ToString() + "');\" onblur=\"Blur(this,'" + dr["FieldDescription"].ToString() + "','" + dr["RegularExpression"].ToString() + "','" + dr["ValidationError"].ToString() + "');\" />&nbsp;<span style='color: #ff002a;' id='sp_txt_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'></span>";
                        }
                        tableTemplate = tableTemplate.Replace("#PRICE#", itemHtml);
                        break;
                    }

                case "3":// Description
                    {
                        if (dr["IsRequired"].ToString() == "1")
                        {
                            txtDescriptionID = "txt_Required_" + uniqueID + "_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString();
                            itemHtml = "<textarea title='" + dr["FieldDescription"].ToString() + "' id='txt_Required_" + uniqueID + "_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'  class='InnerTextBox' rows='7' cols='5' style='width:350px;font-size:15px;' onfocus =\"Focus(this,'" + dr["FieldDescription"].ToString() + "');\" onblur=\"Blur(this,'" + dr["FieldDescription"].ToString() + "','" + dr["RegularExpression"].ToString() + "','" + dr["ValidationError"].ToString() + "');\" >" + dr["FieldDescription"].ToString() + "</textarea>&nbsp;<span style='color: #ff002a;'>*</span><span style='color: #ff002a;' id='sp_txt_Required_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'></span><span style='color: #ff002a;display:none' id='sp_error_txt_Required_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'>" + dr["RequiredError"].ToString() + "</span>";
                        }
                        else
                        {
                            txtDescriptionID = "txt_" + uniqueID + "_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString();
                            itemHtml = "<textarea title='" + dr["FieldDescription"].ToString() + "' id='txt_" + uniqueID + "_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'  class='InnerTextBox' rows='7' cols='5' style='width:350px;font-size:15px;' onfocus =\"Focus(this,'" + dr["FieldDescription"].ToString() + "');\" onblur=\"Blur(this,'" + dr["FieldDescription"].ToString() + "','" + dr["RegularExpression"].ToString() + "','" + dr["ValidationError"].ToString() + "');\" >" + dr["FieldDescription"].ToString() + "</textarea>&nbsp;<span style='color: #ff002a;' id='sp_txt_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'></span>";
                        }
                        tableTemplate = tableTemplate.Replace("#DESCRIPTION#", itemHtml);
                        break;
                    }
                case "24":// Make Offer
                    {
                        chkMakeOfferID = "chk_" + uniqueID + "_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString();
                        itemHtml = "<input type='checkbox'  style='padding-right:6px;' id='chk_" + uniqueID + "_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "' title='" + dr["FieldDescription"].ToString() + "' onclick='CheckBoxSelectionChanged(this,#OFFER_PARAM#);' />" + dr["FieldDescription"].ToString();
                        tableTemplate = tableTemplate.Replace("#OFFER#", itemHtml);
                        break;
                    }
                case "27":// Image
                    {
                        if (item.type.Equals("video"))
                        {
                            string videoHtml = "<div><object width='250' height='200'><param name='movie' value='" + item.fileUrl + "'><param name='type' value='application/x-shockwave-flash'><param name='allowfullscreen' value='true'><param name='allowscriptaccess' value='always'><param name=\"wmode\" value=\"opaque\" /><embed width='250' height='200' src='" + item.fileUrl + "' type='application/x-shockwave-flash' allowfullscreen='true' allowscriptaccess='always' wmode=\"opaque\"></embed></object></div>";
                            tableTemplate = tableTemplate.Replace("#VIDEO#", videoHtml);
                        }
                        else
                        {
                            itemHtml = "<img src=\"#URL#\" height='200' width='250' />";
                            tableTemplate = tableTemplate.Replace("#IMAGE#", itemHtml);
                        }
                        break;
                    }
            }
        }

        //Javacript Params
        //txtTitleID, txtQuantityID, txtPriceID, txtDescriptionID, chkMakeOfferID
        tableTemplate = tableTemplate.Replace("#OFFER_PARAM#", txtPriceID);
        //saveScript += " SaveExtendedFieldValues(" + string.Format(" {0},{1},{2},{3},{4},{5} ", uniqueID, txtTitleID, txtQuantityID, txtPriceID, txtDescriptionID, chkMakeOfferID) + "); ";
        tableTemplate = tableTemplate.Replace("#PARAMS#", string.Format(" {0},{1},{2},{3},{4},{5} ", uniqueID, txtTitleID, txtQuantityID, txtPriceID, txtDescriptionID, chkMakeOfferID));
        tableTemplate = tableTemplate.Replace("#IMAGE#", "").Replace("#VIDEO#", "");
        return tableTemplate;
    }

    private Dictionary<FileTypes, string> SaveImages(int exhibitionID)
    {
        Dictionary<FileTypes, string> imgURLList = new Dictionary<FileTypes, string>();

        DataTable extendedFields = ListingExtendedFields.GetExtendedFields(8, 4680);
        int duration = Convert.ToInt32(this.ddlDuration.SelectedValue);
        bool ApprovedMember = ApprovedMembers.CheckIfApproved(Web.SessionMembers.MemberID);
        int fileCounter = 1;

        //1. foreach image in control . 
        var exhibitItems = Session["UploadedImageFiles"] as List<ExhibitItem>;
        foreach (ExhibitItem image in exhibitItems)
        {
            // Creat listing.
            Listings list = new Listings();
            list.AddNew();
            list.ListingEndDate = duration == 0 ? DateTime.Now.AddDays(14) : DateTime.Now.AddDays(duration);
            list.MemberID = Web.SessionMembers.MemberID;
            list.IsActive = 1;
            list.StatusCode = (ApprovedMember) ? 100 : 200;
            list.CategoryID = 4680; // Make Exhibit
            list.ListingTypeID = 8; // Make Exhibit
            list.ListingDate = DateTime.Now;
            list.IsPrivate = 0;
            list.ShippingLocationID = Convert.ToInt32(this.ddlShippingLocations.SelectedValue);

            if (!string.IsNullOrEmpty(this.txtShippingFee.Text))
            {
                list.ShippingFee = Convert.ToDecimal(this.txtShippingFee.Text);
            }
            if (!string.IsNullOrEmpty(this.txtAdditionalShippingFee.Text))
            {
                list.AdditionalFee = Convert.ToDecimal(this.txtAdditionalShippingFee.Text);
            }
            if (this.rdlShippingFeeUnitOrLot.SelectedValue.ToString().Equals("1"))
            {
                list.ShippingFeeUnit = 1;
                list.AdditionalFeeUnit = 1;
            }
            else
            {
                list.ShippingFeeUnit = 2;
                list.AdditionalFeeUnit = 2;
            }


            list.Save();
            // Creat Listing field values ()
            foreach (DataRow row in extendedFields.Rows)
            {
                int fieldID = Convert.ToInt32(row["FieldID"]);
                ListingExtendedFields listingField = new ListingExtendedFields();
                listingField.AddNew();
                listingField.FieldID = fieldID;
                listingField.SystemObjectID = (int)SystemObjects.Listings;
                if (fieldID == 20)// Title
                {
                    listingField.Data = string.IsNullOrWhiteSpace(image.title) ? string.Empty : image.title;
                }
                else if (fieldID == 4)// Quantity
                {
                    listingField.Data = string.IsNullOrWhiteSpace(image.quantity) ? "0" : image.quantity;
                }
                else if (fieldID == 24)// Make Offer
                {
                    listingField.Data = image.offer;
                }
                else if (fieldID == 10)// Price Each
                {
                    listingField.Data = image.price;
                }
                else if (fieldID == 3)// Description
                {
                    listingField.Data = image.description;
                }
                else if (fieldID == 11)// Duration
                {
                    listingField.Data = this.ddlDuration.SelectedValue;// this.txtDuration.Text;
                }
                else if (fieldID == 27)// Image / path
                {
                    // Could not be calculted here. b/c dependent on SystemObjectFiles. Updated when this obj is created.
                    // listingField.Data = this.txtDuration.Text;
                }
                else if (fieldID == 28)// Image / path
                {
                    listingField.Data = image.fileUrl;
                }
                else if (fieldID == 23)//SellSeperately
                {
                    // Could not be calculted here. b/c dependent on SystemObjectFiles. Updated when this obj is created.
                    listingField.Data = "Sell Separately";
                }
                else if (fieldID == 13)// Payment Types
                {
                    string paymentTypes = "";
                    foreach (ListItem item in this.ckhPaymentTypes.Items)
                    {
                        if (item.Selected)
                        {
                            paymentTypes += item.Value + ",";
                        }
                    }

                    listingField.Data = paymentTypes;
                }
                else if (fieldID == 12)// Shipping Types
                {
                    string shippingMethods = "";
                    foreach (ListItem item in this.chkShippingTypes.Items)
                    {
                        if (item.Selected)
                        {
                            shippingMethods += item.Value + ",";
                        }
                    }

                    listingField.Data = shippingMethods;
                }

                listingField.EntryTime = DateTime.Now;
                listingField.ObjectID = list.ListingID;
                listingField.IsActive = 1;
                listingField.Save();
            }
            // Populate ExhibitionItems table
            ExhibitionItems exhibitItem = new ExhibitionItems();
            exhibitItem.AddNew();
            exhibitItem.ListingID = list.ListingID;
            exhibitItem.ExhibitionID = exhibitionID;
            exhibitItem.Save();
            // Upload Image 
            imgURLList.Add(image.type.ToLower().Equals("video") ? FileTypes.Video : FileTypes.Photo, UploadImage((int)SystemObjects.Listings, list.ListingID, image, fileCounter));

            fileCounter++;
        }

        return imgURLList;
    }
    public static string UploadImage(int systemObjectID, int listingID, ExhibitItem item, int fileCounter)
    {
        string virtualURL = string.Empty;
        try
        {
            var objfile = new SystemObjectFiles();
            string fileName = item.fileName;
            string virtualThumbnailURL = Web.SystemConfigs.GetKey("ATTACHMENTS_PATH") + "/Exhibit/Thumbnail/" + fileName;
            virtualURL = Web.SystemConfigs.GetKey("ATTACHMENTS_PATH") + "/Exhibit/Slide/" + fileName;
            objfile.AddNew();
            objfile.FileDate = DateTime.Now;
            objfile.FileTypeID = (int)FileTypes.ImageURL;
            objfile.s_IsActive = "1";
            objfile.ObjectID = listingID;
            objfile.SystemObjectID = systemObjectID;
            objfile.RemoteIP = System.Web.HttpContext.Current.Request.UserHostAddress;
            objfile.FileFormat = item.type;// Path.GetExtension(imageFile).Remove(0, 1);// remove dot from extention
            objfile.FileName = fileName;
            if (item.type.ToLower().Equals("video"))
            {
                objfile.URL = item.fileUrl;
            }
            else
            {
                objfile.URL = virtualURL;
                objfile.ThumbnailURL = virtualThumbnailURL;
            }
            objfile.MemberID = Web.SessionMembers.MemberID;
            objfile.PrivacyTypeID = 0;
            objfile.Save();
            //27  Image 
            int fieldID = item.type.ToLower().Equals("video") ? 28 : 27;
            string url = item.type.ToLower().Equals("video") ? item.fileUrl : virtualThumbnailURL;
            ListingExtendedFields.UpdateListingExtendedFieldData(listingID, fieldID, url);
            return url;
            //  counter++;
            // }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
        return string.Empty;
    }
    public static string UploadImage(int systemObjectID, int listingID, string imageFile, int privacyTypeID, int fileCounter)
    {
        string virtualURL = string.Empty;
        try
        {
            var objfile = new SystemObjectFiles();
            string fileName = Path.GetFileName(imageFile);
            string virtualThumbnailURL = Web.SystemConfigs.GetKey("ATTACHMENTS_PATH") + "/Exhibit/Thumbnail/" + fileName;
            virtualURL = Web.SystemConfigs.GetKey("ATTACHMENTS_PATH") + "/Exhibit/Slide/" + fileName;
            objfile.AddNew();
            objfile.FileDate = DateTime.Now;
            objfile.FileTypeID = (int)FileTypes.ImageURL;
            objfile.s_IsActive = "1";
            objfile.ObjectID = listingID;
            objfile.SystemObjectID = systemObjectID;
            objfile.RemoteIP = System.Web.HttpContext.Current.Request.UserHostAddress;
            objfile.FileFormat = Path.GetExtension(imageFile).Remove(0, 1);// remove dot from extention
            objfile.FileName = fileName;
            objfile.URL = virtualURL;
            objfile.ThumbnailURL = virtualThumbnailURL;
            objfile.MemberID = Web.SessionMembers.MemberID;
            objfile.PrivacyTypeID = privacyTypeID;
            objfile.Save();
            //27  Image 
            ListingExtendedFields.UpdateListingExtendedFieldData(listingID, 27, virtualThumbnailURL);
            //  counter++;
            // }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }

        return virtualURL;
    }
    public static bool ThumbnailCallback()
    { return false; }


    private void BindDurationDropdown()
    {
        this.ddlDuration.DataSource = ListingExtendedFields.GetFieldValues(11); // Duration id =11
        this.ddlDuration.DataTextField = "Name";
        this.ddlDuration.DataValueField = "Value";
        this.ddlDuration.DataBind();
        this.ddlDuration.SelectedIndex = 5;// 14 days selected by default
    }

    #endregion


}

