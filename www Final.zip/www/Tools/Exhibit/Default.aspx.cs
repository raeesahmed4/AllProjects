﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CodenameRabbitFoot.BusinessLogic;
using System.Web.Services;
using System.Web.Script.Services;
using System.Data;
using System.Text;

public partial class Tools_Exhibit_Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // To Show all exhibitions without login.
        Web.CheckSession();

        if (!Web.IsMemberSession && Web.Action() == "My")
        {
            Web.Redirect(string.Format("http://{0}/index.aspx?ReturnUrl={1}",Request.Url.Authority, Server.UrlEncode("http://" + Request.Url.Authority + "/Tools/Exhibit")));
            return;
            //Web.Redirect(string.Format("../../index.aspx?ReturnUrl={0}", Server.UrlEncode("http://"+Request.Url.Authority+"/Tools/Exhibit")));
        }
        //   else
        //    {
        Exhibitions exhibitions = new Exhibitions();
        if (Web.Action() == "My")
        {
            exhibitions.Where.MemberID.Value = Web.SessionMembers.MemberID;
            litPageTitle.Text = "My Exhibits - Open your online exhibit today.";
        }
        else
        {

            trMyExhibits.Visible = false;
            litPageTitle.Text = "Exhibits - Open your online exhibit today.";
        }
        exhibitions.Where.EndDate.Value = DateTime.Now;
        exhibitions.Where.EndDate.Operator = NCI.EasyObjects.WhereParameter.Operand.GreaterThan;
        exhibitions.Query.AddOrderBy(new NCI.EasyObjects.SchemaItem("ExhibitionID", System.Data.DbType.Int32), NCI.EasyObjects.WhereParameter.Dir.DESC);
        exhibitions.Query.Load();
        IEnumerable<DataRow> allRows = exhibitions.DefaultView.Table.Select();

        int rowID = 1;
        StringBuilder items = new StringBuilder();
        //string divgal = "<div id='gallery'>";
        int tdCount = 0;
        Members member = new Members();
        items.AppendFormat("<table style=\"width:500px;\">");
        string MemberName = string.Empty;

        foreach (DataRow exhibition in allRows)
        {

            member.LoadByPrimaryKey(Convert.ToInt32(exhibition["MemberID"]));

            MemberName = member.FullName.ToString();

            if (tdCount == 0)
            {
                items.AppendFormat("<tr>");
            }
            rowID++;


            //if counter = 0
            // <Tr> </tr>
            // if counter == 2 then counter = 0;

            DataTable exImages = Exhibitions.GetExhibitionListingsTopOne(Convert.ToInt32(exhibition["ExhibitionID"]));
            if (exImages != null)
            {
                if (exImages.Rows.Count > 0)
                {
                    if (Web.Action() == "My")
                    {
                        items.AppendFormat("<td><div style=\"padding-top:10px; padding-bottom:10px;position:relative;\"><a href='View.aspx?Exhibit=My&Action=viewEdit&RecordID={0}'><img class='uiMediaThumb' src='{1}' height='160' width='220' alt='Exhibition Item' /></a><div  style=\"position:absolute; width:220px;  left: 5px;right:0px; bottom: 15px; color: rgb(255, 255, 255); padding-top: 5px; display: block; position: absolute; word-wrap: break-word; background: url('/images/divBackground.png') repeat-x left top; color: rgb(255, 255, 255); padding-top: 5px; display: block; position: absolute; word-wrap: break-word; \"><p style=\"margin-left:15px;margin-bottom:5px;margin-right:15px;\"> {2} <br />({3})</p></div></div></td>", Secure.Encrypt(exhibition["ExhibitionID"]), exImages.Rows[0]["ThumbnailURL"], exhibition["NAME"], MemberName);
                        tdCount++;
                    }
                    else
                    {
                        items.AppendFormat("<td><div style=\"padding-top:10px; padding-bottom:10px;position:relative;\"><a href='View.aspx?Exhibit=All&Action=view&RecordID={0}'><img class='uiMediaThumb' src='{1}' height='160' width='220' alt='Exhibition Item' /></a><div  style=\"position:absolute; width:220px;  left: 5px;right:0px; bottom: 15px; color: rgb(255, 255, 255); padding-top: 5px; display: block; position: absolute; word-wrap: break-word; background: url('/images/divBackground.png') repeat-x left top; color: rgb(255, 255, 255); padding-top: 5px; display: block; position: absolute; word-wrap: break-word; \"><p style=\"margin-left:15px;margin-bottom:5px;margin-right:15px;\"> {2} <br />({3})</p></div></div></td>", Secure.Encrypt(exhibition["ExhibitionID"]), exImages.Rows[0]["ThumbnailURL"], exhibition["NAME"], MemberName);
                        tdCount++;
                    }

                }
                if (tdCount == 2)
                {
                    tdCount = 0;
                    items.AppendFormat("</tr>");
                }

            }
        }
        if (tdCount == 1)
        {
            items.AppendFormat("</tr>");
        }
        items.AppendFormat("</table>");
        setimages.Text = string.Format("{0}", items.ToString());
        //  }

    }
    public static void displayImages()
    {

    }

    [WebMethod(EnableSession = true)]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    //public static JQGrid LoadExhibitions(int pageIndex, int pageSize)
    //{
    //    JQGrid jqGrid = new JQGrid();
    //    if (!Web.IsMemberSession)
    //    {
    //        jqGrid.status = "login";
    //    }

    //    Exhibitions exhibitions = new Exhibitions();
    //    exhibitions.Where.MemberID.Value = Web.SessionMembers.MemberID;
    //    exhibitions.Where.EndDate.Value = DateTime.Now;
    //    exhibitions.Where.EndDate.Operator = NCI.EasyObjects.WhereParameter.Operand.GreaterThan;
    //    exhibitions.Query.AddOrderBy(new NCI.EasyObjects.SchemaItem("ExhibitionID", System.Data.DbType.Int32), NCI.EasyObjects.WhereParameter.Dir.DESC);
    //    exhibitions.Query.Load();
    //    IEnumerable<DataRow> allRows = exhibitions.DefaultView.Table.Select();

    //    // all filterign is made above 
    //    jqGrid.total = allRows.Count() == pageSize ? 1 : (allRows.Count() / pageSize) + 1;
    //    jqGrid.records = pageSize;
    //    jqGrid.page = pageIndex;
    //    IEnumerable<DataRow> dataRows = allRows.Skip((pageIndex - 1) * pageSize).Take(pageSize);

    //    if (dataRows.Count() == 0)
    //    {
    //        JQGrid.Row row = new JQGrid.Row();
    //        row.id = 0;
    //        row.cell.Add("0");
    //        row.cell.Add("<div style='text-align:left; padding:5px;'>" + Constants.MSG_EXHIBITIONS_EMPTY_GRID + "</div>");
    //        jqGrid.rows.Add(row);
    //        jqGrid.status = "empty";
    //    }

    //    int rowID = 1;
    //    //string divgal = "<div id='gallery'>";
    //    foreach (DataRow exhibition in dataRows)
    //    {
    //        rowID++;
    //        JQGrid.Row row = new JQGrid.Row();
    //        row.id = rowID;
    //        row.cell.Add(rowID.ToString());
    //        StringBuilder items = new StringBuilder();
    //        DataTable exImages = Exhibitions.GetExhibitionListings(Convert.ToInt32(exhibition["ExhibitionID"]));
    //        if (exImages != null)
    //        {
    //            if (exImages.Rows.Count > 0)
    //            {
    //                items.AppendFormat("<td style='border:0px; padding:5px;'><img class='exImage' src='{0}' height='80' width='100' alt='Exhibition Item' /></td>", exImages.Rows[0]["ThumbnailURL"]);
    //                items.AppendFormat("<td style='border:0px; padding:5px; width:280px;'><b>{0}</b><br/><span>{1} - {2}</span></td>", exhibition["Name"], Convert.ToDateTime(exhibition["DateAdded"]).ToShortDateString(), Convert.ToDateTime(exhibition["EndDate"]).ToShortDateString());
    //                //items.AppendFormat("<td style='border:0px; padding:5px; width:280px;'>{0} - {1}</td>", exhibition["DateAdded"], exhibition["EndDate"]);  onclick=""document.location.href='View.aspx?Action=view&RecordID={0}'""Secure.Encrypt(exhibition["ExhibitionID"])
    //                items.AppendFormat(@"<td style='border:0px; padding:5px;'><a href='{0}' title='{1}' >View </a></td>",exImages.Rows[0]["URL"],"dasdasdasdasdasdasmdvjasvdhassfwsfdsfd" );
    //                row.cell.Add(string.Format("<table><tr>{0}</tr></table></div>", items.ToString()));
    //                jqGrid.rows.Add(row);
    //            }
    //        }
    //    }

    //    return jqGrid;
    //}

    protected void gvExhibitions_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        // this.gvExhibitions.PageIndex = e.NewPageIndex;
        BindGrid();
    }

    private void BindGrid()
    {
        Exhibitions exhibitions = new Exhibitions();
        exhibitions.Where.MemberID.Value = Web.SessionMembers.MemberID;
        exhibitions.Query.AddOrderBy(new NCI.EasyObjects.SchemaItem("ExhibitionID", System.Data.DbType.Int32), NCI.EasyObjects.WhereParameter.Dir.DESC);

        exhibitions.Query.Load();
        //this.gvExhibitions.DataSource = exhibitions.DefaultView;
        // this.gvExhibitions.DataBind();
    }
}