﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CodenameRabbitFoot.BusinessLogic;
using System.Data;
using System.Text;

public partial class Tools_Exhibit_View : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        this.Master.HideLinkApps();
        Exhibitions exhibition = new Exhibitions();
        try
        {
            Web.CheckSession();
            //if (!Web.IsMemberSession)
            //{
            //    Web.Redirect("~/Account/Login.aspx?ReturnUrl=~/Tools/Exhibit");
            //}

            if (!Page.IsPostBack)
            {
                if (Request.QueryString["RecordID"] != null)
                {
                    //int exhibitionID = Convert.ToInt32(Request.QueryString["RecordID"]);
                    exhibition.LoadByPrimaryKey(Web.RecordID);
                    //this.Master.PageHeading = exhibition.Name;
                    this.exhibitionItems.InnerHtml = GetExhibitionItemsHtml(exhibition);
                }
            }
        }
        catch (Exception exp)
        {
            throw exp;
        }
    }

    private string GetExhibitionItemsHtml(Exhibitions exhibition)
    {
        string html = "";

        //1. Load exhibinot listins
        DataTable exhibitionListings = Exhibitions.GetExhibitionListings(exhibition.ExhibitionID);
        DataTable exhibitionName = Exhibitions.GetExhibitionName(exhibition.ExhibitionID);
        String ExhName = String.Empty;
        foreach (DataRow exName in exhibitionName.Rows)
        {
            ExhName = exName["Name"].ToString();
        }
        litPageTitle.Text = ExhName;
        Members member = new Members();
        string MemberName = string.Empty;
        member.LoadByPrimaryKey(Convert.ToInt32(exhibition.MemberID));
        MemberName = member.FullName.ToString();
        //2. Load extended fields
        //DataTable extendedFields = ListingExtendedFields.GetExtendedFields(8, 4680);
        //3. foreach exhitino listings generate a table of specified template
        //if (Web.Action() == "viewEdit")
        //{
        //    //string hrerEditExhibit = string.Format("Edit.aspx?Action=view&RecordID={0}&ListingTypeID=8", Secure.Encrypt(Web.RecordID));
        //    //html += string.Format("<a href='{0}' > Edit Exhibit </a>", hrerEditExhibit);
        //}
        //else
        //{
        //    if (MemberName.Equals(Web.SessionMembers.FullName))
        //    {
        //        string hrerEditExhibit = string.Format("Edit.aspx?Action=view&RecordID={0}&ListingTypeID=8", Secure.Encrypt(Web.RecordID));
        //        html += string.Format("<a href='{0}' > Edit Exhibit </a>", hrerEditExhibit);
        //    }
        //}

        foreach (DataRow listing in exhibitionListings.Rows)
        {
            html += @"<div>";
            string tableTemplate = string.Empty;
            string hrefByeNow = string.Format("../../MarketPlace/MakeOffer.aspx?RecordID={0}&ListingTypeID=8&Action=BuyNow", Secure.Encrypt(listing["ListingID"]));
            string hrefMakeOffer = string.Format("../../MarketPlace/MakeOffer.aspx?RecordID={0}&ListingTypeID=8", Secure.Encrypt(listing["ListingID"]));
            //<input type='button' value='Edit Exhibit' style='margin-top:10px;' onclick=""document.location.href='#Edit#'"" class='InnerButtonMeduim' styel='width:100px; height:30px; color:white; text-decoration:none;' />
            //<tr><td></td><td align=right><input type='button' onclick='javascript:ViewDetail(#PARAM#); ' value='&gt; View Detail' class='inputbtn' style='width:100px' /></td></tr>
            if (Web.Action() == "viewEdit")
            {
                tableTemplate = @"
                            <table cellpadding='1' cellspacing='1' class='exItem' id='gallery'>
                                <tr><td rowspan='5' valign='top' style='padding-left: 6px'>#IMAGE##VIDEO#</td>
                                    <td valign='top' style='padding-left: 6px;'>#TITLE#</td></tr>
                                <tr><td></td></tr>
                                 <tr><td valign='top' style='padding-left: 6px'>#PRICE#</td></tr>
                                 <tr><td valign='top' style='padding-left: 6px'>#QUANTITY#</td></tr>
                                <tr><td valign='top' style='padding-left: 6px'>#DESCRIPTION#</td></tr>
                               <tr><td></td><td align='right'>                            
                            </td></tr>
                            </table>";
            }
            else
            {
                if (!Web.IsMemberSession)
                {
                    tableTemplate = @"
                            <table cellpadding='1' cellspacing='1' class='exItem' id='gallery'>
                                <tr><td rowspan='5' valign='top' style='padding-left: 6px'>#IMAGE##VIDEO#</td>
                                    <td valign='top' style='padding-left: 6px;'>#TITLE#</td></tr>
                                <tr><td></td></tr>
                                 <tr><td valign='top' style='padding-left: 6px'>#PRICE#</td></tr>
                                 <tr><td valign='top' style='padding-left: 6px'>#QUANTITY#</td></tr>
                                <tr><td valign='top' style='padding-left: 6px'>#DESCRIPTION#</td></tr>
                               <tr><td></td><td align='right'>                            
                            </td></tr>
                            </table>";
                }
                else if (MemberName.Equals(Web.SessionMembers.FullName))
                {
                    tableTemplate = @"
                            <table cellpadding='1' cellspacing='1' class='exItem' id='gallery'>
                                <tr><td rowspan='5' valign='top' style='padding-left: 6px'>#IMAGE##VIDEO#</td>
                                    <td valign='top' style='padding-left: 6px;'>#TITLE#</td></tr>
                                <tr><td></td></tr>
                                 <tr><td valign='top' style='padding-left: 6px'>#PRICE#</td></tr>
                                 <tr><td valign='top' style='padding-left: 6px'>#QUANTITY#</td></tr>
                                <tr><td valign='top' style='padding-left: 6px'>#DESCRIPTION#</td></tr>
                               <tr><td></td><td align='right'>                            
                            </td></tr>
                            </table>";
                }
                else
                {
                    tableTemplate = @"
                            <table cellpadding='1' cellspacing='1' class='exItem' id='gallery'>
                                <tr><td rowspan='5' valign='top' style='padding-left: 6px'>#IMAGE##VIDEO#</td>
                                    <td valign='top' style='padding-left: 6px;'>#TITLE#</td></tr>
                                <tr><td></td></tr>
                                 <tr><td valign='top' style='padding-left: 6px'>#PRICE#</td></tr>
                                 <tr><td valign='top' style='padding-left: 6px'>#QUANTITY#</td></tr>
                                <tr><td valign='top' style='padding-left: 6px'>#DESCRIPTION#</td></tr>
                               <tr><td></td><td align='right'>                            
                            <div>#Button#</div>
                            </td></tr>
                            </table>";
                }
            }
            DataTable listingExtendedFields = ListingExtendedFields.GetListingExtendedFields(Convert.ToInt32(listing["ListingID"]));
            StringBuilder items = new StringBuilder();
            string spanHtml = string.Empty;
            foreach (DataRow field in listingExtendedFields.Rows)
            {
                string itemHtml = string.Empty;
                DataTable result = new DataTable();
                string Price = string.Empty;
                switch (field["FieldID"].ToString())
                {
                    case "20":// Title
                        {
                            itemHtml = string.Format("<b>{0}</b>", field["Data"]);
                            tableTemplate = tableTemplate.Replace("#TITLE#", itemHtml);
                            string Title = field["Data"].ToString();
                            if (Title == "" && Title == null)
                            {
                                Title = "n/a";
                            }
                            items.AppendFormat("<tr style=\"background:rgb(237, 239, 244)\"><td  ><span  style=\"color:#3b5998;font-size:13px; margin-left:5px;\">Title:</span><span data-jsid=\"text\" > {0}</span>  </td></tr>", Title);
                            break;
                        }
                    case "4":// Quantity
                        {
                            itemHtml = string.Format("Quantity: {0}", field["Data"]);
                            tableTemplate = tableTemplate.Replace("#QUANTITY#", itemHtml);
                            string Quantity = field["Data"].ToString();
                            if (Quantity == "" && Quantity == null)
                            {
                                Quantity = "n/a";
                            }
                            items.AppendFormat("<tr style=\"background:rgb(237, 239, 244)\"><td><span  style=\"color:#3b5998;font-size:11px; margin-left:5px;\">Quantity:</span><span data-jsid=\"text\" > {0}</span>  </td></tr>", Quantity);
                            break;
                        }
                    case "9":// Price
                        {
                            decimal price = 0;

                            if (field["Data"] != null)
                            {
                                decimal.TryParse(field["Data"].ToString(), out price);
                            }

                            tableTemplate = tableTemplate.Replace("#PRICE#", string.Format("Price: ${0}", price));
                            break;
                        }
                    case "10":// Price Each
                        {
                            itemHtml = string.Format("Price: ${0}", field["Data"]);
                            tableTemplate = tableTemplate.Replace("#PRICE#", itemHtml);
                            Price = field["Data"].ToString();
                            if (Price == "" && Price == null || Price == "0")
                            {
                                Price = "n/a";
                                string button = @"<input type='button' value='Make Offer' style='margin-top:10px; margin-left:5px;' onclick=""document.location.href='#MAKEOFFER#'"" class='InnerButtonMeduim' styel='width:100px; height:30px; color:white; text-decoration:none;' />";

                                button = button.Replace("#MAKEOFFER#", hrefMakeOffer);
                                tableTemplate = tableTemplate.Replace("#Button#", button);
                            }
                            else
                            {
                                string button = @"<input type='button' value='Buy Now' style='margin-top:10px;' onclick=""document.location.href='#BUYNOW#'"" class='InnerButtonMeduimGreen' styel='width:100px; height:30px; color:white; text-decoration:none;' />
                             <input type='button' value='Make Offer' style='margin-top:10px; margin-left:5px;' onclick=""document.location.href='#MAKEOFFER#'"" class='InnerButtonMeduim' styel='width:100px; height:30px; color:white; text-decoration:none;' />";
                                button = button.Replace("#BUYNOW#", hrefByeNow);
                                button = button.Replace("#MAKEOFFER#", hrefMakeOffer);
                                tableTemplate = tableTemplate.Replace("#Button#", button);
                            }
                            items.AppendFormat("<tr style=\"background:rgb(237, 239, 244)\"><td><span  style=\"color:#3b5998;font-size:11px; margin-left:5px;\">Price:$</span><span data-jsid=\"text\" > {0}</span>  </td></tr>", Price);
                            break;
                        }

                    case "3":// Description
                        {
                            itemHtml = string.Format("<div class='description' style=\"WIDTH: 397px; FONT-SIZE: 15px\" title=\"Description (text only)\">{0}</div>", field["Data"]);
                            tableTemplate = tableTemplate.Replace("#DESCRIPTION#", itemHtml);
                            string Description = field["Data"].ToString();
                            Description = Web.TruncateAtWord(Description, 500);
                            if (Description == "" && Description == null)
                            {
                                Description = "n/a";
                            }
                            items.AppendFormat("<tr style=\"background:rgb(237, 239, 244)\"><td> <span  style=\"color:#3b5998;font-size:11px;margin-left:5px;\">Description:</span><span data-jsid=\"text\" > {0}</span> </td></tr>", Description);
                            break;
                        }
                    case "24":// Make Offer
                        {
                            break;
                        }

                    case "11":// Duration
                        {
                            string Duration = field["Data"].ToString();
                            if (Duration == "" && Duration == null)
                            {
                                Duration = "n/a";
                            }
                            items.AppendFormat("<tr style=\"background:rgb(237, 239, 244)\"><td><span  style=\"color:#3b5998;font-size:11px;font-weight:bold; margin-left:5px;\">Duration:</span> <span data-jsid=\"text\" >{0}</span> </td></tr>", Duration);
                            break;
                        }

                    case "12":  //ShippingOptions
                        {
                            break;
                        }
                    case "13":  //PaymentOptions
                        {
                            break;
                        }
                    case "27":// Image
                        {
                            if (listing["FileFormat"] != null)
                            {
                                if (!listing["FileFormat"].ToString().ToLower().Equals("video"))
                                {
                                    itemHtml = string.Format("<a href='{0}' ><img class='imgContainer' src=\"{1}\" height='200' width='250' /> #DETAIL# </a>", listing["URL"], field["Data"]);
                                    tableTemplate = tableTemplate.Replace("#IMAGE#", itemHtml);
                                }
                            }
                            break;
                        }
                    case "28":
                        {
                            if (listing["FileFormat"] != null)
                            {
                                if (listing["FileFormat"].ToString().ToLower().Equals("video"))
                                {
                                    if (field["Data"] != null)
                                    {
                                        if (!string.IsNullOrEmpty(field["Data"].ToString()))
                                        {
                                            itemHtml = string.Format("<div><object width='250' height='200'><param name='movie' value='{0}'><param name='type' value='application/x-shockwave-flash'><param name='allowfullscreen' value='true'><param name='allowscriptaccess' value='always'><param name=\"wmode\" value=\"opaque\" /><embed width='250' height='200' src='{0}' type='application/x-shockwave-flash' allowfullscreen='true' allowscriptaccess='always' wmode=\"opaque\"></embed></object></div>", field["Data"]);
                                            tableTemplate = tableTemplate.Replace("#VIDEO#", itemHtml);
                                        }
                                    }
                                }
                            }
                            break;
                        }
                }
            }// listing fields
            tableTemplate = tableTemplate.Replace("#VIDEO#", "").Replace("#IMAGE#", "");
            string exID = Web.RecordID.ToString();
            string hrerEditExhibit = string.Format("Edit.aspx?Action=view&RecordID={0}&ListingTypeID=8", Secure.Encrypt(Web.RecordID));
            tableTemplate = tableTemplate.Replace("#MAKEOFFER#", hrefMakeOffer);
            //tableTemplate = tableTemplate.Replace("#Edit#", hrerEditExhibit);
            //if (Web.Action() == "viewEdit")
            //{
            //    spanHtml = string.Format("<div style=\" display:none; width:100px;\"><table style=\"width:295px; position: relative; top:20px; padding-left:5px; padding-right-5px;\"><tr><td align=\"center\" style=\"margin-top:10px; color:#3b5998;\"><span  style=\"color:#3b5998;font-size:11px;font-weight:bold; \">{0}</td></tr>{1} </table><div style=\"position: absolute; bottom: 0px; top:465px;  left: 110px;\"></div></div>", ExhName, items.ToString());
            //}
            //else
            //{
            foreach (DataRow field in listingExtendedFields.Rows)
            {
                string Price = string.Empty;
                string fieldId = field["FieldID"].ToString();
                switch (field["FieldID"].ToString())
                {

                    case "10":// Price each
                        {
                            Price = field["Data"].ToString();
                            if (Price == "" && Price == null || Price == "0")
                            {
                                spanHtml = string.Format("<div style=\" display:none; width:100px;\"><table style=\"width:295px; position: relative; top:20px; padding-left:5px; padding-right-5px;\"><tr><td align=\"center\" style=\"margin-top:10px; color:#3b5998;\"><span  style=\"color:#3b5998;font-size:11px;font-weight:bold; \">{0}</td></tr>{1} </table><div style=\"position: absolute; bottom: 0px; top:465px;  left: 110px;\"><input type='button' value='Make Offer' style='margin-top:10px; margin-left:80px;' onclick=document.location.href='{2}' class='InnerButtonMeduim' styel='width:100px; height:30px; color:white; text-decoration:none;' /></div></div>", ExhName, items.ToString(), hrefMakeOffer);
                                Price = "n/a";
                            }
                            else
                            {
                                spanHtml = string.Format("<div style=\" display:none; width:100px;\"><table style=\"width:295px; position: relative; top:20px; padding-left:5px; padding-right-5px;\"><tr><td align=\"center\" style=\"margin-top:10px; color:#3b5998;\"><span  style=\"color:#3b5998;font-size:11px;font-weight:bold; \">{0}</td></tr>{1} </table><div style=\"position: absolute; bottom: 0px; top:465px;  left: 110px;\"><input type='button' value='Buy Now' style='margin-top:10px;' onclick=document.location.href='{2}' class='InnerButtonMeduimGreen' styel='width:100px; height:30px; color:white; text-decoration:none;' /><input type='button' value='Make Offer' style='margin-top:10px; margin-left:5px;' onclick=document.location.href='{3}' class='InnerButtonMeduim' styel='width:100px; height:30px; color:white; text-decoration:none;' /></div></div>", ExhName, items.ToString(), hrefByeNow, hrefMakeOffer);
                            }
                            break;
                        }
                }
                //}
            }
            tableTemplate = tableTemplate.Replace("#DETAIL#", spanHtml);
            // tableTemplate = tableTemplate.Replace("#PARAM#", string.Format("{0}", Secure.Encrypt(exhibition.ExhibitionID)));
            // When go to ItemDetails page should encrypt Listing id instead of ExhibiontID
            //tableTemplate = tableTemplate.Replace("#PARAM#", "../../MarketPlace/ItemDetails.aspx?Action=View&RecordID=" + Secure.Encrypt(Convert.ToInt32(listing["ListingID"])));
            html += tableTemplate;
            html += "</div>";
        }// listing
        return html;
    }
}