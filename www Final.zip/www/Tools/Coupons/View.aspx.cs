﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Tools_Coupons_View : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!Web.IsMemberSession)
                Web.Redirect("~/index.aspx?ReturnUrl=~/Tools/Coupons");
            
            //this.Master.PageHeading = "Download/Print Coupons";
            //this.Master.ShowLine = true;

            MaskImage();
        }
        catch  
        {
        }
    }


    void MaskImage()
    {
        //get original image
        System.Drawing.Image originalBMP = System.Drawing.Image.FromFile(Server.MapPath("tgi-fridays-coupons.jpg"));

        //make a bigger space (in this case it will be 1000 plus in height)
        System.Drawing.Bitmap finalBMP = new System.Drawing.Bitmap(originalBMP.Width, originalBMP.Height + 30);
        using (System.Drawing.Graphics g = System.Drawing.Graphics.FromImage(finalBMP))
        {
            //draw original image
            g.DrawImage(originalBMP, 0, 0, originalBMP.Width, originalBMP.Height);

            //draw any image/logo on it
            //g.DrawImage(System.Drawing.Image.FromFile(@"D:\Projects\Tony\CodenameRabbitFoot\Code\eOpen\public\www\Tools\Coupons\temp.jpg"), new System.Drawing.Point(50, 100));

            //draw text/strings on it
            g.DrawString(Web.SessionMembers.FullName + " Downloaded From eOpen.com on " + DateTime.Now.ToShortDateString(), new System.Drawing.Font("Verdana", 12), System.Drawing.Brushes.Black, new System.Drawing.PointF(2, originalBMP.Height + 1));
        }
        //use finalBMP where ever you want :)
        string fileName = Guid.NewGuid() + "jpg";
        //finalBMP.Save(Server.MapPath(@"Download\" + fileName));
        imgMain.ImageUrl = @"Download\" + fileName;
        //pictureBox1.Image = finalBMP;

    }
}