﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Services;
using System.Web.Script.Services;
using System.Data;
using CodenameRabbitFoot.BusinessLogic;

public partial class Tools_Coupons_SentCouponDetail : System.Web.UI.Page
{
    public static int ListingID = 0;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request["listingid"] != null)
            ListingID = Convert.ToInt32(Request["listingid"].ToString());

        this.Master.HideLinkApps();

    }

    [WebMethod(EnableSession = true)]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public static JQGrid LoadCouponDetail(int pageIndex, int pageSize)
    {
        JQGrid jqGrid = new JQGrid();
        if (!Web.IsMemberSession)
        {
            jqGrid.status = "login";
        }

        IEnumerable<DataRow> allRows = bindgvCoupons();//(ListingTypeID, CategoryID, LocationID, KeyWord, KeyWordID, FavCatID, radioOption);

        // all filterign is made above 
        jqGrid.total = allRows.Count() == pageSize ? 1 : (allRows.Count() / pageSize) + 1;
        jqGrid.records = pageSize;
        jqGrid.page = pageIndex;
        IEnumerable<DataRow> dataRows = allRows.Skip((pageIndex - 1) * pageSize).Take(pageSize);

        if (dataRows.Count() == 0)
        {
            JQGrid.Row row = new JQGrid.Row();
            row.id = 0;
            row.cell.Add("0");
            row.cell.Add("<div style='text-align:left; padding:5px;'>No records exists.</div>");
            jqGrid.rows.Add(row);
            jqGrid.status = "empty";
        }

        foreach (DataRow item in dataRows)
        {
            object encryptedMemberID = Secure.Encrypt(item["MemberID"]);
            object encryptedListingID = Secure.Encrypt(item["ListingID"]);

            JQGrid.Row row = new JQGrid.Row();
            
            row.id = Convert.ToInt32(item["MemberID"]);
            row.cell.Add(item["MemberID"].ToString());

            row.cell.Add("<div style='padding:5px 0px 5px 0px; margin:0px 0px 0px 5px;' ><img width='40' style='border:5px solid #F1F6F6'; 'margin:5px 0px 5px 0px;' height='40';  src='/epage/ImageViewer.ashx?Action=MembersLogo&RecordID=" + item["ownerid"].ToString() + "' /></div>");

            row.cell.Add(item["fullname"].ToString());
            row.cell.Add(item["listingid"].ToString() + "." + Web.SessionMembers.MemberID);

            row.cell.Add(item["AccessDate"].ToString());
            row.cell.Add(item["AccessType"].ToString() == "1" ? "Print" : "Download");
            row.cell.Add(item["email"].ToString());

            jqGrid.rows.Add(row);
        }

        return jqGrid;
    }

    public static IEnumerable<DataRow> bindgvCoupons()
    {
        DataTable coupontable = new DataTable();
        try
        {

            coupontable = CouponAccessLog.GetCouponDetail(ListingID);
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
        return coupontable.AsEnumerable();
    }
}