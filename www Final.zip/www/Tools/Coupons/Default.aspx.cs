﻿using System;
using System.Collections.Generic;
using System.Web.UI;
using System.Linq;
using System.Web.UI.WebControls;
using CodenameRabbitFoot.BusinessLogic;
using System.Web.Services;
using System.Data;
using System.Xml.Linq;
using System.Web.Script.Services;

public partial class Tools_Coupons_Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            Web.CheckSession();

            this.Master.HideLinkApps();

            if (!Page.IsPostBack)
            {
                //

                //if (Request.QueryString["listid"] != null)
                //{
                //    LoadMemberContactsList();

                //    this.ddlMemberContatctList.SelectedValue = Request.QueryString["listid"].ToString();
                //    this.ddlMemberContatctList.Enabled = false;
                //    this.ddlMemberContatctList.Visible = true;
                //    trcontactlist.Visible = true;
                //}

            }
        }
        catch  
        {
        }
    }

    //public void LoadMemberContactsList()
    //{
    //    MemberContactList mList = new MemberContactList();
    //    mList.Where.MemberID.Value = Web.SessionMembers.MemberID;
    //    mList.Query.AddResultColumn(MemberContactListSchema.BatchNumber);
    //    mList.Query.AddResultColumn(MemberContactListSchema.ContactListName);
    //    mList.Query.Distinct = true;
    //    mList.Query.Load();

    //    this.ddlMemberContatctList.DataSource = mList.DefaultView;
    //    this.ddlMemberContatctList.DataTextField = "ContactListName";
    //    this.ddlMemberContatctList.DataValueField = "BatchNumber";
    //    this.ddlMemberContatctList.DataBind();

    //    this.ddlMemberContatctList.Items.Insert(0, new ListItem("----Select----", "0"));

    //}
    protected void btnSendCoupon_Click(object sender, EventArgs e)
    {

        //if (Convert.ToInt64(this.ddlMemberContatctList.SelectedValue) == 0)
        //{

        //    //Master.ShowMessage("Please select member contact list.");
        //    return;
        //}
        //bool isValid=true;
        //foreach (UploadedFile file in fupPhoto.UploadedFiles)
        //{
        //    if (!(file.FileName.ToLower().EndsWith(".jpg") || file.FileName.ToLower().EndsWith(".png") || file.FileName.ToLower().EndsWith(".jpeg") || file.FileName.ToLower().EndsWith(".gif") || file.FileName.ToLower().EndsWith(".bmp")))
        //    {
        //        isValid=false;
        //    }
        //}
        if (fupPhoto.InvalidFiles.Count > 0)
        {

            // Master.ShowMessage("Please selectd a valid coupon image file.");
            return;
        }

        // List<int> categoryFields = CategoryFields.GetCategoryFields(7, 4679);
        bool ApprovedMember = ApprovedMembers.CheckIfApproved(Web.SessionMembers.MemberID);

        Listings list = new Listings();
        list.AddNew();
        list.ListingEndDate = DateTime.Now.AddYears(20);
        list.MemberID = Web.SessionMembers.MemberID;
        list.IsActive = 1;
        list.StatusCode = (ApprovedMember) ? 100 : 200;

        list.CategoryID = 4679;
        list.ListingTypeID = 7;
        list.ListingDate = DateTime.Now;
        list.IsPrivate = 0;
        list.Save();

        ListingExtendedFields LFields = new ListingExtendedFields();
        LFields.AddNew();
        LFields.Data = Web.GetCleanHTML(this.txtCouponTitle.Text);
        LFields.FieldID = 20;
        LFields.EntryTime = DateTime.Now;
        LFields.IsActive = 1;

        LFields.ObjectID = list.ListingID;
        LFields.SystemObjectID = (int)SystemObjects.Listings;
        LFields.Save();
         
        Web.SaveFiles(Convert.ToInt32(SystemObjects.Listings), list.ListingID, fupPhoto, fupDocument, txtLink, txtURL, 1);
        ClientScript.RegisterClientScriptBlock(Page.GetType(), "redirestto", " alert('Coupon has been saved successfully.'); window.location = \"/Tools/Coupons/Default.aspx\";", true);

        // ToDo: Send Eemail
        //AddMemberCoupon(list.ListingID.ToString(), this.ddlMemberContatctList.SelectedValue, DateTime.Now.AddDays(14).ToShortDateString());

        //if (ApprovedMember)
        //{
        //    MemberCoupons coupon = new MemberCoupons();
        //    coupon.Where.ListingID.Value = list.ListingID;
        //    coupon.Query.Load();
        //    Utils.SendCouponEmail(coupon.BatchNumber);
        //}

        //MemberContactList cList = new MemberContactList();
        //cList.Where.BatchNumber.Value = this.ddlMemberContatctList.SelectedValue;
        //cList.Query.Load();

        //string htmlHeader = Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER");
        //string htmlFooter = Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER");
        //if (cList.RowCount > 0)
        //{
        //    do
        //    {
        //        templateKeys = new System.Collections.Specialized.StringDictionary();

        //        templateKeys.Add("#email_header#", htmlHeader);
        //        templateKeys.Add("#fullname#", cList.s_ContactName);
        //        templateKeys.Add("#company#", Web.SessionMembers.CompanyName);
        //        templateKeys.Add("#couponid#", Secure.Encrypt(cList.s_MemberContactListID));
        //        templateKeys.Add("#email_footer#", htmlFooter);

        //        Web.SendMail(cList.s_ContactEmail, Web.SystemConfigs.GetKey("REG_EMAIL"), 901, templateKeys);

        //        templateKeys = null;

        //    }
        //    while (cList.MoveNext());
        //}

        // Master.ShowMessage(Session["Message"].ToString());
        // Web.Redirect(Request.ApplicationPath,false);
        // Web.Redirect("/Tools/Coupons/Default.aspx");

    }

    [WebMethod(EnableSession = true)]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public static JQGrid LoadMarket(int pageIndex, int pageSize)
    {
        JQGrid jqGrid = new JQGrid();
        if (!Web.IsMemberSession)
        {
            jqGrid.status = "login";
        }

        IEnumerable<DataRow> allRows = bindgvCoupons();//(ListingTypeID, CategoryID, LocationID, KeyWord, KeyWordID, FavCatID, radioOption);

        // all filterign is made above 
        jqGrid.total = allRows.Count() == pageSize ? 1 : (allRows.Count() / pageSize) + 1;
        jqGrid.records = pageSize;
        jqGrid.page = pageIndex;
        IEnumerable<DataRow> dataRows = allRows.Skip((pageIndex - 1) * pageSize).Take(pageSize);

        if (dataRows.Count() == 0)
        {
            JQGrid.Row row = new JQGrid.Row();
            row.id = 0;
            row.cell.Add("0");
            row.cell.Add("<div style='text-align:left; padding:5px;'>No records exists.</div>");
            jqGrid.rows.Add(row);
            jqGrid.status = "empty";
        }

        foreach (DataRow item in dataRows)
        {
            object encryptedMemberID = Secure.Encrypt(item["MemberID"]);
            object encryptedListingID = Secure.Encrypt(item["ListingID"]);

            JQGrid.Row row = new JQGrid.Row();
            row.id = Convert.ToInt32(item["MemberID"]);
            row.cell.Add(item["MemberID"].ToString());
            row.cell.Add("<div style='padding:5px 0px 5px 0px; margin:0px 0px 0px 5px;' ><img width='48' style='border:5px solid #F1F6F6'; 'margin:5px 0px 5px 0px;' height='48';  src='" + (item["ThumbnailURL"].ToString() == "" ? "/images/noimage.png" : item["ThumbnailURL"]) + "' /></div>");

            row.cell.Add(item["Title"].ToString());

            string[] couponcount = CouponAccessLog.GetCouponPrintDownLoadCount(Convert.ToInt32(item["listingid"].ToString())).Split(',');
            row.cell.Add(couponcount[0] + "/" + couponcount[1]);

            row.cell.Add("<a id=\"anchordetail\" href='SentCouponDetail.aspx?listingid=" + item["listingid"].ToString() + "' title=\"Detail\"><span>Detail</span></a>");//"<input type='button' class='InnerButtonMeduim' style='width:80px;' onClick=\"showcoupondetail(\'" + item["ListingID"].ToString() + "\');\" value='Detail'/>");

            if (item["StatusCode"].ToString() == "100")
                row.cell.Add("<input type='button' class='InnerButtonMeduim' style='width:80px;' onClick=\"gotocontactpage(\'" + item["ListingID"].ToString() + "\');\" value='Send'/>");
            else if (item["StatusCode"].ToString() == "200")
                row.cell.Add("Pending Approval");
            jqGrid.rows.Add(row);
        }

        return jqGrid;
    }

    public static IEnumerable<DataRow> bindgvCoupons()
    {
        DataTable coupontable = new DataTable();
        try
        {
            coupontable = MemberCoupons.GetCoupons(Web.SessionMembers.MemberID);
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
        return coupontable.AsEnumerable();
    }

    private void AddMemberCoupon(string listingID, string batchNumber, string expiaryDate)
    {
        MemberCoupons mC = new MemberCoupons();
        mC.AddNew();
        mC.s_BatchNumber = batchNumber;
        mC.s_ListingID = listingID;
        mC.s_ExpiryDate = expiaryDate;
        mC.Save();

        //string connectionString = ConfigurationManager.ConnectionStrings["RabbitConnectionString"].ConnectionString;

        //using (SqlConnection connection = new SqlConnection(connectionString))
        //{
        //    connection.Open();
        //    string query = string.Format("insert into MemberCoupons(ListingID,BatchNumber,ExpiryDate) values('{0}','{1}','{2}')", listingID, batchNumber, expiaryDate);
        //    SqlCommand command = connection.CreateCommand();
        //    command.CommandText = query;
        //    command.ExecuteNonQuery();
        //}

    }

    protected void btncancel_Click(object sender, EventArgs e)
    {
        Web.Redirect("/index.aspx");
    }
}