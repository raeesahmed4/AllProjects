﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CodenameRabbitFoot.BusinessLogic;
using System.Text;
using System.Web.Services;
using System.Data;
using System.Xml.Linq;

public partial class Tools_Coupons_SendCoupontToContactList : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        Web.CheckSession();


        //MemberCoupons coupon = new MemberCoupons();
        //coupon.Where.ListingID.Value = Convert.ToInt32(Web.RecordID);
        //coupon.Query.Load();
        //Utils.SendCouponEmail(coupon.BatchNumber);

        if (!Page.IsPostBack)
        {
            //LoadMemberContactsList();

            //if (Request.QueryString["listid"] != null)
            //{
            //    this.ddlMemberContatctList.SelectedValue = Request.QueryString["listid"].ToString();
            //    this.ddlMemberContatctList.Enabled = false;
            //}

        }

    }

    [WebMethod]
    public static string SendEmail(string batchNumber, string listingID, string listingName, string contactlist)
    {
        //  Send Eemail
        MemberCoupons mC = new MemberCoupons();
        mC.Where.BatchNumber.Value = batchNumber;
        mC.Where.ListingID.Value = listingID;
        mC.Query.Load();
        if (mC.RowCount > 0)
            return "fail";

        mC.AddNew();
        mC.s_BatchNumber = batchNumber;
        mC.s_ListingID = listingID;
        mC.s_ExpiryDate = DateTime.Now.AddDays(14).ToString();
        mC.Save();

        //MemberCoupons coupon = new MemberCoupons();
        //coupon.Where.ListingID.Value = Convert.ToInt32(listingID);
        //coupon.Query.Load();
        try
        {
            Utils.SendCouponEmail(Convert.ToInt64(batchNumber));

            ////call async if error came it will show a mesage in session message object 
            ////and will email user about it
            ////and will log
            //new System.Threading.Thread(
            //    new System.Threading.ParameterizedThreadStart(Utils.SendCouponEmail))
            //    .Start(batchNumber);
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }

        var templateKeys = new System.Collections.Specialized.StringDictionary();
        templateKeys.Add("#listingtype#", ListingTypes.GetTypeName(7));
        templateKeys.Add("#listingname#", listingName);
        templateKeys.Add("#viewlink#", "/Marketplace/ItemDetails.aspx?Action=View&RecordID=#encrypt#" + listingID + "#endencrypt#");
        templateKeys.Add("#contactlist#", contactlist);

        Web.AddActivityLog(Web.SessionMembers.MemberID, 53, templateKeys, Convert.ToInt32(listingID), 7, false, false);

        return "success";
    }

    [WebMethod]
    public static string GetContactList(string batchNumber, string listingID)
    {
        StringBuilder stringBuilder = new StringBuilder();
        MemberContactList mList = new MemberContactList();
        mList.Where.MemberID.Value = Web.SessionMembers.MemberID;
        mList.Query.AddResultColumn(MemberContactListSchema.BatchNumber);
        mList.Query.AddResultColumn(MemberContactListSchema.ContactListName);
        mList.Query.Distinct = true;
        mList.Query.Load();

        if (mList.RowCount == 0)
        {
            stringBuilder.Append("Currently you have not Added/Uploaded contact list. <a href='/Tools/Upload/Default.aspx'>Click here</a> to Add/Upload.");
        }
        else
        {
            foreach (DataRow VARIABLE in mList.DefaultView.Table.Rows)
            {
                stringBuilder.Append("<option value=\"" + VARIABLE["BatchNumber"].ToString() + "\" >" + VARIABLE["ContactListName"].ToString() + "</option>");
            }
        }
        return stringBuilder.ToString();
    }

    [WebMethod]
    public static string CheckMemberCoupons(string batchNumber, string listingID)
    {
        StringBuilder stringBuilder = new StringBuilder();

        MemberContactList mList = new MemberContactList();
        mList.Where.MemberID.Value = Web.SessionMembers.MemberID;
        mList.Query.AddResultColumn(MemberContactListSchema.BatchNumber);
        mList.Query.AddResultColumn(MemberContactListSchema.ContactListName);
        mList.Query.Distinct = true;
        mList.Query.Load();

        foreach (DataRow VARIABLE in mList.DefaultView.Table.Rows)
        {
            MemberCoupons mC = new MemberCoupons();
            mC.Where.BatchNumber.Value = batchNumber;
            mC.Where.ListingID.Value = listingID;
            mC.Query.Load();

            if (mC.RowCount != 0)
                stringBuilder.Append(VARIABLE["BatchNumber"].ToString() + ",");
        }

        return stringBuilder.ToString();
    }


    [WebMethod]
    public static string GetCouponList()
    {
        StringBuilder stringBuilder = new StringBuilder();
        DataTable coupontable = MemberCoupons.GetCoupons(Web.SessionMembers.MemberID);

        foreach (DataRow VARIABLE in coupontable.Rows)
        {
            stringBuilder.Append("<option value=\"'" + VARIABLE["ListingID"].ToString() + "'\" >" + VARIABLE["Title"].ToString() + "</option>");
        }

        return stringBuilder.ToString();
    }

    [WebMethod]
    public static string GetCouponDetail(string listingid)
    {
        StringBuilder stringBuilder = new StringBuilder();
        try
        {
            DataTable coupontable = Listings.GetListingDetails(Convert.ToInt32(listingid));
            string xml = "";
            foreach (DataRow row in coupontable.Rows)
            {
                string img = row["ThumbnailURL"].ToString();
                if (String.IsNullOrEmpty(row["ThumbnailURL"].ToString()))
                    img = "~/Images/noimage.png";

                xml = row["ListingData"].ToString();

                if (!String.IsNullOrEmpty(xml))
                {
                    var listingData = from d in XDocument.Parse("<listings>" + xml + "</listings>").Root.Descendants()
                                      select new
                                      {
                                          FieldID = d.Attribute("FieldID").Value,
                                          FieldName = d.Attribute("FieldName").Value,
                                          Data = d.Attribute("Data").Value
                                      };
                    stringBuilder.Append("<table width='90%' align='center'><tr><td width='30%'><img title='Coupon' src='" + img + "' /></td><td width='70%' align='left' class='Heading'>" + listingData.FirstOrDefault().Data + "</td></tr></table>");
                }
            }
        }
        catch (Exception ex)
        {


        }

        return stringBuilder.ToString();
    }
}