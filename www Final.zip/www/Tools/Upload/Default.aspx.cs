﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using CodenameRabbitFoot.BusinessLogic;
using Telerik.Web.UI;

public partial class Tools_NewTestUpload_Default : System.Web.UI.Page
{
    private string MyExcel972003FormatCs =
            "Provider=Microsoft.Jet.OLEDB.4.0;Extended Properties='Excel 8.0;HDR={0}'; Data Source={1};";
    private string MyExcel2007FormatCs =
        "Provider=Microsoft.ACE.OLEDB.12.0;Extended Properties='Excel 8.0;HDR={0}'; Data Source={1};";
    private string FileUploadPath = "ExcelFiles";

    protected void Page_Load(object sender, EventArgs e)
    {
        Web.CheckSession();
    }


    [WebMethod]
    public static string SaveUserList(string listname, string data)
    {
        string batchNumber = Web.SessionMembers.MemberID + DateTime.Now.ToString("mmddyyhhmmss");
        try
        {
            MemberContactList mList = new MemberContactList();
            mList.Where.ContactListName.Value = listname.Trim();
            mList.Where.MemberID.Value = Web.SessionMembers.MemberID;
            mList.Query.Load();
            if (mList.RowCount > 0)
            {
                return "List with same name already exist.";
            }

            string[] contactData = data.Split(';');
            foreach (string s in contactData)
            {
                string[] tempData = s.Split(',');

                if (tempData.Length == 1)
                    continue;

                mList.AddNew();
                mList.BatchNumber = Convert.ToInt64(batchNumber);
                mList.MemberID = Web.SessionMembers.MemberID;
                mList.ContactName = string.Format("{0} {1}", tempData[0].ToString().Trim(), tempData[1].ToString().Trim()).Trim();
                mList.ContactEmail = tempData[2].ToString();
                mList.ContactListName = listname;
                mList.Save();
            }
        }
        catch (Exception ex)
        {
            return ex.ToString();
        }
        return batchNumber;
    }


    protected void Button1_Click(object sender, EventArgs e)
    {
    }

    private List<DataTable> ImportExcel(string FileName)
    {

        List<DataTable> _dataTables = new List<DataTable>();
        string _ConnectionString = string.Empty;

        string _Extension = Path.GetExtension(FileName);

        //Checking for the extentions, if XLS connect using Jet OleDB

        if (_Extension.Equals(".xls", StringComparison.CurrentCultureIgnoreCase))
        {

            _ConnectionString =

                "Provider=Microsoft.Jet.OLEDB.4.0; Data Source={0};Extended Properties=Excel 8.0";

        }

        //Use ACE OleDb

        else if (_Extension.Equals(".xlsx", StringComparison.CurrentCultureIgnoreCase))
        {

            _ConnectionString =

                "Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties=Excel 8.0";

        }



        DataTable dataTable = null;



        using (OleDbConnection oleDbConnection =

            new OleDbConnection(string.Format(_ConnectionString, FileName)))
        {

            oleDbConnection.Open();

            //Getting the meta data information.

            //This DataTable will return the details of Sheets in the Excel File.

            DataTable dbSchema = oleDbConnection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables_Info, null);

            foreach (DataRow item in dbSchema.Rows)
            {

                //reading data from excel to Data Table

                using (OleDbCommand oleDbCommand = new OleDbCommand())
                {

                    oleDbCommand.Connection = oleDbConnection;

                    oleDbCommand.CommandText = string.Format("SELECT * FROM [{0}]",

                        item["TABLE_NAME"].ToString());

                    using (OleDbDataAdapter oleDbDataAdapter = new OleDbDataAdapter())
                    {

                        oleDbDataAdapter.SelectCommand = oleDbCommand;

                        dataTable = new DataTable(item["TABLE_NAME"].ToString());

                        oleDbDataAdapter.Fill(dataTable);

                        _dataTables.Add(dataTable);

                    }

                }

            }

        }

        return _dataTables;

    }

    void bindUploadedContacts(string batchNumber)
    {
        trRecords.Visible = true;

        MemberContactList mList = new MemberContactList();

        mList.Where.BatchNumber.Value = Convert.ToInt64(batchNumber);
        mList.Query.Load();

        gvContacts.DataSource = mList.DefaultView;
        gvContacts.DataBind();
    }

    protected void lnkSave_Click(object sender, EventArgs e)
    {
        try
        {
            if (fupLoad.InvalidFiles.Count > 0)
            {
                string script = " javascript: ShowMessageBox('Error','Please select an excel or csv file to upload.'); ";
                Page.ClientScript.RegisterStartupScript(GetType(), "JavascriptMsg", script, true);
                return;
            }
            MemberContactList mList = new MemberContactList();
            mList.Where.ContactListName.Value = txtName.Text.Trim();
            mList.Where.MemberID.Value = Web.SessionMembers.MemberID;
            mList.Query.Load();
            if (mList.RowCount > 0)
            {
                string script = " javascript: ShowMessageBox('Error','List with same name already exist.');";
                Page.ClientScript.RegisterStartupScript(GetType(), "JavascriptMsg", script, true);
                return;
            }

            bool hasData = false;
            string batchNumber = Web.SessionMembers.MemberID + DateTime.Now.ToString("mmddyyhhmmss");

            foreach (UploadedFile file in fupLoad.UploadedFiles)
            {
                string ext = System.IO.Path.GetExtension(file.FileName).ToLower();

                if (!(ext.Equals(".csv") || ext.Equals(".xls") || ext.Equals(".xlsx")))
                {
                    string script = " javascript: ShowMessageBox('Error','Please select an excel or csv file to upload.');";
                    Page.ClientScript.RegisterStartupScript(GetType(), "JavascriptMsg", script, true);
                    return;

                }
                
                if (!Directory.Exists(Server.MapPath("Temp/")))
                {
                    Directory.CreateDirectory(Server.MapPath("Temp/"));
                }

                string tempFolder = Web.SystemConfigs.GetKey("ATTACHMENTS_PHYSICAL_PATH") + @"\ContactsTempFiles";
                tempFolder = Path.Combine(tempFolder, Session.SessionID);
                if (!Directory.Exists(tempFolder))
                    Directory.CreateDirectory(tempFolder);

                string fileName = (tempFolder + Guid.NewGuid() + ext);
                
                file.SaveAs(fileName, true);

                List<DataTable> tables = ImportExcel(fileName);




                if (tables[0] != null)
                {
                    if (tables[0].Rows.Count > 0)
                    {
                        foreach (DataRow row in tables[0].Rows)
                        {
                            if (row[1].ToString() != "")
                            {
                                mList.AddNew();
                                mList.BatchNumber = Convert.ToInt64(batchNumber);
                                mList.MemberID = Web.SessionMembers.MemberID;
                                mList.ContactName = string.Format("{0} {1}", row[0].ToString().Trim(), row[1].ToString().Trim()).Trim();
                                mList.ContactEmail = row[2].ToString();
                                mList.ContactListName = txtName.Text.Trim();
                                hasData = true;
                            }
                            mList.Save();
                        }
                    }
                }
            }

            if (hasData)
            {
                Web.Redirect("~/contacts/?Action=Clients&Type=ContactList&BatchNumber=" + batchNumber);
            }
            else
            {
                string script = " javascript: ShowMessageBox('Error','File does not contain any data.');";
                Page.ClientScript.RegisterStartupScript(GetType(), "JavascriptMsg", script, true);
                return; 
            }
        } 
        catch (Exception ex)
        {
            Web.WriteLog("READ File", "UPload contact error", ex);
            string script = " javascript: ShowMessageBox('Error','Error whlile reading data from file.');";
            Page.ClientScript.RegisterStartupScript(GetType(), "JavascriptMsg", script, true);
            // return;
            // this.Master.ShowMessage("Error while reading data from file.", "m");
            //        throw;
        }


    }
    protected void gvContacts_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void gvContacts_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        // gvContacts.PageIndex = e.NewPageIndex;
        // bindUploadedContacts(ViewState["BatchNumber"].ToString());
    }
}