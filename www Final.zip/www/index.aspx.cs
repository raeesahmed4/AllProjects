﻿using System;

using CodenameRabbitFoot.BusinessLogic;

public partial class index : System.Web.UI.Page
{
    public string RequestParameters
    {
        get;
        set;
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        Page.Header.DataBind();

        if (!Web.IsMemberSession)
        {
            Web.CookieLogin();
        }
         
            if (Web.IsMemberSession)
            {

                litUserName.Text = Web.SessionMembers.FullName;
                divLoginPanel.Visible = false;
                divUserPanel.Visible = true;

                //http://localhost:8083/marketplace/ItemDetails.aspx?Action=View&RecordID=HBdxol9WUgXjkoIb3gb0bg==

                if (Request.QueryString["action"] != null && Request.QueryString["RecordID"] != null)
                {
                    if (Request.QueryString["action"].ToLower().Equals("invite_coupons_unregistered"))
                    {
                        Web.Redirect(string.Format("http://{0}/marketplace/ItemDetails.aspx?Action=View&RecordID={1}", Request.Url.Host, Request.QueryString["RecordID"]));
                    }
                }
                else if (Request.UrlReferrer != null)
                {
                    if (Request.UrlReferrer.AbsolutePath.ToLower().Equals("/account/register.aspx"))
                    {
                        Web.Redirect(Request.QueryString["ReturnUrl"]);
                    }
                }
            }
            else
            {
                divLoginPanel.Visible = true;
                divUserPanel.Visible = false;

                if (Request.QueryString["Type"] != null && Request.QueryString["InvitationID"] != null)
                {
                    RequestParameters = string.Format("&Type=NonMember&InvitationID={0}", Request.QueryString["InvitationID"]);
                    // string script = "$.ready( function() { TriggerSignUp(); });";
                    //  Page.ClientScript.RegisterClientScriptBlock(typeof(System.Web.UI.Page), "RegScript", script, true);
                }
                else
                    if (Request.QueryString["action"] != null && Request.QueryString["InvitationID"] != null)
                    {
                        if (Request.QueryString["action"].ToLower().Equals("invite_coupons_unregistered"))
                        {
                            RequestParameters = string.Format("&Type=NonMember&InvitationID={0}", Request.QueryString["InvitationID"]);
                        }
                    }
              //  if (!string.IsNullOrEmpty(Request.QueryString["ReturnUrl"]))
              //      RequestParameters += "&ReturnUrl=" + Request.QueryString["ReturnUrl"];
            }
    }
    protected int GetNewActivitiesCount()
    {
        int count = 0;
        try
        {
            if (Web.IsMemberSession)
            {
                count += Counters.GetCount(CountTypes.Clients_Pending_MyApproval, Web.SessionMembers.MemberID);
                count += Counters.GetCount(CountTypes.Vendors_Pending_MyApproval, Web.SessionMembers.MemberID);
                count += Counters.GetCount(CountTypes.Clients_Waiting_ToApproveMe, Web.SessionMembers.MemberID);
                count += Counters.GetCount(CountTypes.Vendors_Waiting_ToApproveMe, Web.SessionMembers.MemberID);
                count += Counters.GetCount(CountTypes.New_Messages, Web.SessionMembers.MemberID);
                count += Counters.GetCount(CountTypes.Offers_To_Buy_My_Entire_Lot, Web.SessionMembers.MemberID) > 0 ? Counters.GetCount(CountTypes.Offers_To_Buy_My_Entire_Lot, Web.SessionMembers.MemberID) : 0;
                count += Counters.GetCount(CountTypes.Offers_On_My_Selected_Items, Web.SessionMembers.MemberID) > 0 ? Counters.GetCount(CountTypes.Offers_On_My_Selected_Items, Web.SessionMembers.MemberID) : 0;
                count += Counters.GetCount(CountTypes.Offers_On_My_Selected_Items, Web.SessionMembers.MemberID) > 0 ? Counters.GetCount(CountTypes.Offers_On_My_Selected_Items, Web.SessionMembers.MemberID) : 0;

                //if (Web.SessionMembers.s_IsDealerProfileUpdate == "0")
                //count++;
            }
        }
        catch (Exception ex)
        { Web.LogError(ex); }
        return count;
    }




}