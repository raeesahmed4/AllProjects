﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CodenameRabbitFoot.BusinessLogic;
using System.Data;

public partial class Account_EmailSubscriptions : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Web.CheckSession("~/Account/EmailSubscriptions.aspx");        

        if (!IsPostBack)
        {
            populateEnotifier();
            Web.LogUserActivity(Radium.Platform.Core.UserActivity.View);
        }
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            int MemberID = Web.SessionMembers.MemberID;

            foreach (ListItem item in chkEnotifier.Items)
            {

                int emailnotificationid = Convert.ToInt32(item.Value.ToString());
                EmailNotificationTypes emnotificationtype = new EmailNotificationTypes();
                emnotificationtype.LoadByPrimaryKey(emailnotificationid);

                Members.UpdateeNotifier(MemberID, emailnotificationid, item.Selected);
            }

            System.Collections.Specialized.StringDictionary templateKeys = new System.Collections.Specialized.StringDictionary();
            templateKeys.Add("#email_header#", Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER"));
            templateKeys.Add("#email_footer#", Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER"));
            templateKeys.Add("#fullname#", Web.SessionMembers.FullName);
            templateKeys.Add("#link_log_myeoffer#", Web.SystemConfigs.GetKey("SITE_URL"));
            templateKeys.Add("#link_contact_us#", Web.SystemConfigs.GetKey("SITE_URL") + "ContactUs.aspx");

            Web.SendMail(Web.SessionMembers.Email, Web.SystemConfigs.GetKey("ACCOUNTS_EMAIL"), 5, templateKeys);
            
            Session["Message"] = "Email Notification Preferences Updated Successfully";
            this.Master.ShowMessage("Email Notification Preferences Updated Successfully","Information");

            //Web.Redirect("~/Account/MyAccount.aspx");
            //Members member = new Members();
            //member.LoadByPrimaryKey(MemberID);
            //member.s_EmailPrefrence = ddlEmailPref.SelectedValue;
            //member.Save();
        }
        catch (Exception exp)
        {
            //Log.Write("err", exp.GetBaseException().ToString(), exp);
            Web.LogError(exp);
        }

         
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Web.Redirect("/live.aspx");
    }

    private void populateEnotifier()
    {
        try
        {
            EmailNotificationTypes notifications = new EmailNotificationTypes();
            notifications.Where.IsActive.Value = 1;
            notifications.Query.Load();
            if (notifications.RowCount > 0)
            {
                chkEnotifier.DataSource = notifications.DefaultView;
                chkEnotifier.DataTextField = "EmailNotificationTypeName";
                chkEnotifier.DataValueField = "EmailNotificationTypeID";
                chkEnotifier.DataBind();

                foreach (ListItem check in chkEnotifier.Items)
                {
                    check.Selected = true;

                    //check.Text = "&nbsp;" + check.Text;
                }
            }

            DataTable result = Members.GeteNotifier(Web.SessionMembers.MemberID);
            if (result.Rows.Count > 0)
            {
                foreach (DataRow row in result.Rows)
                {
                    string text =  row["EmailNotificationTypeName"].ToString();
                    int status = Convert.ToInt32(row["IsEnabled"].ToString());
                    if (status == 1)
                        chkEnotifier.Items.FindByText(text).Selected = true;
                    else
                        chkEnotifier.Items.FindByText(text).Selected = false;
                }
            }
        }
        catch (Exception exp)
        {
            Web.LogError(exp);
        }
    }

    private void EmailNotification(int TemplateID, int MemberID, bool isEnable)
    {


    }


}