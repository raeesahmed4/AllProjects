﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using CodenameRabbitFoot.BusinessLogic;

public partial class PublicSite_MyAccount_CreatePassword : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //this.Master.ShowMessageBox = false;
        //this.Master.ShowHeader = false;
        //this.Master.ShowLine = true;
        //this.Master.PageHeading = "Create New Password";
        //this.Master.HeadingIcon = "~/Images/PageIcons/sign-up.png";
        if (!IsPostBack)
        {
            Web.LogUserActivity(Radium.Platform.Core.UserActivity.View); 
        }
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            Members member = new Members();
            if (Web.IsMemberSession)
            {
                member.LoadByPrimaryKey(Web.SessionMembers.MemberID);
                member.Password = txtPass.Text;
                member.Save();
                Web.SessionMembers = member;
                Web.Redirect("~/Live.aspx");
            }
            else
            {
                member.Where.Email.Value = txtboxEmail.Text;
                member.Where.MemberID.Value = Web.RecordID;
                member.Where.MemberStatusID.Value = 200;
                member.Query.Load();
                if (member.RowCount > 0)
                {
                    member.Password = txtPass.Text;
                    member.Save();

                    try
                    {
                        Web.AuthenticateMember(member.UserName, member.Password, false, false, false);
                        if (!Web.IsMemberSession)
                            this.Master.ShowMessage("Invalid Login/Password", "warning");
                        else
                            Web.Redirect("~/Live.aspx");
                    }
                    catch (Exception ex)
                    {
                        Web.WriteLog("ERR:Login.aspx : 1", ex.Message, ex);
                    }
                }
                // else
                //this.Master.ShowMessage("Please enter valid information.");
            }
        }
        catch (Exception ex)
        {
            Web.WriteLog("Error Saving Password", ex.GetBaseException().ToString(), ex);
        }
    }
}
