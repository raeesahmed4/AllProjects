﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Account_Default5 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
            if (Web.IsMemberSession)
            {
                Web.Redirect("~/index.aspx");
            }
         
        if (Request["login"] != null)
        {
            txtLogin.Text = Request["login"].ToString();
        }

        if(Request["Action"]=="error")
        {
            errorspan.InnerHtml = "<div class='errorspan'>Invalid Login or Password</div>";
        }
         
    }
}