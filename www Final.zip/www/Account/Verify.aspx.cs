﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CodenameRabbitFoot.BusinessLogic;
using System.Collections.Specialized;

public partial class Account_Verify : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Web.IsMemberSession)
            txtEmail.Text = Web.SessionMembers.Email;

        if (Web.IsAction("Activate") && Request["sid"] != null)
        {
            Members member = new Members();
            member.Where.SurrogateID.Value = (Request["sid"]);
            member.Query.Load();

            if (member.MemberStatusID == 102)
            {
                txtEmail.Text = member.Email;
            }
            else if (member.MemberStatusID == 200)
                Web.Redirect("~/index.aspx");
        }
        if (Web.IsAction("Activate") && Request["code"] != null)
        {
            txtVerificationCode.Text = Request["code"].ToString();
        }
    }



    protected void sendActivationCode(object sender, EventArgs e)
    {

        Members member = new Members();

        if (Web.SessionMembers != null)
        {
            if (Web.SessionMembers.MemberID != null)
                member.LoadByPrimaryKey(Web.SessionMembers.MemberID);
        }
        else if (Request["sid"] != null)
        {
            member.Where.SurrogateID.Value = (Request["sid"]);
            member.Query.Load();
        }
        else
        {
            member.Where.Email.Value = txtEmail.Text;
            member.Query.Load();
        }

        var emails = new Emails();
        emails.Where.ToEmail.Value = member.Email;
        emails.Where.Subject.Value = "eOpen Email Verification, to continue your registration";
        emails.Where.EmailDate.Value = DateTime.Now.AddHours(-24);
        emails.Where.EmailDate.Operator = NCI.EasyObjects.WhereParameter.Operand.GreaterThanOrEqual;
        emails.Query.Load();
        if (emails.RowCount < 1)
        {
            member.RegistrationCode = Web.CalculateRegCode();
            member.Save();

            //mail to user
            StringDictionary templateKeys = new StringDictionary();
            templateKeys.Add("#site_url#", Web.SystemConfigs.GetKey("SITE_URL"));
            templateKeys.Add("#email_header#", Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER"));
            templateKeys.Add("#email_footer#", Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER"));
            templateKeys.Add("#email#", member.Email);
            templateKeys.Add("#username#", (!String.IsNullOrEmpty(member.FullName)) ? member.FullName : member.Email);
            templateKeys.Add("#activation_link#", Web.SystemConfigs.GetKey("SITE_URL") + "/Account/Verify.aspx?Action=Activate&code=" + member.RegistrationCode + "&RecordID=" + Secure.Encrypt(member.MemberID) + "&sid=" + member.SurrogateID);
            templateKeys.Add("#activationcode#", member.RegistrationCode);
            templateKeys.Add("#link_log_myeoffer#", Web.SystemConfigs.GetKey("SITE_URL"));
            templateKeys.Add("#fullname#", (!String.IsNullOrEmpty(member.FullName)) ? member.FullName : member.Email);

            Web.SendMail(member.Email, Web.SystemConfigs.GetKey("ACCOUNTS_EMAIL"), 16, templateKeys);

            //this.Master.ShowMessage("Email has been sent to you.");
            Web.Redirect("/Account/Verify.aspx?Action=Activate&RecordID=" + Secure.Encrypt(member.MemberID) + "&sid=" + member.SurrogateID);
        }

    }


    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            Members member = null;

            if (Web.IsMemberSession)
            {
                member = Web.SessionMembers;
            }
            else
            {
                member = new Members();
                member.Where.SurrogateID.Value = (Request["sid"]);
                member.Query.Load();
            }

            if (Members.VerifyRegistrationCode(member.UserName, txtVerificationCode.Text.Trim()))
            {
                Web.WriteMemberStatusChangeLog(member.MemberID, 200, "System");

                if (Web.SessionMembers != null)
                    Web.SessionMembers.MemberStatusID = 200;

                Web.SessionMembers = member;
                Web.Redirect("~/index.aspx");
            }
        }
        catch (Exception exp)
        {
            this.divErrorMessage.Visible = true;
            Web.LogError(exp);
            //throw exp;
        }
    }
}