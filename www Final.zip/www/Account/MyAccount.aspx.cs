﻿using System;
using System.Collections.Specialized;
using System.Web.UI.WebControls;
using CodenameRabbitFoot.BusinessLogic;

public partial class Account_MyAccount : System.Web.UI.Page
{

    //MasterPages_Public master = null;

    #region Properties
    public string EPageLink = "";
    private int requestsascustomer = 0;
    public int RequestsasCustomer
    {
        get { return requestsascustomer; }
        set { requestsascustomer = value; }
    }

    private int requestsassupplier = 0;
    public int RequestsasSupplier
    {
        get { return requestsassupplier; }
        set { requestsassupplier = value; }
    }

    private int messagesCount = 0;
    public int MessagesCount
    {
        get { return messagesCount; }
        set { messagesCount = value; }
    }
    #endregion

    protected void Page_Load(object sender, EventArgs e)
    {
        this.Master.HideLinkApps();
     
        Web.CheckSession("~/MyAccount/MyAccount.aspx");

        try
        {
            if (!IsPostBack)
            {
                LoadContactRequests();
                LoadSummary();
                Web.LogUserActivity(Radium.Platform.Core.UserActivity.View);
            }
            ucNewActivities.OwnerID = Web.SessionMembers.MemberID;
        }
        catch (Exception ex)
        {
            //Log.Write("Error", ex.GetBaseException().ToString(), ex);
            Web.LogError(ex);
        }
    }
    private void LoadContactRequests()
    {
        try
        {
            //rptContacts.DataSource = Invitations.GetInvitationsForMember(Web.SessionMembers.MemberID, Web.SessionMembers.Email);
            //rptContacts.DataBind();
            //if (rptContacts.Items.Count > 0)
            //{
            //    pnlcontactRequest.Visible = true;
            //}
            //else
            //{
            //    pnlcontactRequest.Visible = false;
            //}
        }
        catch (Exception ex)
        {
            //Log.Write("Error", ex.GetBaseException().ToString(), ex);
            Web.LogError(ex);
        }
    }
    private void LoadSummary()
    {
        try
        {
            //try
            //{
            //    DataSet ds = Members.GetNewActivities(Web.SessionMembers.MemberID);
            //    RequestsasCustomer = Convert.ToInt32(ds.Tables[0].Rows[0]["RequestsasSupplier"].ToString());
            //    RequestsasSupplier = Convert.ToInt32(ds.Tables[1].Rows[0]["RequestsasCustomer"].ToString());
            //    lblMessages.Text = ds.Tables[2].Rows[0]["MessagesCount"].ToString();
            //    lblOffersLots.Text = ds.Tables[3].Rows[0]["LotOffersCount"].ToString();
            //    lblOffersLotItems.Text = ds.Tables[4].Rows[0]["ItemOffersCount"].ToString();
            //    lblPendingContacts.Text = (RequestsasCustomer + RequestsasSupplier).ToString();
            //}
            //catch (Exception exp)
            //{
            //    Web.WriteLog("LoadSummary:", exp.GetBaseException().ToString(), exp);
            //}

            //lblQuestionsItems.Text = ItemQuestions.GetItemPendingQuestions(Web.SessionMembers.MemberID).ToString();
            //lblQuestionsLots.Text = LotQuestions.GetLotPendingQuestions(Web.SessionMembers.MemberID).ToString();
            //lblOffersItems.Text = ItemOffers.GetOffersCount(Web.SessionMembers.MemberID).ToString();
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }
    protected void lbtnViewPage_Click(object sender, EventArgs e)
    {
            Web.Redirect("~/Members/default.aspx?u=" + Web.SessionMembers.UserName);       
    }
    protected void btnContacts_OnCommand(object sender, CommandEventArgs e)
    {
        try
        {
            if (e.CommandArgument != null)
            {
                int InvitationID = Convert.ToInt32(e.CommandArgument);
                Invitations invitation = new Invitations();
                invitation.LoadByPrimaryKey(InvitationID);

                if (e.CommandName == "Accept")
                {
                    if (invitation.InvitationStatus == 0)
                    {
                        Contacts contact = Contacts.AcceptContactRequest(InvitationID, Web.SessionMembers.MemberID);

                        System.Collections.Specialized.StringDictionary templateKeys = new System.Collections.Specialized.StringDictionary();
                        MemberTrustScore.TrustMemberScore(contact.MemberID, Web.SessionMembers.MemberID, "Added as a " + Web.GetContactTypeInverse(contact.ContactType), ((contact.ContactType == 2) ? RatingTypes.Added_As_Client : RatingTypes.Added_As_Vendor), contact.ContactID);

                        Members member = new Members();
                        member.LoadByPrimaryKey(contact.MemberID);
                        templateKeys = new System.Collections.Specialized.StringDictionary();
                        templateKeys.Add("#type#", Web.GetContactType(contact.ContactType));
                        templateKeys.Add("#initiatedto#", "#memberid#" + Web.SessionMembers.MemberID + "#endmemberid#");
                        templateKeys.Add("#profileclass#", "#profileclass#" + Web.SessionMembers.MemberID + "#endprofileclass#");
                        templateKeys.Add("#initiatedtoprofile#", "/Contacts/ViewProfile.aspx?Action=ViewDealer&RecordID=#encrypt#" + Web.SessionMembers.MemberID + "#endencrypt#");

                        if (contact.ContactAccessibilityID == 1)
                            Web.AddActivityLog(contact.MemberID, 18, templateKeys, contact.ContactMemberID, contact.ContactMemberID);
                        else
                            Web.AddPrivateActivityLog(member.MemberID, 18, templateKeys, member.MemberID, contact.ContactMemberID, contact.ContactMemberID);
                        MemberTrustScore.TrustMemberScoreOne(Web.SessionMembers.MemberID, member.MemberID, "Added as a " + (ContactTypes)contact.ContactType, (RatingTypes)contact.ContactType, contact.ContactID);

                        templateKeys = new StringDictionary();
                        templateKeys.Add("#company_name#", Web.SessionMembers.CompanyName);
                        templateKeys.Add("#fullname#", member.FullName);
                        templateKeys.Add("#email_header#", Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER"));
                        templateKeys.Add("#email_footer#", Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER"));
                        templateKeys.Add("#contactnetwork#", Web.SystemConfigs.GetKey("SITE_URL") + "Contacts/Default.aspx");
                        templateKeys.Add("#livefeed#", Web.SystemConfigs.GetKey("SITE_URL") + "Live.aspx");
                        templateKeys.Add("#dealingfloor#", Web.SystemConfigs.GetKey("SITE_URL") + "MarketPlace/Default.aspx");
                        templateKeys.Add("#type#", Web.GetContactTypeInverse(contact.ContactType));
                        templateKeys.Add("#name_request_approver#", Web.SessionMembers.FullName);
                        templateKeys.Add("#company_request_approver#", Web.SessionMembers.CompanyName);
                        templateKeys.Add("#link_profile_name#", Web.SystemConfigs.GetKey("SITE_URL") + "Contacts/ViewProfile.aspx?Action=ViewDealer&RecordID=" + Secure.Encrypt(Web.SessionMembers.MemberID));
                        templateKeys.Add("#profile_name#", Web.SessionMembers.UserName);
                        Web.SendMail(member.Email, Web.SystemConfigs.GetKey("CONTACT_EMAIL"), 401, templateKeys);
                    }
                }
                else if (e.CommandName == "Ignore")
                {
                    if (invitation.InvitationStatus == 0)
                    {
                        invitation = Contacts.DeclineContactRequest(InvitationID, Web.SessionMembers.MemberID);

                        System.Collections.Specialized.StringDictionary templateKeys = new System.Collections.Specialized.StringDictionary();
                        Members member = new Members();
                        member.LoadByPrimaryKey(invitation.InvitedBy);
                        templateKeys.Add("#type#", Web.GetContactType(invitation.ContactType));
                        templateKeys.Add("#profile_name#", Web.SessionMembers.UserName);
                        templateKeys.Add("#company_name#", Web.SessionMembers.CompanyName + ": " + Web.SessionMembers.FullName);
                        templateKeys.Add("#fullname#", member.FullName);
                        templateKeys.Add("#email_header#", Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER"));
                        templateKeys.Add("#email_footer#", Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER"));
                        templateKeys.Add("#link_log_myeoffer#", Web.SystemConfigs.GetKey("SITE_URL"));
                        Web.SendMail(member.Email, Web.SystemConfigs.GetKey("CONTACT_EMAIL"), 402, templateKeys);
                        //this.Master.ShowMessage("You have declined <span style=\"" + Web.GetProfileClass(member.MemberID, Web.SessionMembers.MemberID) + "\">" + member.UserName + "</span> to be added to your Contacts");
                    }
                }
                LoadContactRequests();
            }
        }
        catch (Exception ex)
        {
            //Log.Write("Error", ex.GetBaseException().ToString(), ex);
            Web.LogError(ex);
        }
    }
    public static void AddActivityLog(int ActivityID, int ActivityOf, StringDictionary templateKeys)
    {
        try
        {
            Activities activity = new Activities();
            VisualSoft.SystemManagement.TemplateManager templateManager = new VisualSoft.SystemManagement.TemplateManager();

            activity.LoadByPrimaryKey(ActivityID);
            if (activity != null)
            {
                string parsedTemplate = templateManager.ParseTemplate(activity.s_Template, templateKeys);

                MemberActivityLog log = new MemberActivityLog();
                log.AddNew();
                log.MemberID = ActivityOf;
                log.ActivityDate = DateTime.Now;
                log.ActivityID = activity.ActivityID;
                log.Description = parsedTemplate;
                log.Save();

                Members member = new Members();
                member.LoadByPrimaryKey(ActivityOf);
                member.LastActivityDate = DateTime.Now;
                member.Save();
            }
        }
        catch (Exception ex)
        {
            //Log.Write("AddActivityLog", ex.GetBaseException().ToString(), ex);
            Web.LogError(ex);
        }
    }
}