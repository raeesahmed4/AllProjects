﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Services;
using CodenameRabbitFoot.BusinessLogic;

public partial class Account_Register : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.QueryString["InvitationID"] != null && Request.QueryString["Type"] != null)
        {
            int invitaionID = 0;

            try
            {
                if (!int.TryParse(Request.QueryString["InvitationID"], out invitaionID))
                {
                    invitaionID = Convert.ToInt32(Secure.Decrypt(Request.QueryString["InvitationID"]));
                }


                Invitations invitaion = new Invitations();
                invitaion.LoadByPrimaryKey(invitaionID);
                if (invitaion.RowCount > 0)
                {
                    this.UserRegistration1.Email = invitaion.InvitationToEmail;
                    string[] names = invitaion.InvitationToName.Split(' ');
                    this.UserRegistration1.FirstName = names[0];
                    if (names[1] != null)
                        this.UserRegistration1.LastName = names[1];

                    this.UserRegistration1.IsEmailReadOnly = true;
                }
            }
            catch (Exception exp)
            {
                Web.LogError(exp);
            }
        }
    }

    [WebMethod]
    public static string LoadContactEmail(string sid)
    {
        Members members = new Members();
        members.Where.SurrogateID.Value = sid;
        members.Query.Load();

        return members.Email;
    }
}