﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using CodenameRabbitFoot.BusinessLogic;
using System.IO;
using Telerik.Web.UI;
using System.Drawing;
using System.Drawing.Imaging;

public partial class Account_UpdatePublicProfile : System.Web.UI.Page
{
   
    protected void Page_Load(object sender, EventArgs e)
    {
        Web.CheckSession();
        if (!Web.IsMemberSession)
            return;

        //handleBillBoardDisplay();




        this.Master.HideLinkApps();
        
        if (!IsPostBack)
        {
            txtQRCode.Text = Web.SessionMembers.s_MemberLiveBanner;

            if (Request.QueryString["Action"] == "imagechange")
            {
                string javascript = "javascript: selectTab('tabs-2') ";
                Page.ClientScript.RegisterStartupScript(GetType(), "Javascript", javascript, true);
            }
            else if (Request.QueryString["Action"] == "BillBoard")
            {
                string javascript = "javascript: selectTab('tabs-6') ";
                Page.ClientScript.RegisterStartupScript(GetType(), "Javascript", javascript, true);
            }
            else if (Request.QueryString["Action"] == "QRCode")
            {
                string javascript = "javascript: selectTab('tabs-7') ";
                Page.ClientScript.RegisterStartupScript(GetType(), "Javascript", javascript, true);
            }
            else if (Request.QueryString["Action"] == "ContactDetails")
            {
                string javascript = "javascript: selectTab('tabs-3') ";
                Page.ClientScript.RegisterStartupScript(GetType(), "Javascript", javascript, true);
            }
            else if (Request.QueryString["Action"] == "ActivatedBillBoard")
            {
                string javascript = "javascript: selectTab('tabs-6') ";
                Page.ClientScript.RegisterStartupScript(GetType(), "Javascript", javascript, true);
            }
            else if (Request.QueryString["Action"] == "Privacy")
            {
                string javascript = "javascript: selectTab('tabs-4') ";
                Page.ClientScript.RegisterStartupScript(GetType(), "Javascript", javascript, true);
            }
            else if (Request.QueryString["Action"] == "MyCat")
            {
                string javascript = "javascript: selectTab('tabs-5') ";
                Page.ClientScript.RegisterStartupScript(GetType(), "Javascript", javascript, true);
            }
            else if (Request.QueryString["Action"] == "ContactInfo")
            {
                string javascript = "javascript: selectTab('tabs-1') ";
                Page.ClientScript.RegisterStartupScript(GetType(), "Javascript", javascript, true);
            }
        }

        //this.Master.ShowMessageBox = false;
        // this.Master.ShowHeader = true;
        // this.Master.ShowPageLine = true;
        // this.Master.HeadingIcon = "~/Images/PageIcons/SignUp.png";
        //this.Master.PageHeading = "My Exhibit";
        //----------------if redirect from offer page to complete profile

        //if (Request["redirectFrom"] != null)
        //{
        //    this.redirect2Item.Visible = true;
        //    this.hypLnkItems.NavigateUrl = "~/MarketPlace/ItemDetails.aspx?Action=View&RecordID=" + Request["RecordID"].ToString() + "";
        //}

        if (Web.IsMemberSession == false)
            Web.Redirect("~/index.aspx?ReturnUrl=~/MyAccount/UpdatePublicProfile.aspx" + Request.Url.Query);
        else
        {
            string action = "";
            if (Request["Action"] != null)
                action = Request["Action"];

            if (action.ToLower() == "address")
            {
                //TabStrip.SelectedIndex = 4;
                //multiViewProfile.SelectedIndex = 2;
            }
            else
            {
                //TabStrip.SelectedIndex = 0;
                //multiViewProfile.SelectedIndex = 0;
            }

            if (!IsPostBack)
            {
                LoadData();

                Web.LogUserActivity(Radium.Platform.Core.UserActivity.View);
            }

            if (Request.QueryString["tab"] != null)
            {
                if (Request.QueryString["tab"] == "Categories")
                {
                    //TabStrip.SelectedIndex = 8;
                    // multiViewProfile.SelectedIndex = 4;
                }
                else
                {
                    // TabStrip.SelectedIndex = 4;
                    // multiViewProfile.SelectedIndex = 2;
                }
            }
        }

    }

    private void LoadData()
    {
        string action = "";
        if (Request["Action"] != null)
            action = Request["Action"];

        if (action.ToLower() == "address")
        {
            //TabStrip.SelectedIndex = 4;
        }
        try
        {
            ddlCountry.Items.Clear();
            ddlCountry.DataSource = CodenameRabbitFoot.BusinessLogic.Country.GetCountries();
            ddlCountry.DataValueField = "CountryID";
            ddlCountry.DataTextField = "CountryName";
            ddlCountry.DataBind();
            ddlCountry.SelectedValue = "91";
        }
        catch (Exception ex) { Web.LogError(ex); }

        //Load Basic Info
        //try
        //{
        //    txtboxEmail.Text = Web.SessionMembers.Email;
        //    txtWebsite.Text = Web.SessionMembers.Website;
        //    txtCompanyName.Text = Web.SessionMembers.CompanyName;
        //    txtTwitter.Text = Web.SessionMembers.Twitter;
        //    txtFacebook.Text = Web.SessionMembers.Facebook;
        //    txtBrandspecializein.Text = Web.SessionMembers.MemberBrandNames;
        //    txtLiveBillboard.Text = MemberActivityLog.LoadBillboardDescription(Web.SessionMembers.MemberID);
        //    txtServiceDescription.Text = Web.SessionMembers.MemberServiceDescription;
        //    string[] str = Web.SessionMembers.FullName.Split(' ');
        //    txtFirstName.Text = str[0];
        //    txtLastName.Text = "";
        //    for (int i = 1; i < str.Length; i++)
        //    {
        //        if (txtLastName.Text.Length == 0)
        //            txtLastName.Text = str[i];
        //        else
        //            txtLastName.Text += " " + str[i];
        //    }
        //}
        //catch (Exception ex) { Web.LogError(ex); }

        //Load Contact Info
        //try
        //{
        //    if (Web.SessionMembers.shippingAddress != null)
        //    {
        //        txtAddress1.Text = Web.SessionMembers.shippingAddress.Address1;
        //        txtAddress2.Text = Web.SessionMembers.shippingAddress.Address2;
        //        txtFaxNo.Text = Web.SessionMembers.shippingAddress.Fax;
        //        txtState.Text = Web.SessionMembers.shippingAddress.State;
        //        txtCity.Text = Web.SessionMembers.shippingAddress.City;
        //        txtPhone.Text = Web.SessionMembers.shippingAddress.Phone;
        //        txtCellPhone.Text = Web.SessionMembers.shippingAddress.CellNumber;
        //        ddlCountry.SelectedValue = Web.SessionMembers.shippingAddress.s_CountryID;
        //        txtPostalCode.Text = Web.SessionMembers.shippingAddress.Zip;
        //    }
        //    //Load IM Screen Names
        //    txtAIM.Text = Web.SessionMembers.AIM;
        //    txtYahoo.Text = Web.SessionMembers.Yahoo;
        //    txtMSN.Text = Web.SessionMembers.MSN;
        //    txtSkype.Text = Web.SessionMembers.Skype;

        //}
        //catch (Exception ex) { Web.LogError(ex); }

        //Load Privacy Settings
        try
        {
            rdbProfilepublic.SelectedValue = Web.SessionMembers.s_IsPrivate;
            chkShareInfo.Items.Clear();
            PrivacySettings privacyseting = new PrivacySettings();
            privacyseting.Where.IsActive.Value = 1;
            privacyseting.Query.Load();
            do
            {
                ListItem item = new ListItem();
                item.Text = privacyseting.PrivacyName;
                item.Value = privacyseting.s_PrivacyID;
                if (privacyseting.PrivacyID == 1 || privacyseting.PrivacyID == 4 || privacyseting.PrivacyID == 5 || privacyseting.PrivacyID == 6 || privacyseting.PrivacyID == 7 || privacyseting.PrivacyID == 10)
                    item.Selected = true;

                chkShareInfo.Items.Add(item);
            } while (privacyseting.MoveNext());
            chkShareInfo.DataBind();

            foreach (ListItem item in chkShareInfo.Items)
            {
                MemberPrivacySetting memprivcysetting = new MemberPrivacySetting();
                memprivcysetting.Where.PrivacyID.Value = Convert.ToInt32(item.Value);
                memprivcysetting.Where.MemberID.Value = Web.SessionMembers.MemberID;
                memprivcysetting.Query.Load();
                if (memprivcysetting.RowCount > 0)
                {
                    if (memprivcysetting.s_IsPrivate == "0")
                        item.Selected = true;
                    else
                        item.Selected = false;
                }
                else
                    item.Selected = false;

                //--------------------
                //if (item.Text == "Zip Code")
                //    item.Selected = true;
            }
        }
        catch (Exception ex) { Web.LogError(ex); }

        //Load Categories
        try
        {
            buildSpecializedTree(null);
            PopulatetreeviewFavoriteCategories();
            //treeviewBuyerSpecialize.Nodes.Clear();
            //treeviewSellerSpecialize.Nodes.Clear();
            //buildSpecializedTree(null, 0, 1);
            //buildSpecializedTree(null, 0, 2);
            //PopulatetreeviewSellerSpecialize();
            //PopulatetreeviewBuyerSpecialize();
        }
        catch (Exception ex) { Web.LogError(ex); }
    }

    protected void btnCheckAvailability_Click(object sender, EventArgs e)
    {
        if (CheckAvailability(txtboxEmail.Text))
        {
            imgavailability.Visible = true;
            imgavailability.ImageUrl = "~/Images/activate32.gif";
            imgavailability.ToolTip = "Available";
        }
        else
        {
            imgavailability.Visible = true;
            imgavailability.ImageUrl = "~/Images/reject.png";
            imgavailability.ToolTip = "Not Available";
        }
    }

    private bool CheckAvailability(string Email)
    {
        bool result = false;
        try
        {
            if (!String.IsNullOrEmpty(Email))
            {
                var member = new Members();
                member.Query.AddResultColumn(MembersSchema.Email);
                member.Query.AddResultColumn(MembersSchema.MemberID);
                member.Where.Email.Value = Email;
                member.Where.MemberID.Value = Web.SessionMembers.MemberID;
                member.Where.MemberID.Operator = NCI.EasyObjects.WhereParameter.Operand.NotEqual;
                if (member.Query.Load())
                    result = false;
                else
                    result = true;
            }
        }
        catch (Exception exp)
        {
            Web.LogError(exp);
        }
        return result;
    }


    System.Collections.Specialized.StringDictionary templateKeys;
    bool done;
    Members member;
    bool isUpdatingAgainInDefinedTime ;
    ShippingAddresses address;
    string command;
    bool redirect;
    private void preSaveTasks(string eCommandName)
    {
        templateKeys = new System.Collections.Specialized.StringDictionary();
        done = false;
        member = new Members();
        member.LoadByPrimaryKey(Web.SessionMembers.MemberID);

        //check if profile is already updated in same day then dont add activity log else ok                
        isUpdatingAgainInDefinedTime = false;
        if (member.LastProfileUpdate.Date == DateTime.Now.Date)
            isUpdatingAgainInDefinedTime = true;

        member.LastProfileUpdate = DateTime.Now;
        member.AccountExpiry = DateTime.Now.AddYears(1);
        member.MemberStatusID = (member.MemberStatusID < 200) ? 200 : member.MemberStatusID;

         address = new ShippingAddresses();
        address.Where.MemberID.Value = Web.SessionMembers.MemberID;
        address.Query.Load();

         command = (eCommandName.Contains("Redirect")) ? eCommandName.Substring(0, eCommandName.Length - 8) : eCommandName;
         redirect = (eCommandName.Contains("Redirect")) ? true : false;
    }

    private void postSaveTasks()
    {
        if (done)
        {
            member.Save();
            Web.SessionMembers = member;
            Web.SessionMembers.shippingAddress = address;
            //LoadData();
            
            templateKeys = new System.Collections.Specialized.StringDictionary();
            try
            {
                // Update of information Email
                templateKeys.Add("#email_header#", Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER"));
                templateKeys.Add("#fullname#", Web.SessionMembers.FullName);
                templateKeys.Add("#link_contact_us#", Web.SystemConfigs.GetKey("SITE_URL") + "ContactUs.aspx");
                templateKeys.Add("#link_report_account_compromised#", Web.SystemConfigs.GetKey("SITE_URL") + "MyAccount/Verify.aspx?Action=View&RecordID=" + Secure.Encrypt(Web.SessionMembers.MemberID));
                templateKeys.Add("#link_log_myeoffer#", Web.SystemConfigs.GetKey("SITE_URL"));
                templateKeys.Add("#email_footer#", Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER"));
                Web.SendMail(Web.SessionMembers.Email, Web.SystemConfigs.GetKey("ACCOUNTS_EMAIL"), 7, templateKeys);
            }
            catch (Exception ex)
            {
                Web.WriteLog("Email Error", ex.GetBaseException().ToString(), ex);
            }

            templateKeys = new System.Collections.Specialized.StringDictionary();

            //dont add log if updating again in defined period
            if (!isUpdatingAgainInDefinedTime)
                Web.AddPrivateActivityLog(8, templateKeys, Web.SessionMembers.MemberID);

            if (Request.QueryString["ReturnUrl"] != null)
            {
                string url = Request.Url.ToString();
                url = url.Substring(url.IndexOf("ReturnUrl=") + 10);
                Web.Redirect(url);
            }
            else
            {
                if (!redirect)
                {
                    //this.Master.ShowMessage("Profile Updated Successfully.");
                }
                else
                    Web.Redirect("~/Contacts/ViewProfile.aspx?Action=ViewDealer&RecordID=" + Secure.Encrypt(Web.SessionMembers.MemberID));
            }
        }
    }

    protected void lnkSave_Command(object sender, CommandEventArgs e)
    {
        try
        {
            preSaveTasks(e.CommandName);

            switch (command)
            {
                case "BasicInfo":
                    {
                        if (CheckAvailability(txtboxEmailHidden.Value))
                        {
                            member.Email = txtboxEmailHidden.Value;
                            member.CompanyName = txtCompanyName.Text;
                            member.FullName = txtFirstName.Text + " " + txtLastName.Text;
                            member.Website = txtWebsite.Text;
                            member.IsDealerProfileUpdate = 1;
                            member.MemberServiceDescription = txtServiceDescription.Text;
                            member.MemberBrandNames = txtBrandspecializein.Text;
                            member.Twitter = txtTwitter.Text;
                            member.Facebook = txtFacebook.Text;

                            done = true;

                        }

                        this.Master.ShowMessage("Your Profile has been updated Successfully", "Profile Update");
                        string javascript = "javascript: selectTab('tabs-1') ";

                        Page.ClientScript.RegisterStartupScript(GetType(), "Javascript", javascript, true);

                        //  else
                        // this.Master.ShowMessage("Email already exists.");

                        break;
                    }
                case "Billboard":
                    {
                        /*if (!String.IsNullOrEmpty(txtLiveBillboard.Text))
                        {
                            MemberActivityLog.UpdateBillboard(Web.SessionMembers.MemberID, txtLiveBillboard.Text);

                            done = true;
                            //this.Master.ShowMessage("Your Profile has been updated Successfully", "Profile Update");
                        }

                        Web.Redirect("~/live.aspx");
                        */

                        // else
                        // this.Master.ShowMessage("could not update your billboard.");

                        // string javascript = "javascript: selectTab('tabs-6') ";

                        // Page.ClientScript.RegisterStartupScript(GetType(), "Javascript", javascript, true);

                        break;
                    }
                
                case "QRCode":
                    {
                        if (!String.IsNullOrEmpty(txtQRCode.Text))
                        {
                            string oldQRImageID = member.s_QRImageID;

                            member.MemberLiveBanner = txtQRCode.Text;
                            member.QRImageID = Guid.NewGuid();
                            Web.SessionMembers.MemberLiveBanner = txtQRCode.Text;

                            string folderName = Web.SystemConfigs.GetKey("ATTACHMENTS_PHYSICAL_PATH") + "/QRCode";
                            string fileName = Path.Combine(folderName, member.s_QRImageID + ".jpg");

                            try
                            {
                                if (member.s_MemberLiveBanner != "")
                                    QRCode.EncodeQRCode(member.MemberLiveBanner, null, Color.White, Color.Black).Save(fileName, ImageFormat.Jpeg);
                                else if (member.s_FullName != "")
                                    QRCode.EncodeQRCode(member.FullName, null, Color.White, Color.Black).Save(fileName, ImageFormat.Jpeg);
                            }
                            catch (Exception exx)
                            {
                                Web.LogError(exx);
                            }

                            //delete old QRImageID
                            try
                            {
                                File.Delete(Path.Combine(folderName, oldQRImageID + ".jpg"));
                            }
                            catch { }

                            done = true;
                            Web.Redirect("~/live.aspx");
                            //this.Master.ShowMessage("Your Profile has been updated Successfully", "Profile Update");
                        }

                        break;
                    }
                case "ProfilePicture":
                    {
                        if (fupLogo.UploadedFiles.Count > 0)
                        {
                            foreach (UploadedFile file in fupLogo.UploadedFiles)
                            {
                                System.Drawing.Image img = System.Drawing.Image.FromStream(fupLogo.UploadedFiles[0].InputStream);
                                if (img.Width < 100 || img.Height < 100)
                                    this.Master.ShowMessage("Image size must be greater than 100x100.", "Profile Update");
                                else
                                {
                                    img.Dispose();

                                    string imageName = Web.SessionMembers.MemberID + "_" + Guid.NewGuid().ToString("N");

                                    // update the Memberslogo
                                    var memberslogo = new MembersLogo();
                                    memberslogo.LoadByPrimaryKey(Web.SessionMembers.MemberID);
                                    if (memberslogo.RowCount > 0)
                                    {
                                        memberslogo.MarkAsDeleted();
                                        memberslogo.Save();
                                    }

                                    memberslogo.AddNew();
                                    memberslogo.MemberID = Web.SessionMembers.MemberID;
                                    memberslogo.LogoGUID = imageName;
                                    memberslogo.LastUpdate = DateTime.Now;
                                    memberslogo.IP = Request.ServerVariables["Remote_Addr"].ToString();
                                    memberslogo.Save();


                                    //save the file in real location without changing dimensions
                                    string realFolder = Web.SystemConfigs.GetKey("ATTACHMENTS_PHYSICAL_PATH") + "/Members/Logo/real";
                                    string realPath = Path.Combine(realFolder, imageName + ".jpg");

                                    if (File.Exists(realPath))
                                        File.Delete(realPath);

                                    file.SaveAs(realPath, true);

                                    //Create the thumbnail from the real uploaded file
                                    System.Drawing.Image logoImage = System.Drawing.Image.FromFile(realPath);
                                    string logoFolder = Web.SystemConfigs.GetKey("ATTACHMENTS_PHYSICAL_PATH") + "/Members/Logo/";
                                    string logoPath = Path.Combine(logoFolder, imageName + ".jpg");
                                    Web.CreateThumbnail(logoImage, 120, 120).Save(logoPath);

                                    //img.Dispose();
                                    //save the thumbnail
                                    System.Drawing.Image thImage = System.Drawing.Image.FromFile(realPath);
                                    string thFolder = Web.SystemConfigs.GetKey("ATTACHMENTS_PHYSICAL_PATH") + "/Members/Logo/thumbnail";
                                    string thPath = Path.Combine(thFolder, imageName + ".jpg");
                                    Web.CreateThumbnail(thImage, 50, 50).Save(thPath);



                                }
                            }
                            this.Master.ShowMessage("Your Profile has been updated Successfully", "Profile Update");
                        }
                        //  else
                        //  this.Master.ShowMessage("Please select an image to upload.");

                        // TabStrip.SelectedIndex = 2;
                        //  multiViewProfile.SelectedIndex = 1;

                        string javascript = "javascript: selectTab('tabs-2') ";

                        Page.ClientScript.RegisterStartupScript(GetType(), "Javascript", javascript, true);

                        break;
                    }
                case "ContactInfo":
                    {
                        member.IsDealerProfileUpdate = 1;
                        if (address.RowCount > 0)
                        {
                            address.s_Address1 = txtAddress1.Text;
                            address.s_Address2 = txtAddress2.Text;
                            address.s_CellNumber = txtCellPhone.Text;
                            address.s_City = txtCity.Text;
                            address.s_CountryID = ddlCountry.SelectedValue;
                            address.s_Fax = txtFaxNo.Text;
                            address.s_Phone = txtPhone.Text;
                            address.s_State = txtState.Text;
                            address.s_Zip = txtPostalCode.Text;
                            address.Save();
                        }
                        else
                        {
                            address.AddNew();
                            address.s_Address1 = txtAddress1.Text;
                            address.s_Address2 = txtAddress1.Text;
                            address.s_CellNumber = txtCellPhone.Text;
                            address.s_City = txtCity.Text;
                            address.s_CountryID = ddlCountry.SelectedValue;
                            address.s_Fax = txtFaxNo.Text;
                            address.s_Phone = txtPhone.Text;
                            address.s_State = txtState.Text;
                            address.s_Zip = txtPostalCode.Text;
                            address.MemberID = Web.SessionMembers.MemberID;
                            address.Save();
                        }
                        Web.SessionMembers.shippingAddress = address;

                        //Update IM Screen Names
                        member.AIM = txtAIM.Text;
                        member.Yahoo = txtYahoo.Text;
                        member.MSN = txtMSN.Text;
                        member.Skype = txtSkype.Text;

                        done = true;
                        this.Master.ShowMessage("Your Profile has been updated Successfully", "Profile Update");

                        //  TabStrip.SelectedIndex = 4;
                        // multiViewProfile.SelectedIndex = 2;

                        string javascript = "javascript: selectTab('tabs-3') ";

                        Page.ClientScript.RegisterStartupScript(GetType(), "Javascript", javascript, true);

                        break;
                    }
                case "PrivacySettings":
                    {
                        member.s_IsPrivate = rdbProfilepublic.SelectedValue;
                        var memberprivacysetting = new MemberPrivacySetting();
                        foreach (ListItem item in chkShareInfo.Items)
                        {
                            memberprivacysetting = new MemberPrivacySetting();
                            memberprivacysetting.Where.MemberID.Value = Web.SessionMembers.MemberID;
                            memberprivacysetting.Where.PrivacyID.Value = item.Value;
                            memberprivacysetting.Query.Load();
                            if (memberprivacysetting.RowCount > 0)
                            {
                                if (item.Selected == true)
                                    memberprivacysetting.IsPrivate = 0;
                                else
                                    memberprivacysetting.IsPrivate = 1;
                            }
                            else
                            {
                                memberprivacysetting.AddNew();
                                memberprivacysetting.MemberID = member.MemberID;
                                memberprivacysetting.PrivacyID = Convert.ToInt32(item.Value);

                                if (item.Selected == true)
                                    memberprivacysetting.IsPrivate = 0;
                                else
                                    memberprivacysetting.IsPrivate = 1;
                            }
                            memberprivacysetting.Save();

                        }
                        done = true;
                        this.Master.ShowMessage("Your Profile has been updated Successfully", "Profile Update");
                        string javascript = "javascript: selectTab('tabs-4') ";
                        Page.ClientScript.RegisterStartupScript(GetType(), "Javascript", javascript, true);
                        break;
                    }
                case "Categories":
                    {
                        if (IsCategorySelected())
                        {
                            int status = Members.DeleteMemberSpecializedCategories(Web.SessionMembers.MemberID);
                            MemberCategories membercategory = new MemberCategories();

                            foreach (ListItem chk in ChkCategories.Items)
                            {
                                if (chk.Selected == true)
                                {
                                    membercategory.AddNew();
                                    membercategory.MemberID = member.MemberID;
                                    membercategory.CategoryID = Convert.ToInt32(chk.Value);
                                    membercategory.CategoryType = 0;
                                    membercategory.Save();
                                }
                            }
                        }
                        done = true;
                        this.Master.ShowMessage("Your Profile has been updated Successfully", "Profile Update");

                        string javascript = "javascript: selectTab('tabs-5') ";
                        Page.ClientScript.RegisterStartupScript(GetType(), "Javascript", javascript, true);
                        //TabStrip.SelectedIndex = 6;
                        //multiViewProfile.SelectedIndex = 4;
                        break;
                    }
            }

            postSaveTasks();
        } 
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }

    private bool IsCategorySelected()
    {
        bool result = false;
        try
        {
            //foreach (TreeNode node in treeviewCategories.CheckedNodes)
            //{

            //    if (node.Checked == true)
            //    {
            //        result = true;
            //        break;
            //    }
            //}

            //foreach (TreeNode node in treeviewSellerSpecialize.CheckedNodes)
            //{

            //    if (node.Checked == true)
            //    {
            //        result = true;
            //        break;
            //    }
            //}

            //if (!result)
            //{
            //    foreach (TreeNode node in treeviewBuyerSpecialize.CheckedNodes)
            //    {

            //        if (node.Checked == true)
            //        {
            //            result = true;
            //            break;
            //        }
            //    }
            //}
        }
        catch (Exception ex)
        {
            Web.WriteLog("Error", ex.GetBaseException().ToString(), ex);
        }
        return true;
    }

    public void buildSpecializedTree(TreeNode n)
    {
        try
        {
            DataTable resultData = CodenameRabbitFoot.BusinessLogic.Categories.GetCategories(1);

            ChkCategories.DataSource = resultData.DefaultView;
            ChkCategories.DataTextField = "CategoryName";
            ChkCategories.DataValueField = "CategoryID";
            ChkCategories.DataBind();

            ////Bind First tree
            //foreach (DataRow row in resultData.Rows)
            //{
            //    TreeNode node = new TreeNode(row["CategoryName"].ToString(), row["CategoryID"].ToString());
            //    node.SelectAction = TreeNodeSelectAction.Expand;

            //    if (n == null)
            //        treeviewCategories.Nodes.Add(node);
            //    else
            //        n.ChildNodes.Add(node);

            //}

            //treeviewCategories.Attributes.Add("onclick", "OnTreeClick(event)");

        }
        catch (Exception exp)
        {
            Web.LogError(exp);

        }
    }

    private void PopulatetreeviewFavoriteCategories()
    {
        try
        {
            DataTable result = MemberCategories.GetMemberFavoriteCategories(Web.SessionMembers.MemberID);
            if (result.Rows.Count > 0)
            {

                foreach (ListItem chk in ChkCategories.Items)
                {
                    foreach (DataRow row in result.Rows)
                    {
                        if (chk.Value == row["CategoryID"].ToString())
                            chk.Selected = true;
                    }
                }
            }

        }
        catch (Exception exp)
        {
            Web.LogError(exp);
        }
    }

    protected bool hasimage()
    {
        bool result = false;
        try
        {
            MembersLogo memberlogo = new MembersLogo();
            memberlogo.LoadByPrimaryKey(Web.SessionMembers.MemberID);
            if (memberlogo.RowCount > 0)
                result = true;
        }
        catch (Exception exp)
        {
            Web.LogError(exp);
        }
        return result;
    }

    protected void btnEnableBillBoard_Click(object sender, EventArgs e)
    {
        try
        {
            MembersModuleSubscriptions mms = new MembersModuleSubscriptions();
            mms.AddNew();
            mms.ModuleID = 10;
            mms.MemberID = Web.SessionMembers.MemberID;
            mms.Save();
            Web.Redirect("~/Account/UpdatePublicProfile.aspx?Action=ActivatedBillBoard");
        } 
        catch (Exception ex)
        {
            Web.LogError(ex);
        }

    }


    void handleBillBoardDisplay()
    {
        //check if the user is subscribed for billboard

        //if (Web.IsMemberSession)
        //{

        //    MembersModuleSubscriptions mms = new MembersModuleSubscriptions();
        //    mms.Where.MemberID.Value = Web.SessionMembers.MemberID;
        //    mms.Where.ModuleID.Conjunction = NCI.EasyObjects.WhereParameter.Conj.And;
        //    mms.Where.ModuleID.Value = 10;
        //    mms.Query.Load();

        //    if (mms.RowCount > 0)
        //    {
        //        // litBillBoard.Visible = true;

        //        pnlEnableBillBoard.Visible = false;
        //        Billboardshow.Visible = true;

        //        DataTable billBoard = MemberActivityLog.LoadBillboard(Web.SessionMembers.MemberID);
        //        if (billBoard.Rows.Count > 0)
        //            litBillBoardText.Text = billBoard.Rows[0]["Description"].ToString();
        //    }
        //    else
        //    {
        //        pnlEnableBillBoard.Visible = true;
        //    }
        //}
    }
}