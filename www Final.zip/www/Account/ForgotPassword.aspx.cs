﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CodenameRabbitFoot.BusinessLogic;
using System.Collections.Specialized;
using VisualSoft.VSharp.Utils;

public partial class Account_Forgot_Password : System.Web.UI.Page
{
    public bool ShowCaptcha = true;
    protected void Page_Load(object sender, EventArgs e)
    {
        txtEmail.Focus();
    }
    protected void radio_CheckedChanged(object sender, EventArgs e)
    {
        pnlZipCode.Visible = rdoFP.Checked;
    }
     
    protected void btnRetrieve_Click(object sender, EventArgs e)
    {
        try
        {
            if (Request["Action"] != null)
            {
                string Action = Request["Action"].ToString();
                var findmember = new Members();
                findmember.Where.Email.Value = txtEmail.Text;
                findmember.Query.Load();
                if (findmember.RowCount > 0)
                {
                    var memberDetail = Members.GetMemberByEmail(txtEmail.Text);

                    var address = new ShippingAddresses();
                    if (rdoFP.Checked)
                        address.Where.Zip.Value = txtZipCode.Text;
                    address.Where.MemberID.Value = findmember.MemberID;
                    address.Query.Load();
                    if (rdoFP.Checked == false && address.RowCount == 0)
                    {
                        Members member = new Members();
                        member.LoadByPrimaryKey(memberDetail.MemberID);
                        var emails = new Emails();
                        emails.Where.ToEmail.Value = member.Email;
                        emails.Where.Subject.Value = "eOpen Email Verification, to continue your registration";
                        //emails.Where.EmailDate.Value = DateTime.Now.AddHours(-24);
                        emails.Where.EmailDate.Operator = NCI.EasyObjects.WhereParameter.Operand.GreaterThanOrEqual;
                        emails.Query.Load();
                        if (emails.RowCount < 1)
                        {
                            member.RegistrationCode = Web.CalculateRegCode();
                            member.Save();

                            //mail to user
                            StringDictionary templateKeys = new StringDictionary();
                            templateKeys.Add("#site_url#", Web.SystemConfigs.GetKey("SITE_URL"));
                            templateKeys.Add("#email_header#", Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER"));
                            templateKeys.Add("#email_footer#", Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER"));
                            templateKeys.Add("#email#", member.Email);
                            templateKeys.Add("#username#", (!String.IsNullOrEmpty(memberDetail.FullName)) ? memberDetail.FullName : memberDetail.Email);
                            templateKeys.Add("#activation_link#", Web.SystemConfigs.GetKey("SITE_URL") + "Account/Verify.aspx?action=Activate&code=" + member.RegistrationCode + "&RecordID=" + Secure.Encrypt(member.MemberID) + "&sid=" + member.SurrogateID);
                            templateKeys.Add("#activationcode#", member.RegistrationCode);
                            templateKeys.Add("#link_log_myeoffer#", Web.SystemConfigs.GetKey("SITE_URL"));
                            templateKeys.Add("#fullname#", (!String.IsNullOrEmpty(memberDetail.FullName)) ? memberDetail.FullName : memberDetail.Email);

                            Web.SendMail(memberDetail.Email, Web.SystemConfigs.GetKey("ACCOUNTS_EMAIL"), 16, templateKeys);
                            Web.Redirect("~/Account/Verify.aspx?RecordID=" + Secure.Encrypt(member.MemberID) + "&sid=" + member.SurrogateID);
                        }
                        //on QA Demanad
                        //2012-06-12 14:27
                        //A user should be able to request as many activation codes to be resent to his email as he wants.
                        //else
                        //{
                        //    lblError.Text = "You can not retrieve activation code again in 24 hours.";
                        //    divError.Visible = true;
                        //    // this.Master.ShowMessage("We are very sorry, we cannot resend the activation code before 24 hours."); 
                        //}
                    }
                    else if (rdoActCode.Checked && address.RowCount > 0)
                    {

                        if (this.txtCaptchaValue1.Text.ToLower() == this.Session["CaptchaImageText"].ToString().ToLower())
                        {
                            if (Page.IsValid)
                            {
                                //this.Master.ShowMessageBox = false;
                                if (Action == "ForgotPwd")
                                {
                                    if (memberDetail.MemberStatusID >= 200)
                                    {
                                        var emails = new Emails();
                                        emails.Where.ToEmail.Value = memberDetail.Email;
                                        emails.Where.Subject.Value = "eOpen: Your request to retrieve your lost password";
                                        emails.Where.EmailDate.Value = DateTime.Now.AddHours(-24);
                                        emails.Where.EmailDate.Operator = NCI.EasyObjects.WhereParameter.Operand.GreaterThanOrEqual;
                                        emails.Query.Load();
                                        if (emails.RowCount < 1)
                                        {
                                            //mail to user
                                            StringDictionary templateKeys = new StringDictionary();
                                            templateKeys.Add("#site_url#", Web.SystemConfigs.GetKey("SITE_URL"));
                                            templateKeys.Add("#email_header#", Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER"));
                                            templateKeys.Add("#email_footer#", Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER"));
                                            templateKeys.Add("#link_confirm_lostpassword#", Web.SystemConfigs.GetKey("SITE_URL") + "Default.aspx");
                                            templateKeys.Add("#link_report_account_compromised#", Web.SystemConfigs.GetKey("SITE_URL") + "MyAccount/AccountVerification.aspx?Action=View&RecordID=" + Secure.Encrypt(memberDetail.MemberID));
                                            templateKeys.Add("#link_log_myeoffer#", Web.SystemConfigs.GetKey("SITE_URL"));
                                            templateKeys.Add("#fullname#", memberDetail.FullName);
                                            templateKeys.Add("#password#", memberDetail.Password);
                                            Web.SendMail(memberDetail.Email, Web.SystemConfigs.GetKey("ACCOUNTS_EMAIL"), 006, templateKeys);
                                            //mail to user
                                            //master.ShowMessage("Password has been sent to your email address.If you did not get the email, please check your Bulk or Spam folder, it may accidently has been filed there ", "info");

                                            if (HttpContext.Current.Request.QueryString["ReturnUrl"] != null)
                                            {

                                                string url = HttpContext.Current.Request.Url.ToString();
                                                url = url.Substring(url.IndexOf("ReturnUrl=") + 10);
                                                Web.Redirect(url + "?Action=mailsent");
                                            }
                                            else
                                            {
                                                ClientScript.RegisterStartupScript(Page.GetType(), "redirestto", "redirect()", true);
                                            }
                                        }
                                        else
                                        {
                                            lblError.Text = "You can not retrieve activation code again in 24 hours.";
                                            divError.Visible = true;
                                            //   master.ShowMessage("We are very sorry, we cannot resend password before 24 hours.");
                                        }
                                    }
                                    else
                                    {
                                        Members member = new Members();
                                        member.LoadByPrimaryKey(memberDetail.MemberID);
                                        var emails = new Emails();
                                        emails.Where.ToEmail.Value = member.Email;
                                        emails.Where.Subject.Value = "eOpen Email Verification, to continue your registration";
                                        emails.Where.EmailDate.Value = DateTime.Now.AddHours(-24);
                                        emails.Where.EmailDate.Operator = NCI.EasyObjects.WhereParameter.Operand.GreaterThanOrEqual;
                                        emails.Query.Load();
                                        if (emails.RowCount < 1)
                                        {
                                            member.RegistrationCode = Web.CalculateRegCode();
                                            member.Save();

                                            //mail to user
                                            StringDictionary templateKeys = new StringDictionary();
                                            templateKeys.Add("#site_url#", Web.SystemConfigs.GetKey("SITE_URL"));
                                            templateKeys.Add("#email_header#", Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER"));
                                            templateKeys.Add("#email_footer#", Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER"));
                                            templateKeys.Add("#email#", member.Email);
                                            templateKeys.Add("#username#", (!String.IsNullOrEmpty(memberDetail.FullName)) ? memberDetail.FullName : memberDetail.Email);
                                            templateKeys.Add("#activation_link#", Web.SystemConfigs.GetKey("SITE_URL") + "Account/Verify.aspx&code=" + member.RegistrationCode + "&RecordID=" + Secure.Encrypt(member.MemberID) + "&sid=" + member.SurrogateID);
                                            templateKeys.Add("#activationcode#", member.RegistrationCode);
                                            templateKeys.Add("#link_log_myeoffer#", Web.SystemConfigs.GetKey("SITE_URL"));
                                            templateKeys.Add("#fullname#", (!String.IsNullOrEmpty(memberDetail.FullName)) ? memberDetail.FullName : memberDetail.Email);

                                            Web.SendMail(memberDetail.Email, Web.SystemConfigs.GetKey("ACCOUNTS_EMAIL"), 16, templateKeys);
                                            Web.Redirect("~/Account/Verify.aspx?RecordID=" + Secure.Encrypt(member.MemberID) + "&sid=" + member.SurrogateID);
                                        }
                                        else
                                        {
                                            lblError.Text = "You can not retrieve activation code again in 24 hours.";
                                            divError.Visible = true;
                                            //   master.ShowMessage("We are very sorry, we cannot resend the activation code before 24 hours.");
                                        }
                                    }
                                }
                                else
                                {
                                    Members member = new Members();
                                    member.LoadByPrimaryKey(memberDetail.MemberID);
                                    member.RegistrationCode = Web.CalculateRegCode();
                                    member.Save();

                                    //mail to user
                                    StringDictionary templateKeys = new StringDictionary();
                                    templateKeys.Add("#email_header#", Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER"));
                                    templateKeys.Add("#email_footer#", Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER"));
                                    templateKeys.Add("#email#", member.Email);
                                    templateKeys.Add("#username#", memberDetail.FullName);
                                    templateKeys.Add("#activation_link#", Web.SystemConfigs.GetKey("SITE_URL") + "Account/Verify.aspx&code=" + member.RegistrationCode + "&RecordID=" + Secure.Encrypt(member.MemberID) + "&sid=" + member.SurrogateID);
                                    templateKeys.Add("#activationcode#", member.RegistrationCode);
                                    templateKeys.Add("#link_log_myeoffer#", Web.SystemConfigs.GetKey("SITE_URL"));
                                    templateKeys.Add("#fullname#", memberDetail.FullName);
                                    templateKeys.Add("#site_url#", Web.SystemConfigs.GetKey("SITE_URL"));

                                    Web.SendMail(memberDetail.Email, Web.SystemConfigs.GetKey("ACCOUNTS_EMAIL"), 16, templateKeys);
                                    Web.Redirect("~/Account/Verify.aspx?RecordID=" + Secure.Encrypt(member.MemberID) + "&sid=" + member.SurrogateID);
                                }

                                txtZipCode.Text = "";
                                txtCaptchaValue1.Text = "";
                                txtEmail.Text = "";
                            }
                            else
                            {
                                pnlRecover.Visible = true;
                                lblError.Text = "Please enter the security code correctly";
                                divError.Visible = true;
                                //pnlLogin.Visible = false;
                                // master.ShowMessage("Please enter the security code correctly");
                            }
                        }
                        else
                        {
                            lblError.Text = "Security code is not valid";
                            divError.Visible = true;
                            //   master.ShowMessage("Security code is not valid");
                        }
                    }
                    else
                        if (rdoFP.Checked)
                        {
                            lblError.Text = "Wrong zip code";
                            divError.Visible = true;
                            //  master.ShowMessage("Wrong zip code");
                        }
                        else
                        {
                            lblError.Text = "Account already activated";
                            divError.Visible = true;
                            //    master.ShowMessage("Account already activated");
                        }
                }
                else
                {
                    lblError.Text = "Member with this email does not exist";
                    divError.Visible = true;
                    //   master.ShowMessage("Member with this email does not exist");
                }
            }
        }
        catch (VException vex)
        {
            throw vex;
            //Log.Write("Error", vex.GetBaseException().ToString(), vex);
            Web.LogError(vex);
        }
        catch (Exception exp)
        {
            throw exp;
            //Log.Write("Error", exp.Message, exp);
            Web.LogError(exp);
        }
        // Web.Redirect("~/index.aspx");
    }
}