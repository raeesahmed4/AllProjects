﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Services;
using System.Web.Script.Services;
using CodenameRabbitFoot.BusinessLogic;
using System.Data;
using System.Xml.Linq;
using System.Text.RegularExpressions;

public partial class Live : System.Web.UI.Page
{
    public string RepositryKey
    {
        get
        {
            return Request.Url.AbsolutePath.Replace("/", "").TrimEnd(".aspx".ToCharArray());
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        this.dvMakePost.Visible = Web.IsMemberSession;
        this.uploaderControl.WebPageName = this.RepositryKey;

        DataTable postingTypes = PostingTypes.GetPostingTypes();
        this.ddlPostType.DataSource = postingTypes;
        this.ddlPostType.DataTextField = "PostTypeName";
        this.ddlPostType.DataValueField = "PostTypeID";
        this.ddlPostType.DataBind();
        this.ddlPostType.Items.Insert(0, new ListItem("-- Choose Post Type --", "-1"));
    }

    [WebMethod(EnableSession = true)]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public static string PostData(string postText, string postTypeID, string categoryID, string repositryKey)
    {
        if (!Web.IsMemberSession)
            return "login";

        try
        {
            string activityTitle = "added ";
            if (postTypeID.Equals("1"))
            {
                activityTitle += "an Opinion";
            }
            else if (postTypeID.Equals("2"))
            {
                activityTitle += "News & Info";
            }
            else if (postTypeID.Equals("3"))
            {
                activityTitle += "Event";
            }

            //insert this activity in MemeberActivityLog table
            Members m = new Members();
            m.LoadByPrimaryKey(Web.SessionMembers.MemberID);

            MemberActivityLog log = new MemberActivityLog();
            log.AddNew();
            log.ActivityID = 45;
            log.MemberID = Web.SessionMembers.MemberID;
            log.ActivityDate = DateTime.Now;
            log.IsActive = 1;
            log.IsPrivate = 0;
            log.Description = activityTitle;
            log.s_PostTypeID = postTypeID;
            log.s_CategoryID = categoryID;
            log.PrivacyTypeID = 1;
            log.s_IsPosting = "1";
            log.Save();

            var fields = new PostingExtendedFields();
            fields.AddNew();
            fields.Data = Web.GetCleanHTML(postText);
            fields.FieldID = 3;
            fields.EntryTime = DateTime.Now;
            fields.IsActive = 1;

            fields.ObjectID = log.ActivityLogID;
            fields.SystemObjectID = (int)SystemObjects.Posts;
            fields.Save();

            //call none static method save file
            // Web.SaveFiles(Convert.ToInt32(SystemObjects.Posts), log.ActivityLogID, fupPhoto, fupDocument, txtLink, txtURL, PrivacyTypeID);
            Web.SaveFiles((int)SystemObjects.Posts, log.ActivityLogID, repositryKey);
            //  AddCookie();

        }
        catch (Exception ex)
        {
            Web.LogError(ex);
            return "error";
        }
        return "success";
    }

    [WebMethod(EnableSession = true)]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public static IEnumerable<FeedItem> LoadFeedItems(int numberItemsToSkip, int numberOfItemsToTake)
    {
        List<FeedItem> items = new List<FeedItem>();
        try
        {
            int counter = 0;
            int feedItemSequenceNumber = 0;
            var resultSet = Fx.ExecuteDataSet("EN_LoadFeed", numberItemsToSkip, numberOfItemsToTake, (Web.IsMemberSession ? Web.SessionMembers.MemberID : 0), 0, "ALL");

            if (resultSet == null)
                return items;

            var feedItems = resultSet.Tables[0];
            feedItemSequenceNumber = 1;

            foreach (DataRow row in feedItems.Rows)
            {
                FeedItem item = new FeedItem();
                item.Id = feedItemSequenceNumber.ToString();
                item.EncryptedItemId = Secure.Encrypt(row["ActivityLogID"].ToString());
                item.MemberId = row["MemberID"].ToString();
                item.UserName = row["UserName"].ToString();
                if (Web.IsMemberSession)
                {
                    item.UserName = item.MemberId.Equals(Web.SessionMembers.MemberID.ToString()) ? "You" : row["UserName"].ToString();
                }

                item.IsPosting = row["IsPosting"].ToString();
                item.Title = HttpContext.Current.Server.HtmlEncode(row["Title"].ToString());
                if (item.IsPosting.Equals("0"))
                {
                    var titleParts = item.Title.Split('|');
                    if (titleParts.Count() > 1)
                    {
                        item.Title = titleParts[0];
                        item.ListingTypeName = titleParts[1];
                    }
                }

                item.Date = Convert.ToDateTime(row["ActivityDate"]).ToUniversalTime().ToString();// Convert.ToDateTime(row["ActivityDate"]).Subtract(new DateTime(1970, 1, 1)).Ticks.ToString();
                item.Description = row["Description"].ToString();
                item.ShowLinkUnlink = row["ShowLinkUnlink"].ToString();
                item.ObjectId = row["ObjectID"].ToString();
                if (!item.ObjectId.Equals("0"))
                    item.ObjectId = Secure.Encrypt(item.ObjectId);// Listing ID etc.

                string xmlData = row["Files"].ToString();
                if (!string.IsNullOrWhiteSpace(xmlData))
                {
                    XDocument xDocument = XDocument.Parse(xmlData);
                    counter = 1;
                    foreach (var element in xDocument.Root.Descendants())
                    {
                        FeedItem.Files file = new FeedItem.Files();
                        file.Id = counter.ToString();
                        file.EncryptedFileId = Secure.Encrypt(element.Attribute("SystemObjectFileID").Value);
                        file.FileName = element.Attribute("FileName").Value;
                        file.Type = Web.GetFileType(element.Attribute("Type").Value.ToLower().Trim(), file.FileName);
                        file.Url = element.Attribute("Url").Value;
                        file.Thumbnail = element.Attribute("ThumbnailUrl").Value;
                        item.files.Add(file);
                        counter++;
                    }
                }

                // Fetch comments
                xmlData = row["ActivityComments"].ToString();
                if (!string.IsNullOrWhiteSpace(xmlData))
                {
                    XDocument xDocument = XDocument.Parse(xmlData);
                    counter = 1;
                    foreach (var element in xDocument.Root.Descendants())
                    {
                        Comments comment = new Comments();
                        comment.Id = counter.ToString();
                        comment.EncryptedCommentId = Secure.Encrypt(element.Attribute("ActivityLogCommentsID").Value);
                        comment.Description = element.Attribute("Comments").Value;
                        comment.Date = Convert.ToDateTime(element.Attribute("CommentsDate").Value).ToUniversalTime().ToString();// Convert.ToDateTime(element.Attribute("CommentsDate").Value).Subtract(new DateTime(1970, 1, 1)).TotalMilliseconds.ToString();
                        comment.CommentBy = element.Attribute("CommentsBy").Value;
                        comment.UserName = element.Attribute("UserName").Value;
                        // Item owner can delete every comment. Comment owner can delete his own comments only.
                        if (Web.IsMemberSession)
                            comment.AllowDelete = Web.SessionMembers.MemberID.ToString().Equals(item.MemberId) || Web.SessionMembers.MemberID.ToString().Equals(comment.CommentBy);

                        if (Web.IsMemberSession)
                            comment.UserName = comment.CommentBy.Equals(Web.SessionMembers.MemberID.ToString()) ? "You" : element.Attribute("UserName").Value;
                        item.comments.Add(comment);
                        counter++;
                    }
                }
                items.Add(item);
                feedItemSequenceNumber++;
            }
        }
        catch (Exception exp)
        {
            Web.LogError(exp);
        }
        return items;
    }

    [WebMethod(EnableSession = true)]
    public static string DeleteItem(string id, string type)
    {
        try
        {
            type = type.ToLower().Trim();
            int decryptedID = Convert.ToInt32(Secure.Decrypt(id));

            if (!Web.IsMemberSession)
                return "login";

            if (type.Equals("feed"))
                DeleteFeedItem(decryptedID);
            else if (type.Equals("comment"))
                DeleteComment(decryptedID);
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
            return "failed";
        }

        return "success";
    }

    [WebMethod(EnableSession = true)]
    public static string ToggleLinkUnlinkStatus(string id, string type)
    {
        try
        {
            if (!Web.IsMemberSession)
                return "login";

            type = type.ToLower().Trim();
            int decryptedID = Convert.ToInt32(Secure.Decrypt(id));
            Fx.ExecuteSp("EN_ToggleLinkUnlinkStatus", id, Web.SessionMembers.MemberID, type);
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
            return "failed";
        }
        return "success";
    }

    [WebMethod]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public static Comments AddComment(string itemId, string comment)
    {
        Comments feedItemComment = new Comments();
        try
        {
            feedItemComment.Id = "_" + Guid.NewGuid().ToString().Replace("-", "");
            feedItemComment.Description = Web.ConvertToTinyURL(HttpContext.Current.Server.UrlDecode(comment));
            feedItemComment.Date = DateTime.Now.AddSeconds(10).ToUniversalTime().ToString();
            feedItemComment.CommentBy = Web.SessionMembers.MemberID.ToString();
            feedItemComment.UserName = "You";
            int activityLogID = Convert.ToInt32(Secure.Decrypt(itemId));
            var result = Fx.ExecuteSp("EN_AddMemberActivityLogComment", activityLogID, Web.SessionMembers.MemberID, feedItemComment.Description, DateTime.Now);
            feedItemComment.EncryptedCommentId = Secure.Encrypt(result.Tables[0].Rows[0][0]);
            // Web.EmailonComment(activityLogID, Web.SessionMembers.UserName, feedItemComment.Description, Web.SessionMembers.MemberID);
        }
        catch (Exception exp)
        {
            Web.LogError(exp);
        }

        return feedItemComment;
    }

    public static bool DeleteFeedItem(int id)
    {
        Fx.ExecuteSp("EN_DeleteFeedItem", id, Web.SessionMembers.MemberID);
        return true;
    }

    public static bool DeleteComment(int id)
    {
        Fx.ExecuteSp("EN_DeleteComment", id);
        return true;
    }

}