﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using CodenameRabbitFoot.BusinessLogic;
using System.Web.Services;
using System.Text.RegularExpressions;
using System.Text;

public partial class Controls_UploadFiles : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string FileName = "";
        if (!string.IsNullOrEmpty(Request.QueryString["action"]) && Request.QueryString["action"] == "Upload")
        {
            string tempFolder = RepositryManager.GetRepositryPath(Web.QueryStringVariables.WebPageName);// @"E:\Projects\eOpen\public\www\Uploads\temp";

            Response.Clear();
            HttpFileCollection multipleFiles = Request.Files;

            for (int fileCount = 0; fileCount < multipleFiles.Count; fileCount++)
            {
                HttpPostedFile uploadedFile = multipleFiles[fileCount];

                Regex imageFilenameRegex = new Regex(@"(.*?)\.(jpg|jpeg|png|gif|txt|doc|docx|pdf)$", RegexOptions.IgnoreCase);

                if (imageFilenameRegex.IsMatch(uploadedFile.FileName))
                {
                    string fileName = Path.GetFileName(uploadedFile.FileName);
                    string filePath = Path.Combine(tempFolder, uploadedFile.FileName);
                    string icon = GetFileIconUrl(filePath);

                    if (uploadedFile.ContentLength > 0)
                    {
                        var repositry = RepositryManager.AddFileToRepositry(Web.QueryStringVariables.WebPageName, uploadedFile);

                        if (repositry != null)
                        {
                            Response.Write(GetRepositryFileResponseHtml(repositry));
                            // Response.Write("<li  id='" + repositry.FileId + "'>" + repositry.FileName + " <a href='#' onclick=\"DeleteRepositryFile('" + repositry.FileId + "','" + repositry.FileType.ToString().ToLower() + "')\">X</a></li>");
                            //Response.Write(string.Format("<li  id='{0}' title='{2}'>{1}<a href='#' title='Delete uploaded file.' onclick=\"DeleteRepositryFile('{0}','{3}')\">&nbsp;X</a></li>", repositry.FileId, Utils.GetReducedString(repositry.FileName, 80), repositry.FileName, repositry.FileType));
                        }
                    }
                }
            }

            //Session["multipleFiles"] = uploadedFiles;
            Response.End();
        }

        //if (!string.IsNullOrEmpty(Request.QueryString["action"]) && Request.QueryString["action"] == "Delete")
        //{
        //    Response.Clear();
        //    try
        //    {
        //        File.Delete(Server.MapPath("~/Files/") + Request.QueryString["FileName"]);
        //        Response.Write("Deleted...");
        //    }
        //    catch (Exception ex)
        //    {
        //        Response.Write(ex.ToString());
        //    }
        //    Response.End();
        //}
    }

    [WebMethod(EnableSession = true)]
    public static string DeleteRepositryFile(string fileId, string webPageName)
    {
        RepositryManager.RemoveFromRepositry(webPageName, fileId);
        return "success";
    }

    [WebMethod(EnableSession = true)]
    public static string AddVideo(string repositryKey, string videoTitle, string videoUrl)
    {
        var repositry = RepositryManager.AddVideoToRepositry(repositryKey, videoTitle, HttpContext.Current.Server.UrlDecode(videoUrl));

        if (repositry != null)
            return GetRepositryFileResponseHtml(repositry);

        //return "<li  id='" + repositry.FileId + "'>" + repositry.FileName + " <a href='#' onclick=\"DeleteRepositryFile('" + repositry.FileId + "','" + repositry.FileType.ToString().ToLower() + "')\">X</a></li>";
        //return string.Format("<li  id='{0}' title='{2}'>{1}<a href='#' title='Delete uploaded file.' onclick=\"DeleteRepositryFile('{0}','{3}')\">&nbsp;X</a></li>", repositry.FileId, Utils.GetReducedString(repositry.FileName, 80), repositry.FileName, repositry.FileType);
        
        return string.Empty;
    }

    [WebMethod(EnableSession = true)]
    public static string LoadPreExistingUploadedFiles(string repositryKey)
    {
        StringBuilder html = new StringBuilder();
        var files = RepositryManager.GetRepositry(repositryKey);
        foreach (var file in files)
            html.Append(GetRepositryFileResponseHtml(file));

        return html.ToString();
    }

    [WebMethod(EnableSession = true)]
    public static string ClearPreExistingUploadedFiles(string repositryKey)
    {
        RepositryManager.ClearRepositry(repositryKey);
        return "success";
    }

    public static string GetRepositryFileResponseHtml(UploaderRepository repositry)
    {
        return string.Format("<li  id='{0}' title='{2}'>{1}<a href='#' title='Delete uploaded file.' onclick=\"DeleteRepositryFile('{0}','{3}')\">&nbsp;X</a></li>", repositry.FileId, Utils.GetReducedString(repositry.FileName, 80), repositry.FileName, repositry.FileType);
    }

    public static string GetFileIconUrl(object filePath)
    {
        string baseUrl = string.Format("/Images/eOpen16X16Icons/", HttpContext.Current.Server.MapPath("App_Themes").TrimEnd('/'));

        try
        {
            string fileExtention = Path.GetExtension(filePath.ToString()).ToLower().TrimEnd();

            if (fileExtention.Equals(".doc") || fileExtention.Equals(".docx") || fileExtention.Equals(".rtf") || fileExtention.Equals(".txt"))
            {
                return baseUrl + "eo_icon_word.png";
            }
            if (fileExtention.Equals(".ppt") || fileExtention.Equals(".pptx"))
            {
                return baseUrl + "eo_icon_powerpoint.png";
            }
            if (fileExtention.Equals(".xls") || fileExtention.Equals(".xlsx"))
            {
                return baseUrl + "eo_icon_xlsx.png";
            }
            if (fileExtention.Equals(".xls") || fileExtention.Equals(".xlsx"))
            {
                return baseUrl + "eo_icon_pdf.png";
            }//eo_panel_icon_photo.png
            if (fileExtention.Equals(".jpg") || fileExtention.Equals(".png"))
            {
                return baseUrl + "eo_panel_icon_photo.png";
            }
        }
        catch (Exception exp)
        {
            Web.LogError(exp);
        }
        return baseUrl + "eo_icon_default_file.png";
    }

    private string GetFileClass(string File)
    {
        string Ext = Path.GetExtension(File).ToLower().Trim();
        string CssClass = "defaultIcon";
        if (Ext == ".png" || Ext == ".jpg" || Ext == ".jpeg" || Ext == ".gif")
        {
            CssClass = "imageIcon";
        }

        return CssClass;
    }


}