﻿using System;
using System.Configuration;
using CodenameRabbitFoot.BusinessLogic;
using System.Collections.Generic;
using System.Data;
using System.IO;

public partial class logoMaker : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        ApplianceStore logo = new ApplianceStore();
        logo.Query.Load();



        IEnumerable<DataRow> allRows = logo.DefaultView.Table.Select();


        foreach (DataRow row in allRows)
        {
            Response.Write(row["ApplianceStoreID"].ToString() + "<br />");


            byte[] thumbnailContent = row["Logo"] as byte[];

            if (thumbnailContent != null)
            {
                System.Drawing.Image img = Web.byteArrayToImage(thumbnailContent);
                Web.CreateThumbnail(img, 60, 60).Save(Web.SystemConfigs.GetKey("ATTACHMENTS_PHYSICAL_PATH") + @"\ApplianceStore\" +
                         row["ApplianceStoreID"] + ".jpg");
            }
            //if(thumbnailContent != null)
            //File.WriteAllBytes(Web.SystemConfigs.GetKey("ATTACHMENTS_PHYSICAL_PATH") + @"\ApplianceStore\" + row["ApplianceStoreID"] + ".jpg", thumbnailContent);
        }
 
    }
}