﻿using System;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using CodenameRabbitFoot.BusinessLogic;
using System.Collections.Generic;
using System.Web.Services;
using System.Linq;

public partial class SearchResults : System.Web.UI.Page
{
    
    [WebMethod]
    public static JQGrid LoadgrdForMembers(string searchText, int pageIndex,int pageNewIndex, int pageSize, string checkBoxValue)
    {
        JQGrid jqGrid = new JQGrid();
      
        if (!Web.IsMemberSession)
        {
            jqGrid.status = "login";
        }
        string filter = string.Empty;
        if (checkBoxValue.Length > 0)
        {
            string str2 = checkBoxValue.Substring(0, checkBoxValue.Length - 1);
            string[] words = str2.Split(',');
            foreach (string word in words)
            {
                filter += string.Format(" Type like '%{0}%' OR", word);
            }
            filter = filter.Substring(0, filter.Length - 2);
        }
        SearchEngine searchEngine = new SearchEngine();
        DataSet ds = searchEngine.Search(searchText);
        DataView dv = new DataView(ds.Tables[0]);
        dv.RowFilter = filter;
        IEnumerable<DataRow> allRows = dv.ToTable().Select();
        jqGrid.total = allRows.Count() == pageSize ? 1 : (allRows.Count() / pageSize) + 1;
        jqGrid.records = pageSize;
        if (pageNewIndex == 1)
        {
            jqGrid.page = 1;
        }
        else
        {
            jqGrid.page = pageIndex;
        }
       
        IEnumerable<DataRow> selectedRows = allRows.Skip((pageIndex - 1) * pageSize).Take(pageSize);
        if (selectedRows.Count() == 0)
        {
            JQGrid.Row row = new JQGrid.Row();
            //string gridTemplate = "<td style='width:300xp;'><div style='text-align:left; padding:5px; width:400px;'>No records exists.</div></td>";
            row.id = 0;
            //row.cell.Add("0");
            row.cell.Add("<td style='width:300xp;'><div style='text-align:left; padding:5px; width:400px;'>No records exists.</div></td>");
            jqGrid.rows.Add(row);
            jqGrid.status = "empty";
         
        }
        else
        {
            string itemHtml = string.Empty;
            
            //background-image:url('App_Themes/Space/Images/eOpen%20post_tp_world%20Icons/rent_48_x_48.png')
            foreach (DataRow obj in selectedRows)
            {
                //<div style='background: center url('pitr-head.png') no-repeat,center url('#BACKIMAGE#') no-repeat,center url('#BACKIMAGE#') no-repeat,center url('#BACKIMAGE#') no-repeat;'>
                JQGrid.Row row = new JQGrid.Row();
                row.cell.Add(obj["RecordID"].ToString());
                string gridTemplate = @"<div style='padding:10px 0px 25px 0px; margin:0px 0px 0px 10px;'><div class='entry'>
                                    <div class='#SET#'>
                                    <div style='float:left;text-align:center;'><img title='' src='#IMAGE#' width='50' height='50'/><br/><span style='text-align:center;color:#78899e;'>#TYPE#</span> </div>
                                    <div style='float:left; width:10px; height:55px;'> </div>   
                                    <div style='float:left;  margin:0px 0px 0px 0px;'>
                                            <span class='title' ><a href='#HREF#' >#TITLE#</a></span></div>
                                    <div style='float:right;text-align: right;'>#LINK#</div>
                                 
                               <br />
                                <div class='summary' style='margin-left:0px;margin-top:5px; width:600px;'><span style='margin-left:0px;'>#SUMMARY#</span></div></div></div>";
                   //<div style='float: right; text-align: right; margin-right:30px;'>
                   //                     <img title='' src='#BACKIMAGE#' width='30' height='30'/></div>
                itemHtml = string.Format("<b>{0}</b>", obj["Title"]);
                gridTemplate = gridTemplate.Replace("#TITLE#", itemHtml);
                itemHtml = string.Format("{0}", obj["Description"]);
                gridTemplate = gridTemplate.Replace("#SUMMARY#", itemHtml);
                string type = obj["Type"].ToString();
                if (type.Equals("Appliance Store"))
                {
                    string setCss = "setLapps"; //SET
                    string ApplianceStoreLogoHref = string.Format("/ePage/ImageViewer.ashx?Action=ApplianceStoreLogo&RecordID={0}", Secure.Decrypt(obj["RecordID"].ToString()));
                    gridTemplate = gridTemplate.Replace("#SET#", setCss);
                    itemHtml = "../App_Themes/Space/Images/eOpen 32X32 Icons/eo_panel_off_icon_my_linkings_1.png";
                    gridTemplate = gridTemplate.Replace("#IMAGE#", ApplianceStoreLogoHref);
                    gridTemplate = gridTemplate.Replace("#TYPE#", "LinkApps");
              
                    string Href = string.Format("/ApplianceStore/browse.aspx?RecordID={0} ' target='_blank' ", Secure.Encrypt(obj["RecordID"].ToString()));
                    itemHtml = string.Format(" <span style='padding: 5px;'><a class='liView' title='View' href='/ApplianceStore/browse.aspx?RecordID={0}' target='_blank'>&nbsp;</a><a title='Add' onclick='AddApplianceStore({1})'><img id=ApplianceStore_{1} alt='Add' src='/Images/Icons/Add_Icon.png'></a></span>", Secure.Encrypt(obj["RecordID"].ToString()), Secure.Decrypt(obj["RecordID"].ToString()));
                    gridTemplate = gridTemplate.Replace("#LINK#", itemHtml);
                    gridTemplate = gridTemplate.Replace("#HREF#", Href);
                 
                }
                else if (type.Equals("For Sale"))
                {
                    string setCss = "setSale"; //SET
                    gridTemplate = gridTemplate.Replace("#SET#", setCss);
                    string Href = string.Format("/marketplace/ItemDetails.aspx?Action=View&RecordID={0}",Secure.Encrypt(obj["RecordID"].ToString()));
                    itemHtml = string.Format(" <span style='padding: 5px;'><a class='liView' title='View' href='{0}'>&nbsp;</a></span>", Href);
                    gridTemplate = gridTemplate.Replace("#LINK#", itemHtml);
                    gridTemplate = gridTemplate.Replace("#HREF#", Href);
                    itemHtml = "../App_Themes/Space/Images/eOpen post_tp_world Icons/sale_50_x_50.png";
                    gridTemplate = gridTemplate.Replace("#IMAGE#", itemHtml);
                    gridTemplate = gridTemplate.Replace("#TYPE#", "For Sale");
                }
                else if (type.Equals("Coupon") || type.Equals("Coupons & Discounts"))
                {
                    string setCss = "setCoupon"; //SET
                    gridTemplate = gridTemplate.Replace("#SET#", setCss);
                    string Href = string.Format("/marketplace/ItemDetails.aspx?Action=View&RecordID={0}", Secure.Encrypt(obj["RecordID"].ToString()));
                    itemHtml = string.Format(" <span style='padding: 5px;'><a class='liView' title='View' href='{0}'>&nbsp;</a></span>", Href);
                    gridTemplate = gridTemplate.Replace("#LINK#", itemHtml);
                    gridTemplate = gridTemplate.Replace("#HREF#", Href);
                    itemHtml = "../App_Themes/Space/Images/eOpen post_tp_world Icons/coupon_50_x_50.png";
                    gridTemplate = gridTemplate.Replace("#IMAGE#", itemHtml);
                    gridTemplate = gridTemplate.Replace("#TYPE#", "Coupon");
                }
                else if (type.Equals("For Rent"))
                {
                    string setCss = "setRent"; //SET
                    gridTemplate = gridTemplate.Replace("#SET#", setCss);
                    string Href = string.Format("/marketplace/ItemDetails.aspx?Action=View&RecordID={0}", Secure.Encrypt(obj["RecordID"].ToString()));
                    itemHtml = string.Format(" <span style='padding: 5px;'><a class='liView' title='View' href='{0}'>&nbsp;</a></span>", Href);
                    gridTemplate = gridTemplate.Replace("#LINK#", itemHtml);
                    gridTemplate = gridTemplate.Replace("#HREF#", Href);
                    itemHtml = "../App_Themes/Space/Images/eOpen post_tp_world Icons/rent_50_x_50.png";
                    gridTemplate = gridTemplate.Replace("#IMAGE#", itemHtml);
                    gridTemplate = gridTemplate.Replace("#TYPE#", "For Rent");
                }
                else if (type.Equals("Services"))
                {
                    string setCss = "setServices"; //SET
                    gridTemplate = gridTemplate.Replace("#SET#", setCss);
                    string Href = string.Format("/marketplace/ItemDetails.aspx?Action=View&RecordID={0}", Secure.Encrypt(obj["RecordID"].ToString()));
                    itemHtml = string.Format(" <span style='padding: 5px;'><a class='liView' title='View' href='{0}'>&nbsp;</a></span>", Href);
                    gridTemplate = gridTemplate.Replace("#LINK#", itemHtml);
                    gridTemplate = gridTemplate.Replace("#HREF#", Href);
                    itemHtml = "../App_Themes/Space/Images/eOpen post_tp_world Icons/service_50_x_50.png";
                    gridTemplate = gridTemplate.Replace("#IMAGE#", itemHtml);
                    gridTemplate = gridTemplate.Replace("#TYPE#", "Services");
                }
                else if (type.Equals("Jobs"))
                {
                    string setCss = "setJob"; //SET
                    gridTemplate = gridTemplate.Replace("#SET#", setCss);
                    string Href = string.Format("/marketplace/ItemDetails.aspx?Action=View&RecordID={0}", Secure.Encrypt(obj["RecordID"].ToString()));
                    itemHtml = string.Format(" <span style='padding: 5px;'><a class='liView' title='View' href='{0}'>&nbsp;</a></span>", Href);
                    gridTemplate = gridTemplate.Replace("#LINK#", itemHtml);
                    gridTemplate = gridTemplate.Replace("#HREF#", Href);
                    itemHtml = "../App_Themes/Space/Images/eOpen post_tp_world Icons/jobs_50_x_50.png";
                    gridTemplate = gridTemplate.Replace("#IMAGE#", itemHtml);
                    gridTemplate = gridTemplate.Replace("#TYPE#", "Jobs");
                }
                //else if (type.Equals("Make Exhibit"))
                //{
                //    itemHtml = string.Format("{0}", obj["UserName"]);
                //    gridTemplate = gridTemplate.Replace("#LINK#", itemHtml);
                //    itemHtml = "../App_Themes/Space/Images/eOpen post_tp_world Icons/jobs_48_x_48.png";//
                //    gridTemplate = gridTemplate.Replace("#IMAGE#", itemHtml);
                //}
                else if (type.Equals("Personal"))
                {
                    string setCss = "setPersonal"; //SET
                    gridTemplate = gridTemplate.Replace("#SET#", setCss);
                    itemHtml = string.Format("{0}", obj["UserName"]);
                    gridTemplate = gridTemplate.Replace("#LINK#", itemHtml);
                    itemHtml = "../App_Themes/Space/Images/eOpen post_tp_world Icons/personal_50_x_50.png";//personal_48_x_48.png
                    gridTemplate = gridTemplate.Replace("#IMAGE#", itemHtml);
                    gridTemplate = gridTemplate.Replace("#TYPE#", "Personal");
                }
                else if (type.Equals("Member"))
                {
                    string setCss = "setMember"; //SET
                    string MemberLogoHref = string.Format("/ePage/ImageViewer.ashx?Action=MembersLogoThumbnail&RecordID={0}", Secure.Decrypt(obj["RecordID"].ToString()));
                    gridTemplate = gridTemplate.Replace("#IMAGE#", MemberLogoHref);
                    ///ePage/ImageViewer.ashx?Action=MembersLogoThumbnail&RecordID=Txu3qRcyEaYxDkTk2iK1PQ
                    gridTemplate = gridTemplate.Replace("#SET#", setCss);
                    string Href = string.Format("/Contacts/ViewProfile.aspx?Action=ViewDealer&RecordID={0}", Secure.Encrypt(obj["RecordID"].ToString()));
                    itemHtml = string.Format(" <span style='padding: 5px;'><a class='liView' title='View' href='{0}'>&nbsp;</a></span>", Href);
                    gridTemplate = gridTemplate.Replace("#LINK#", itemHtml);
                    gridTemplate = gridTemplate.Replace("#HREF#", Href);
                    //itemHtml = "../App_Themes/Space/Images/eOpen post_tp_world Icons/member_48_x_48.png";
                    //gridTemplate = gridTemplate.Replace("#IMAGE#", itemHtml);
                    gridTemplate = gridTemplate.Replace("#TYPE#", "Member");
                }
                string LogoHtml = string.Format("<div style='padding:5px 0px 5px 0px; margin:0px 0px 0px 5px;' ><a  href='/Contacts/ViewProfile.aspx?Action=ViewDealer&RecordID={0}'><img style='border:5px solid #F1F6F6;' width='20px' height='20px' id='' alt='Logo' src='/ePage/ImageViewer.ashx?Action=MembersLogoThumbnail&amp&RecordID={0}'></a></div>", Secure.Encrypt(obj["RecordID"].ToString()));
                row.cell.Add(gridTemplate);
                jqGrid.rows.Add(row);
            }
        }
            return jqGrid;
    }
    [WebMethod(EnableSession = true)]
    public static string GetLeftMenuHtml(string invitationID)
    {
        string html = @"<ul class='leftMenu'>";
        bool isValidInvitation = false;

        if (invitationID != "null")
        {
            try
            {
                var invitaions = new Invitations();
                invitaions.LoadByPrimaryKey(Convert.ToInt32(Secure.Decrypt(invitationID)));
                isValidInvitation = invitaions.RowCount > 0;
            }
            catch (Exception ex)
            { Web.LogError(ex); }
        }
        //
        if (Web.IsMemberSession || isValidInvitation)
        {
            html += @" <li id='liHome' class='menuItem'><span class='liHome'></span><a href='../live.aspx'><span>Live Exhibit Floor</span></a></li>
                                <li id='liHome0' class='selectedMenuItem'><span class='liPost'></span><a onclick=OnMenuItemClicked(this,'GlobalPosts')><span>Search</span></a></li>
                                <li><ul id='searchoption'>
                                <li id='lisearch1' class='menuItem'><div style='width:15px;float:left;height: 20px; vertical-align: middle; padding-top: 4px;'><input type='checkbox' name='All' value='All' checked='checked' onclick=checkUncheck('searchoption') /></div><div style='width:145px;float:left;'><span class='searchSpan'>Everything</span></li>
                                <li id='lisearch2' class='menuItem'><div style='width:15px;float:left;height: 20px; vertical-align: middle; padding-top: 4px;'><input type='checkbox' name='For Sale' value='Item for Sale' onclick=OnMenuItemClicked('searchoption') /></div><div style='width:145px;float:left;'><span  class='searchSpan' style='padding-top: 10px;'>Item for Sale</span></div></li>
                              
                                <li id='lisearch5' class='menuItem'><div style='width:15px;float:left;height: 20px; vertical-align: middle; padding-top: 4px;'><input type='checkbox' name='Member' value='Members' onclick=OnMenuItemClicked('searchoption') /></div><div style='width:145px;float:left;'><span  class='searchSpan' style='padding-top: 10px;'>Members</span></div></li>
                                <li id='lisearch6' class='menuItem'><div style='width:15px;float:left;height: 20px; vertical-align: middle; padding-top: 4px;'><input type='checkbox' name='Appliance Store' value='LinkApps' onclick=OnMenuItemClicked('searchoption') /></div><div style='width:145px;float:left;'><span  class='searchSpan' style='padding-top: 10px;'>LinkApps</span></div></li>
                                <li id='lisearch7' class='menuItem'><div style='width:15px;float:left;height: 20px; vertical-align: middle; padding-top: 4px;'><input type='checkbox' name='For Rent' value='ItemforRent' onclick=OnMenuItemClicked('searchoption') /></div><div style='width:145px;float:left;'><span  class='searchSpan' style='padding-top: 10px;'>Item for Rent</span></div></li>
                                <li id='lisearch8' class='menuItem'><div style='width:15px;float:left;height: 20px; vertical-align: middle; padding-top: 4px;'><input type='checkbox' name='Coupon' value='Coupons' onclick=OnMenuItemClicked('searchoption') /></div><div style='width:145px;float:left;'><span  class='searchSpan'>Coupons</span></div></li>
                                <li id='lisearch9' class='menuItem'><div style='width:15px;float:left;height: 20px; vertical-align: middle; padding-top: 4px;'><input type='checkbox' name='Jobs' value='Jobs' onclick=OnMenuItemClicked('searchoption') /></div><div style='width:145px;float:left;'><span  class='searchSpan' style='padding-top: 10px;'>Jobs</span></div></li>
                                <li id='lisearch10' class='menuItem'><div style='width:15px;float:left;height: 20px; vertical-align: middle; padding-top: 4px;'><input type='checkbox' name='Services' value='Services' onclick=OnMenuItemClicked('searchoption') /></div><div style='width:145px;float:left;'><span  class='searchSpan' style='padding-top: 10px;'>Services</span></div></li>
                                <li id='lisearch11' class='menuItem'><div style='width:15px;float:left;height: 20px; vertical-align: middle; padding-top: 4px;'><input type='checkbox' name='Personal' value='Personal' onclick=OnMenuItemClicked('searchoption') /></div><div style='width:145px;float:left;'><span  class='searchSpan' style='padding-top: 10px;'>Personal</span></div></li>
                                
                               </li></ul>                              
                        ";

            //<li id='liHome0' class='selectedMenuItem'><span class='liPost'></span><a onclick=OnMenuItemClicked(this,'GlobalPosts')><span>Search</span></a></li>
            //                    <li><ul id='searchoption'>
            //                    <li id='lisearch1' class='menuItem'><div style='width:15px;float:left;height: 20px; vertical-align: middle; padding-top: 4px;'><input type='checkbox' name='All' value='All' checked='checked' onclick=checkUncheck('searchoption') /></div><div style='width:145px;float:left;'><span class='searchSpan'>Everything</span></li>
            //                    <li id='lisearch2' class='menuItem'><div style='width:15px;float:left;height: 20px; vertical-align: middle; padding-top: 4px;'><input type='checkbox' name='For Sale' value='Item for Sale' onclick=OnMenuItemClicked('searchoption') /></div><div style='width:145px;float:left;'><img src='App_Themes/Space/Images/eOpen post_tp_world Icons/sale_48_x_48.png' height='20px;' width='20px;' /><span  class='searchSpan' style='padding-top: 10px;'>Item for Sale</span></div></li>
                              
            //                    <li id='lisearch5' class='menuItem'><div style='width:15px;float:left;height: 20px; vertical-align: middle; padding-top: 4px;'><input type='checkbox' name='Member' value='Members' onclick=OnMenuItemClicked('searchoption') /></div><div style='width:145px;float:left;'><img src='App_Themes/Space/Images/eOpen post_tp_world Icons/member_48_x_48.png' height='20px;' width='20px;' /><span  class='searchSpan' style='padding-top: 10px;'>Members</span></div></li>
            //                    <li id='lisearch6' class='menuItem'><div style='width:15px;float:left;height: 20px; vertical-align: middle; padding-top: 4px;'><input type='checkbox' name='Appliance Store' value='LinkApps' onclick=OnMenuItemClicked('searchoption') /></div><div style='width:145px;float:left;'><img src='App_Themes/Space/Images/eOpen 32X32 Icons/eo_panel_off_icon_my_linkings_1.png' height='20px;' width='20px;' /><span  class='searchSpan' style='padding-top: 10px;'>LinkApps</span></div></li>
            //                    <li id='lisearch7' class='menuItem'><div style='width:15px;float:left;height: 20px; vertical-align: middle; padding-top: 4px;'><input type='checkbox' name='For Rent' value='ItemforRent' onclick=OnMenuItemClicked('searchoption') /></div><div style='width:145px;float:left;'><img src='App_Themes/Space/Images/eOpen post_tp_world Icons/rent_48_x_48.png' height='20px;' width='20px;' /><span  class='searchSpan' style='padding-top: 10px;'>Item for Rent</span></div></li>
            //                    <li id='lisearch8' class='menuItem'><div style='width:15px;float:left;height: 20px; vertical-align: middle; padding-top: 4px;'><input type='checkbox' name='Coupon' value='Coupons' onclick=OnMenuItemClicked('searchoption') /></div><div style='width:145px;float:left;'><img src='App_Themes/Space/Images/eOpen post_tp_world Icons/coupon_48_x_48.png' height='20px;' width='20px;' /><span  class='searchSpan'>Coupons</span></div></li>
            //                    <li id='lisearch9' class='menuItem'><div style='width:15px;float:left;height: 20px; vertical-align: middle; padding-top: 4px;'><input type='checkbox' name='Jobs' value='Jobs' onclick=OnMenuItemClicked('searchoption') /></div><div style='width:145px;float:left;'><img src='App_Themes/Space/Images/eOpen post_tp_world Icons/jobs_48_x_48.png' height='20px;' width='20px;' /><span  class='searchSpan' style='padding-top: 10px;'>Jobs</span></div></li>
            //                    <li id='lisearch10' class='menuItem'><div style='width:15px;float:left;height: 20px; vertical-align: middle; padding-top: 4px;'><input type='checkbox' name='Services' value='Services' onclick=OnMenuItemClicked('searchoption') /></div><div style='width:145px;float:left;'><img src='App_Themes/Space/Images/eOpen post_tp_world Icons/service_48_x_48.png' height='20px;' width='20px;' /><span  class='searchSpan' style='padding-top: 10px;'>Services</span></div></li>
            //                    <li id='lisearch11' class='menuItem'><div style='width:15px;float:left;height: 20px; vertical-align: middle; padding-top: 4px;'><input type='checkbox' name='Personal' value='Personal' onclick=OnMenuItemClicked('searchoption') /></div><div style='width:145px;float:left;'><img src='App_Themes/Space/Images/eOpen post_tp_world Icons/personal_48_x_48.png' height='20px;' width='20px;' /><span  class='searchSpan' style='padding-top: 10px;'>Personal</span></div></li>
//              <li id='lisearch3' class='menuItem'><input type='checkbox' name='Wanttobuy' value='Want to buy' onclick=OnMenuItemClicked('searchoption') /><span  class='searchSpan'>Want to buy</span></li>
//                                <li id='lisearch4' class='menuItem'><input type='checkbox' name='Contacts' value='Contacts' onclick=OnMenuItemClicked('searchoption') /><span  class='searchSpan'>Contacts</span></li>
        }
        else
        {
            //html += @" <li id='liHome' class='menuItem'><span class='liHome'></span><a href='../index.aspx'><span>eOpen</span></a></li>";
            html += @" <li id='liHome' class='menuItem'><span class='liHome'></span><a href='../live.aspx'><span>Live Exhibit Floor</span></a></li>
                                <li id='liHome0' class='selectedMenuItem'><span class='liPost'></span><a onclick=OnMenuItemClicked(this,'GlobalPosts')><span>Global Posts</span></a></li>
                                <li id='liHome4' class='menuItem'><span class='liLinkBoard'></span><a onclick=OnMenuItemClicked(this,'LApps')><span>L-Apps</span></a></li>
                      ";

        }

        html += @"</ul>";

        return html;
    }

    private string searchText = "";

    protected void Page_Load(object sender, EventArgs e)
    {

        try
        {
            this.Master.HideLinkApps();
            string searchText = Request.QueryString["Search"].ToString();
            litPageTitle.Text = "Search result for &#34" + searchText + "&#34";
            if (PreviousPage != null)
            {
                Page previousPage = PreviousPage;
                //searchText = ((MasterPages_Main)PreviousPage.Master).SearchText;
                //if (searchText != "")
                //    searchAll();

            }
            else //if (IsPostBack)
            {
                //searchText = ((MasterPages_Main)Page.Master).SearchText;
                //if (searchText != "")
                //    searchAll();
            }

            //if (Request.QueryString["Search"] != null)
            //    searchText = Request.QueryString["Search"].ToString();
            //if (searchText != "")
            //    searchAll();

        }
        catch (Exception exp)
        {
            Web.LogError(exp);
            Response.Redirect("~/ErrorPage.aspx", true);
        }
    }




}