﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Net.Mail;
using System.Collections.Specialized;
using VisualSoft.VSharp.Utils;
using CodenameRabbitFoot.BusinessLogic;

public partial class PublicSite_MarketPlace_Reply : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            LoadData();
        }
        BtnAnswer.Attributes["onclick"] = string.Format("{0}.disabled=true;{1};", BtnAnswer.ClientID, GetPostBackEventReference(BtnAnswer));
    }


    protected void BtnAnswer_OnClick(object sender, EventArgs e)
    {
        try
        {
            BtnAnswer.Enabled = false;
            Questions question = new Questions();
            question.LoadByPrimaryKey(Web.RecordID);
            question.IsReplied = 1;
            question.Answer = TxtBoxAnswer.Text;
            question.AnswerDate = DateTime.Now;
            question.Save();

            Listings lot = new Listings();
            lot.LoadByPrimaryKey(question.ObjectID);

            Members seller = new Members();
            seller.LoadByPrimaryKey(lot.MemberID);
            
            Members buyer = new Members();
            buyer.LoadByPrimaryKey(question.QuestionBy);

            string title = Listings.GetTitle(Web.RecordID);
            string replylink = Web.SystemConfigs.GetKey("SITE_URL") + "live.aspx";
            StringDictionary TemplateKeys = new StringDictionary();
            TemplateKeys.Add("#email_header#", Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER"));
            TemplateKeys.Add("#fullname#", buyer.FullName);
            TemplateKeys.Add("#seller#", Web.SessionMembers.FullName);
            TemplateKeys.Add("#question#", question.Question);
            TemplateKeys.Add("#reply#", question.Answer);
            TemplateKeys.Add("#link_item#", Web.SystemConfigs.GetKey("SITE_URL") + "MarketPlace/ItemDetails.aspx?Action=View&RecordID=" + Secure.Encrypt(question.ObjectID));
            TemplateKeys.Add("#link_log_myeoffer#", Web.SystemConfigs.GetKey("SITE_URL") + "index.aspx");
            TemplateKeys.Add("#email_footer#", Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER"));
            TemplateKeys.Add("#link_view#", replylink);
            //Web.NotifyMember(members.MemberID, 42, TemplateKeys);
            Web.SendMail(buyer.Email, Web.SystemConfigs.GetKey("ALERTS_EMAIL"), 310, TemplateKeys);

            var templateKeys = new System.Collections.Specialized.StringDictionary();
            templateKeys.Add("#viewlink#", "../Listing/DealingFloor.aspx?TabIndex=130");
            templateKeys.Add("#initiatedto#", "#memberid#" + buyer.MemberID + "#endmemberid#");
            templateKeys.Add("#profileclass#", "#profileclass#" + buyer.MemberID + "#endprofileclass#");
            templateKeys.Add("#initiatedtoprofile#", "ViewContact.aspx?Action=ViewDealer&RecordID=#encrypt#" + buyer.MemberID + "#endencrypt#");
            Web.AddPrivateActivityLog(17, templateKeys, Web.SessionMembers.MemberID, question.QuestionID, buyer.MemberID);
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
        ClientScript.RegisterStartupScript(Page.GetType(), "CloseAndRebind", "CloseAndRebind();", true);
    }

    private void LoadData()
    {
        try
        {
            Questions LotQ = new Questions();
            LotQ.LoadByPrimaryKey(Web.RecordID);
            if (LotQ.RowCount > 0)
            {
                Listings lot = new Listings();
                lot.LoadByPrimaryKey(LotQ.ObjectID);
                if (lot.MemberID == Web.SessionMembers.MemberID)
                {
                    TxtBoxAnswer.Text = LotQ.Answer;
                    lblquestion.Text = "<b>Question:</b> " + LotQ.Question;
                }
                else
                    ClientScript.RegisterStartupScript(Page.GetType(), "CancelEdit", "CancelEdit();", true);
            }
            else
                ClientScript.RegisterStartupScript(Page.GetType(), "CancelEdit", "CancelEdit();", true);
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }
    private void ShowMessage(string message)
    {
        string messageScript = "showMessage('" + message + "');";
        ScriptManager.RegisterStartupScript(this.Page, typeof(Page), "ShowMessageScript", messageScript, true);
    }
}