﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Web.Script.Services;
using System.Web.Services;
using System.Web.UI.WebControls;
using CodenameRabbitFoot.BusinessLogic;
using System.Linq;
using System.Xml.Linq;

public partial class MarketPlace_Default : System.Web.UI.Page
{
    public bool Fav_cat_exist = false;

    protected void Page_Load(object sender, EventArgs e)
    {   
        this.Master.ShowPageIcon = false;
        this.Master.HideLinkApps();

        if (Session["POST_MESSAGE"] != null)
        {
            this.Master.ShowMessage(Session["POST_MESSAGE"].ToString(), "Info");
            Session["POST_MESSAGE"] = null;
        }

        if (!IsPostBack)
        {
            buildFavCatTree();

            LoadListingTypes();
            LoadCats();
            LoadCountries();
        }
    }

    [WebMethod(EnableSession = true)]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public static JQGrid LoadMarket(string contactType, int pageIndex, int pageSize, string filter, int ListingTypeID, int CategoryID, int LocationID, string KeyWord, int KeyWordID, int FavCatID, int radioOption)
    {
        JQGrid jqGrid = new JQGrid();
        if (!Web.IsMemberSession)
        {
            jqGrid.status = "login";
        }

        IEnumerable<DataRow> allRows = bindgvListings(ListingTypeID, CategoryID, LocationID, KeyWord, KeyWordID, FavCatID, radioOption);

        // all filterign is made above 
        jqGrid.total = allRows.Count() == pageSize ? 1 : (allRows.Count() / pageSize) + 1;
        jqGrid.records = pageSize;
        jqGrid.page = pageIndex;
        IEnumerable<DataRow> dataRows = allRows.Skip((pageIndex - 1) * pageSize).Take(pageSize);

        if (dataRows.Count() == 0)
        {
            JQGrid.Row row = new JQGrid.Row();
            row.id = 0;
            row.cell.Add("0");
            row.cell.Add("<div style='text-align:left; padding:5px;'>No records exists.</div>");
            jqGrid.rows.Add(row);
            jqGrid.status = "empty";
        }

        foreach (DataRow item in dataRows)
        {
            object encryptedListingID = Secure.Encrypt(item["ListingID"]);
            object encryptedMemberID = Secure.Encrypt(item["MemberID"]);
            JQGrid.Row row = new JQGrid.Row();
            row.id = Convert.ToInt32(item["MemberID"]);
            row.cell.Add(item["MemberID"].ToString());
            row.cell.Add("<div style='padding:5px 0px 5px 0px; margin:0px 0px 0px 5px;' ><img width='48' style='border:5px solid #F1F6F6'; 'margin:5px 0px 5px 0px;' height='48';  src='" + (item["ThumbnailURL"].ToString() == "" ? getDefaultImage(Convert.ToInt32(item["ListingTypeID"].ToString())) : item["ThumbnailURL"]) + "' /></div>");
            row.cell.Add(string.Format("<a href='ItemDetails.aspx?Action=View&RecordID={0}' title='{1}'>{2}</a>", encryptedListingID, item["Title"], GetTite(item["Title"].ToString())));
            row.cell.Add(item["Quantity"].ToString());
            string priceText = "";
            try
            {
                if (!string.IsNullOrEmpty(item.ItemArray[10].ToString()))
                {
                    priceText = "$" + item.ItemArray[10].ToString() + " per listing";
                }
                if (!string.IsNullOrEmpty(item.ItemArray[4].ToString()))
                {
                    var listingData = from d in XDocument.Parse("<listings>" + item.ItemArray[4].ToString() + "</listings>").Root.Descendants()
                                      select new
                                      {
                                          FieldID = d.Attribute("FieldID").Value,
                                          FieldName = d.Attribute("FieldName").Value,
                                          Data = d.Attribute("Data") == null ? "" : d.Attribute("Data").Value
                                      };

                    if (listingData.Count() > 0)
                    {
                        bool isOffer = false;

                        foreach (var i in listingData)
                        {
                            if (i.FieldName.Equals("MakeOffer") && Convert.ToBoolean(i.Data))
                            {
                                priceText = "Make an Offer";
                                isOffer = true;
                            }
                            else
                            {
                                if (i.FieldName.Equals("PriceEach") && !isOffer)
                                {
                                    try
                                    {
                                        double priceeach = Convert.ToDouble(i.Data);
                                        if (priceeach == 0)
                                        {
                                            priceText = "Make an Offer";
                                        }
                                        {
                                            priceText = "$" + i.Data + " per Item";
                                        }
                                    }
                                    catch
                                    {
                                        priceText = "";
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch { }
            row.cell.Add(priceText);
            row.cell.Add(string.Format("<a href='../Contacts/ViewProfile.aspx?Action=ViewDealer&RecordID={0}'>{1}</a>", encryptedMemberID, item["UserName"]));
            row.cell.Add(GetButtonsHtml(item["MemberID"], item["ListingID"]));
            jqGrid.rows.Add(row);

        }

        return jqGrid;
    }

    private static object getDefaultImage(int listingTypeID)
    {
        switch (listingTypeID)
        {
            case 1:
                return "../App_Themes/Space/Images/eOpen post_tp_world Icons/sale_50_x_50.png";
            case 2:
                return "../App_Themes/Space/Images/eOpen post_tp_world Icons/rent_50_x_50.png";
            case 3:
                return "../App_Themes/Space/Images/eOpen post_tp_world Icons/service_50_x_50.png";
            case 4:
                return "../App_Themes/Space/Images/eOpen post_tp_world Icons/jobs_50_x_50.png";
            case 5:
                return "../App_Themes/Space/Images/eOpen post_tp_world Icons/personal_50_x_50.png";
            case 6:
                return "../App_Themes/Space/Images/eOpen post_tp_world Icons/coupon_50_x_50.png";
            case 7:
                return "../App_Themes/Space/Images/eOpen post_tp_world Icons/coupon_50_x_50.png";
            case 8:
                return "/Images/noimage.png";
            default:
                return "/Images/noimage.png";
        }
    }

    [WebMethod(EnableSession = true)]
    public static string AddtoWatchList(int listingID)
    {
        /// salu man di laltain what is this??
        MembersWatchList.AddtoWatchList(Convert.ToInt32(listingID), Web.SessionMembers.MemberID);
        return "success";
    }

    [WebMethod(EnableSession = true)]
    public static string RemoveFromWatchList(int listingID)
    {
        MembersWatchList.RemoveFromWatchList(Convert.ToInt32(listingID), Web.SessionMembers.MemberID);
        return "success";
    }

    private static string GetTite(string title)
    {
        if (title.Length > 35)
        {
            return title.Substring(0, 32) + "...";
        }
        return title;
    }

    private static string GetButtonsHtml(object memberID, object listingID)
    {
        string addID = "AddtoWatch" + listingID.ToString();
        string removeID = "RemovefromWatch" + listingID.ToString();

        string html = @" <span class='feed_actionLinks' style='display: inline;'>
                            <a href='ItemDetails.aspx?Action=View&RecordID=" + Secure.Encrypt(listingID) + @"' title='View this Item Details'>
                                <span class='liView' title='View'></span>
                            </a>
                        </span> ";

        if (Web.IsMemberSession)
        {
            if (Web.SessionMembers.MemberID.ToString() != memberID.ToString())
            {
                html += @"<div ID='" + addID + "' class='feed_actionLinks' style='display: " + (Web.ShowWatchListing(listingID.ToString(), memberID.ToString()) ? "inline" : "none") + @";'>
                            <a href='javascript:void(0);' onclick=""AddtoWatchList('" + addID + @"','" + listingID + @"','" + removeID + @"')"">
                                <img src='../images/icons/add-to-watch-list.png' width='15' height='15' title='Add to WatchList' />
                            </a>
                        </div>
                        <div ID='" + removeID + "' class='feed_actionLinks' style='display: " + (Web.ShowWatchListing(listingID.ToString(), memberID.ToString()) ? "none" : "inline") + @";'>
                            <a href='javascript:void(0);' onclick=""RemoveFromWatchList('" + removeID + @"','" + listingID + @"','" + addID + @"')"">
                                <img src='../images/icons/delete.png' width='15' height='15' title='Remove from WatchList' />
                            </a>
                        </div>          
                        ";
            }
        }

        return html;
    }

    public static IEnumerable<DataRow> bindgvListings(int ListingTypeID, int CategoryID, int LocationID, string KeyWord, int KeyWordID, int FavCatID, int radioOption)
    {
        DataTable filteredListings = new DataTable();
        try
        {
            bool done = false;
            
            int memberID = Web.IsMemberSession ? Web.SessionMembers.MemberID : 0;

            if (!done)
            {
                if (radioOption == 0) //main search
                {
                    filteredListings = Listings.FilterListings(ListingTypeID, CategoryID, LocationID, (KeyWord == "" ? "Keywords" : KeyWord), "-1", -1, KeyWordID, memberID);
                }
                else if (radioOption == 1) //fav cats
                {
                    filteredListings = Listings.FilterListings(-1, FavCatID, -1, "Keywords", "-1", -1, 0, 0);
                }
                else if (radioOption == 2) //watch list
                {
                    filteredListings = Listings.GetMemberWatchList(Web.SessionMembers.MemberID);
                }
            }           
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
        return filteredListings.AsEnumerable();
    }



    void LoadCountries()
    {
        try
        {
            DataTable dtTypes = new DataTable();
            dtTypes = Country.GetCountries();

            foreach (DataRow dr in dtTypes.Rows)
            {
                ddlCountry.Items.Add(new ListItem(dr["CountryName"].ToString(), dr["CountryID"].ToString()));
            }
            ddlCountry.Items.Insert(0, new ListItem("...All Countries...", "-1"));
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }

    void LoadCats()
    {
        try
        {
            ddlCategory.Items.Clear();
            DataTable dtCats = new DataTable();
            dtCats = Categories.GetCategories(1);

            foreach (DataRow dr in dtCats.Rows)
            {
                ddlCategory.Items.Add(new ListItem(dr["CategoryName"].ToString(), dr["CategoryID"].ToString()));
            }
            ddlCategory.Items.Insert(0, new ListItem("...Choose a Category...", "-1"));
            ddlCategory.SelectedIndex = 0;
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }

    }

    void LoadListingTypes()
    {
        try
        {
            DataTable LType = new DataTable();
            LType = ListingTypes.GetListingTypes();
            foreach (DataRow dR in LType.Rows)
            {
                //this.ddlList.Items.Add(new ListItem(dR["ListingTypeName"].ToString(), dR["ListingTypeID"].ToString()));
                ddlList.Items.Add(new ListItem(dR["ListingTypeName"].ToString(), dR["ListingTypeID"].ToString()));

            }
            ddlList.Items.Insert(0, new ListItem("...All types of Listing...", "-1"));

        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }

    protected void ddlList_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            ddlCategory.Items.Clear();
            DataTable dtCats = new DataTable();
            dtCats = CategorizedListingTypes.GetAllListingTypeCategories(Convert.ToInt32(ddlList.SelectedValue));

            foreach (DataRow dr in dtCats.Rows)
            {
                ddlCategory.Items.Add(new ListItem(dr["CategoryName"].ToString(), dr["CategoryID"].ToString()));
            }
            ddlCategory.Items.Insert(0, new ListItem("...Choose a Category...", "-1"));
            ddlCategory.SelectedIndex = 0;
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }

    public void buildFavCatTree()
    {
        try
        {
            if (Web.IsMemberSession)
            {
                ddlfavcats.Items.Clear();
                ddlfavcats.Items.Add(new ListItem("...Favorite Categories...", "-2"));

                DataTable catData = CodenameRabbitFoot.BusinessLogic.MemberCategories.GetMemberFavoriteCategories(Web.SessionMembers.MemberID);
                //TreeNode node;
                if (catData.Rows.Count != 0)
                {
                    Fav_cat_exist = true;
                    foreach (DataRow row in catData.Rows)
                    {
                        //node = new TreeNode(row["CategoryName"].ToString(), row["CategoryID"].ToString());
                        //node.SelectAction = TreeNodeSelectAction.Select;
                        ddlfavcats.Items.Add(new ListItem(row["CategoryName"].ToString(), row["CategoryID"].ToString()));
                    }
                }
                //else                    
                //ddlfavcats.Visible = false;
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }


}