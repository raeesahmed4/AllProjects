﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CodenameRabbitFoot.BusinessLogic;
using System.Data;
using System.Text;
using System.Web.Services;
using System.Text.RegularExpressions;
using System.IO;

public partial class MarketPlace_EditPost : System.Web.UI.Page
{
    public static int EditorID;
    int ListingID { get; set; }

    protected void Page_Load(object sender, EventArgs e)
    {
        this.Master.HideLinkApps();
        this.ListingID = Web.RecordID;


        if (!Page.IsPostBack)
        {
            LoadUrls();
            Listings listing = new Listings();
            listing.LoadByPrimaryKey(this.ListingID);
            if (listing.RowCount > 0)
            {
                LoadListingCategories(listing.ListingTypeID);
                this.contentAraeaListingFields.InnerHtml = GenerateListingFields(listing.ListingTypeID, listing.CategoryID);

                LoadShippingLocation();
                LoadShippingTypes();
                LoadPaymentOptions();
            }


            // Load the Listing Shipping Information

            //1. Shipping Locaiton
            if (!string.IsNullOrEmpty(listing.s_ShippingLocationID))
            {
                this.ddlShippingLocations.SelectedValue = listing.s_ShippingLocationID;
            }

            //2. Load the Shipping Methods
            ListingShippingTypes shippingTypes = new ListingShippingTypes();
            shippingTypes.Where.ListingID.Value = this.ListingID;
            shippingTypes.Query.Load();
            if (shippingTypes.RowCount > 0)
            {
                foreach (ListItem item in this.chkShippingTypes.Items)
                {
                    item.Selected = shippingTypes.DefaultView.Table.Select("ShippingTypeID=" + item.Value).Count() > 0;
                }
            }

            //3. Shipping , addtional fee
            this.txtShippingFee.Text = listing.s_ShippingFee;
            this.txtAdditionalShippingFee.Text = listing.s_AdditionalFee;
            this.rdlShippingFeeUnitOrLot.SelectedValue = listing.s_ShippingFeeUnit.ToString().Equals("1") ? "1" : "0";

            // Load Payment Information
            ListingPaymentTypes paymentTypes = new ListingPaymentTypes();
            paymentTypes.Where.ListingID.Value = this.ListingID;
            paymentTypes.Query.Load();
            if (paymentTypes.RowCount > 0)
            {
                foreach (ListItem item in this.ckhPaymentTypes.Items)
                {
                    item.Selected = paymentTypes.DefaultView.Table.Select("PaymentTypeID=" + item.Value).Count() > 0;
                }
            }

            if (listing.ListingTypeID == 1)
            {
                imageselectedpost.ImageUrl = "../App_Themes/Space/Images/eOpen post_tp_world Icons/sale.png";
                lblselectepost.Text = "For Sale";
            }
            if (listing.ListingTypeID == 2)
            {
                imageselectedpost.ImageUrl = "App_Themes/Space/Images/eOpen post_tp_world Icons/rent.png";
                lblselectepost.Text = "For Rent";
            }
            else if (listing.ListingTypeID == 3)
            {
                imageselectedpost.ImageUrl = "App_Themes/Space/Images/eOpen post_tp_world Icons/service.png";
                lblselectepost.Text = "Services";
            }
            else if (listing.ListingTypeID == 4)
            {
                imageselectedpost.ImageUrl = "App_Themes/Space/Images/eOpen post_tp_world Icons/jobs.png";
                lblselectepost.Text = "Jobs";
            }
            else if (listing.ListingTypeID == 5)
            {
                imageselectedpost.ImageUrl = "App_Themes/Space/Images/eOpen post_tp_world Icons/personal.png";
                lblselectepost.Text = "Personals";
            }
            else if (listing.ListingTypeID == 6)
            {
                imageselectedpost.ImageUrl = "App_Themes/Space/Images/eOpen post_tp_world Icons/coupon.png";
                lblselectepost.Text = "Coupons and Discounts";
            }

            imageselectedpost.Visible = true;
            lblselectepost.Visible = true;
        }
    }

    private void LoadUrls()
    {
        SystemObjectFiles systemObjectFiles = new SystemObjectFiles();
        systemObjectFiles.Where.ObjectID.Value = this.ListingID;
        systemObjectFiles.Query.Load();

        if (systemObjectFiles.RowCount > 0)
        {
            foreach (DataRow row in systemObjectFiles.DefaultView.Table.Rows)
            {
                string fileUrl = string.Empty;
                string fileTypeID = row["FileTypeID"].ToString().Trim();

                if (fileTypeID.Equals("3") || fileTypeID.Equals("4")) // textLink & video link
                {
                    fileUrl = row["URL"].ToString().Trim().ToUpper();
                    if (fileUrl.Contains("TINYURLS.ASHX?TINYURLID="))
                    {
                        fileTypeID = fileUrl.Substring(fileUrl.IndexOf("TINYURLID=") + 10);
                        fileTypeID = fileTypeID.Substring(0, fileTypeID.IndexOf("'"));
                        int urlID = 0;
                        if (int.TryParse(fileTypeID, out urlID))
                        {
                            TinyUrls url = new TinyUrls();
                            url.LoadByPrimaryKey(urlID);
                            if (url.RowCount > 0)
                            {
                                if (row["FileTypeID"].ToString().Trim().Equals("3"))
                                {
                                    this.txtLink.Text = url.TinyUrl;
                                }
                                else
                                {
                                    this.txtURL.Value = url.TinyUrl;
                                    this.txtVideoLink.Value = url.TinyUrl;
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private string GenerateListingFields(int listingTypeID, int CategoryID)
    {
        this.ddlCategory.SelectedValue = CategoryID.ToString();

        StringBuilder sb = new StringBuilder();
        string result = "";
        StringBuilder oneRowHTML = new StringBuilder();
        try
        {
            DataTable dtControls = new DataTable();

            dtControls = ListingExtendedFields.GetExtendedFields(listingTypeID, CategoryID);
            List<ListingExtendedFields> fieldsData = LoadListingData();
            sb.Append("<table cellspaciing=3 cellpadding=3 border=0 bordercolor=red><tr><td>");
            //to set price each, quantity and Sell separately ddl in a single row
            int count = 0;
            string txtControl = "";
            string makeOfferBlock = "";
            //string containerID = Guid.NewGuid().ToString().Replace("-", "");

            foreach (DataRow dr in dtControls.Rows)
            {
                txtControl = dr["FieldID"].ToString();
                string controlName = dr["FieldID"].ToString();
                string data = "";
                var dataField = fieldsData.Where(f => f.FieldID.ToString() == txtControl).FirstOrDefault();
                if (dataField != null)
                {
                    data = dataField.Data.ToString();
                }

                if (txtControl == "4" || txtControl == "10" || txtControl == "24")// 4=Quantity, 10=PriceEach, 23=SellSeprately
                {
                    if (count == 0)
                        sb.Append("##REPLACE##");

                    if (dr["FieldTypeID"].ToString() == "1") //textbox
                    {
                        oneRowHTML.Append("<Tr>");

                        string priceEach = "";

                        if (txtControl == "10")
                        {
                            priceEach = "&nbsp;<span style='font-size:13px;'>$</span>";
                            makeOfferBlock = "#makeofferblock#";
                        }

                        if (dr["IsRequired"].ToString() == "1")
                        {
                            oneRowHTML.Append("<td width=120>" + dr["FieldDescription"].ToString() + ":</td>");
                            oneRowHTML.Append("<td height=30><div style='display:inline;' id=PRICE_EACH_" + dr["FieldID"].ToString() + "><input name='" + dr["FieldID"].ToString() + "' title='" + dr["FieldDescription"].ToString() + "' value='" + (string.IsNullOrEmpty(data) ? dr["FieldDescription"].ToString() : data)
                                + "' class='InnerTextBox' type='text'  id='txt_Required_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString()
                                + "'  style='width:180px;' onfocus =\"Focus(this,'" + dr["FieldDescription"].ToString() + "');\" onblur=\"Blur(this,'" + dr["FieldDescription"].ToString() + "','" + dr["RegularExpression"].ToString() + "','" + dr["ValidationError"].ToString() + "');\" />"
                                + priceEach + "&nbsp;<span style='color: #ff002a;'>*</span><span style='color: #ff002a;' id='sp_txt_Required_" +
                                dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'></span><span style='color: #ff002a;display:none' id='sp_error_txt_Required_"
                                + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'>" + dr["RequiredError"].ToString() + "</span></div>&nbsp;");

                            oneRowHTML.Append(makeOfferBlock);
                        }
                        else
                        {
                            oneRowHTML.Append("<Td><input name='" + dr["FieldID"].ToString() + "' title='" + dr["FieldDescription"].ToString() + "' value='" + (string.IsNullOrEmpty(data) ? dr["FieldDescription"].ToString() : data) + "' class='InnerTextBox' type='text'  id='txt_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'  style='width:110px;' onfocus =\"Focus(this,'" + dr["FieldDescription"].ToString() + "');\" onblur=\"Blur(this,'" + dr["FieldDescription"].ToString() + "','" + dr["RegularExpression"].ToString() + "','" + dr["ValidationError"].ToString() + "');\" />" + priceEach + "&nbsp;<span style='color: #ff002a;' id='sp_txt_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'></span>");
                        }


                        oneRowHTML.Append("</td></tr>");
                    }
                    else if (dr["FieldTypeID"].ToString() == "3") //checkbox
                    {
                        oneRowHTML.Append("<td valign='middle'  align=\"center\">");
                        if (dr["FieldName"].ToString().Equals("MakeOffer"))
                        {
                            if (listingTypeID == 1)
                            {
                                oneRowHTML.Replace("#makeofferblock#", "<input type='checkbox' id='chk_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "' title='" + dr["FieldDescription"].ToString() + "' onclick='CheckBoxSelectionChanged(this);' />&nbsp;" + dr["FieldDescription"].ToString());
                                //oneRowHTML.Append("<input type='checkbox' id='chk_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "' title='" + dr["FieldDescription"].ToString() + "' onclick='CheckBoxSelectionChanged(this);' />&nbsp;" + dr["FieldDescription"].ToString());
                            }
                        }
                        else
                        {
                            oneRowHTML.Append("<input type='checkbox' id='chk_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "' title='" + dr["FieldDescription"].ToString() + "'  />&nbsp;" + dr["FieldDescription"].ToString());
                        }
                        oneRowHTML.Append("</td>");
                    }
                    count++;

                }
                else
                {
                    if (dr["FieldTypeID"].ToString() == "1")//textbox
                    {
                        sb.Append("<tr><td colspan='2'>");

                        if (dr["IsRequired"].ToString() == "1")
                            sb.Append("<div><input name='" + dr["FieldID"].ToString() + "' title='" + dr["FieldDescription"].ToString() + "' value='" + (string.IsNullOrEmpty(data) ? dr["FieldDescription"].ToString() : data) + "' class='InnerTextBox' type='text'  id='txt_Required_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'  style='width:300px;' onfocus =\"Focus(this,'" + dr["FieldDescription"].ToString() + "');\" onblur=\"Blur(this,'" + dr["FieldDescription"].ToString() + "','" + dr["RegularExpression"].ToString() + "','" + dr["ValidationError"].ToString() + "');\" />&nbsp;<span style='color: #ff002a;'>*</span><span style='color: #ff002a;' id='sp_txt_Required_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'></span><span style='color: #ff002a;display:none' id='sp_error_txt_Required_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'>" + dr["RequiredError"].ToString() + "</span>");
                        else
                            sb.Append("<input name='" + dr["FieldID"].ToString() + "' title='" + dr["FieldDescription"].ToString() + "' value='" + (string.IsNullOrEmpty(data) ? dr["FieldDescription"].ToString() : data) + "'e  class='InnerTextBox' type='text'  id='txt_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'  style='width:300px;' onfocus =\"Focus(this,'" + dr["FieldDescription"].ToString() + "');\" onblur=\"Blur(this,'" + dr["FieldDescription"].ToString() + "','" + dr["RegularExpression"].ToString() + "','" + dr["ValidationError"].ToString() + "');\" />&nbsp;<span style='color: #ff002a;' id='sp_txt_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'></span>");
                        sb.Append("</td></tr>");
                    }
                    else if (dr["FieldTypeID"].ToString() == "2")//combobox
                    {
                        sb.Append("<tr><td>" + dr["FieldDescription"].ToString() + ":</td><Td>");

                        if (dr["IsRequired"].ToString() == "1")
                        {
                            sb.Append("<select name='" + dr["FieldID"].ToString() + "' style=\"width: 190px\" id='dynamic_ddl_Required_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "' style='width:120px' class='InnerTextBox' title='" + dr["FieldDescription"].ToString() + "' onfocus =\"Focus(this,'" + dr["FieldDescription"].ToString() + "');\" >");
                            //sb.Append("<option>" + dr["FieldDescription"].ToString() + "</option>");
                            //load combobox values
                            sb.Append(Web.LoadFieldValues(Convert.ToInt32(dr["FieldID"]), dr["FieldName"].ToString()));
                            sb.Append("</select> ");
                            sb.Append("&nbsp;<span style='color: #ff002a;'>*</span><span style='color: #ff002a;' id='sp_cbx_Required_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'></span><span style='color: #ff002a;display:none' id='sp_error_dynamic_ddl_Required_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'>" + dr["RequiredError"].ToString() + "</span>");
                        }
                        else
                        {
                            sb.Append("<select name='" + dr["FieldID"].ToString() + "' id='dynamic_ddl_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "' style='width:120px' class='mycombo' title='" + dr["FieldDescription"].ToString() + "' onfocus =\"Focus(this,'" + dr["FieldDescription"].ToString() + "');\" >");
                            //sb.Append("<option>" + dr["FieldDescription"].ToString() + "</option>");
                            //load combobox values
                            sb.Append(Web.LoadFieldValues(Convert.ToInt32(dr["FieldID"]), dr["FieldName"].ToString()));
                            sb.Append("</select> ");
                        }

                        sb.Append("</td></tr>");

                    }
                    else if (dr["FieldTypeID"].ToString() == "3")//checkbox
                    {
                        if (dr["FieldName"].ToString().Equals("MakeOffer"))
                        {
                            if (listingTypeID == 1)
                            {
                                sb.Append("<input  type='checkbox' id='chk_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "' title='" + dr["FieldDescription"].ToString() + "' onclick='CheckBoxSelectionChanged(this);' />" + dr["FieldDescription"].ToString());
                            }
                        }
                        else
                        {
                            sb.Append("<input  type='checkbox' id='chk_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "' title='" + dr["FieldDescription"].ToString() + "'  />" + dr["FieldDescription"].ToString());
                        }
                    }
                    else if (dr["FieldTypeID"].ToString() == "4")//textarea
                    {
                        if (dr["IsRequired"].ToString() == "1")
                            sb.Append("<textarea name='" + dr["FieldID"].ToString() + "' style=visibility:hidden;'  title='" + dr["FieldDescription"].ToString() + "' id='txt_Required_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'  class='InnerTextBox' rows='7' cols='5' style='width:397px;font-size:15px;' onfocus =\"Focus(this,'" + dr["FieldDescription"].ToString() + "');\" onblur=\"Blur(this,'" + dr["FieldDescription"].ToString() + "','" + dr["RegularExpression"].ToString() + "','" + dr["ValidationError"].ToString() + "');\" >" + (string.IsNullOrEmpty(data) ? dr["FieldDescription"].ToString() : data) + "</textarea>&nbsp;<span style='color: #ff002a;'>*</span><span style='color: #ff002a;' id='sp_txt_Required_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'></span><span style='color: #ff002a;display:none' id='sp_error_txt_Required_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'>" + dr["RequiredError"].ToString() + "</span>");
                        else
                            sb.Append("<textarea name='" + dr["FieldID"].ToString() + "' style=visibility:hidden;'  title='" + dr["FieldDescription"].ToString() + "' id='txt_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'  class='InnerTextBox' rows='7' cols='5' style='width:397px;font-size:15px;' onfocus =\"Focus(this,'" + dr["FieldDescription"].ToString() + "');\" onblur=\"Blur(this,'" + dr["FieldDescription"].ToString() + "','" + dr["RegularExpression"].ToString() + "','" + dr["ValidationError"].ToString() + "');\" >" + (string.IsNullOrEmpty(data) ? dr["FieldDescription"].ToString() : data) + "</textarea>&nbsp;<span style='color: #ff002a;' id='sp_txt_" + dr["FieldName"].ToString() + "_" + dr["FieldID"].ToString() + "'></span>");

                        // sb.Append("</td></tr>");

                    }
                    else if (dr["FieldTypeID"].ToString() == "6")//Formated TextArea
                    {
                        //sb.Append("<input type='hidden' id='hdshowEditor' value='true'/>");
                        // EditorID = Convert.ToInt32(dr["FieldID"].ToString());
                        // this.txtFormatedText.Text = data;
                        sb.AppendFormat("<tr><td colspan='2'><textarea style='width: 600px; height: 120px;' cols='20' rows='2' name='{0}'>{1}</textarea>", dr["FieldID"].ToString(), data);
                        //  descriptionTexexAreaHtml = string.Format("<textarea style='width: 600px; height: 120px;' cols='20' rows='2' name='{0}'>{1}</textarea>", dr["FieldID"].ToString(), data);
                    }

                    //put the hidden out of it
                    sb.Append("</td></tr>");
                }
            }

            oneRowHTML.Replace("#makeofferblock#", ""); // In the end if there any placeholder exists...just remove it
            sb.Append("</table>");

            //scripts
            sb.Append("<script type=\"text/javascript\"> ");
            //onfocus event
            sb.Append("function Focus(obj,title) {");
            sb.Append("var id = obj.id;");
            sb.Append("$('#sp_'+ id).html('');");
            sb.Append("$('#sp_error_'+ id).hide('');");
            sb.Append("if ($('#' + id).val() == title) {");
            sb.Append("$('#' + id).val('');");
            sb.Append("$('#' + id).removeClass('red');");
            //sb.Append("$('#' + id).removeClass('InnerTextBox');");
            sb.Append("}");
            sb.Append(" }");
            //on blur event
            sb.Append("function Blur(obj, title, regex, message) {");
            sb.Append("var id = obj.id;");
            sb.Append("if ($('#' + id).val() == '') {");
            sb.Append("$('#' + id).val(title);");
            //sb.Append("$('#' + id).addClass('InnerTextBox');");
            sb.Append("}");
            //regex 
            sb.Append("var Expression = new RegExp(regex);");//using its Regex
            sb.Append("if ($('#' + id).val().match(Expression) == null) {");
            sb.Append("if($('#' + id).val()!=title){");
            sb.Append("$('#sp_'+ id).html(message);");
            sb.Append("return false;");
            sb.Append("}");
            sb.Append("}");
            sb.Append(" }");
            sb.Append("</script>");
        }
        catch (Exception ex) { Web.LogError(ex); }
        result = sb.ToString();
        result = result.Replace("##REPLACE##", "<tr>" + oneRowHTML.ToString() + "</tr>");
        return result;
    }

    private List<ListingExtendedFields> LoadListingData()
    {
        List<ListingExtendedFields> fields = new List<ListingExtendedFields>();

        ListingExtendedFields lef = new ListingExtendedFields();
        lef.Where.ObjectID.Value = this.ListingID;
        lef.Where.IsActive.Value = true;
        lef.Query.Load();
        if (lef.RowCount > 0)
        {
            foreach (DataRow row in lef.DefaultView.Table.Rows)
            {
                ListingExtendedFields field = new ListingExtendedFields();
                field.AddNew();
                field.ListingExtendedFieldID = Convert.ToInt32(row["ListingExtendedFieldID"]);
                field.FieldID = Convert.ToInt32(row["FieldID"]);
                field.SystemObjectID = Convert.ToInt32(row["SystemObjectID"]);
                field.Data = row["Data"].ToString();
                field.ObjectID = Convert.ToInt32(row["ObjectID"]);
                fields.Add(field);
            }
        }

        return fields;
    }

    private void SaveAdditionalInfo(int ListingID, List<int> categoryFields)
    {
        try
        {
            //if (categoryFields.Contains(12))
            //{
            //    ListingShippingTypes ShipTypes = null;
            //    foreach (ListItem sTypes in chkShippingTypes.Items)
            //    {
            //        if (sTypes.Selected == true)
            //        {
            //            ShipTypes = new ListingShippingTypes();
            //            ShipTypes.AddNew();
            //            ShipTypes.ShippingTypeID = Convert.ToInt32(sTypes.Value);
            //            ShipTypes.ListingID = ListingID;
            //            ShipTypes.Save();
            //        }
            //    }
            //}

            //if (categoryFields.Contains(13))
            //{
            //    ListingPaymentTypes PaymentTypes = null;
            //    foreach (ListItem pTypes in ckhPaymentTypes.Items)
            //    {
            //        if (pTypes.Selected == true)
            //        {
            //            PaymentTypes = new ListingPaymentTypes();
            //            PaymentTypes.AddNew();
            //            PaymentTypes.ListingID = ListingID;
            //            PaymentTypes.PaymentTypeID = Convert.ToInt32(pTypes.Value);
            //            PaymentTypes.Save();
            //        }
            //    }
            //}

            //if (categoryFields.Contains(15))
            //{
            //    Web.SaveFiles(Convert.ToInt32(SystemObjects.Listings), ListingID, fupPhoto, fupDocument, txtLink, txtURL, 1);
            //}
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        UpdateListing(Web.RecordID);
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Web.Redirect("~/MarketPlace/Default.aspx");
    }


    //xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

    public void UpdateListing(int listingID)
    {

        try
        {
            string title = string.Empty;
            bool ApprovedMember = ApprovedMembers.CheckIfApproved(Web.SessionMembers.MemberID);
            Listings listing = new Listings();
            listing.LoadByPrimaryKey(listingID);
            if (listing.RowCount < 1)
            {
                throw new Exception("Unable to load the Listing.");
            }

            //1. Save Listing Category
            listing.CategoryID = Convert.ToInt32(this.ddlCategory.SelectedValue);

            //2. Save ListingExtendedFields data            
            List<ListingExtendedFields> listingFields = LoadListingData();
            foreach (ListingExtendedFields field in listingFields)
            {
                ListingExtendedFields lef = new ListingExtendedFields();
                lef.LoadByPrimaryKey(field.ListingExtendedFieldID);

                if (Request.Form[field.FieldID.ToString()] != null)
                {
                    if (lef.RowCount > 0)
                    {
                        lef.Data = Request.Form[field.FieldID.ToString()].ToString();

                    }
                }
                else if (field.FieldID == 5)
                {
                    lef.Data = this.txtFormatedText.Text;
                }
                lef.Save();

                if (field.FieldID == 20 && !string.IsNullOrEmpty(lef.Data))
                {
                    title = lef.Data;
                }
            }

            //3. Save Shipping Options
            foreach (ListItem item in this.chkShippingTypes.Items)
            {
                Fx.ExecuteNonQuery("EN_UpdateListingShippingMethod", listingID, item.Value, item.Selected ? "ADD" : "REMOVE");
            }
            decimal shippingFee = 0, additionalFee = 0;
            decimal.TryParse(txtShippingFee.Text, out shippingFee);
            decimal.TryParse(txtAdditionalShippingFee.Text, out additionalFee);
            listing.ShippingFee = shippingFee;
            listing.AdditionalFee = additionalFee;
            //4. Save Payment Options
            foreach (ListItem item in this.ckhPaymentTypes.Items)
            {
                Fx.ExecuteNonQuery("EN_UpdateListingPaymentTypes", listingID, item.Value, item.Selected ? "ADD" : "REMOVE");
            }

            listing.Save();

            // Save the files.
            string webPageName = Path.GetFileNameWithoutExtension(Request.FilePath);
            var filesList = Web.GetSessionFiles(webPageName);
            Web.SaveFiles(600, listing.ListingID, filesList, this.txtLink.Text, this.txtURL.Value, 1);
            Web.ClearSessionFiles(webPageName);

            if (ApprovedMember)
            {
                Session["Message"] = "Listing " + "\"" + title + "\"" + " has been updated successfully.";
                var templateKeys = new System.Collections.Specialized.StringDictionary();
                templateKeys.Add("#listingtype#", ListingTypes.GetTypeName(listing.ListingTypeID));
                templateKeys.Add("#listingname#", title);
                templateKeys.Add("#viewlink#", "../MarketPlace/ItemDetails.aspx?Action=View&RecordID=#encrypt#" + listing.ListingID + "#endencrypt#");

                Web.AddActivityLog(Web.SessionMembers.MemberID, 46, templateKeys, listing.ListingID, listing.ListingTypeID, false, 0);

                try
                {
                    var TemplateKeys = new System.Collections.Specialized.StringDictionary();
                    TemplateKeys.Add("#email_header#", Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER"));
                    TemplateKeys.Add("#fullname#", Web.SessionMembers.FullName);
                    TemplateKeys.Add("#lot_title#", title);
                    TemplateKeys.Add("#dealing_floor_summary#", Web.SystemConfigs.GetKey("SITE_URL") + "MarketPlace/");
                    TemplateKeys.Add("#link_log_myeoffer#", Web.SystemConfigs.GetKey("SITE_URL"));
                    TemplateKeys.Add("#email_footer#", Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER"));
                    Web.SendMail(Web.SessionMembers.Email, Web.SystemConfigs.GetKey("REG_EMAIL"), 308, TemplateKeys);
                }
                catch (Exception ex)
                {
                    Web.LogError(ex);
                }
            }
            else
            {
                Session["POST_MESSAGE"] = @"Success! Your updated listing is being reviewed by the administrator and will post to the Marketplace shortly.<br /><br />Please note: If you would like to be preapproved for automatic posting, please complete your company profile. Upon clearance, all your listings will immediately appear in the Marketplace";

                Session["Message"] = "The listing " + "\"" + title + "\"" + " is under review, it will be updated live shortly after administrative approval.";
            }

            Web.Redirect("~/MarketPlace/ItemDetails.aspx?Action=View&RecordID=" + Secure.Encrypt(listing.ListingID));
        } 
        catch (Exception ex)
        {
            Web.LogError(ex);
            Session["Message"] = "There was some problem while updating the listing, please try again.";
            Web.Redirect("~/Post.aspx?" + Request.Url.Query);
        }
    }

    public void LoadListingCategories(int ListTypeID)
    {
        try
        {
            ddlCategory.Items.Clear();
            DataTable dtCats = new DataTable();
            dtCats = CategorizedListingTypes.GetAllListingTypeCategories(ListTypeID);

            foreach (DataRow dr in dtCats.Rows)
            {
                //ddlCategory.Items.Add(new RadComboBoxItem(dr["CategoryName"].ToString(), dr["CategoryID"].ToString()));
                ddlCategory.Items.Add(new ListItem(dr["CategoryName"].ToString(), dr["CategoryID"].ToString()));
            }
            //ddlCategory.Items.Insert(0, new RadComboBoxItem("...Choose a Category...", "-1"));
            ddlCategory.Items.Insert(0, new ListItem("...Choose a Category...", "-1"));
            ddlCategory.SelectedIndex = 0;
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }

    public void LoadShippingLocation()
    {
        DataTable result = null;
        try
        {
            result = ShippingLocationTypes.GetShippingLocations(1);
            ddlShippingLocations.DataSource = result;
            ddlShippingLocations.DataTextField = "ShippingLocationName";
            ddlShippingLocations.DataValueField = "ShippingLocationID";
            ddlShippingLocations.DataBind();
            //ddlShippingLocations.Items.Insert(0, new RadComboBoxItem("...Shipping Location...", "-1"));
            ddlShippingLocations.Items.Insert(0, new ListItem("...Shipping Location...", "-1"));

            ddlShippingLocations.Items.FindByText("See Description").Selected = true;
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }

    public void LoadPaymentOptions()
    {
        try
        {
            PaymentTypes paymentTypes = new PaymentTypes();
            paymentTypes.Query.AddOrderBy(PaymentTypesSchema.PaymentName);
            paymentTypes.Query.AddResultColumn(PaymentTypesSchema.PaymentName);
            paymentTypes.Query.AddResultColumn(PaymentTypesSchema.PaymentTypeID);
            paymentTypes.Query.AddResultColumn(PaymentTypesSchema.IsActive);
            paymentTypes.Where.IsActive.Value = 1;
            paymentTypes.Query.Load();

            ckhPaymentTypes.DataSource = paymentTypes.DefaultView.Table;
            ckhPaymentTypes.DataTextField = "PaymentName";
            ckhPaymentTypes.DataValueField = "PaymentTypeID";
            ckhPaymentTypes.DataBind();
            //ckhPaymentTypes.SelectedIndex = ckhPaymentTypes.Items.Count - 4;
            //ckhPaymentTypes.Items[3].Selected = true;

            for (int i = 0; i < ckhPaymentTypes.Items.Count; i++)
            {
                if (ckhPaymentTypes.Items[i].Text == "See Description")
                    ckhPaymentTypes.Items[i].Selected = true;
            }

        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }

    public void LoadShippingTypes()
    {
        try
        {
            ShippingTypes shippingTypes = new ShippingTypes();
            shippingTypes.Query.AddOrderBy(ShippingTypesSchema.ShippingName);
            shippingTypes.Query.AddResultColumn(ShippingTypesSchema.ShippingName);
            shippingTypes.Query.AddResultColumn(ShippingTypesSchema.ShippingTypeID);
            shippingTypes.Query.AddResultColumn(ShippingTypesSchema.IsActive);
            shippingTypes.Query.AddOrderBy(ShippingTypesSchema.ShippingTypeID, NCI.EasyObjects.WhereParameter.Dir.ASC);
            shippingTypes.Where.IsActive.Value = 1;
            shippingTypes.Query.Load();

            chkShippingTypes.DataSource = shippingTypes.DefaultView.Table;


            chkShippingTypes.DataTextField = "ShippingName";
            chkShippingTypes.DataValueField = "ShippingTypeID";
            chkShippingTypes.DataBind();
            chkShippingTypes.SelectedIndex = chkShippingTypes.Items.Count - 3;
            // ckhPaymentTypes.Items[7].Selected = true;

        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }
}