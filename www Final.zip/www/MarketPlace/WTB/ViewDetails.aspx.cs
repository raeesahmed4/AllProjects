﻿using System;
using System.Collections;
using System.Data;
using CodenameRabbitFoot.BusinessLogic;
using VisualSoft.VSharp.Utils;

public partial class MarketPlace_WTB_ViewDetails : System.Web.UI.Page
{
    //MasterPages_Public master = null;

    //    DataSet resultData = null;
    DataTable resultTable = null;
    public static bool ImagesAvailable = false;
    public static bool DocsAvailable = false;
    public static bool DescriptionAvailable = false;
    public DateTime SystemCurrentTime = DateTime.Now;
    public DateTime EndDate = new DateTime();
    public int ItemDuration = 0;
    protected string showreason = "You can not make offer";
    public static bool enablinks = true;
    protected string ItemDescription = string.Empty;
    protected string pageheading = "View Detail";
    protected bool ShowBuyerInfo = true;
    protected static string returnurl = "";

    protected void Page_Load(object sender, EventArgs e)
    {
        //  master = this.Master as MasterPages_Public;
        //master.ShowMessageBox = false;
        //MessageBox.Visible = false;
        //this.Master.ShowPageIcon = false;
        //this.master.HeadingIcon = "~/Images/Icons/view-detail.png";
        //this.master.PageHeading = "Detail of Item";
        try
        {
            if (!IsPostBack)
            {
                if (Web.RecordID > 0)
                {
                    if (AllowToView())
                    {
                        if (IsPrivate())
                        {
                            LoadData();
                            //ToggleButtons();
                            GetTrustScore();
                        }
                      //  else
                            //multiViewControl.ActiveViewIndex = 1;
                    }
                    //else
                    {
                    //    multiViewControl.ActiveViewIndex = 2;
                    }
                }
                Web.LogUserActivity(Radium.Platform.Core.UserActivity.View);
            }
        }
        catch (Exception ex)
        {
            //  master.ShowMessage(ex.GetBaseException().ToString(), "error");
            //Log.Write("ViewDetails:000", ex.GetBaseException().ToString(), ex);
            Web.LogError(ex);
        }
    }

    protected bool AllowToView()
    {
        bool result = true;
        try
        {
            if (Web.RecordID > 0)
            {
                Items item = new Items();
                item.LoadByPrimaryKey(Web.RecordID);
                if (item.RowCount > 0)
                {
                    if (item.StatusCode != 100 && item.StatusCode != 800 && item.MemberID != Web.SessionMembers.MemberID)
                    {
                        result = false;
                    }
                }
            }
        }
        catch (Exception exp)
        {

            Web.LogError(exp);
        }
        return result;
    }

    private bool IsPrivate()
    {
        bool result = false;

        try
        {
            if (Web.IsMemberSession)
            {
                PrivateItems items = new PrivateItems();
                items.Query.AddResultColumn(PrivateItemsSchema.ItemID);
                items.Query.AddResultColumn(PrivateItemsSchema.PrivateTo);
                items.Where.ItemID.Value = Web.RecordID;
                items.Query.Load();
                if (items.RowCount > 0)
                {
                    if (items.PrivateTo == Web.SessionMembers.MemberID)
                        result = true;
                    else
                    {
                        Items item = new Items();
                        item.LoadByPrimaryKey(Web.RecordID);
                        if (item.MemberID == Web.SessionMembers.MemberID)
                            result = true;
                        else
                            result = false;
                    }
                }
                else
                    result = true;
            }
            else
                result = true;
        }
        catch (Exception ex)
        {
            //Log.Write("Error:000", ex.GetBaseException().ToString(), ex);
            Web.LogError(ex);
        }

        return result;
    }

    void ToggleButtons()
    {
        try
        {
            if (Web.IsMemberSession)
            {
                Items item = new Items();
                item.LoadByPrimaryKey(Web.RecordID);
                if (item.RowCount > 0)
                {


                    if (item.StatusCode == 100)
                    {
                        if (Web.SessionMembers.MemberID == item.MemberID)
                        {
                            lnkBtnAddTrust.Enabled = false;
                            lnkBtnAddUnTrust.Enabled = false;
                            lnkBtnAddTrust.CssClass = "rateUp";
                            lnkBtnAddUnTrust.CssClass = "rateDown";
                            //  lnkAddSeller.Enabled = false;
                            btnAddasCustomer.Visible = false;
                            btnAddasSupplier.Visible = false;
                            enablinks = false;
                            showreason = "You cannot make Offer on your own item";
                            //master.ShowMessage("You cannot make Offer on your own item", "warning");
                        }
                        else
                        {
                            ItemOffers offers = new ItemOffers();
                            offers.Query.AddResultColumn(ItemOffersSchema.ItemID);
                            offers.Query.AddResultColumn(ItemOffersSchema.OfferBy);
                            offers.Query.AddResultColumn(ItemOffersSchema.OfferStatusID);
                            offers.Where.ItemID.Value = Web.RecordID;
                            offers.Where.OfferBy.Value = Web.SessionMembers.MemberID;
                            offers.Query.Load();
                            if (offers.RowCount > 0)
                            {
                                enablinks = false;
                                showreason = "You have already made offer on this Item";
                                //master.ShowMessage("You have already made offer on this Item", "warning");
                            }
                            else
                            {
                                enablinks = true;


                            }

                            // lnkAddSeller.Enabled = true;
                            btnAddasCustomer.Visible = true;
                            btnAddasSupplier.Visible = true;
                        }
                    }
                    else
                    {
                        enablinks = false;
                        showreason = "Item is not approved by admin or it has been sold";

                    }
                    if (System.DateTime.Now > item.ItemEndDate)
                    {
                        showreason = "Item has been Expired";
                        enablinks = false;
                        lblTimeRemaining.Text = "Expired";
                    }
                    //
                }
                else
                {
                    //        master.ShowMessage("Item Not Found", "warning");
                }

                //
            }
            else
            {
                showreason = "0";
                returnurl = "~/MarketPlace/WTB/ViewDetails.aspx" + Request.Url.Query;
            }
            ToggleRatingButtons();
        }
        catch (Exception ex)
        {
            //master.MessageBoxText = ex.GetBaseException().ToString();
            //master.ShowMessageBox = true;

            //Log.Write("ViewLot : 003", ex.GetBaseException().ToString(), ex);
            Web.LogError(ex);
        }

    }


    protected void btnAlreadyPosted_Click(object sender, EventArgs e)
    {
        Web.Redirect("~/MarketPlace/WTB/SubmitLinks.aspx?Action=View&RecordID=" + Secure.Encrypt(Web.RecordID));
    }

    private void LoadData()
    {
        try
        {
            Items item = new Items();
            item.LoadByPrimaryKey(Web.RecordID);
            if (item.RowCount > 0)
            {
                Session["MemberID"] = item.MemberID;
                pageheading = "Detail of <u>" + item.s_ItemName + "</u>";
                lblItemName.Text = item.ItemName;
                lblLotOffer.Text = (item.DesiredPrice > 0) ? Web.GetDefaultCurrencyCode() + " " + item.s_DesiredPrice : "Open for Offers";
                lblQuantity.Text = item.s_Quantity;
                ItemDescription = item.ItemDescription;
                //  lblDescription.Text = item.ItemDescription;
                EndDate = item.ItemEndDate;
                ItemDuration = item.ItemDuration;
                lblEndDate.Text = Convert.ToDateTime(item.ItemEndDate).ToString("dd-MMM-yyyy");
                // lblTimeRemaining.Text = GetTimeRemaining(item.ItemEndDate);

                lblShippingLocation.Text = GetShippingLocationName(item.ItemLocationID);
                LoadPaymentTypes();
                LoadShippingMethods();
                LoadImages();

                ItemConditions conditions = new ItemConditions();
                resultTable = conditions.GetItemConditions(Web.RecordID);
                if (resultTable.Rows.Count > 0)
                {
                    dlstConditions.DataSource = resultTable;
                    dlstConditions.DataBind();
                }

                Members member = new Members();
                member.LoadByPrimaryKey(item.MemberID);
                if (member.RowCount > 0)
                {
                    if (Web.IsMemberSession)
                        lblName.Text = "<a href='/Contacts/ViewProfile.aspx?RecordID=" + Secure.Encrypt(member.MemberID) + "'><span class=\"" + Web.GetProfileClass(member.MemberID, Web.SessionMembers.MemberID) + "\">" + member.UserName + "</span></a>";
                    else
                        lblName.Text = "<a href='/Contacts/ViewProfile.aspx?RecordID=" + Secure.Encrypt(member.MemberID) + "'><span class=\"" + Web.GetProfileClass(member.MemberID, null) + "\">" + member.UserName + "</span></a>";

                    ShippingAddresses address = new ShippingAddresses();
                    address.Query.AddResultColumn(ShippingAddressesSchema.City);
                    address.Query.AddResultColumn(ShippingAddressesSchema.CountryID);
                    address.Query.AddResultColumn(ShippingAddressesSchema.State);
                    address.Query.AddResultColumn(ShippingAddressesSchema.MemberID);
                    address.Where.MemberID.Value = item.MemberID;
                    address.Query.Load();
                    if (address.RowCount > 0)
                    {
                        Country country = new Country();
                        lblCity.Text = string.Concat(address.s_City, ", ", address.s_State, " ,", country.GetCountryName(address.CountryID));
                    }
                    lblDealerOffer.Text = GetLotsCount(item.MemberID);
                }

                GetTrustScore();
                if (Web.IsMemberSession)
                    ToggleButtons();
                else
                {
                    lnkBtnAddTrust.Enabled = false;
                    lnkBtnAddUnTrust.Enabled = false;
                }
                ShowBuyerInfo = true;
                AllowAddInContact(item.MemberID);
            }
            else
            {
                //  master.ShowMessage("Item Not Found", "warning");
                lnkBtnAddTrust.Enabled = false;
                lnkBtnAddUnTrust.Enabled = false;
                ShowBuyerInfo = false;
            }
        }
        catch (VException vx)
        {
            //master.ShowMessage(vx.ErrorMessage, "error");
            //Log.Write(vx.ErrorCode, vx.ErrorMessage, vx);
            Web.LogError(vx);
        }
        catch (Exception ex)
        {
            //master.ShowMessage(ex.GetBaseException().ToString(), "error");
            //Log.Write("ViewDetails:000", ex.GetBaseException().ToString(), ex);
            Web.LogError(ex);
        }
    }

    private string GetTimeRemaining(DateTime dateTime)
    {
        string result = "";
        try
        {
            TimeSpan span = dateTime.Subtract(System.DateTime.Now);
            result = span.Days.ToString() + "days";



        }
        catch (Exception exp)
        {

            //Log.Write("Remaining Time:",exp.GetBaseException().ToString(),exp);
            Web.LogError(exp);
        }
        return result;
    }
    private void LoadImages()
    {
        try
        {
            ItemFiles images = new ItemFiles();
            images.Query.AddResultColumn(ItemFilesSchema.ItemFileID);
            images.Query.AddResultColumn(ItemFilesSchema.ItemID);
            images.Query.AddResultColumn(ItemFilesSchema.IsActive);
            images.Query.AddResultColumn(ItemFilesSchema.FileTypeID);

            images.Where.ItemID.Value = Web.RecordID;
            images.Where.IsActive.Value = 1;
            images.Where.FileTypeID.Value = 1;

            images.Query.Load();
            if (images.RowCount > 0)
            {
                rptImages.DataSource = images.DefaultView;
                rptImages.DataBind();
                ImagesAvailable = true;
            }
            else
                ImagesAvailable = false;
        }
        catch (Exception ex)
        {
            //master.ShowMessage(ex.GetBaseException().ToString(), "error");
            //Log.Write("ViewLot : 026", ex.GetBaseException().ToString(), ex);
            Web.LogError(ex);
        }
    }
    private void LoadShippingMethods()
    {
        try
        {
            DataTable dt = new DataTable();
            dt = ItemShippingTypes.GetItemShippingTypes(Web.RecordID);
            if (dt.Rows.Count > 0)
            {
                dlstShippingTypes.DataSource = dt;
                dlstShippingTypes.DataBind();
            }
        }
        catch (Exception ex)
        {
            //master.ShowMessage(ex.GetBaseException().ToString(), "error");
            //Log.Write("ViewLot : 020", ex.GetBaseException().ToString(), ex);
            Web.LogError(ex);
        }
    }
    private void LoadPaymentTypes()
    {
        try
        {
            DataTable dt = new DataTable();
            dt = ItemPaymentTypes.GetItemPaymentTypes(Web.RecordID);
            if (dt.Rows.Count > 0)
            {
                dlstPaymentMethods.DataSource = dt;
                dlstPaymentMethods.DataBind();
            }
        }
        catch (Exception ex)
        {
            //master.ShowMessage(ex.GetBaseException().ToString(), "error");
            //Log.Write("ViewLot : 021", ex.GetBaseException().ToString(), ex);
            Web.LogError(ex);
        }
    }
    private string GetShippingLocationName(int ShippingLocationID)
    {
        string name = "";
        try
        {
            ShippingLocationTypes type = new ShippingLocationTypes();
            type.LoadByPrimaryKey(ShippingLocationID);
            name = type.s_ShippingLocationName;
        }
        catch (Exception ex)
        {
            //master.ShowMessage(ex.GetBaseException().ToString(), "error");
            //Log.Write("ViewLot : 022", ex.GetBaseException().ToString(), ex);
            Web.LogError(ex);
        }
        return name;
    }
    private string GetLotsCount(int ItemID)
    {
        string count = "";
        try
        {
            ItemOffers offers = new ItemOffers();
            offers.Query.AddResultColumn(ItemOffersSchema.ItemID);
            offers.Where.ItemID.Value = ItemID;
            offers.Query.Load();
            count = offers.RowCount.ToString();
        }
        catch (VException vx)
        {
            //master.ShowMessage(vx.ErrorMessage, "error");
            //Log.Write(vx.ErrorCode, vx.ErrorMessage, vx);
            Web.LogError(vx);
        }
        catch (Exception ex)
        {
            //master.ShowMessage(ex.GetBaseException().ToString(), "error");
            //Log.Write("ViewDetails:000", ex.GetBaseException().ToString(), ex);
            Web.LogError(ex);
        }
        return count;
    }
    protected string GetParentCategory(int categoryID)
    {
        try
        {
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            Stack stack = new Stack();

            while (categoryID != 0)
            {
                Categories category = new Categories();
                category.LoadByPrimaryKey(categoryID);

                stack.Push(category.CategoryName);

                categoryID = category.CategoryID;

                if (categoryID != 0)
                    stack.Push(" > ");
            }
            int Counter = stack.Count;

            for (int i = 0; i < Counter; i++)
            {
                sb.Append(stack.Pop().ToString());
            }
            return sb.ToString();
        }
        catch (VException vx)
        {
            //master.ShowMessage(vx.ErrorMessage, "error");
            //Log.Write(vx.ErrorCode, vx.ErrorMessage, vx);
            Web.LogError(vx);
            return null;
        }
        catch (Exception ex)
        {
            //master.ShowMessage(ex.GetBaseException().ToString(), "error");
            //Log.Write("ViewDetails:000", ex.GetBaseException().ToString(), ex);
            Web.LogError(ex);
            return null;
        }
    }

    protected void lnkViewContacts_Click(object sender, EventArgs e)
    { 
            CodenameRabbitFoot.BusinessLogic.Items item = new CodenameRabbitFoot.BusinessLogic.Items();
            item.LoadByPrimaryKey(Web.RecordID);
            Web.Redirect("/Contacts/ViewProfile.aspx?Action=ViewDealer&RecordID=" + item.s_MemberID);            
        
    }
    protected void lnkAddSeller_Click(object sender, EventArgs e)
    {
        try
        {
            CodenameRabbitFoot.BusinessLogic.Items item = new CodenameRabbitFoot.BusinessLogic.Items();
            item.LoadByPrimaryKey(Web.RecordID);

            Members member = new Members();
            member.LoadByPrimaryKey(item.MemberID);
            AddContact(member.MemberID, 2);

        }
        catch (VException vx)
        {
            //Master.ShowMessage(vx.ErrorMessage, "error");
            //Log.Write(vx.ErrorCode, vx.ErrorMessage, vx);
            Web.LogError(vx);
        }
        catch (Exception ex)
        {
            //Master.ShowMessage(ex.GetBaseException().ToString(), "error");
            //Log.Write("ViewDetails:000", ex.GetBaseException().ToString(), ex);
            Web.LogError(ex);
        }
    }

    public void AddContact(int ContactMemberID, int ContactType)
    {
        //MessageBox.Visible = false;
        try
        {
            if (Web.SessionMembers.MemberID != ContactMemberID)
            {
                Contacts contact = new Contacts();
                contact.Where.MemberID.Value = Web.SessionMembers.MemberID;
                contact.Where.ContactMemberID.Value = ContactMemberID;
                contact.Query.Load();
                if (contact.RowCount < 1)
                {
                    Invitations invitations = new Invitations();
                    invitations.Where.InvitationToMemberID.Value = ContactMemberID;
                    invitations.Where.InvitedBy.Value = Web.SessionMembers.MemberID;
                    invitations.Query.Load();
                    if (invitations.RowCount < 1)
                    {
                        Members member = new Members();
                        member.LoadByPrimaryKey(ContactMemberID);
                        string[] name = member.FullName.Split(' ');
                        int InvitationID = Contacts.AddToContact(ContactMemberID, Web.SessionMembers.MemberID, ContactType, null);
                        if (InvitationID > 0)
                        {
                            Invitations invitation = new Invitations();
                            invitation.LoadByPrimaryKey(InvitationID);

                            System.Collections.Specialized.StringDictionary templateKeys = new System.Collections.Specialized.StringDictionary();
                            try
                            {
                                templateKeys.Add("#email_header#", Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER"));
                                templateKeys.Add("#email_footer#", Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER"));
                                templateKeys.Add("#profile_link#", Web.SystemConfigs.GetKey("SITE_URL") + "/Contacts/ViewProfile.aspx?Action=ViewDealer&status=pending&RecordID=" + Secure.Encrypt(Web.SessionMembers.MemberID) + "&ID=" + Secure.Encrypt(member.MemberID));
                                templateKeys.Add("#company_invitee#", Web.SessionMembers.CompanyName);
                                templateKeys.Add("#fullname_invitee#", Web.SessionMembers.FullName);
                                name = Web.SessionMembers.FullName.Split(' ');
                                templateKeys.Add("#first_name_invitee#", name[0]);
                                templateKeys.Add("#fullname#", member.FullName);
                                templateKeys.Add("#type#", Web.GetContactType(invitation.ContactType));
                                templateKeys.Add("#message#", "Please accept my invitation to add you as my " + Web.GetContactType(invitation.ContactType) + " to be able to instantly communicate as well as keep up to date with each other's social and business activities.");
                                templateKeys.Add("#link_contact_requests#", Web.SystemConfigs.GetKey("SITE_URL") + "Contacts/Default.aspx?Action=clients");

                                Web.SendMail(member.Email, Web.SystemConfigs.GetKey("CONTACT_EMAIL"), 203, templateKeys);
                            }
                            catch (Exception ex)
                            {
                                //Log.Write("Email Error", ex.GetBaseException().ToString(), ex);
                                Web.LogError(ex);
                            }
                            // Master.ShowMessage("A contact notification has been sent to Vendor for approval.", "info");
                        }
                        //  else
                        //Master.ShowMessage("Vendor you requested to add in contact is blocked.", "warning");
                    }
                    //else
                    {
                        //if (invitations.InvitationStatus == 1)
                        //Master.ShowMessage("Vendor has already accepted your contact invitation", "warning");
                        //else if (invitations.InvitationStatus == 2)
                        //Master.ShowMessage("Vendor has already rejected your contact invitation.", "warning");
                        //else
                        //  Master.ShowMessage("You have already invited the Vendor to your contact list.", "warning");
                    }
                }
                //else
                // Master.ShowMessage("You have already invited the Vendor to your contact list.", "warning");

            }
            // else
            //   Master.ShowMessage("You cannot add yourself in your contact list.", "warning");
        }
        catch (Exception ex)
        {
            //Log.Write("AddContact:008", ex.GetBaseException().ToString(), ex);
            Web.LogError(ex);
        }
    }

    #region Rating Module
    public void ToggleRatingButtons()
    {
        try
        {
            if (Web.IsMemberSession)
            {
                CodenameRabbitFoot.BusinessLogic.Items item = new CodenameRabbitFoot.BusinessLogic.Items();
                item.LoadByPrimaryKey(Web.RecordID);

                ItemOffers offers = new ItemOffers();
                offers.Query.AddResultColumn(ItemOffersSchema.ItemID);
                offers.Query.AddResultColumn(ItemOffersSchema.OfferBy);
                offers.Query.AddResultColumn(ItemOffersSchema.OfferStatusID);
                offers.Where.ItemID.Value = Web.RecordID;
                offers.Where.OfferBy.Value = Web.SessionMembers.MemberID;
                offers.Where.OfferStatusID.Value = 200;
                offers.Query.Load();

                if (item.MemberID.Equals(Web.SessionMembers.MemberID))
                {
                    lnkBtnAddTrust.Enabled = false;
                    lnkBtnAddUnTrust.Enabled = false;
                    lnkBtnAddTrust.CssClass = "rateUp";
                    lnkBtnAddUnTrust.CssClass = "rateDown";
                }
                else
                {
                    int AlreadyTrusted = 0, AlreadyUnTrusted = 0;
                    CodenameRabbitFoot.BusinessLogic.MemberTrustLog trustLog = new CodenameRabbitFoot.BusinessLogic.MemberTrustLog();
                    trustLog.Query.AddResultColumn(CodenameRabbitFoot.BusinessLogic.MemberTrustLogSchema.IsTrusted);
                    trustLog.Query.AddResultColumn(CodenameRabbitFoot.BusinessLogic.MemberTrustLogSchema.MemberID);
                    trustLog.Query.AddResultColumn(CodenameRabbitFoot.BusinessLogic.MemberTrustLogSchema.TrustedBy);
                    trustLog.Where.MemberID.Value = item.MemberID;
                    trustLog.Where.TrustedBy.Value = Web.SessionMembers.MemberID;
                    trustLog.Query.Load();
                    if (trustLog.RowCount > 0)
                    {
                        do
                        {
                            if (trustLog.s_IsTrusted == "0")
                                AlreadyTrusted++;
                            else
                                AlreadyUnTrusted++;

                        } while (trustLog.MoveNext());
                    }
                    if (AlreadyTrusted > 0)
                    {
                        lnkBtnAddTrust.Enabled = false;
                        lnkBtnAddTrust.CssClass = "rateUp";
                    }
                    else
                    {
                        if (offers.RowCount > 0)
                        {
                            lnkBtnAddTrust.Enabled = true;
                            lnkBtnAddTrust.CssClass = "rateUp-on";
                        }
                        else
                        {
                            lnkBtnAddTrust.Enabled = false;
                            lnkBtnAddTrust.CssClass = "rateUp";
                        }
                    }
                    if (AlreadyUnTrusted > 0)
                    {
                        lnkBtnAddUnTrust.Enabled = false;
                        lnkBtnAddUnTrust.CssClass = "rateDown";
                    }
                    else
                    {
                        if (offers.RowCount > 0)
                        {
                            lnkBtnAddUnTrust.Enabled = true;
                            lnkBtnAddUnTrust.CssClass = "rateDown-on";
                        }
                        else
                        {
                            lnkBtnAddUnTrust.Enabled = false;
                            lnkBtnAddUnTrust.CssClass = "rateDown";
                        }
                    }
                }
            }
            else
            {
                lnkBtnAddTrust.Enabled = false;
                lnkBtnAddTrust.CssClass = "rateUp";
                lnkBtnAddUnTrust.Enabled = false;
                lnkBtnAddUnTrust.CssClass = "rateDown";
            }
        }
        catch (Exception ex)
        {
            //master.ShowMessage(ex.GetBaseException().ToString(), "error");
            //Log.Write("ViewLot : 010", ex.GetBaseException().ToString(), ex);
            Web.LogError(ex);
        }
    }
    public void GetTrustScore()
    {
        try
        {
            Items lot = new Items();
            lot.LoadByPrimaryKey(Web.RecordID);
            if (lot.RowCount > 0)
            {


                MemberTrustScore score = new MemberTrustScore();
                score.Query.AddResultColumn(MemberTrustScoreSchema.TrustedScore);
                score.Query.AddResultColumn(MemberTrustScoreSchema.TrustByTotal);
                score.Query.AddResultColumn(MemberTrustScoreSchema.UnTrustByTotal);
                score.Query.AddResultColumn(MemberTrustScoreSchema.MemberID);
                score.Where.MemberID.Value = lot.MemberID;
                score.Query.Load();
                if (score.RowCount > 0)
                {
                    System.Text.StringBuilder FinalTrustScore = new System.Text.StringBuilder();
                    FinalTrustScore.Append(score.s_TrustedScore);
                    if (!String.IsNullOrEmpty(score.s_TrustByTotal))
                    {
                        FinalTrustScore.Append(" (<a href='../MyAccount/ViewRatingDetails.aspx?Action=ViewTrusted&RecordID=" + Secure.Encrypt(Session["MemberID"]) + "'>Trusted by ");
                        FinalTrustScore.Append(score.s_TrustByTotal);

                        if (!String.IsNullOrEmpty(score.s_TrustByTotal))
                            FinalTrustScore.Append("</a>,");
                        else
                            FinalTrustScore.Append("</a>)");
                    }

                    if (!String.IsNullOrEmpty(score.s_UnTrustByTotal))
                    {
                        if (!String.IsNullOrEmpty(score.s_TrustByTotal))
                            FinalTrustScore.Append(" <a href='../MyAccount/ViewRatingDetails.aspx?Action=ViewUnTrusted&RecordID=" + Secure.Encrypt(Session["MemberID"]) + "'>Untrusted by ");
                        else
                            FinalTrustScore.Append(" (<a href='../MyAccount/ViewRatingDetails.aspx?Action=ViewUnTrusted&RecordID=" + Secure.Encrypt(Session["MemberID"]) + "'>Untrusted by ");
                        FinalTrustScore.Append(score.s_UnTrustByTotal);
                        FinalTrustScore.Append("</a>)");
                    }

                    if (FinalTrustScore.Length <= 0)
                        FinalTrustScore.Append("Not Rated Yet");

                    lblRating.Text = FinalTrustScore.ToString();


                    double ORating = 0.0;
                    double myScore = score.TrustedScore;
                    double myRatedBy = score.TrustByTotal;
                    ORating = myScore / myRatedBy;

                    //  string myTotalRatingString = "";

                }
                else
                {
                    lblRating.Text = "Not rated yet";
                }
            }
            else
            {
                //  master.ShowMessage("Item Not Found", "warning");
            }

        }
        catch (Exception ex)
        {
            //Master.ShowMessage(ex.GetBaseException().ToString(), "error");
            //Log.Write("ViewLot : 011", ex.GetBaseException().ToString(), ex);
            Web.LogError(ex);
        }
    }
    protected void lnkBtnAddTrust_Click(object sender, EventArgs e)
    {
        try
        {
            if (Web.IsMemberSession)
            {
                CodenameRabbitFoot.BusinessLogic.Items item = new CodenameRabbitFoot.BusinessLogic.Items();
                item.LoadByPrimaryKey(Web.RecordID);

                CodenameRabbitFoot.BusinessLogic.MemberTrustLog trustLog = new CodenameRabbitFoot.BusinessLogic.MemberTrustLog();
                trustLog.Query.AddResultColumn(CodenameRabbitFoot.BusinessLogic.MemberTrustLogSchema.IsTrusted);
                trustLog.Query.AddResultColumn(CodenameRabbitFoot.BusinessLogic.MemberTrustLogSchema.MemberID);
                trustLog.Query.AddResultColumn(CodenameRabbitFoot.BusinessLogic.MemberTrustLogSchema.TrustedBy);
                trustLog.Where.MemberID.Value = item.MemberID;
                trustLog.Where.TrustedBy.Value = Web.SessionMembers.MemberID;
                trustLog.Where.IsTrusted.Value = 1;
                trustLog.Query.Load();
                if (trustLog.RowCount > 0)
                {
                    //if (CodenameRabbitFoot.BusinessLogic.MemberTrustScore.TrustMemberScore(Web.SessionMembers.MemberID, item.MemberID, "Trusted"))
                    //    GetTrustScore();
                }
                ToggleRatingButtons();
            }
            else
                Web.Redirect("~/index.aspx?ReturnUrl=~/MarketPlace/WTS/ViewLot.aspx?Action=View&RecordID=" + Secure.Encrypt(Web.RecordID));
        } 
        catch (Exception ex)
        {
            //master.ShowMessage(ex.GetBaseException().ToString(), "error");
            //Log.Write("ViewLot : 012", ex.GetBaseException().ToString(), ex);
            Web.LogError(ex);
        }
    }
    protected void lnkBtnAddUnTrust_Click(object sender, EventArgs e)
    {
        try
        {
            if (Web.IsMemberSession)
            {
                CodenameRabbitFoot.BusinessLogic.Items item = new CodenameRabbitFoot.BusinessLogic.Items();
                item.LoadByPrimaryKey(Web.RecordID);

                CodenameRabbitFoot.BusinessLogic.MemberTrustLog trustLog = new CodenameRabbitFoot.BusinessLogic.MemberTrustLog();
                trustLog.Query.AddResultColumn(CodenameRabbitFoot.BusinessLogic.MemberTrustLogSchema.IsTrusted);
                trustLog.Query.AddResultColumn(CodenameRabbitFoot.BusinessLogic.MemberTrustLogSchema.MemberID);
                trustLog.Query.AddResultColumn(CodenameRabbitFoot.BusinessLogic.MemberTrustLogSchema.TrustedBy);
                trustLog.Where.MemberID.Value = item.MemberID;
                trustLog.Where.TrustedBy.Value = Web.SessionMembers.MemberID;
                trustLog.Where.IsTrusted.Value = 0;
                trustLog.Query.Load();
                if (trustLog.RowCount > 0)
                {
                    //if (CodenameRabbitFoot.BusinessLogic.MemberTrustScore.UnTrustMemberScore(Web.SessionMembers.MemberID, item.MemberID, "Un-Trusted"))
                    //    GetTrustScore();
                }
                ToggleRatingButtons();
            }
            else
                Web.Redirect("~/index.aspx?ReturnUrl=~/MarketPlace/WTS/ViewLot.aspx?Action=View&RecordID=" + Secure.Encrypt(Web.RecordID));
        } 
        catch (Exception ex)
        {
            //master.ShowMessage(ex.GetBaseException().ToString(), "error");
            //Log.Write("ViewLot : 013", ex.GetBaseException().ToString(), ex);
            Web.LogError(ex);
        }

    }
    #endregion

    private void AddMemberToWatchList(int MemberID)
    {
        try
        {

            MembersWatchListDealers MWDealer = new MembersWatchListDealers();

            MWDealer.Where.DealerID.Value = MemberID;
            MWDealer.Where.MemberID.Value = Web.SessionMembers.MemberID;
            MWDealer.Query.Load();
            if (MWDealer.RowCount <= 0)
            {
                if (MemberID != Web.SessionMembers.MemberID)
                {
                    MembersWatchListDealers memberwatchlistdealer = new MembersWatchListDealers();
                    memberwatchlistdealer.AddNew();
                    memberwatchlistdealer.MemberID = Web.SessionMembers.MemberID;
                    memberwatchlistdealer.DealerID = MemberID;
                    memberwatchlistdealer.CreateDate = System.DateTime.Now;
                    memberwatchlistdealer.Save();
                    // Master.ShowMessage("Added to  WatchList Successfully", "info");


                }
                else
                {
                    //  Master.ShowMessage("You can not add yourself in watchlist", "warning");

                }
            }
            else
            {
                //  Master.ShowMessage("Already in WatchList", "warning");

            }

        }
        catch (Exception exp)
        {

            //Log.Write("err", exp.GetBaseException().ToString(), exp);
            Web.LogError(exp);
        }
    }

    protected void btnAddasSupplier_Click(object sender, EventArgs e)
    {
        try
        {
            CodenameRabbitFoot.BusinessLogic.Items item = new CodenameRabbitFoot.BusinessLogic.Items();
            item.LoadByPrimaryKey(Web.RecordID);

            Members member = new Members();
            member.LoadByPrimaryKey(item.MemberID);
            AddContact(member.MemberID, 2);
        }
        catch (Exception exp)
        {

            //Log.Write("Add as Supplier", exp.GetBaseException().ToString(), exp);
            Web.LogError(exp);
        }
    }

    protected void btnAddasCustomer_Click(object sender, EventArgs e)
    {
        try
        {
            CodenameRabbitFoot.BusinessLogic.Items item = new CodenameRabbitFoot.BusinessLogic.Items();
            item.LoadByPrimaryKey(Web.RecordID);

            Members member = new Members();
            member.LoadByPrimaryKey(item.MemberID);
            AddContact(member.MemberID, 1);
        }
        catch (Exception exp)
        {

            //Log.Write("AddAsCustomer", exp.GetBaseException().ToString(), exp);
            Web.LogError(exp);
        }
    }

    protected void btnAddToWatchList_Click(object sender, EventArgs e)
    {
        try
        {
            if (Web.IsMemberSession)
            {
                int ItemID = Web.RecordID;
                int MemberID = 0;
                Items item = new Items();
                item.LoadByPrimaryKey(ItemID);
                if (item.RowCount > 0)
                {
                    MemberID = item.MemberID;
                }

                if (MemberID != Web.SessionMembers.MemberID)
                {
                    MembersWatchListWTB currentWatchList = new MembersWatchListWTB();
                    currentWatchList.Query.AddResultColumn(MembersWatchListWTBSchema.ItemID);
                    currentWatchList.Query.AddResultColumn(MembersWatchListWTBSchema.MemberID);
                    currentWatchList.Where.ItemID.Value = ItemID;
                    currentWatchList.Where.MemberID.Value = Web.SessionMembers.MemberID;
                    currentWatchList.Query.Load();
                    if (currentWatchList.RowCount < 1)
                    {
                        MembersWatchListWTB watchlist = new MembersWatchListWTB();
                        watchlist.AddNew();
                        watchlist.ItemID = ItemID;
                        watchlist.MemberID = Web.SessionMembers.MemberID;
                        watchlist.CreateDate = System.DateTime.Now;
                        watchlist.Save();

                        System.Collections.Specialized.StringDictionary templateKeys = new System.Collections.Specialized.StringDictionary();
                        templateKeys.Add("#itemname#", item.ItemName);
                        templateKeys.Add("#pronoun#", "#pronoun#" + Web.SessionMembers.MemberID + "#endpronoun#");
                        templateKeys.Add("#link#", "../WTB/ViewDetails.aspx?Action=View&RecordID=#encrypt#" + item.ItemID + "#endencrypt#");
                        templateKeys.Add("#link_to_watchlist#", "../MyAccount/WatchList.aspx?Action=Buy&RecordID=999");
                        Web.AddPrivateActivityLog(32, templateKeys, Web.SessionMembers.MemberID, item.ItemID);

                        //          master.ShowMessage("Item has been added to your watchlist.", "info");

                    }
                    //  else
                    //        master.ShowMessage("Item already present in your watchlist.", "info");
                }
                //else
                //  master.ShowMessage("You cannot add your own Item in your watchlist.", "warning");

            }
            else
                Web.Redirect("~/index.aspx?ReturnUrl=~/MarketPlace/WTB/ViewDetails.aspx?Action=View&RecordID=" + Secure.Encrypt(Web.RecordID));
        } 
        catch (Exception exp)
        {
            //Log.Write("AddWatchList", exp.GetBaseException().ToString(), exp);
            Web.LogError(exp);
        }
    }

    public void AllowAddInContact(int MemberID)
    {

        try
        {
            if (MemberID != Web.SessionMembers.MemberID)
            {
                Invitations invitation = new Invitations();
                invitation.Where.InvitedBy.Value = Web.SessionMembers.MemberID;
                invitation.Where.InvitationToMemberID.Value = MemberID;
                invitation.Query.Load();
                if (invitation.RowCount > 0)
                {

                    btnAddasCustomer.Visible = false;
                    btnAddasSupplier.Visible = false;
                }
                else
                {
                    invitation = new Invitations();
                    invitation.Where.InvitedBy.Value = MemberID;
                    invitation.Where.InvitationToMemberID.Value = Web.SessionMembers.MemberID;
                    invitation.Query.Load();
                    if (invitation.RowCount > 0)
                    {
                        btnAddasCustomer.Visible = false;
                        btnAddasSupplier.Visible = false;
                    }
                }

            }

        }
        catch (Exception exp)
        {
            Web.LogError(exp);
        }

    }
}