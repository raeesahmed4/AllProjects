﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Collections.Specialized;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Reflection;
using System.Drawing;
using System.Drawing.Imaging;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.IO;

using VisualSoft.VSharp.Data;
using VisualSoft.VSharp.Utils;

using CodenameRabbitFoot.BusinessLogic;


public partial class MarketPlace_WTB_Add : System.Web.UI.Page
{
    #region Members & Properties

    //MasterPages_Public master = null;

    public static int flag = 0;
    private int itemID = 0;
    public int ItemID
    {
        get { return itemID; }
        set { itemID = value; }
    }
    private string itemTitle = "";
    public string ItemTitle
    {
        get { return itemTitle; }
        set { itemTitle = value; }
    }
    //    string separator;
    //    string subCategory;
    //    int Counter = 0;
    public int TextCount = 10000;
    //    int count_rows = 0;
    DataTable result = null;
    public static int ImageCount = 0;
    //    static Hashtable CategoryColors = null;
    public bool showPage = true;

    // must create new keys and ivs for each application
    private static byte[] key_192 = new byte[] 
    {10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10,
        10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10};

    private static byte[] iv_128 = new byte[]
    {10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10,
        10, 10, 10, 10};
    #endregion

    #region Methods
    protected void Page_Load(object sender, EventArgs e)
    {

        this.Master.HideLinkApps();
        bindCategories();
     
        //master = this.Master as MasterPages_Public;


        //this.Master.PageHeading = "Want to Buy";
        //this.Master.ShowMessageBox = false;
        //this.Master.ShowHeader = false;
        //this.Master.ShowLine = true;
        //this.Master.HeadingIcon = "~/images/PageIcons/buy.png";


        try
        {
            if (!Web.IsMemberSession)
                Web.Redirect("~/index.aspx?ReturnUrl=~/MarketPlace/WTB/Add.aspx" + Request.Url.Query);
            else
            {
                if (!IsPostBack)
                {
                    if (Web.SessionMembers.shippingAddress != null)
                    {
                        if (!String.IsNullOrEmpty(Web.SessionMembers.shippingAddress.s_Address1))
                        {
                            LoadLists();
                            //GetValidImageFormats();


                            //if (HttpContext.Current.Request.Browser.Cookies)
                            //    LoadCookies();

                            if (Request.QueryString["Category"] != null)
                            {
                                string strCategory = Request.QueryString["Category"].ToString();
                                if (!String.IsNullOrEmpty(strCategory))
                                {
                                    int category = -1;
                                    try
                                    {

                                        category = Convert.ToInt32(strCategory);
                                    }
                                    catch (Exception ex)
                                    { //Log.Write("err", ex.GetBaseException().ToString(), ex);
                                        Web.LogError(ex);
                                    }
                                    //if (category > 0)
                                    //    ucCategories.SelectedParentCategoryID = strCategory;
                                }
                            }
                        }
                        else
                            Web.Redirect("~/Account/UpdatePublicProfile.aspx?Action=address&ReturnUrl=~/MarketPlace/WTB/Add.aspx" + Request.Url.Query);
                    }
                    else
                        Web.Redirect("~/Account/UpdatePublicProfile.aspx?Action=address&ReturnUrl=~/MarketPlace/WTB/Add.aspx" + Request.Url.Query);
                    Web.LogUserActivity(Radium.Platform.Core.UserActivity.View);
                }
            }
            txtOpeningPrice.Attributes.Add("onkeypress", "javascript:ToggleValidation();");
            btnPreview.Attributes["onclick"] = string.Format("{0}.disabled=true;{1};", btnPreview.ClientID, GetPostBackEventReference(btnPreview));
        }

        catch (Exception ex)
        {
            //this.Master.MessageBoxText = ex.GetBaseException().ToString();
            //this.Master.ShowMessageBox = true;
        }
    }

    #region Add
    protected void btnAdd_Click(Object sender, EventArgs e)
    {
        if ((ItemID = AddItem()) > 0)
        {
            EmailToSubscribedMembers(ItemID);
            string action = System.Web.HttpContext.Current.Request.QueryString["Action"];
            if (action == "LiveFeed")
            {
                Web.Redirect("~/live.aspx");
            }
            multiViewWTX.ActiveViewIndex = 2;
        }
    }
    protected void btnSaveAddNew_Click(Object sender, EventArgs e)
    {
        if ((ItemID = AddItem()) > 0)
        {
           // multiViewWTX.ActiveViewIndex = 2;
            //this.Master.ShowMessage("asdfasd","asdfasd");
            Web.Redirect("~/Live.aspx");
        }
    }


    private int AddItem()
    {

        NCI.EasyObjects.TransactionManager transactionManager = new NCI.EasyObjects.TransactionManager();
        transactionManager.BeginTransaction();
        StringDictionary templateKeys;

        try
        {
            Items items = new Items();
            items.AddNew();
            items.s_DesiredPrice = (!String.IsNullOrEmpty(txtOpeningPrice.Text) && (txtOpeningPrice.Text != "<Send Offers>")) ? txtOpeningPrice.Text : "0";
            items.s_IsActive = "1";
            items.s_ItemDate = DateTime.Now.ToString();
            items.s_ItemDescription = Web.GetCleanHTML(txtDescription.Content);

            if (ddlDays.SelectedValue == "0")
            {
                items.ItemDuration = 1000;
                items.s_ItemEndDate = DateTime.Now.AddDays(1000).ToString();
            }
            else if (ddlDays.SelectedValue == "c")
            {
                items.ItemDuration = 100;
                items.s_ItemEndDate = DateTime.Now.AddDays(100).ToString();
            }
            else if (int.Parse(ddlDays.SelectedValue) != -1)
            {
                items.ItemDuration = int.Parse(ddlDays.SelectedValue);
                items.s_ItemEndDate = DateTime.Now.AddDays(Convert.ToDouble(ddlDays.SelectedValue)).ToString();
            }
            else
            {
                items.ItemDuration = 15;
                items.s_ItemEndDate = DateTime.Now.AddDays(Convert.ToDouble(ddlDays.SelectedValue)).ToString();
            }
            //items.s_ItemID = "";
            items.s_ItemLocationID = ddlLocation.SelectedValue;
            items.s_ItemName = txtTitle.Text;
            items.s_Keywords = txtTitle.Text;
            items.s_MemberID = Web.SessionMembers.MemberID.ToString();
            items.s_Quantity = txtQuantity.Text;

            if (ApprovedMembers.CheckIfApproved(Web.SessionMembers.MemberID))
                items.StatusCode = 100;
            else
                items.StatusCode = 200;

            items.Save();

            if (items.ItemID > 0)
            {
                if (ApprovedMembers.CheckIfApproved(Web.SessionMembers.MemberID))
                {
                    if (!Web.IsAction("private_WTB"))
                    {
                        templateKeys = new StringDictionary();
                        templateKeys.Add("#itemname#", items.ItemName);
                        templateKeys.Add("#viewlink#", "../Marketplace/WTB/ViewDetails.aspx?Action=View&RecordID=#encrypt#" + items.ItemID + "#endencrypt#");
                        Web.AddActivityLog(3, templateKeys, items.ItemID);
                    }
                }

                ItemID = items.ItemID;
                ApprovedMembers approvedmember = new ApprovedMembers();

                approvedmember.Where.MemberID.Value = items.MemberID;
                approvedmember.Where.IsActive.Value = 1;
                approvedmember.Query.Load();
                if (approvedmember.RowCount > 0)
                {
                    lblposteditemmessage.Text = " Item:" + items.s_ItemName + " has been listed successfully.";
                }
                else
                {
                    lblposteditemmessage.Text = " The Item " + "\"" + items.s_ItemName + "\"" + " is under review, it will be listed live shortly after administrative approval.";
                }


                DataTable tblConditionTypes = new DataTable();
                DataTable tblPaymentTypes = new DataTable();
                DataTable tblShippingTypes = new DataTable();
                DataTable tblImages = new DataTable();
                DataTable tblItemCategories = new DataTable();

                tblConditionTypes = GetConditionTypes(ItemID);
                tblShippingTypes = GetShippingTypes(ItemID);
                tblItemCategories = GetItemCategories(ItemID);
                tblPaymentTypes = GetPaymentTypes(ItemID);
                tblImages = GetImages();

                //Save Item Conditions------------------------------------------
                ItemConditions itemConditions = null;
                if (tblConditionTypes.Rows.Count > 0)
                {
                    foreach (DataRow rowConditionTypes in tblConditionTypes.Rows)
                    {
                        itemConditions = new ItemConditions();
                        itemConditions.AddNew();
                        itemConditions.s_ItemID = rowConditionTypes["ItemID"].ToString();
                        itemConditions.s_ConditionID = rowConditionTypes["ConditionTypeID"].ToString();
                        itemConditions.Save();
                    }
                }

                //Save Item Shipping Types--------------------------------------
                ItemShippingTypes itemShippingTypes = null;
                if (tblShippingTypes.Rows.Count > 0)
                {
                    foreach (DataRow rowShippingTypes in tblShippingTypes.Rows)
                    {
                        itemShippingTypes = new ItemShippingTypes();
                        itemShippingTypes.AddNew();
                        itemShippingTypes.s_ItemID = rowShippingTypes["ItemID"].ToString();
                        itemShippingTypes.s_ShippingTypeID = rowShippingTypes["ShippingTypeID"].ToString();
                        itemShippingTypes.Save();
                    }
                }

                //Save Item Categories------------------------------------------
                if (tblItemCategories.Rows.Count > 0)
                {
                    foreach (DataRow rowItemCategories in tblItemCategories.Rows)
                    {
                        ItemCategories itemCategories = null;
                        itemCategories = new ItemCategories();
                        itemCategories.AddNew();
                        itemCategories.s_CategoryID = rowItemCategories["CategoryID"].ToString();
                        itemCategories.s_ItemID = rowItemCategories["ItemID"].ToString();
                        itemCategories.Save();
                    }
                }

                //Save Item Payment Types---------------------------------------
                ItemPaymentTypes itemPaymentTypes = null;
                if (tblPaymentTypes.Rows.Count > 0)
                {
                    foreach (DataRow rowPaymentTypes in tblPaymentTypes.Rows)
                    {
                        itemPaymentTypes = new ItemPaymentTypes();
                        itemPaymentTypes.AddNew();
                        itemPaymentTypes.s_ItemID = rowPaymentTypes["ItemID"].ToString();
                        itemPaymentTypes.s_PaymentTypeID = rowPaymentTypes["PaymentTypeID"].ToString();
                        itemPaymentTypes.Save();
                    }
                }

                //Save Item Files----------------------------------------------
                ItemFiles itemFiles = null;
                if (tblImages.Rows.Count > 0)
                {
                    foreach (DataRow rowImages in tblImages.Rows)
                    {
                        itemFiles = new ItemFiles();
                        itemFiles.AddNew();
                        itemFiles.FileDate = DateTime.Now;
                        itemFiles.s_FileFormat = rowImages["ext"].ToString();
                        itemFiles.s_FileName = rowImages["ListingImageName"].ToString();
                        itemFiles.FileContents = (byte[])rowImages["ListingImage"];
                        itemFiles.FileTypeID = 1;
                        itemFiles.s_IsActive = "1";
                        itemFiles.ItemID = ItemID;
                        itemFiles.RemoteIP = Request.UserHostAddress;
                        itemFiles.Save();
                    }
                }

                templateKeys = new System.Collections.Specialized.StringDictionary();
                if (Web.IsAction("private_WTB"))
                {
                    Items item = new Items();
                    item.LoadByPrimaryKey(items.ItemID);
                    if (item.RowCount > 0)
                    {
                        item.IsPrivate = 1;
                        item.Save();
                        if (Web.RecordID > 0 && Web.RecordID != 99999999)
                        {
                            Contacts contact = new Contacts();
                            contact.LoadByPrimaryKey(Web.RecordID);
                            Members member = new Members();
                            member.LoadByPrimaryKey(contact.ContactMemberID);

                            PrivateItems pItem = new PrivateItems();
                            pItem.AddNew();
                            pItem.ItemID = items.ItemID;
                            pItem.PrivateTo = contact.ContactMemberID;
                            pItem.Save();

                            try
                            {
                                templateKeys = new System.Collections.Specialized.StringDictionary();
                                templateKeys.Add("#fullname#", member.FullName);
                                templateKeys.Add("#seller_name#", Web.SessionMembers.FullName);
                                templateKeys.Add("#private_posting_link#", Web.SystemConfigs.GetKey("SITE_URL") + "MarketPlace/WTB/ViewDetails.aspx?Action=View&RecordID=" + Secure.Encrypt(ItemID));
                                templateKeys.Add("#email_header#", Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER"));
                                templateKeys.Add("#email_footer#", Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER"));

                                Web.SendMail(member.Email, Web.SystemConfigs.GetKey("LISTING_EMAIL"), 211, templateKeys);
                            }
                            catch (Exception ex)
                            {
                                //Log.Write("Email Error", ex.GetBaseException().ToString(), ex);
                                Web.LogError(ex);
                            }

                            try
                            {
                                templateKeys = new System.Collections.Specialized.StringDictionary();
                                templateKeys.Add("#fullname#", member.FullName);
                                templateKeys.Add("#sending_contact#", Web.SessionMembers.FullName);
                                templateKeys.Add("#private_posting_link#", Web.SystemConfigs.GetKey("SITE_URL") + "MarketPlace/WTB/ViewDetails.aspx?Action=View&RecordID=" + Secure.Encrypt(ItemID));
                                templateKeys.Add("#email_header#", Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER"));
                                templateKeys.Add("#email_footer#", Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER"));

                                Web.SendMail(member.Email, Web.SystemConfigs.GetKey("CONTACT_EMAIL"), 405, templateKeys);
                            }
                            catch (Exception ex)
                            {
                                //Log.Write("Email Error", ex.GetBaseException().ToString(), ex);
                                Web.LogError(ex);
                            }
                        }
                        else
                        {
                            ArrayList ContactsList = new ArrayList();
                            ContactsList = Session["ContactsList"] as ArrayList;

                            foreach (int ContactID in ContactsList)
                            {
                                templateKeys = new System.Collections.Specialized.StringDictionary();
                                Contacts contact = new Contacts();
                                contact.LoadByPrimaryKey(ContactID);
                                Members member = new Members();
                                member.LoadByPrimaryKey(contact.ContactMemberID);

                                PrivateItems pItem = new PrivateItems();
                                pItem.AddNew();
                                pItem.ItemID = items.ItemID;
                                pItem.PrivateTo = contact.ContactMemberID;
                                pItem.Save();

                                try
                                {
                                    templateKeys = new System.Collections.Specialized.StringDictionary();
                                    templateKeys.Add("#fullname#", member.FullName);
                                    templateKeys.Add("#seller_name#", Web.SessionMembers.FullName);
                                    templateKeys.Add("#private_posting_link#", Web.SystemConfigs.GetKey("SITE_URL") + "MarketPlace/WTB/ViewDetails.aspx?Action=View&RecordID=" + Secure.Encrypt(ItemID));
                                    templateKeys.Add("#email_header#", Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER"));
                                    templateKeys.Add("#email_footer#", Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER"));

                                    Web.SendMail(member.Email, Web.SystemConfigs.GetKey("LISTING_EMAIL"), 211, templateKeys);

                                    templateKeys = new System.Collections.Specialized.StringDictionary();
                                    templateKeys.Add("#fullname#", member.FullName);
                                    templateKeys.Add("#sending_contact#", Web.SessionMembers.FullName);
                                    templateKeys.Add("#private_posting_link#", Web.SystemConfigs.GetKey("SITE_URL") + "MarketPlace/WTB/ViewDetails.aspx?Action=View&RecordID=" + Secure.Encrypt(ItemID));
                                    templateKeys.Add("#email_header#", Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER"));
                                    templateKeys.Add("#email_footer#", Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER"));

                                    Web.SendMail(member.Email, Web.SystemConfigs.GetKey("CONTACT_EMAIL"), 405, templateKeys);
                                }
                                catch (VException vex)
                                {
                                    //Log.Write("Email Error", vex.GetBaseException().ToString(), vex);
                                    Web.LogError(vex);
                                }
                                catch (Exception ex)
                                {
                                    //Log.Write("Email Error", ex.GetBaseException().ToString(), ex);
                                    Web.LogError(ex);
                                }
                            }
                        }
                    }
                }
            }

            transactionManager.CommitTransaction();

            Session["ItemName"] = txtTitle.Text;

            // Write a cookie for user's listing preferences
            //if (IfCookiesEnabled())
            //    AddCookie();

            return ItemID;
        }
        catch (VException vx)
        {
            transactionManager.RollbackTransaction();
            //this.Master.MessageBoxText = vx.ErrorMessage;
            //this.Master.ShowMessageBox = true;
            return ItemID;
        }
        catch (Exception ex)
        {
            transactionManager.RollbackTransaction();
            //this.Master.MessageBoxText = ex.GetBaseException().ToString();
            //this.Master.ShowMessageBox = true;
            return ItemID;
        }
    }
    public byte[] StrToByteArray(string str)
    {
        System.Text.ASCIIEncoding encoding = new System.Text.ASCIIEncoding();
        return encoding.GetBytes(str);
    }
    private DataTable GetConditionTypes(int ItemID)
    {
        try
        {
            bool selected = false;
            DataRow row;
            DataTable ConditionTypes = new DataTable();
            ConditionTypes.Columns.Add(new DataColumn("ConditionTypeID", typeof(int)));
            ConditionTypes.Columns.Add(new DataColumn("ItemID", typeof(int)));

            foreach (ListItem item in chkConditions.Items)
            {
                if (item.Selected == true)
                {
                    row = ConditionTypes.NewRow();
                    row["ConditionTypeID"] = Convert.ToInt32(item.Value);
                    row["ItemID"] = ItemID;
                    ConditionTypes.Rows.Add(row);
                    selected = true;
                }
            }
            if (!selected)
            {
                ListItem item = chkConditions.Items[0];
                row = ConditionTypes.NewRow();
                row["ConditionTypeID"] = Convert.ToInt32(item.Value);
                row["ItemID"] = ItemID;
                ConditionTypes.Rows.Add(row);
            }
            return ConditionTypes;
        }
        catch (VException vx)
        {
            //this.Master.MessageBoxText = vx.ErrorMessage;
            //this.Master.ShowMessageBox = true;
            return null;
        }
        catch (Exception ex)
        {
            //this.Master.MessageBoxText = ex.GetBaseException().ToString();
            //this.Master.ShowMessageBox = true;
            return null;
        }
    }
    private DataTable GetShippingTypes(int ItemID)
    {
        try
        {
            bool selected = false;
            DataRow row;
            DataTable ShippingTypes = new DataTable();
            ShippingTypes.Columns.Add(new DataColumn("ShippingTypeID"));
            ShippingTypes.Columns.Add(new DataColumn("ItemID"));

            foreach (ListItem item in chkShippingTypes.Items)
            {
                if (item.Selected == true)
                {
                    row = ShippingTypes.NewRow();
                    row["ShippingTypeID"] = item.Value;
                    row["ItemID"] = ItemID;
                    ShippingTypes.Rows.Add(row);
                    selected = true;
                }
            }
            if (!selected)
            {
                ListItem item = chkShippingTypes.Items[0];
                row = ShippingTypes.NewRow();
                row["ShippingTypeID"] = item.Value;
                row["ItemID"] = ItemID;
                ShippingTypes.Rows.Add(row);
            }
            return ShippingTypes;
        }
        catch (VException vx)
        {
            //this.Master.MessageBoxText = vx.ErrorMessage;
            //this.Master.ShowMessageBox = true;
            return null;
        }
        catch (Exception ex)
        {
            //this.Master.MessageBoxText = ex.GetBaseException().ToString();
            //this.Master.ShowMessageBox = true;
            return null;
        }
    }
    private DataTable GetPaymentTypes(int ItemID)
    {
        try
        {
            bool selected = false;
            DataRow row;
            DataTable PaymentTypes = new DataTable();

            PaymentTypes.Columns.Add(new DataColumn("PaymentTypeID"));
            PaymentTypes.Columns.Add(new DataColumn("ItemID"));

            foreach (ListItem item in ckhPaymentTypes.Items)
            {
                if (item.Selected == true)
                {
                    row = PaymentTypes.NewRow();
                    row["PaymentTypeID"] = item.Value;
                    row["ItemID"] = ItemID;
                    PaymentTypes.Rows.Add(row);
                    selected = true;
                }
            }
            if (!selected)
            {
                ListItem item = ckhPaymentTypes.Items[0];
                row = PaymentTypes.NewRow();
                row["PaymentTypeID"] = item.Value;
                row["ItemID"] = ItemID;
                PaymentTypes.Rows.Add(row);
            }
            return PaymentTypes;
        }
        catch (VException vx)
        {
            //this.Master.MessageBoxText = vx.ErrorMessage;
            //this.Master.ShowMessageBox = true;
            return null;
        }
        catch (Exception ex)
        {
            //this.Master.MessageBoxText = ex.GetBaseException().ToString();
            //this.Master.ShowMessageBox = true;
            return null;
        }
    }

    private void EmailToSubscribedMembers(int ItemID)
    {
        try
        {
            string categoryList = "0";
            Items item = new Items();
            item.LoadByPrimaryKey(ItemID);

            ItemCategories categories = new ItemCategories();
            categories.Query.AddResultColumn(ItemCategoriesSchema.CategoryID);
            categories.Where.ItemID.Value = ItemID;
            categories.Query.Load();
            if (categories.RowCount > 0)
            {
                categoryList = "";
                categories.Rewind();
                do
                {
                    categoryList += categories.s_CategoryID + ",";
                } while (categories.MoveNext());
                categoryList = categoryList.Substring(0, categoryList.Length - 2);
            }

            StringDictionary templateKeys = new StringDictionary();
            Members members = new Members();
            members.Query.AddResultColumn(MembersSchema.Email);
            members.Query.AddResultColumn(MembersSchema.MemberID);
            members.Query.AddResultColumn(MembersSchema.FullName);
            members.Query.AddResultColumn(MembersSchema.EmailPrefrence);
            members.Where.EmailPrefrence.Value = 1;
            members.Query.Load();
            if (members.RowCount > 0)
            {
                members.Rewind();
                do
                {
                    MembersAlertSubscriptions alerts = new MembersAlertSubscriptions();
                    alerts.Query.AddResultColumn(MembersAlertSubscriptionsSchema.CategoryID);
                    alerts.Where.MemberID.Value = members.MemberID;
                    alerts.Where.ModuleType.Value = 2;
                    alerts.Where.CategoryID.Value = categoryList;
                    alerts.Where.CategoryID.Operator = NCI.EasyObjects.WhereParameter.Operand.In;
                    alerts.Query.Load();
                    if (alerts.RowCount > 0)
                    {
                        templateKeys.Clear();
                        templateKeys.Add("#email_header#", SystemConfigKeys.GetKey("HTML_EMAIL_HEADER"));
                        templateKeys.Add("#email_footer#", SystemConfigKeys.GetKey("HTML_EMAIL_FOOTER"));
                        templateKeys.Add("#site_name#", SystemConfigKeys.GetKey("SITE_NAME"));
                        templateKeys.Add("#link_email_notification_update#", SystemConfigKeys.GetKey("SITE_URL") + "Account/MyAccount.aspx?category=eNotifier");
                        templateKeys.Add("#title_listing#", item.ItemName);
                        templateKeys.Add("#link_listing#", SystemConfigKeys.GetKey("SITE_URL") + "MarketPlace/WTB/ViewDetails.aspx?Action=View&RecordID=" + Secure.Encrypt(ItemID));
                        templateKeys.Add("#fullname#", members.FullName);

                        Web.SendMail(members.Email, SystemConfigKeys.GetKey("ALERTS_EMAIL"), 102, templateKeys);
                    }
                } while (members.MoveNext());
            }
        }
        catch (Exception ex)
        {
            //Log.Write("Error", ex.GetBaseException().ToString(), ex);
            Web.LogError(ex);
        }
    }
    #endregion

    #region Preview
    protected void btnBack_Click(Object Sender, EventArgs e)
    {
        //this.Master.ShowMessageBox = false;
        multiViewWTX.ActiveViewIndex = 0;
    }
    protected void btnPreview_Click(Object sender, EventArgs e)
    {
        if (lstCategory.SelectedValue != "-1" || lstCategory1.SelectedValue != "-1" || lstCategory2.SelectedValue != "-1" || lstCategory3.SelectedValue!="-1")
        {
            int check = 0;
            check = ValidateInfo();
            if (check == 0)
            {
                //this.Master.ShowMessageBox = false;
                // multiViewWTX.ActiveViewIndex = 1;
                try
                {
                    if ((ItemID = AddItem()) > 0)
                    {
                        EmailToSubscribedMembers(ItemID);
                        string action = System.Web.HttpContext.Current.Request.QueryString["Action"];
                        if (action == "LiveFeed")
                        {
                            Web.Redirect("~/LiveFeed.aspx");
                        }
                        multiViewWTX.ActiveViewIndex = 2;
                    }

                }
                catch (Exception ex)
                {
                    Web.LogError(ex);
                }
            }
        }
        else
        {
            //this.Master.ShowMessage("Please select a category");
        }
        //this.Master.ShowMessage("Your Profile has been updated Successfully", "Profile Update");
      //  this.Master.ShowMessage("Add Successfully","Info");
       // Web.Redirect("~/live.aspx");
    }

    private int ValidateInfo()
    {
        int check = 0;
        try
        {
            if (chkConditions.Items.FindByText("Other see description").Selected == true)
            {
                //if (txtDescription.Content == "")
                //{
                //    this.Master.MessageBoxText = "Please enter the condition of item in 'Item Description'";
                //    this.Master.ShowMessageBox = true;
                //    check = 1;
                //}
            }
            if (chkConditions.SelectedIndex == -1)
            {
                if ((chkRememberConditions.Checked == true) || (chkRememberConditions.Checked == false))
                    //this.Master.MessageBoxText = "Please select any item condition ";
                //this.Master.ShowMessageBox = true;
                check = 1;
            }
            if (chkShippingTypes.SelectedIndex == -1)
            {
                if (ckhRememberShippingMethods.Checked == true)
                {
                  //  this.Master.MessageBoxText = "Please checked the Shipping Methods that you want to remember for future";
                    //this.Master.ShowMessageBox = true;
                    check = 1;
                }
            }
            if (chkShippingTypes.Items.FindByText("Other (See Description)").Selected == true)
            {
                //if (txtDescription.Content == "")
                //{
                //    this.Master.MessageBoxText = "Please enter the shipping type in 'Item Description'";
                //    this.Master.ShowMessageBox = true;
                //    check = 1;
                //}
            }
            if (lstCategory.SelectedValue != "-1" && lstCategory1.SelectedValue!= "-1" && lstCategory2.SelectedValue != "-1" && lstCategory3.SelectedValue!= "-1")
            {
                if (chkRememberCategories.Checked == true)
                {
                    //this.Master.MessageBoxText = "Please select categories that you want to remember for future";
                    //this.Master.ShowMessageBox = true;
                    check = 1;
                }
                else
                {
                    //this.Master.MessageBoxText = "Please Select Related Category";
                    //this.Master.ShowMessageBox = true;
                    check = 1;
                }
            }
            if ((Convert.ToInt32(txtQuantity.Text)) < 1)
            {
                txtQuantity.Text = "";
                //this.Master.MessageBoxText = "Quantity cannot be less than 1";
                //this.Master.ShowMessageBox = true;
                check = 1;
            }
        }
        catch (Exception ex)
        {
            //this.Master.MessageBoxText = ex.GetBaseException().ToString();
            //this.Master.ShowMessageBox = true;
        }
        return check;
    }
    #endregion

    #region Cookie Manipulation

    #region Write Cookies
    private void AddCookie()
    {
        // chkRememberCategories.Checked || chkRememberConditions.Checked || chkRememberDuration.Checked || chkRememberPricingDetails.Checked || ckhRememberShippingMethods.Checked
        if (chkRememberCategories.Checked || chkRememberDuration.Checked)
        {
            if (HttpContext.Current.Request.Browser.Cookies)
            {
                if (Request.Cookies["ListingPreferencesWTB"] == null)
                {
                    HttpCookie listingPreferences = new HttpCookie("ListingPreferencesWTB");

                    if (chkRememberCategories.Checked)
                    {
                        if (lstCategory.SelectedValue != "-1")
                            listingPreferences.Values["Category"] = GetSelectedCategories();

                    }
                    // if (chkRememberConditions.Checked)
                    //   listingPreferences.Values["Condition"] = GetSelectedConditionTypes();
                    if (chkRememberDuration.Checked)
                    {
                        // if ((int.Parse(ddlDays.SelectedValue)) >= 0)
                        if (ddlDays.SelectedValue != "0")
                            listingPreferences.Values["EndDays"] = EncryptRijndaelManaged(ddlDays.SelectedValue);
                        //
                        listingPreferences.Values["Condition"] = GetSelectedConditionTypes();

                    }
                    if (ckhRememberShippingMethods.Checked)
                    {
                        listingPreferences.Values["PaymentTypes"] = GetSelectedPaymentTypes();
                        listingPreferences.Values["ShippingTypes"] = GetSelectedShippingTypes();
                        listingPreferences.Values["ShippingLocation"] = ddlLocation.SelectedValue;
                    }

                    listingPreferences.Expires = DateTime.MaxValue;
                    Response.Cookies.Add(listingPreferences);
                }
                else
                {
                    if (chkRememberCategories.Checked)
                    {
                        if (lstCategory.SelectedValue != "-1")
                            Response.Cookies["ListingPreferencesWTB"]["Category"] = GetSelectedCategories();
                    }
                    else
                    {
                        if (Request.Cookies["ListingPreferencesWTB"]["Category"] != null)
                            Response.Cookies["ListingPreferencesWTB"]["Category"] = Request.Cookies["ListingPreferencesWTB"]["Category"];
                    }

                    /*      if (chkRememberConditions.Checked)
                               Response.Cookies["ListingPreferencesWTB"]["Condition"] = GetSelectedConditionTypes();
                           else
                           {
                               if (Request.Cookies["ListingPreferencesWTB"]["Condition"] != null)
                                   Response.Cookies["ListingPreferencesWTB"]["Condition"] = Request.Cookies["ListingPreferencesWTB"]["Condition"];
                           }*/

                    if (chkRememberDuration.Checked)
                    {
                        //if (int.Parse(ddlDays.SelectedValue) >= 0)
                        if (ddlDays.SelectedValue != "0")
                            Response.Cookies["ListingPreferencesWTB"]["EndDays"] = EncryptRijndaelManaged(ddlDays.SelectedValue);
                        //
                        Response.Cookies["ListingPreferencesWTB"]["Condition"] = GetSelectedConditionTypes();
                    }
                    else
                    {
                        if (Request.Cookies["ListingPreferencesWTB"]["EndDays"] != null)
                            Response.Cookies["ListingPreferencesWTB"]["EndDays"] = Request.Cookies["ListingPreferencesWTB"]["EndDays"];
                        //
                        if (Request.Cookies["ListingPreferencesWTB"]["Condition"] != null)
                            Response.Cookies["ListingPreferencesWTB"]["Condition"] = Request.Cookies["ListingPreferencesWTB"]["Condition"];
                    }

                    if (ckhRememberShippingMethods.Checked)
                    {
                        Response.Cookies["ListingPreferencesWTB"]["PaymentTypes"] = GetSelectedPaymentTypes();
                        Response.Cookies["ListingPreferencesWTB"]["ShippingTypes"] = GetSelectedShippingTypes();
                        Request.Cookies["ListingPreferencesWTB"]["ShippingLocation"] = ddlLocation.SelectedValue;
                    }
                    else
                    {
                        Request.Cookies["ListingPreferencesWTB"]["ShippingLocation"] = Request.Cookies["ListingPreferencesWTB"]["ShippingLocation"];
                        if (Request.Cookies["ListingPreferencesWTB"]["PaymentTypes"] != null)
                            Response.Cookies["ListingPreferencesWTB"]["PaymentTypes"] = Request.Cookies["ListingPreferencesWTB"]["PaymentTypes"];
                        if (Request.Cookies["ListingPreferencesWTB"]["ShippingTypes"] != null)
                            Response.Cookies["ListingPreferencesWTB"]["ShippingTypes"] = Request.Cookies["ListingPreferencesWTB"]["ShippingTypes"];
                    }

                    Response.Cookies["ListingPreferencesWTB"].Expires = DateTime.MaxValue;
                }
            }
            else
            {
              //  this.Master.MessageBoxText = "In order to save your selections for future listings, you need to enable cookies on your browser.";
                //this.Master.ShowMessageBox = true;
            }
        }
    }
    private string GetSelectedConditionTypes()
    {
        System.Text.StringBuilder ConditionTypes = new System.Text.StringBuilder();
        foreach (ListItem item in chkConditions.Items)
        {
            if (item.Selected)
            {
                ConditionTypes.Append(EncryptRijndaelManaged(item.Value));
                ConditionTypes.Append(",");
            }
        }
        string types = ConditionTypes.ToString();
        types = types.Substring(0, types.Length - 1);
        return types;
    }
    private string GetSelectedCategories()
    {
        System.Text.StringBuilder Categories = new System.Text.StringBuilder();

        if (lstCategory.SelectedValue != "-1")
        {
            Categories.Append(EncryptRijndaelManaged(lstCategory.SelectedValue.ToString()));
            Categories.Append(",");
        }
        if (lstCategory1.SelectedValue !="-1")
        {
            Categories.Append(EncryptRijndaelManaged(lstCategory1.SelectedValue.ToString()));
            Categories.Append(",");
        }
        if (lstCategory2.SelectedValue!="-1")
        {
            Categories.Append(EncryptRijndaelManaged(lstCategory2.SelectedValue.ToString()));
            Categories.Append(",");
        }
        if (lstCategory3.SelectedValue != "-1")
        {
            Categories.Append(EncryptRijndaelManaged(lstCategory3.SelectedValue.ToString()));
            Categories.Append(",");
        }
        string types = Categories.ToString();
        types = types.Substring(0, types.Length - 1);
        return types;
    }
    private string GetSelectedPaymentTypes()
    {
        System.Text.StringBuilder paymentTypes = new System.Text.StringBuilder();
        foreach (ListItem item in ckhPaymentTypes.Items)
        {
            if (item.Selected)
            {
                paymentTypes.Append(EncryptRijndaelManaged(item.Value));
                paymentTypes.Append(",");
            }
        }
        string types = paymentTypes.ToString();
        types = types.Substring(0, types.Length - 1);
        return types;
    }
    private string GetSelectedShippingTypes()
    {
        System.Text.StringBuilder shippingTypes = new System.Text.StringBuilder();
        foreach (ListItem item in chkShippingTypes.Items)
        {
            if (item.Selected)
            {
                shippingTypes.Append(EncryptRijndaelManaged(item.Value));
                shippingTypes.Append(",");
            }
        }
        string types = shippingTypes.ToString();
        types = types.Substring(0, types.Length - 1);
        return types;
    }
    #endregion

    #region Encrypt or Decrypt Cookies
    public static string EncryptRijndaelManaged(string value)
    {
        if (value == "")
            return "";

        RijndaelManaged crypto = new RijndaelManaged();
        MemoryStream ms = new MemoryStream();
        CryptoStream cs = new CryptoStream(ms, crypto.CreateEncryptor(key_192, iv_128),
            CryptoStreamMode.Write);

        StreamWriter sw = new StreamWriter(cs);

        sw.Write(value);
        sw.Flush();
        cs.FlushFinalBlock();
        ms.Flush();

        return Convert.ToBase64String(ms.GetBuffer(), 0, (int)ms.Length);
    }
    public static string DecryptRijndaelManaged(string value)
    {
        if (value == "")
            return "";

        RijndaelManaged crypto = new RijndaelManaged();
        MemoryStream ms = new MemoryStream(Convert.FromBase64String(value));
        CryptoStream cs = new CryptoStream(ms, crypto.CreateDecryptor(key_192, iv_128),
            CryptoStreamMode.Read);

        StreamReader sw = new StreamReader(cs);

        return sw.ReadToEnd();
    }
    #endregion

    #region Load Cookies
    private void LoadCookies()
    {
        try
        {
            if (Request.Cookies["ListingPreferencesWTB"] != null)
            {
                if (HttpContext.Current.Request.Browser.Cookies)
                {
                    if (Request.Cookies["ListingPreferencesWTB"]["Condition"] != null)
                    {
                        chkConditions.ClearSelection();
                        string strConditionTypes = Request.Cookies["ListingPreferencesWTB"]["Condition"];
                        string[] ConditionTypes = SplitByComma(strConditionTypes);
                        foreach (string str in ConditionTypes)
                        {
                            foreach (ListItem item in chkConditions.Items)
                            {
                                if (item.Value == DecryptRijndaelManaged(str))
                                    item.Selected = true;
                            }
                        }
                    }
                    if (Request.Cookies["ListingPreferencesWTB"]["PaymentTypes"] != null)
                    {
                        ckhPaymentTypes.ClearSelection();
                        string strPaymentTypes = Request.Cookies["ListingPreferencesWTB"]["PaymentTypes"];
                        string[] PaymentTypes = SplitByComma(strPaymentTypes);
                        foreach (string str in PaymentTypes)
                        {
                            foreach (ListItem item in ckhPaymentTypes.Items)
                            {
                                if (item.Value == DecryptRijndaelManaged(str))
                                    item.Selected = true;
                            }
                        }
                    }
                    if (Request.Cookies["ListingPreferencesWTB"]["ShippingTypes"] != null)
                    {
                        chkShippingTypes.ClearSelection();
                        string strShippingTypes = Request.Cookies["ListingPreferencesWTB"]["ShippingTypes"];
                        string[] ShippingTypes = SplitByComma(strShippingTypes);
                        foreach (string str in ShippingTypes)
                        {
                            foreach (ListItem item in chkShippingTypes.Items)
                            {
                                if (item.Value == DecryptRijndaelManaged(str))
                                    item.Selected = true;
                            }
                        }
                    }

                    if (Request.Cookies["ListingPreferencesWTB"]["ShippingLocation"] != null)
                        ddlLocation.SelectedValue = DecryptRijndaelManaged(Request.Cookies["ListingPreferencesWTB"]["ShippingLocation"]);

                    if (Request.Cookies["ListingPreferencesWTB"]["EndDays"] != null)
                        ddlDays.SelectedValue = DecryptRijndaelManaged(Request.Cookies["ListingPreferencesWTB"]["EndDays"]);

                    //if (Request.Cookies["ListingPreferencesWTB"]["Category"] != null)
                    //{
                    //    string strCategories = Request.Cookies["ListingPreferencesWTB"]["Category"];
                    //    string[] Categories = SplitByComma(strCategories);

                    //    if (Categories.Length >= 1)
                    //        ucCategories.SelectedCategoryID = Convert.ToInt32(DecryptRijndaelManaged(Categories[0]));

                    //    if (Categories.Length >= 2)
                    //        ucCategories1.SelectedCategoryID = Convert.ToInt32(DecryptRijndaelManaged(Categories[1]));

                    //    if (Categories.Length >= 3)
                    //        ucCategories2.SelectedCategoryID = Convert.ToInt32(DecryptRijndaelManaged(Categories[2]));

                    //    if (Categories.Length == 4)
                    //        ucCategories3.SelectedCategoryID = Convert.ToInt32(DecryptRijndaelManaged(Categories[3]));

                    //}
                }
                else
                {
                  //  this.Master.MessageBoxText = "In order to view your saved selections, you need to enable cookies on your browser.";
                    //this.Master.ShowMessageBox = true;
                }
            }
        }
        catch (Exception ex)
        {
            //Log.Write("ERR", ex.Message, ex);
            Web.LogError(ex);
        }
    }
    private string[] SplitByComma(string strInput)
    {
        // constants for the space and comma characters
        const char Space = ' ';
        const char Comma = ',';

        // array of delimiters to split the sentence with
        char[] delimiters = new char[]
                 {
                    Space,
                    Comma
                 };

        // split the string and then iterate over the
        // resulting array of strings

        String[] resultArray = strInput.Split(delimiters);
        return resultArray;
    }
    #endregion

    /// <summary>
    /// Expire a cookie
    /// </summary>
    /// <param name="cookieName">Name of the cookie</param>
    private void ExpireCookie(string cookieName)
    {
        if (Request.Cookies[cookieName] != null)
        {
            HttpCookie myCookie = new HttpCookie(cookieName);
            myCookie.Expires = DateTime.Now.AddMonths(-1);
            Response.Cookies.Add(myCookie);
        }
    }

    /// <summary>
    /// Check if the browser accepts cookies or not, if yes then load cookies
    /// </summary>
    /// <returns>true- if accepts cookies / false-otherwise</returns>
    private bool IfCookiesEnabled()
    {
        HttpCookie testCookie = new HttpCookie("TestCookie");
        testCookie.Expires = DateTime.Now.AddDays(1);
        Response.Cookies.Add(testCookie);

        if (Request.Cookies["TestCookie"] == null)
            return false;
        else
        {
            // Delete test cookie.
            Response.Cookies["TestCookie"].Expires = DateTime.Now.AddDays(-1);
            return true;
        }
    }

    #endregion

    #region Other Methods
    public void LoadLists()
    {
        try
        {
            try
            {
                result = PaymentTypes.GetPaymentTypes(1);
                ckhPaymentTypes.DataSource = result;
                ckhPaymentTypes.DataTextField = "PaymentName";
                ckhPaymentTypes.DataValueField = "PaymentTypeID";
                ckhPaymentTypes.DataBind();
                //ckhPaymentTypes.SelectedIndex = ckhPaymentTypes.Items.Count - 1;
            }
            catch (Exception ex)
            {
                Web.LogError(ex);
            }

            try
            {
                result = ShippingTypes.GetShippingTypes(1);
                chkShippingTypes.DataSource = result;
                chkShippingTypes.DataTextField = "ShippingName";
                chkShippingTypes.DataValueField = "ShippingTypeID";
                chkShippingTypes.DataBind();
                //chkShippingTypes.SelectedIndex = chkShippingTypes.Items.Count - 1;
            }
            catch (Exception ex)
            {
                Web.LogError(ex);
            }

            try
            {
                result = ShippingLocationTypes.GetShippingLocations(1);
                ddlLocation.DataSource = result;
                ddlLocation.DataTextField = "ShippingLocationName";
                ddlLocation.DataValueField = "ShippingLocationID";
                ddlLocation.DataBind();
                ddlLocation.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                Web.LogError(ex);
            }

            try
            {
                chkConditions.DataSource = Conditions.GetConditions(1);
                chkConditions.DataTextField = "ConditionName";
                chkConditions.DataValueField = "ConditionID";
                chkConditions.DataBind();
                chkConditions.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                Web.LogError(ex);
            }

            try
            {
                string strListingDurations = Web.SystemConfigs.GetKey("LISTING_DURATIONS");

                string[] ListingDurations = strListingDurations.Split(',');
                foreach (string duration in ListingDurations)
                {
                    ListItem item = new ListItem();
                    
                    if (duration == "0")
                        item.Text = "Until Request Fulfilled (Fees will be charged on monthly basis)";

                    else if (duration == "c")
                        item.Text = "Until Cancelled";

                    else if (duration == "1")
                        item.Text = duration + " Day - Must Buy Today";

                    else
                        item.Text = duration + " Days";

                    item.Value = duration;
                    ddlDays.Items.Add(item);
                }
                ddlDays.DataBind();
                ddlDays.SelectedIndex = 6;
            }
            catch (Exception ex)
            {
                Web.LogError(ex);
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }
    protected string GetClientSideURL(string url)
    {
        url = "../.." + url.Substring(1);
        return url;
    }
    public string GetAutoRepost(string autoRepost)
    {
        if (autoRepost == "-1")
            return "Untill it Sells";
        else if (autoRepost == "0")
            return "Do not Auto-Repost";
        else
            return autoRepost + " Time(s)";

    }
    protected void ClearData()
    {
        txtTitle.Text = "";
        lstCategory.SelectedValue = "-1";
        chkConditions.SelectedIndex = 0;
        txtOpeningPrice.Text = "";
        txtQuantity.Text = "";
        chkShippingTypes.ClearSelection();
        ckhPaymentTypes.ClearSelection();
        txtDescription.Content = "";
        ddlDays.SelectedIndex = 0;
        chkConditions.ClearSelection();

    }

    private void GetValidImageFormats()
    {
        try
        {
            // Example Expression:
            //ValidationExpression="^(([a-zA-Z]:)|(\\{2}\w+)\$?)(\\(\w[\w].*))+(.jpg|.JPG|.jpeg|.JPEG|.gif|.GIF|.bmp|.BMP|.png|.PNG|.tiff|.TIFF|.tif|.TIF)$"

            System.Text.StringBuilder sb = new System.Text.StringBuilder();

            //get extensions from system settings
            char[] chr = { ',' };
            string[] fileExtensions = Web.SystemConfigs.GetKey("DEF_IMAGE_FORMAT").Split(chr);

            //append them all in one string
            for (int i = 0; i < fileExtensions.Length; i++)
            {
                sb.Append(fileExtensions[i].Replace(" ", ""));
                sb.Append("|");
            }
            sb.Remove(sb.Length - 1, 1);

            string expression = "^(([a-zA-Z]:)|(\\\\{2}\\w+)\\$?)(\\\\(\\w[\\w].*))+(" + sb.ToString() + ")$";
            //vldiUpload1.ValidationExpression = expression;
            //vldiUpload2.ValidationExpression = expression;
            //vldiUpload3.ValidationExpression = expression;
            //vldiUpload4.ValidationExpression = expression;
        }
        catch (Exception ex)
        {
            //this.Master.MessageBoxText = ex.GetBaseException().ToString();
            //this.Master.ShowMessageBox = true;
        }
    }

    private DataTable GetImages()
    {

        ImageCount = 0;
        DataRow row;

        DataTable Images = new DataTable();
        Images.Columns.Add(new DataColumn("ListingImageName"));
        Images.Columns.Add(new DataColumn("ListingImage", typeof(byte[])));
        Images.Columns.Add(new DataColumn("ext"));

        //Upload Images
        string imageName = null;
        string ext = null;
        try
        {
            //foreach (Control ctrl in pnlImages.Controls)
            //{
            //    if (ctrl.ToString() == "System.Web.UI.WebControls.FileUpload")
            //    {
            //        FileUpload fUpload = ctrl as FileUpload;
            //        if (fUpload.HasFile)
            //        {
            if (fupPhoto.UploadedFiles.Count > 0)
            {
                foreach (Telerik.Web.UI.UploadedFile file in fupPhoto.UploadedFiles)
                {
                    row = Images.NewRow();

                    imageName = file.FileName;
                    ext = imageName.Substring(imageName.LastIndexOf(@"."));
                    if (txtTitle.Text.Length > 35)
                        imageName = txtTitle.Text.Remove(35) + "_" + ImageCount + 1;
                    else
                        imageName = txtTitle.Text + "_" + ImageCount + 1;

                    row["ListingImageName"] = imageName;
                    row["ListingImage"] = Web.UploadImage(file);
                    row["ext"] = ext;

                    Images.Rows.Add(row);
                    ImageCount++;
                }
            }
            //        }
            //    }
            //}
            Session["ImagesTable"] = Images;
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
        return Images;
    }
    private DataTable GetImages(int ItemID)
    {
        //Upload Images
        string imageName = null;
        string ext = null;
        string imagePath = null;
        string imageURL = null;
        string thumbnailPath = null;
        //        string thumbnailURL = null;

        DataTable tblImages = new DataTable();
        tblImages.Columns.Add(new DataColumn("ItemID"));
        tblImages.Columns.Add(new DataColumn("ListingImageName"));
        tblImages.Columns.Add(new DataColumn("ListingImageURL"));
        tblImages.Columns.Add(new DataColumn("ThumbnailImageURL"));
        tblImages.Columns.Add(new DataColumn("ListingImage", typeof(byte[])));
        tblImages.Columns.Add(new DataColumn("ListingThumbnail", typeof(byte[])));
        tblImages.Columns.Add(new DataColumn("ext"));

        DataTable temp = new DataTable();
        try
        {
            temp = (DataTable)Session["ImagesTable"];
            if (temp.Rows.Count > 0)
                foreach (DataRow row in temp.Rows)
                {

                    DataRow tempRow = tblImages.NewRow();
                    tempRow["ItemID"] = ItemID;
                    tempRow["ListingImageName"] = row["ListingImageName"];

                    System.Drawing.Image itemImage = System.Drawing.Image.FromFile(Server.MapPath(row["ListingImageURL"].ToString()));
                    //create image path and save
                    imageName = row["ListingImageName"].ToString();
                    string imageNumber = imageName.Substring(imageName.IndexOf("_"));
                    ext = row["ListingImageURL"].ToString().Substring(row["ListingImageURL"].ToString().IndexOf("."));
                    imagePath = Server.MapPath(@"~\PublicSite\Listing\ListingImages\") + ItemID.ToString() + imageNumber + ext;

                    if (System.IO.File.Exists(imagePath))
                        System.IO.File.Delete(imagePath);

                    itemImage.Save(imagePath);
                    imageURL = @"~\PublicSite\Listing\ListingImages\" + ItemID.ToString() + imageNumber + ext;

                    System.Drawing.Image image = itemImage.GetThumbnailImage(64, 64, null, System.IntPtr.Zero);
                    thumbnailPath = Server.MapPath(@"~\PublicSite\Listing\ListingImages\") + "th_" + ItemID.ToString() + imageNumber + ".gif";
                    image.Save(thumbnailPath, ImageFormat.Gif);

                    thumbnailPath = @"~\PublicSite\Listing\ListingImages\th_" + ItemID.ToString() + imageNumber + ".gif";


                    tempRow["ext"] = ext;
                    tempRow["ListingImageURL"] = imageURL;
                    tempRow["ThumbnailImageURL"] = thumbnailPath;
                    tempRow["ListingImage"] = row["ListingImage"];
                    tempRow["ListingThumbnail"] = row["ListingThumbnail"];
                    tblImages.Rows.Add(tempRow);

                    ImageCount++;

                    //File.Delete(Server.MapPath(row["ListingImageURL"].ToString()));
                    //File.Delete(Server.MapPath(row["ThumbnailImageURL"].ToString()));
                }

        }
        catch (VException vx)
        {
            //this.Master.MessageBoxText = vx.ErrorMessage;
            //this.Master.ShowMessageBox = true;
            //return null;
        }
        catch (Exception ex)
        {
            //this.Master.MessageBoxText = ex.GetBaseException().ToString();
            //this.Master.ShowMessageBox = true;
            //return null;
        }
        return tblImages;
    }
    //protected void chkAllConditions_CheckedChanged(object sender, EventArgs e)
    //{
    //    try
    //    {
    //        if (flag == 0)
    //        {
    //            foreach (ListItem items in chkConditions.Items)
    //                items.Selected = true;
    //            flag = 1;
    //        }
    //        else
    //        {
    //            foreach (ListItem items in chkConditions.Items)
    //                items.Selected = false;
    //            flag = 0;
    //        }
    //    }
    //    catch (VException vx)
    //    {
    //        this.Master.MessageBoxText = vx.ErrorMessage;
    //        this.Master.ShowMessageBox = true;
    //    }
    //    catch (Exception ex)
    //    {
    //        this.Master.MessageBoxText = ex.GetBaseException().ToString();
    //        this.Master.ShowMessageBox = true;
    //    }
    //}


    private void bindCategories()
    {
       DataTable categories = Web.CategoriesTable;
       lstCategory.DataSource = lstCategory1.DataSource = lstCategory2.DataSource = lstCategory3.DataSource = categories;
       lstCategory.DataTextField = lstCategory1.DataTextField = lstCategory2.DataTextField = lstCategory3.DataTextField = "CategoryName";
       lstCategory.DataValueField = lstCategory1.DataValueField = lstCategory2.DataValueField = lstCategory3.DataValueField = "CategoryID";
        lstCategory.DataBind();
        lstCategory1.DataBind();
        lstCategory2.DataBind();
        lstCategory3.DataBind();
        lstCategory.Items.Insert(0,new ListItem("----Select a Category----", "-1"));
        lstCategory1.Items.Insert(0, new ListItem("----Select a Category----", "-1"));
        lstCategory2.Items.Insert(0, new ListItem("----Select a Category----", "-1"));
        lstCategory3.Items.Insert(0, new ListItem("----Select a Category----", "-1"));
        


    }

    /// <summary>
    /// Get Listing Categories
    /// </summary>
    /// <returns>ArrayList of Listing Categories</returns>
    public DataTable GetItemCategories(int ItemID)
    {
        DataTable dtListingCategories = new DataTable();

        dtListingCategories.Columns.Add(new DataColumn("CategoryID"));
        dtListingCategories.Columns.Add(new DataColumn("ItemID"));


        if (lstCategory.SelectedValue != "-1")
        {
            DataRow row = dtListingCategories.NewRow();
            row["ItemID"] = ItemID;
            row["CategoryID"] = lstCategory.SelectedValue;
            dtListingCategories.Rows.Add(row);
        }


        if (lstCategory1.SelectedValue != "-1")
        {
            DataRow row = dtListingCategories.NewRow();
            row["ItemID"] = ItemID;
            row["CategoryID"] = lstCategory1.SelectedValue;
            dtListingCategories.Rows.Add(row);
        }
        if (lstCategory2.SelectedValue !="-1")
        {
            DataRow row = dtListingCategories.NewRow();
            row["ItemID"] = ItemID;
            row["CategoryID"] = lstCategory2.SelectedValue;
            dtListingCategories.Rows.Add(row);
        }
        if (lstCategory3.SelectedValue!="-1")
        {
            DataRow row = dtListingCategories.NewRow();
            row["ItemID"] = ItemID;
            row["CategoryID"] = lstCategory3.SelectedValue;
            dtListingCategories.Rows.Add(row);
        }
        return dtListingCategories;
    }
    #endregion
    #endregion
    protected void btncancel_Click(object sender, EventArgs e)
    {
        Web.Redirect("/live.aspx");
    }
}