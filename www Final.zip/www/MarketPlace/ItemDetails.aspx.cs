﻿using System;
using System.Collections.Generic;
using System.Linq;
using CodenameRabbitFoot.BusinessLogic;
using System.Data;
using System.Xml;
using System.Xml.Linq;
using System.Drawing;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Data.Common;
using System.Collections.Specialized;
using System.Web.Services;


public partial class MarketPlace_ItemDetails : System.Web.UI.Page
{
    public int ItemDuration = 0;
    public DateTime EndDate = DateTime.Now;
    public bool ShowMakeOfferButton = false;
    public bool ShowOptions = false;
    public bool ShowCondition = false;
    public bool ShowPayment = false;
    public bool ShowWarranty = false;
    public bool IsPaymentMethod = false;
    public bool IsShippingMethod = false;
    public bool ShowQuantity = false;
    public bool ShowShipping = false;
    public bool ShowPrice = false;
    public bool ShowPriceEach = false;
    public bool ShowLocation = false;
    public bool ShowAddress = false;
    public bool ImagesAvailable = false;
    public bool DocumentsAvailable = false;
    public bool LinksAvailable = false;
    public bool VideosAvailable = false;
    public int MemberID = 0;
    public int ListingTypeID = 0;
    public bool AllowMessaging = false;
    public bool IsMyListing = false;
    public int TotalOffers = 0;

    public string lastMaskedFilePath = "";
    public string lastMaskedImagePath = "";
    public int lastListingID = 0;
    public int lastMemberID = 0;

    protected void Page_Load(object sender, EventArgs e)
    {
        Web.CheckSession();

        try
        {

            if (Web.IsMemberSession)
            {
                Listings listing = new Listings();
                listing.LoadByPrimaryKey(Web.RecordID);
                if (listing.RowCount > 0)
                {
                    this.divEditPostButton.Visible = (listing.MemberID == Web.SessionMembers.MemberID);
                }

                CouponAccessLog calCheck = new CouponAccessLog();
                calCheck.Where.ListingID.Value = Web.RecordID;
                calCheck.Where.MemberID.Value = Web.SessionMembers.MemberID;
                calCheck.Query.Load();

                if (calCheck.RowCount > 0)
                {
                    Session["Message"] =
                        "You have already downloaded or printed this coupon. Please contact support for more details.";
                    Web.Redirect("/Live.aspx");
                }
            }

            this.Master.HideLinkApps();
            LoadDetails();
            LoadImages();
            LoadDocuments();
            LoadLinks();
            loadRatingControl();
            loadInfoCardControl();
            //FacebookShare();
            LoadVideos();

            if (Web.IsMemberSession)
            {
                Listings lot = new Listings();
                lot.LoadByPrimaryKey(Web.RecordID);
                if (lot.RowCount > 0)
                {
                    this.lnkAskSellerQuestion.Visible = !lot.MemberID.ToString().Equals(Web.SessionMembers.MemberID.ToString());
                }
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }

    protected void LoadDetails()
    {
        DataTable result = new DataTable();
        var xdoc = new XmlDocument();
        string xml = null;
        XmlNodeList _nodelist;
        try
        {
            if (Web.RecordID > 0)
            {
                Listings listing = new CodenameRabbitFoot.BusinessLogic.Listings();
                listing.LoadByPrimaryKey(Web.RecordID);

                if (listing.ListingTypeID == 2 || listing.ListingTypeID == 3 || listing.ListingTypeID == 4 || listing.ListingTypeID == 5 || listing.ListingTypeID == 6)
                {
                    divItemCondition.Visible = false;
                    divShippingPrice.Visible = false;
                }

                if (listing.RowCount == 0)
                    Web.Redirect("~/ErrorPage.aspx?status=nolisting");
                else
                {
                    if (Web.IsMemberSession)
                    {
                        if (listing.MemberID == Web.SessionMembers.MemberID)
                        {
                            IsMyListing = true;
                            TotalOffers = ListingOffers.GetListingOffersCount(Web.SessionMembers.MemberID, Web.RecordID);
                        }


                        if (!Web.HasPlacedOffer(Web.RecordID, Web.SessionMembers.MemberID))
                            ShowMakeOfferButton = true;
                        else
                            ShowMakeOfferButton = false;
                    }

                    if (listing.StatusCode > 200)
                        ShowOptions = false;
                    else
                    {
                        ShowOptions = true;
                    }

                    ListingTypes types = new ListingTypes();
                    ListingTypeID = listing.ListingTypeID;
                    types.LoadByPrimaryKey(listing.ListingTypeID);
                    lblListingType.Text = types.ListingTypeName;

                    List<int> categoryFields = CategoryFields.GetCategoryFields(listing.ListingTypeID, listing.CategoryID);
                    hfMemberID.Value = listing.s_MemberID;

                    //show seller name (can use other seller/member info on page as needed)
                    Members member = new Members();
                    member.LoadByPrimaryKey(Convert.ToInt32(hfMemberID.Value));
                    if (member.RowCount > 0)
                    {
                        lbl_Seller.Text = member.UserName;
                    }

                    result = Listings.GetListingDetails(Web.RecordID);
                    foreach (DataRow row in result.Rows)
                    {
                        if (!String.IsNullOrEmpty(row["ThumbnailURL"].ToString()))
                        {
                            img_top.ImageUrl = row["ThumbnailURL"].ToString();

                            //WebClient webclient = new WebClient();
                            //using (Stream stream = webclient.OpenRead(row["ThumbnailURL"].ToString()))
                            //{
                            //    System.Drawing.Image img = System.Drawing.Image.FromStream(stream);
                            //    if (img.Width > img.Height)
                            //    {
                            //        using (img_top)
                            //        {
                            //            img_top.Width = new Unit((double.Parse(img_top.Width.ToString().Replace("px", "")) * ((double)img.Width / (double)img.Height)).ToString());
                            //        }
                            //    }
                            //}
                        }
                        else
                        {
                            switch (listing.ListingTypeID)
                            {
                                case 1:
                                    img_top.ImageUrl = "../App_Themes/Space/Images/eOpen post_tp_world Icons/sale.png";
                                    break;
                                case 2:
                                    img_top.ImageUrl = "../App_Themes/Space/Images/eOpen post_tp_world Icons/rent.png";
                                    break;
                                case 3:
                                    img_top.ImageUrl = "../App_Themes/Space/Images/eOpen post_tp_world Icons/service.png";
                                    break;
                                case 4:
                                    img_top.ImageUrl = "../App_Themes/Space/Images/eOpen post_tp_world Icons/jobs.png";
                                    break;
                                case 5:
                                    img_top.ImageUrl = "../App_Themes/Space/Images/eOpen post_tp_world Icons/personal.png";
                                    break;
                                case 6:
                                    img_top.ImageUrl = "../App_Themes/Space/Images/eOpen post_tp_world Icons/coupon.png";
                                    break;
                                case 7:
                                    img_top.ImageUrl = "../App_Themes/Space/Images/eOpen post_tp_world Icons/coupon.png";
                                    break;
                                case 8:
                                    img_top.ImageUrl = "~/Images/noimage.png";
                                    break;
                                default:
                                    img_top.ImageUrl = "~/Images/noimage.png";
                                    break;
                            }
                        }
                        xml = row["ListingData"].ToString();

                        if (!String.IsNullOrEmpty(xml))
                        {
                            var listingData = from d in XDocument.Parse("<listings>" + xml + "</listings>").Root.Descendants()
                                              select new
                                              {
                                                  FieldID = d.Attribute("FieldID").Value,
                                                  FieldName = d.Attribute("FieldName").Value,
                                                  Data = d.Attribute("Data").Value
                                              };
                            if (listingData.Count() > 0)
                            {
                                bool isOffer = false;
                                foreach (var item in listingData)
                                {
                                    if (item.FieldName.Equals("MakeOffer"))
                                    {
                                        if (Convert.ToBoolean(item.Data))
                                        {
                                            lbl_PriceEach.Text = "Make an Offer";
                                            lbl_Price.Text = "Make an Offer";
                                            ShowPriceEach = true;
                                            isOffer = true;
                                        }
                                    }
                                    else
                                        if (item.FieldName.Equals("Title"))
                                        {
                                            lbl_Title.Text = item.Data;
                                            continue;
                                        }
                                        else if (item.FieldName.Equals("Quantity"))
                                        {
                                            lbl_Quantity.Text = item.Data;
                                            ShowQuantity = (!String.IsNullOrEmpty(lbl_Quantity.Text)) ? true : false;
                                            continue;
                                        }
                                        else if (item.FieldName.Equals("Price"))
                                        {
                                            if (string.IsNullOrEmpty(item.Data) || item.Data.Equals("0"))
                                            {
                                                lbl_Price.Text = "Make an Offer";
                                            }
                                            else
                                                lbl_Price.Text += "$" + item.Data + "<br/>";
                                            ShowPrice = (!String.IsNullOrEmpty(lbl_Price.Text)) ? true : false;
                                            continue;
                                        }
                                        else if (item.FieldName.Equals("PriceEach") && !isOffer)
                                        {
                                            string s_price = item.Data.ToLower();
                                            try
                                            {
                                                double priceeach = Convert.ToDouble(s_price);
                                                lbl_PriceEach.Text = "$" + s_price + " per Item";
                                                ShowPriceEach = true;
                                            }
                                            catch
                                            {
                                                lbl_PriceEach.Text = "";
                                                ShowPriceEach = false;
                                                lblPriceEachTitle.Visible = false;
                                            }
                                            continue;
                                        }
                                        else if (item.FieldName.Equals("Location"))
                                        {
                                            lbl_ItemLocation.Text += item.Data;
                                            ShowLocation = true;

                                        }
                                        else if (item.FieldName.Equals("Warranty"))
                                        {
                                            lbl_itemWarranty.Text += item.Data + " days";
                                            ShowWarranty = true;
                                        }
                                        else if (item.FieldName.Equals("Address"))
                                        {
                                            lblAddress.Text = item.Data;
                                            ShowAddress = true;
                                        }
                                }
                            }
                        }

                        if (categoryFields.Contains(14))
                        {
                            if (!String.IsNullOrEmpty(row["Condition"].ToString()))
                            {
                                lbl_itemCondition.Text = row["Condition"].ToString();
                                ShowCondition = true;
                            }
                            else
                                ShowCondition = false;
                        }
                        else
                            ShowCondition = false;

                        if (!String.IsNullOrEmpty(row["ListingEndDate"].ToString()))
                        {
                            ItemDuration = Convert.ToDateTime(row["ListingEndDate"].ToString()).Subtract(DateTime.Now).Days;
                            EndDate = Convert.ToDateTime(row["ListingEndDate"].ToString());
                        }

                        if (categoryFields.Contains(13))
                        {
                            if (!String.IsNullOrEmpty(row["PaymentMethods"].ToString()))
                            {
                                xml = row["PaymentMethods"].ToString();
                                xdoc.LoadXml("<Payments>" + xml + "</Payments>");
                                _nodelist = xdoc.SelectNodes("Payments/PaymentMethods");
                                if (_nodelist.Count > 0)
                                {
                                    foreach (XmlNode node in _nodelist)
                                    {
                                        if (node.Attributes.Item(0).Value != null)
                                        {
                                            IsPaymentMethod = true;
                                            lbl_paymentMethods.Text += (lbl_paymentMethods.Text.Trim() == "" ? "" : ", ") + node.Attributes.Item(0).Value.Trim();
                                        }
                                        else
                                            lbl_paymentMethods.Text = "n/a";
                                    }
                                    ShowPayment = true;
                                }
                            }
                            else
                                ShowPayment = false;
                        }
                        else
                            ShowPayment = false;

                        if (categoryFields.Contains(12))
                        {
                            ShowShipping = false;
                            if (!String.IsNullOrEmpty(listing.s_ShippingFee))
                            {
                                ShowShipping = true;
                                lbl_Shipping.Text = "$" + listing.ShippingFee + Web.GetListingPriceUnit(listing.s_ShippingFeeUnit);
                            }

                            if (!String.IsNullOrEmpty(row["ShippingMethods"].ToString()))
                            {
                                xml = row["ShippingMethods"].ToString();
                                xdoc.LoadXml("<Shipping>" + xml + "</Shipping>");
                                _nodelist = xdoc.SelectNodes("Shipping/ShippingMethods");
                                if (_nodelist.Count > 0)
                                {
                                    foreach (XmlNode node in _nodelist)
                                    {
                                        if (node.Attributes.Item(0).Value != null)
                                        {
                                            lbl_shippingMethods.Text += (lbl_shippingMethods.Text.Trim() == "" ? "" : ", ") + node.Attributes.Item(0).Value.Trim();
                                            IsShippingMethod = true;
                                        }
                                        else
                                            lbl_shippingMethods.Text = "n/a";
                                    }

                                    //if (lbl_shippingMethods.Text.Length > 3)
                                    //{
                                    //    lbl_shippingMethods.Text = lbl_shippingMethods.Text.Trim().Remove(lbl_shippingMethods.Text.Length - 1, 1);
                                    //}

                                }

                                lbl_shippinglocation.Text = (row["ShippingLocation"].ToString() == "" ? "n/a" : row["ShippingLocation"].ToString());
                                ShowShipping = true;
                            }
                        }
                        else
                            ShowShipping = false;
                    }
                }

            }
            else
                Web.Redirect("~/ErrorPage.aspx?status=nolisting");
        } 
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }

    protected void LoadImages()
    {
        DataTable result = new DataTable();
        try
        {
            result = SystemObjectFiles.GetFiles(600, 5, Web.RecordID);
            if (result.Rows.Count > 0)
            {
                rptImages.DataSource = result;
                rptImages.DataBind();

                rptCoupons.DataSource = result;
                rptCoupons.DataBind();

                ImagesAvailable = true;
            }
            else
                ImagesAvailable = false;
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }
    protected void LoadDocuments()
    {
        DataTable result = new DataTable();
        try
        {
            result = SystemObjectFiles.GetFiles(600, 6, Web.RecordID);
            if (result.Rows.Count > 0)
            {
                rpt_documents.DataSource = result;
                rpt_documents.DataBind();
                DocumentsAvailable = true;
            }
            else
                DocumentsAvailable = false;
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }
    protected void LoadVideos()
    {
        DataTable result = new DataTable();
        try
        {
            result = SystemObjectFiles.GetFiles(600, 4, Web.RecordID);
            if (result.Rows.Count > 0)
            {
                RptVideos.DataSource = result;
                RptVideos.DataBind();
                VideosAvailable = true;
            }
            else
                VideosAvailable = false;
        }
        catch (Exception ex)
        {

            Web.LogError(ex);
        }
    }
    protected void LoadLinks()
    {
        DataTable result = new DataTable();
        try
        {
            result = SystemObjectFiles.GetFiles(600, 3, Web.RecordID);
            if (result.Rows.Count > 0)
            {
                rpt_Links.DataSource = result;
                rpt_Links.DataBind();
                LinksAvailable = true;
            }
            else
                LinksAvailable = false;
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }
    void loadInfoCardControl()
    {
        try
        {
            if (Web.IsMemberSession)
            {
                var member = new Listings();
                member.Query.AddResultColumn(ListingsSchema.MemberID);
                member.Where.ListingID.Value = Web.RecordID;
                member.Query.Load();
            }
        }
        catch (Exception ex) { Web.LogError(ex); }
    }
    void loadRatingControl()
    {
        try
        {
            if (Web.IsMemberSession)
            {
                var member = new Listings();
                member.Query.AddResultColumn(ListingsSchema.MemberID);
                member.Where.ListingID.Value = Web.RecordID;
                member.Query.Load();
                MemberID = member.MemberID;
            }
        }
        catch (Exception ex) { Web.LogError(ex); }
    }
    public static bool CheckMessage(int MemberID)
    {
        bool result = false;
        try
        {
            var contact = new Contacts();
            contact.Where.ContactMemberID.Value = Web.RecordID;
            contact.Where.MemberID.Value = Web.SessionMembers.MemberID;
            if (contact.Query.Load())
            {
                if (contact.ContactStatusID == 1)
                {
                    result = true;
                }
            }
            else result = false;
        }
        catch (Exception ex)
        {

            Web.LogError(ex);
        }
        return result;
    }
    protected void RadTabStrip1_TabClick(object sender, Telerik.Web.UI.RadTabStripEventArgs e)
    {
    }

    protected string GetMaskedImage(string imagePath)
    {
        Listings listing = new CodenameRabbitFoot.BusinessLogic.Listings();
        listing.LoadByPrimaryKey(Web.RecordID);

        //check if ListingTypeID  is 7
        //then show masked image
        //else with high slide
        if (listing.ListingTypeID == 7)
        {
            //also check if current user and this listingid has same batch
            Database db = DatabaseFactory.CreateDatabase();
            DbCommand dbCommand = db.GetSqlStringCommand("SELECT * FROM dbo.MemberCoupons, dbo.MemberContactList WHERE dbo.MemberCoupons.ListingID = @ListingID AND dbo.MemberCoupons.BatchNumber = dbo.MemberContactList.BatchNumber AND dbo.MemberContactList.ContactEmail = @ContactEmail");
            db.AddInParameter(dbCommand, "@ListingID", DbType.Int32, listing.ListingID);
            db.AddInParameter(dbCommand, "@ContactEmail", DbType.String, Web.SessionMembers.Email);
            DataSet ds = db.ExecuteDataSet(dbCommand);

            if (ds.Tables[0].Rows.Count == 0 && listing.MemberID != Web.SessionMembers.MemberID)
                Web.Redirect("/Live.aspx");

            divTopDetails.Visible = false;
            rptImages.Visible = false;
            rptCoupons.Visible = true;
            ImagesAvailable = true;
            //mpage_mainDetails.Visible = false;
            dv_mainDetails.Visible = false;
            panelOptions.Visible = true;
            ShowOptions = false;
            return MaskImage(Web.SystemConfigs.SystemConfigKeys["ATTACHMENTS_PHYSICAL_PATH"] + @"\" + imagePath, listing.ListingID);
        }
        else
        {
            rptImages.Visible = true;
            rptCoupons.Visible = false;
            panelOptions.Visible = false;

            return Web.SystemConfigs.SystemConfigKeys["ATTACHMENTS_PHYSICAL_PATH"] + @"\" + imagePath;
            //return MaskImage(Web.SystemConfigs.SystemConfigKeys["ATTACHMENTS_PHYSICAL_PATH"] + @"\" + imagePath, listing.ListingID);
        }
    }

    string MaskImage(string imageURL, int ListingID)
    {
        try
        {
            //get original image
            System.Drawing.Image originalBMP = System.Drawing.Image.FromFile(imageURL);

            //ShowOptions = false;

            //make a bigger space (in this case it will be 1000 plus in height)
            Bitmap finalBMP = new Bitmap(originalBMP.Width, originalBMP.Height + 30);
            using (Graphics g = Graphics.FromImage(finalBMP))
            {
                g.FillRectangle(Brushes.Black, new Rectangle(0, originalBMP.Height, originalBMP.Width, 30));

                //draw original image
                g.DrawImage(originalBMP, 0, 0, originalBMP.Width, originalBMP.Height);

                //draw any image/logo on it
                g.DrawImage(System.Drawing.Image.FromFile(Server.MapPath("watermark.png")), new Point(originalBMP.Width / 2 - 60, originalBMP.Height / 2 - 55));

                // g.DrawImage(System.Drawing.Image.FromFile(Server.MapPath("mask.png")), new System.Drawing.Rectangle(0, 0, originalBMP.Width, originalBMP.Height));

                //draw text/strings on it
                string text2Write = "One Time Use Only. Must be presented by: " + Web.SessionMembers.FullName + "     Serial# " + ListingID.ToString() + "." + Web.SessionMembers.MemberID.ToString();
                int fontSize = 20;
                Font font = new Font("Verdana", fontSize);

                // Measure string.
                double calculatedWidth = 0;
                while (calculatedWidth == 0 || calculatedWidth > originalBMP.Width)
                {
                    font = new Font("Verdana", fontSize--);
                    calculatedWidth = g.MeasureString(text2Write, font).Width;
                }

                g.DrawString(text2Write, font, Brushes.White, new PointF(2, originalBMP.Height + 1));
            }
            //use finalBMP where ever you want :) 
            string file = Guid.NewGuid() + ".jpg";
            string fileName = @"UploadedImages\" + file;
            finalBMP.Save(Server.MapPath(fileName));

            lastMaskedFilePath = file;
            lastMaskedImagePath = fileName;
            lastListingID = ListingID;
            lastMemberID = Web.SessionMembers.MemberID;

            return fileName;
            //imgMain.ImageUrl = @"Download\" + fileName;
            //return //imgMain.ImageUrl;
            //pictureBox1.Image = finalBMP;
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
            //throw ex;
        }
        return "";
    }

    protected void btnDownload_Click(object sender, EventArgs e)
    {
        try
        {
            //download image to client
            Response.ContentType = "image/jpeg";
            Response.AppendHeader("Content-Disposition", "attachment; filename=coupon.jpg");
            Response.TransmitFile(lastMaskedImagePath);

            //make an entry in DB
            CouponAccessLog cal = new CouponAccessLog();
            cal.AddNew();
            cal.ListingID = lastListingID;
            cal.MemberID = lastMemberID;
            cal.AccessType = 2;

            cal.Save();
        }
        catch (Exception ex)
        {
            throw;
        }
    }

    protected string GetListingMembers(int ListingID)
    {
        string result = "";
        ListingOffers listingOffers = new ListingOffers();
        listingOffers.Query.AddResultColumn(ListingOffersSchema.OfferBy.FieldName);
        listingOffers.Query.Distinct = true;
        listingOffers.Where.ListingID.Value = ListingID;
        listingOffers.Where.OfferBy.Value = Web.SessionMembers.MemberID;
        listingOffers.Where.OfferBy.Operator = NCI.EasyObjects.WhereParameter.Operand.NotEqual;
        listingOffers.Query.Load();
        if (listingOffers.RowCount > 0)
        {
            do
            {
                Members members = new Members();
                members.Query.AddResultColumn(MembersSchema.FullName.FieldName);
                members.Where.MemberID.Value = listingOffers.OfferBy;
                members.Query.Load();
                result += "[<a href='ViewOffer.aspx?Action=View&RecordID=" + Secure.Encrypt(Web.RecordID) + "&MID=" + Secure.Encrypt(listingOffers.OfferBy) + "'>" + members.FullName + "</a>]&nbsp;";
            } while (listingOffers.MoveNext());
        }
        return result;
    }

    [WebMethod(EnableSession = true)]
    public static string AskSellerQuestion(string recordID, string questionText)
    {
        string result = "success";
        try
        {
            int listingID = Convert.ToInt32(Secure.Decrypt(recordID));
            Listings lot = new Listings();
            lot.LoadByPrimaryKey(listingID);

            Questions question = new Questions();
            question.AddNew();
            question.ObjectID = listingID;
            question.QuestionBy = Web.SessionMembers.MemberID;
            question.QuestionDate = DateTime.Now;
            question.s_Question = questionText;
            question.IsActive = 1;
            question.IsReplied = 0;
            question.QuestionTo = lot.MemberID;
            question.SystemObjectTypeID = 600;
            question.Save();

            Members seller = new Members();
            seller.LoadByPrimaryKey(lot.MemberID);

            string title = Listings.GetTitle(listingID);
            string replylink = Web.SystemConfigs.GetKey("SITE_URL") + "MarketPlace/MyListings.aspx?tabid=tabs-4&QuestionID=" + Secure.Encrypt(question.QuestionID) + "&QuestionFrom=" + Web.SessionMembers.UserName;
            StringDictionary TemplateKeys = new StringDictionary();
            TemplateKeys.Add("#email_header#", Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER"));
            TemplateKeys.Add("#fullname#", seller.FullName);
            TemplateKeys.Add("#item_title#", title);
            TemplateKeys.Add("#profile_name#", Web.SessionMembers.UserName);
            TemplateKeys.Add("#question#", question.s_Question);
            TemplateKeys.Add("#link#", replylink);
            TemplateKeys.Add("#reply_link#", replylink);
            TemplateKeys.Add("#link_log_myeoffer#", Web.SystemConfigs.GetKey("SITE_URL") + "Account/Login.aspx");
            TemplateKeys.Add("#email_footer#", Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER"));
            Web.NotifyMember(seller.MemberID, 12, TemplateKeys);
            // Web.SendMail(seller.Email, Web.SystemConfigs.GetKey("ALERTS_EMAIL"), 302, TemplateKeys);

            // askd question from seller
            System.Collections.Specialized.StringDictionary templateKeys = new System.Collections.Specialized.StringDictionary();
            templateKeys = new System.Collections.Specialized.StringDictionary();
            templateKeys.Add("#viewlink#", "../Listing/DealingFloor.aspx?TabIndex=130");
            templateKeys.Add("#initiatedto#", "#memberid#" + seller.MemberID + "#endmemberid#");
            templateKeys.Add("#profileclass#", "#profileclass#" + seller.MemberID + "#endprofileclass#");
            templateKeys.Add("#initiatedtoprofile#", "ViewContact.aspx?Action=ViewDealer&RecordID=#encrypt#" + seller.MemberID + "#endencrypt#");
            Web.AddPrivateActivityLog(16, templateKeys, seller.MemberID, question.QuestionID, Web.SessionMembers.MemberID);
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
            result = "failed";
        }

        return result;
    }



}