﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CodenameRabbitFoot.BusinessLogic;
using System.Data;
using System.Xml;
using System.Web.UI.HtmlControls;
using System.Collections;
using System.Xml.Linq;
using System.Drawing;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Data.Common;
using System.Collections.Specialized;

public partial class MarketPlace_ViewOffer : System.Web.UI.Page
{
    protected bool ShowOffer = true;
    protected bool ShowSellerOptions = false;
    protected bool ShowBuyerOptions = false;
    protected bool ShowPrintOptions = false;
    protected bool ShowSendOption = false;
    protected bool ShowPricing = false;
    protected bool ShowShipping = false;
    protected bool ShowPayment = false;
    protected bool ShowDocument = false;
    protected bool ShowQTY = false;
    private bool IsOwner = false;
    protected string ShippingPrice = string.Empty;
    protected string AdditionalPrice = string.Empty;
    protected int AvailableQuantity = 0;

    protected void Page_Load(object sender, EventArgs e)
    {

        Web.CheckSession("~/MarketPlace/ViewOffer.aspx?Action=View&RecordID=" + Web.RecordID);

        this.Master.HideLinkApps();

        // if (Request.QueryString["MID"] == null || Request.QueryString["MID"].ToString() == "")
        //     Web.Redirect("../index.aspx");

        if (!IsPostBack)
        {
            LoadDetails();
        }
    }

    protected void LoadDetails()
    {
        DataTable result = new DataTable();
        var xdoc = new XmlDocument();
        string xml = null;
        XmlNodeList _nodelist;
        // try
        {
            if (Web.RecordID > 0)
            {
                Listings listing = new CodenameRabbitFoot.BusinessLogic.Listings();
                listing.LoadByPrimaryKey(Web.RecordID);
                if (listing.RowCount == 0)
                    Web.Redirect("~/ErrorPage.aspx?status=nolisting");
                else
                {

                    if (listing.MemberID == Web.SessionMembers.MemberID)
                        IsOwner = true;

                    ShippingPrice = listing.s_ShippingFee;
                    AdditionalPrice = listing.s_AdditionalFee;

                    //if memberID is passed then use it else go with login user session memberID
                    //this is when owner of an item is viewing offers and he specifically selects what thread he want to see
                    int MID = Web.SessionMembers.MemberID;
                    if (Request.QueryString["MID"] != null && Request.QueryString["MID"].ToString() != "")
                        MID = Convert.ToInt32(Secure.Decrypt(Request.QueryString["MID"].ToString()));

                    DataTable dt = ListingOffers.GetListingOffers(Web.RecordID, MID);

                    //Response.Write("WTF" + dt.Rows.Count.ToString());


                    if (listing.StatusCode > 200)
                        ShowOffer = false;
                    else
                    {
                        ShowOffer = true;
                        if (Web.IsMemberSession)
                            if (!Web.HasPlacedOffer(Web.RecordID, Web.SessionMembers.MemberID))
                                ShowOffer = true;
                            else ShowOffer = false;
                    }


                    List<int> categoryFields = CategoryFields.GetCategoryFields(listing.ListingTypeID, listing.CategoryID);
                    result = Listings.GetListingDetails(Web.RecordID);

                    foreach (DataRow row in result.Rows)
                    {
                        img_top.ImageUrl = row["ThumbnailURL"].ToString();
                        if (String.IsNullOrEmpty(row["ThumbnailURL"].ToString()))
                        {
                            img_top.ImageUrl = "~/Images/noimage.png";
                        }

                        xml = row["ListingData"].ToString();

                        if (!String.IsNullOrEmpty(xml))
                        {
                            var listingData = from d in XDocument.Parse("<listings>" + xml + "</listings>").Root.Descendants()
                                              select new
                                              {
                                                  FieldID = d.Attribute("FieldID").Value,
                                                  FieldName = d.Attribute("FieldName").Value,
                                                  Data = d.Attribute("Data").Value
                                              };
                            if (listingData.Count() > 0)
                            {
                                foreach (var item in listingData)
                                {
                                    if (item.FieldName.Equals("MakeOffer"))
                                    {
                                        if (Convert.ToBoolean(item.Data))
                                        {
                                            lbl_PriceEach.Text = "Make an Offer";
                                            //lbl_Price.Text = "Make an Offer";
                                            //ShowPriceEach = true;
                                            //isOffer = true;
                                        }
                                    }
                                    else if (item.FieldName.Equals("Title"))
                                    {
                                        if (!IsPostBack)
                                            lbl_Title.Text = item.Data;
                                        continue;
                                    }
                                    else if (item.FieldName.Equals("Quantity"))
                                    {
                                        lblQuantity.Text = item.Data;
                                        AvailableQuantity = Convert.ToInt32(item.Data);
                                        continue;
                                    }
                                    else if (item.FieldName.Equals("PriceEach"))
                                    {
                                        lbl_PriceEach.Text = "$" + item.Data;
                                        continue;
                                    }
                                }
                            }
                        }
                    }


                    rptOffers.DataSource = dt.DefaultView;
                    rptOffers.DataBind();

                }
            }
            else
                Web.Redirect("~/ErrorPage.aspx?status=nolisting");
        }

        //  catch (Exception ex)
        {
            //      Web.LogError(ex);
            //      throw ex;
        }
    }

    protected string TimeLeft(DateTime OfferDate, int ValidFor)
    {
        TimeSpan timeleft = OfferDate.AddDays(ValidFor).Subtract(DateTime.Now);
        if (timeleft.TotalSeconds > 0)
        {
            if (timeleft.Days > 0)
                return timeleft.Days + " day(s), " + timeleft.Hours + " hr(s), " + timeleft.Minutes + " min(s)";
            else
                return timeleft.Hours + " hr(s), " + timeleft.Minutes + " min(s)";

        }
        else return "Expired";
    }

    protected string GetOfferType(int BuyEntireLot)
    {
        if (BuyEntireLot == 1)
            return "for Entire Lot";
        else
            return "per item";
    }



    #region accept offer region


    private void sendDeclineEmail(int ListingOfferID)
    {
        try
        {
            ListingOffers offer = new ListingOffers();
            if (offer.LoadByPrimaryKey(ListingOfferID))
            {
                Members buyer = new Members();
                buyer.LoadByPrimaryKey(offer.OfferBy);

                string title = Listings.GetTitle(offer.ListingID);

                //Decline Email To Buyer
                StringDictionary TemplateKeys = new StringDictionary();
                TemplateKeys.Add("#email_header#", Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER"));
                TemplateKeys.Add("#fullname#", buyer.FullName);
                TemplateKeys.Add("#seller_profile_name#", Web.SessionMembers.UserName);
                TemplateKeys.Add("#offer_profile_name#", "your");
                TemplateKeys.Add("#offerby#", "Your");
                TemplateKeys.Add("#item_lot#", title);
                TemplateKeys.Add("#email_footer#", Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER"));
                Web.NotifyMember(buyer.MemberID, 14, TemplateKeys);

                TemplateKeys = new System.Collections.Specialized.StringDictionary();
                TemplateKeys.Add("#lot#", title);
                TemplateKeys.Add("#viewlot#", "../MarketPlace/ItemDetails.aspx?Action=View&RecordID=#encrypt#" + offer.ListingID + "#endencrypt#");
                TemplateKeys.Add("#initiatedto#", "#memberid#" + buyer.MemberID + "#endmemberid#");
                TemplateKeys.Add("#profileclass#", "#profileclass#" + buyer.MemberID + "#endprofileclass#");
                TemplateKeys.Add("#initiatedtoprofile#", "/Contacts/ViewProfile.aspx?Action=ViewDealer&RecordID=#encrypt#" + buyer.MemberID + "#endencrypt#");
                Web.AddPrivateActivityLog(49, TemplateKeys, Web.SessionMembers.MemberID, offer.ListingOfferID, offer.OfferBy);
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }
    protected void AddToContact(int MemberID)
    {
        try
        {
            if (Web.SessionMembers.MemberID != MemberID)
            {
                Contacts contact = new Contacts();
                contact.Where.MemberID.Value = Web.SessionMembers.MemberID;
                contact.Where.ContactMemberID.Value = MemberID;
                contact.Query.Load();
                if (contact.RowCount < 1)
                {
                    int InvitationID = 0;
                    DataTable dt = Invitations.CheckIfInvited(Web.SessionMembers.MemberID, MemberID);
                    if (dt.Rows.Count <= 0)
                    {
                        Members member = new Members();
                        member.LoadByPrimaryKey(MemberID);
                        string[] name = member.FullName.Split(' ');
                        InvitationID = Contacts.AddToContact(member.Email, (!String.IsNullOrEmpty(member.FullName)) ? name[0] : "", member.CompanyName, Web.SessionMembers.MemberID, (int)ContactTypes.Client, 1);
                        if (InvitationID > 0)
                        {
                            Invitations invitation = new Invitations();
                            invitation.LoadByPrimaryKey(InvitationID);

                            System.Collections.Specialized.StringDictionary templateKeys = new System.Collections.Specialized.StringDictionary();
                            try
                            {
                                // add activity
                                var newContact = new Contacts();
                                newContact.Where.InvitationID.Value = InvitationID;
                                newContact.Query.Load();
                                if (newContact.RowCount > 0)
                                {
                                    templateKeys.Add("#type#", Web.GetContactType(newContact.ContactType));
                                    templateKeys.Add("#initiatedto#", "#memberid#" + newContact.ContactMemberID + "#endmemberid#");
                                    templateKeys.Add("#profileclass#", "#profileclass#" + newContact.ContactMemberID + "#endprofileclass#");
                                    templateKeys.Add("#initiatedtoprofile#", "/Contacts/ViewProfile.aspx?Action=ViewDealer&RecordID=#encrypt#" + newContact.ContactMemberID + "#endencrypt#");
                                    Web.AddPrivateActivityLog(Web.SessionMembers.MemberID, 33, templateKeys, Web.SessionMembers.MemberID, newContact.ContactID, member.MemberID);
                                }
                                templateKeys = new System.Collections.Specialized.StringDictionary();
                                templateKeys.Add("#email_header#", Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER"));
                                templateKeys.Add("#email_footer#", Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER"));
                                templateKeys.Add("#profile_link#", Web.SystemConfigs.GetKey("SITE_URL") + "Contacts/ViewProfile.aspx?Action=Dealer&RecordID=" + Secure.Encrypt(Web.SessionMembers.MemberID));
                                templateKeys.Add("#company_invitee#", Web.SessionMembers.CompanyName);
                                templateKeys.Add("#fullname_invitee#", Web.SessionMembers.FullName);
                                name = Web.SessionMembers.FullName.Split(' ');
                                templateKeys.Add("#first_name_invitee#", name[0]);
                                templateKeys.Add("#fullname#", member.FullName);
                                templateKeys.Add("#type#", Web.GetContactType(invitation.ContactType));
                                templateKeys.Add("#message#", "Please accept my invitation to add you as my " + Web.GetContactType(invitation.ContactType) + " in order to keep up to date with your " + Web.GetActivityType(invitation.ContactType) + " activities, and communicate to you instantly on " + Web.SystemConfigs.GetKey("SITE_NAME") + ".com.");

                                Web.NotifyMember(member.MemberID, 1, templateKeys);
                            }
                            catch (Exception ex)
                            {
                                Web.LogError(ex);
                            }

                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }

    #endregion


    protected bool HideSubmitButton(int OfferQuantity)
    {

        //this.Master.ShowMessage(AvailableQuantity.ToString(), "");

        if (OfferQuantity <= AvailableQuantity)
        {
            return true;
        }
        else
        {

            if (IsOwner)
            {
                this.Master.ShowMessage("You can not accept this offer because the available quanity has been decresed since this offer has been made.", "");
                // we need to add the edit offer functionality for buyer
            }
            else
            {
                // this.Master.ShowMessage("Please edit your offer as the quantity is no more available.", "");
                // Please edit your offer as the quantity is no more available...
            }
            return false;
        }
    }

    protected bool ShowButtons(int OfferStatus, string UpdateDate)
    {
        //initially all ok
        //else if declined (400) then allow after 7 days
        if (OfferStatus == 100)//&& IsOwner == true
            return true;
        else if (OfferStatus == 400 && UpdateDate != "" && Convert.ToDateTime(UpdateDate).AddDays(7) < DateTime.Now)
            return true;
        else
            return false;
    }

    protected string isCounterOfferButtonNeeded(string BuyItOrLeaveIt, string RejectionCount, string Quantity, string TotalPrice, string OfferPrice, string IsBuyEntireListing)
    {
        //is FinalOffer Or RejectionLimitReached Or offer is Same or More than last

        int rejectionCount = 0;
        try { rejectionCount = int.Parse(RejectionCount); }
        catch { }

        int MID = Web.SessionMembers.MemberID;
        if (Request.QueryString["MID"] != null && Request.QueryString["MID"].ToString() != "")
            MID = Convert.ToInt32(Secure.Decrypt(Request.QueryString["MID"].ToString()));

        bool priceCheckOK = false;
        double lastOfferAmount = 0;
        DataTable offerDT = ListingOffers.GetListingOffers(Web.RecordID, MID);
        if (offerDT.Rows.Count > 0)
        {
            if (offerDT.Rows.Count == 1) //first offer on listing so get last price and info from extendedfield table
            {
                ListingExtendedFields listingExtendedField = new ListingExtendedFields();
                listingExtendedField.Query.AddResultColumn(ListingExtendedFieldsSchema.Data.FieldName);
                listingExtendedField.Where.ObjectID.Value = Web.RecordID;
                listingExtendedField.Where.FieldID.Value = "4,10";
                listingExtendedField.Where.FieldID.Operator = NCI.EasyObjects.WhereParameter.Operand.In;
                listingExtendedField.Query.Load();

                if (listingExtendedField.RowCount > 0)
                {
                    do
                    {
                        if (listingExtendedField.Data != "" && listingExtendedField.Data != "0")
                        {
                            if (lastOfferAmount == 0)
                                lastOfferAmount = Convert.ToDouble(listingExtendedField.Data);
                            else
                                lastOfferAmount *= Convert.ToDouble(listingExtendedField.Data);
                        }
                    } while (listingExtendedField.MoveNext());
                }

                if (IsBuyEntireListing == "1")
                    priceCheckOK = Convert.ToDouble(OfferPrice) >= lastOfferAmount;
                else
                    priceCheckOK = Convert.ToDouble(OfferPrice) * Convert.ToDouble(Quantity) >= lastOfferAmount;
            }
            else //match with last offer
            {
                Listings listing = new Listings();
                listing.LoadByPrimaryKey(Web.RecordID);
                if (listing.RowCount > 0)
                {
                    //if owner itself then dont show counter offer button if a person is offering same or more
                    //else if not owner then dont show counter offer button if owner is offering same or less
                    if (listing.MemberID == Web.SessionMembers.MemberID)
                        priceCheckOK = Convert.ToDouble(TotalPrice) >= Convert.ToDouble(offerDT.Rows[1]["TotalPrice"].ToString());
                    else
                        priceCheckOK = Convert.ToDouble(TotalPrice) <= Convert.ToDouble(offerDT.Rows[1]["TotalPrice"].ToString());
                }
            }
        }

        return (BuyItOrLeaveIt == "1" || rejectionCount > 1 || priceCheckOK ? "none" : "inline");
    }

    protected bool IsMyOffer(int OfferBy, int OfferStatus)
    {
        if (OfferBy == Web.SessionMembers.MemberID && OfferStatus == 100)
            return true;
        else
            return false;
    }

    protected void rptOffers_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName == "AcceptOffer")
        {
            if (ListingOffers.Accept(Convert.ToInt32(e.CommandArgument)))
            {
                Web.SendWinnerEmail(Convert.ToInt32(e.CommandArgument));
                // TO DO: make him as contact
                Web.Redirect("/live.aspx");
            }
        }
        else if (e.CommandName == "DeclineOffer")
        {
            if (ListingOffers.Decline(Convert.ToInt32(e.CommandArgument)))
            {
                sendDeclineEmail(Convert.ToInt32(e.CommandArgument));
                Fx.ExecuteText(string.Format(" UPDATE dbo.MemberActivityLog SET IsActive=0 WHERE ReferenceID='{0}' AND ActivityID='47' ", e.CommandArgument));
                Web.Redirect("ViewOffer.aspx");
            }
        }   
        else if (e.CommandName == "CancelOffer")
        {
            if (ListingOffers.Decline(Convert.ToInt32(e.CommandArgument)))
            {
                sendDeclineEmail(Convert.ToInt32(e.CommandArgument));
                Fx.ExecuteText(string.Format(" UPDATE dbo.MemberActivityLog SET IsActive=0 WHERE ReferenceID='{0}' AND ActivityID='47' ", e.CommandArgument));
                Web.Redirect("ViewOffer.aspx");
            }
        }
    }


    protected void btnMakeCounterOffer_Click(object sender, EventArgs e)
    {
        //   try
        {
            DataTable offerDT = ListingOffers.GetListingOffers(Web.RecordID, Web.SessionMembers.MemberID);

            if (offerDT.Rows.Count > 0)
            {
                Listings listing = new Listings();
                listing.LoadByPrimaryKey(Convert.ToInt32(offerDT.Rows[0]["ListingID"].ToString()));

                string ListingTitle = lbl_Title.Text;

                ListingExtendedFields fields = new ListingExtendedFields();
                fields.Where.ObjectID.Value = listing.ListingID;
                fields.Where.IsActive.Value = 1;
                if (fields.Query.Load())
                    ListingTitle = Convert.ToString(Web.GetFieldData(fields, 20));

                Members member = new Members();
                member.LoadByPrimaryKey(listing.MemberID);


                int QTY = (!String.IsNullOrEmpty((rptOffers.Items[0].FindControl("txtQTY") as TextBox).Text)) ? Convert.ToInt32((rptOffers.Items[0].FindControl("txtQTY") as TextBox).Text) : 0;
                double price = Convert.ToDouble((rptOffers.Items[0].FindControl("txtOfferPrice") as TextBox).Text);
                double shippingPrice = 0, totalPrice = 0;

                // calculate total offer price
                if (QTY > 0 && price > 0)
                {

                    totalPrice = QTY * price;


                    if (!String.IsNullOrEmpty(listing.s_ShippingFee))
                    {
                        //calculate shipping price
                        shippingPrice = Convert.ToDouble(listing.ShippingFee);
                        if (listing.ShippingFeeUnit == 1)
                        {
                            if (!String.IsNullOrEmpty(listing.s_AdditionalFee))
                                shippingPrice = (shippingPrice + (Convert.ToDouble(listing.AdditionalFee) * (QTY - 1)));
                        }
                        totalPrice = totalPrice + shippingPrice;
                        ShowShipping = true;
                    }
                }
                else if (price > 0)
                    totalPrice = price;
                else
                    totalPrice = 0;

                ListingOffers newOffer = new ListingOffers();
                newOffer.AddNew();
                newOffer.ListingID = Convert.ToInt32(offerDT.Rows[0]["ListingID"].ToString());
                newOffer.OfferDate = DateTime.Now;
                newOffer.OfferBy = Web.SessionMembers.MemberID;
                newOffer.OfferStatusID = 800;
                newOffer.s_ArrangePickup = offerDT.Rows[0]["ArrangePickup"].ToString();
                newOffer.s_OfferValidFor = offerDT.Rows[0]["OfferValidFor"].ToString();
                newOffer.s_PaymentTypeID = offerDT.Rows[0]["PaymentTypeID"].ToString();
                newOffer.AdditionalTerms = (rptOffers.Items[0].FindControl("txtAdditionalTerms") as TextBox).Text;
                newOffer.ShippingPrice = Convert.ToDecimal(shippingPrice);
                newOffer.TotalPrice = Convert.ToDecimal(totalPrice);
                newOffer.OfferPrice = Convert.ToDecimal(price);
                newOffer.Quantity = QTY;
                newOffer.s_IsBuyEntireListing = ((rptOffers.Items[0].FindControl("rdlUnit") as RadioButtonList).SelectedIndex == 0) ? "1" : "0";
                newOffer.ListingTypeID = Convert.ToInt32(offerDT.Rows[0]["ListingTypeID"].ToString());
                newOffer.s_ShippingTypeID = offerDT.Rows[0]["ShippingTypeID"].ToString();
                //newOffer.s_BuyItOrLeaveIt = (chkBuyOrLeave.Checked) ? "1" : "0";
                newOffer.Save();

                HiddenField hidOfferID = rptOffers.Items[0].FindControl("hidOfferID") as HiddenField;
                //TODO:

                //Counter Offer ID ON which ITem??
                ListingOffers offer = new ListingOffers();
                offer.LoadByPrimaryKey(Convert.ToInt32(hidOfferID.Value));
                offer.CounterOfferID = newOffer.ListingOfferID;
                offer.Save();

                Web.Redirect("/live.aspx");
            }
        }
        //    catch (Exception exp)
        {
            //        throw exp;
            //Web.LogError(exp);
        }
    }
}