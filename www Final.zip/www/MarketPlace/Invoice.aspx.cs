﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Xml;
using CodenameRabbitFoot.BusinessLogic;

public partial class MarketPlace_Invoice : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        LoadDetails();
    }

    protected void LoadDetails()
    {
        try
        {
            // get the offer data 
            ListingOffers offer = new ListingOffers();
            offer.LoadByPrimaryKey(Web.RecordID); //Web.RecordID

            if (offer.RowCount > 0)
            {
                litQuantity.Text = offer.Quantity.ToString();
                litPrice.Text = "$" + offer.OfferPrice.ToString();
                litTotal.Text = "$" + offer.TotalPrice.ToString();
                litShippingPrice.Text = "$" + offer.s_ShippingPrice;
                litAdditionalTerms.Text = offer.AdditionalTerms;

                // get payment method type
                PaymentTypes pTypes = new PaymentTypes();
                pTypes.LoadByPrimaryKey(offer.PaymentTypeID);
                litPaymentMethod.Text = pTypes.PaymentName;

                // get shipping method type
                ShippingTypes shippingTypes = new ShippingTypes();
                shippingTypes.LoadByPrimaryKey(offer.ShippingTypeID);
                litShippingMethod.Text = shippingTypes.ShippingName;


                DataTable result = new DataTable();
                var xdoc = new XmlDocument();
                string xml = null;
                XmlNodeList _nodelist;
                Listings listing = new CodenameRabbitFoot.BusinessLogic.Listings();
                listing.LoadByPrimaryKey(offer.ListingID);
                if (listing.RowCount == 0)
                    Web.Redirect("~/ErrorPage.aspx?status=nolisting");

                else
                {
                    result = Listings.GetListingDetails(listing.ListingID);
                    // get seller information
                    Members seller = new Members();
                    seller.LoadByPrimaryKey(listing.MemberID);
                    litSellerName.Text = seller.FullName;
                    litSellerCompanyName.Text = seller.CompanyName;
                    litSellerEmail.Text = seller.Email;

                    ShippingAddresses sellerAddress = ShippingAddresses.LoadByMemberID(seller.MemberID);
                    litSellerAddress.Text = sellerAddress.Address1;
                    litSellerCountry.Text = sellerAddress.CountryName;
                    litSellerCity.Text = sellerAddress.City;



                    // logic to get the buyer
                    var buyer = new Members();
                    if (listing.MemberID == offer.OfferBy) // mean the counter offer is by the seller to the buyer
                    {
                        // get the buyer from the fucking counteroffer id
                        var previousOffer = new ListingOffers();
                        previousOffer.Where.ListingOfferID.Value = offer.CounterOfferID;
                        previousOffer.Query.AddResultColumn(ListingOffersSchema.OfferBy);
                        previousOffer.Query.Load();

                        if (previousOffer.RowCount > 0)
                            buyer.LoadByPrimaryKey(previousOffer.OfferBy);
                    }
                    else
                        buyer.LoadByPrimaryKey(offer.OfferBy);

                    // get buyer Address
                    var buyerAddress = ShippingAddresses.LoadByMemberID(buyer.MemberID);

                    litShippingLocation.Text = buyerAddress.Address1 + "<br />" + buyerAddress.City + ", " + buyerAddress.CountryName;

                    foreach (DataRow row in result.Rows)
                    {
                        xml = row["ListingData"].ToString();

                        if (!String.IsNullOrEmpty(xml))
                        {
                            xdoc.LoadXml("<listings>" + xml + "</listings>");
                            _nodelist = xdoc.SelectNodes("listings/ListingData");
                            if (_nodelist.Count > 0)
                            {
                                foreach (XmlNode node in _nodelist)
                                {
                                    if (node.Attributes.Item(0).Value == "20")
                                        litLotName.Text = node.Attributes.Item(2).Value;
                                }

                            }
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
         //   throw ex;
            Web.LogError(ex);
        }
    }
}