﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Xml;
using CodenameRabbitFoot.BusinessLogic;

public partial class MarketPlace_PrintListing : System.Web.UI.Page
{
    public static bool IsItemCondition = false;
    public static bool IsItemWarranty = false;
    public static bool IsPaymentMethod = false;
    public static bool IsShippingMethod = false;
    public static bool IsPrice = false;
    public static bool IsQuantity = false;
    public static bool IsShipping = false;
    public static bool IsLocation = false;
    public static bool ImagesAvailable = false;
    public static bool DocumentsAvailable = false;
    public static bool VideosAvailable = false;
    public static string title = "";

    protected void Page_Load(object sender, EventArgs e)
    {
        //this.Master.HideLinkApps();
        LoadDetails();
        LoadImages();
    }

    protected void LoadDetails()
    {
        DataTable result = new DataTable();
        var xdoc = new XmlDocument();
        string xml = null;
        XmlNodeList _nodelist;
        try
        {
            Listings listing = new CodenameRabbitFoot.BusinessLogic.Listings();
            listing.LoadByPrimaryKey(Web.RecordID);
            if (listing.RowCount == 0)
                Web.Redirect("~/ErrorPage.aspx?status=nolisting");
            else
            {
                result = Listings.GetListingDetails(Web.RecordID);
                foreach (DataRow row in result.Rows)
                {
                    img_top.ImageUrl = (!String.IsNullOrEmpty(row["ThumbnailURL"].ToString())) ? row["ThumbnailURL"].ToString() : "~/Images/noimage.png";
                    xml = row["ListingData"].ToString();

                    if (!String.IsNullOrEmpty(xml))
                    {
                        xdoc.LoadXml("<listings>" + xml + "</listings>");
                        _nodelist = xdoc.SelectNodes("listings/ListingData");
                        if (_nodelist.Count > 0)
                        {
                            foreach (XmlNode node in _nodelist)
                            {
                                if (node.Attributes.Item(0).Value == "3")
                                {
                                    lbl_desp.Text += node.Attributes.Item(2).Value + "<br/>";
                                }
                                else if (node.Attributes.Item(0).Value == "5")
                                {
                                    lbl_desp.Text += node.Attributes.Item(2).Value + "<br/>";
                                }
                                else if (node.Attributes.Item(0).Value == "20")
                                {
                                    lbl_Title.Text = node.Attributes.Item(2).Value;
                                    title = node.Attributes.Item(2).Value;
                                }
                                else if (node.Attributes.Item(0).Value == "4")
                                {
                                    lbl_Quantity.Text = node.Attributes.Item(2).Value;
                                    IsQuantity = (!String.IsNullOrEmpty(lbl_Quantity.Text)) ? true : false;
                                }
                                else if (node.Attributes.Item(0).Value == "9")
                                {
                                    lbl_Price.Text = "$" + node.Attributes.Item(2).Value + "<br/>";
                                    IsPrice = (!String.IsNullOrEmpty(lbl_Price.Text)) ? true : false;
                                }
                                else if (node.Attributes.Item(0).Value == "10")
                                {
                                    string s_price = node.Attributes.Item(2).Value.ToLower();
                                    try
                                    {
                                        double priceeach = Convert.ToDouble(s_price);
                                        lbl_Price.Text = "$" + s_price + " per Item";
                                        IsPrice = true;
                                    }
                                    catch  
                                    {
                                        lbl_Price.Text = "";
                                        IsPrice = false;
                                    }
                                }
                            }
                        }
                    }

                    if (!String.IsNullOrEmpty(row["Condition"].ToString()))
                    {
                        IsItemCondition = true;
                        lbl_itemCondition.Text = row["Condition"].ToString();
                    }

                    if (!String.IsNullOrEmpty(row["ListingEndDate"].ToString()))
                    {
                        lbl_EndDate.Text = row["ListingEndDate"].ToString();
                    }

                    if (!String.IsNullOrEmpty(row["PaymentMethods"].ToString()))
                    {
                        xml = row["PaymentMethods"].ToString();
                        xdoc.LoadXml("<Payments>" + xml + "</Payments>");
                        _nodelist = xdoc.SelectNodes("Payments/PaymentMethods");
                        if (_nodelist.Count > 0)
                        {
                            foreach (XmlNode node in _nodelist)
                            {
                                if (node.Attributes.Item(0).Value != null)
                                {
                                    IsPaymentMethod = true;
                                    lbl_paymentMethods.Text += node.Attributes.Item(0).Value;
                                }
                            }
                        }
                    }

                    if (!String.IsNullOrEmpty(row["ShippingMethods"].ToString()))
                    {
                        xml = row["ShippingMethods"].ToString();
                        xdoc.LoadXml("<Shipping>" + xml + "</Shipping>");
                        _nodelist = xdoc.SelectNodes("Shipping/ShippingMethods");
                        if (_nodelist.Count > 0)
                        {
                            foreach (XmlNode node in _nodelist)
                            {
                                if (node.Attributes.Item(0).Value != null)
                                {
                                    lbl_shippingMethods.Text += node.Attributes.Item(0).Value;
                                    IsShippingMethod = true;
                                }
                            }
                        }

                        lbl_shippinglocation.Text = row["ShippingLocation"].ToString();
                        IsLocation = (!String.IsNullOrEmpty(row["ShippingLocation"].ToString())) ? true : false;
                    }
                }
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }

    protected void LoadImages()
    {
        ImagesAvailable = false;
        DataTable result = new DataTable();
        try
        {
            result = SystemObjectFiles.GetFiles(600, 5, Web.RecordID);
            if (result.Rows.Count > 0)
            {
                rptImages.DataSource = result;
                rptImages.DataBind();
                ImagesAvailable = true;
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }
}