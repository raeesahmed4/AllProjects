﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using CodenameRabbitFoot.BusinessLogic;
using Telerik.Web.UI;
using System.Data;
using System.Xml;

public partial class PublicSite_MarketPlace_CouponPrinting : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            CouponAccessLog calCheck = new CouponAccessLog();
            calCheck.Where.ListingID.Value = Web.RecordID;
            calCheck.Where.MemberID.Value = Web.SessionMembers.MemberID;
            calCheck.Where.AccessType.Value = 1;
            calCheck.Query.Load();

            if (calCheck.RowCount > 0)
            {
                Session["Message"] = "You have already downloaded or printed this coupon. Please contact support for more details.";
                Web.Redirect("/Live.aspx");
            }


            if (!IsPostBack)
            {
                imgCoupon.ImageUrl = @"UploadedImages\" + Request.QueryString["fileName"];

                //make an entry in DB
                CouponAccessLog cal = new CouponAccessLog();
                cal.AddNew();
                cal.ListingID = Convert.ToInt32(Request.QueryString["ListingID"].ToString());
                cal.MemberID = Web.SessionMembers.MemberID;
                cal.AccessType = 1;

                cal.Save();
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }
}