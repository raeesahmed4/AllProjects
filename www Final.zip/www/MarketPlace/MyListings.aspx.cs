﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Services;
using System.Web.Script.Services;
using System.Data;
using CodenameRabbitFoot.BusinessLogic;
using System.Xml.Linq;
using System.Text;
using System.Collections.Specialized;
using System.Xml;

public partial class MarketPlace_MyListings : System.Web.UI.Page
{
    static bool ShowEdit, ShowViewOffers, ShowRelist, ShowWatchItem, ShowSendMessage, ShowArchive, ShowPrint, ShowEnd, ShowDelete;

    protected void Page_Load(object sender, EventArgs e)
    {
        this.Master.HideLinkApps();
    }

    [WebMethod(EnableSession = true)]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public static JQGrid LoadListings(int pageIndex, int pageSize, int listingTypeID)
    {
        bool ShowWatchItem = false, ShowSendMessage = true, ShowPrint = true, ShowDelete = true, ShowEnd = true, ShowArchive = true, ShowEdit = true;

        JQGrid jqGrid = new JQGrid();
        if (!Web.IsMemberSession)
        {
            jqGrid.status = "login";
        }
        else
        {
            // Load all listing            
            IEnumerable<DataRow> allRows = GetListings(listingTypeID);

            // all filterign is made above 
            jqGrid.total = allRows.Count() == pageSize ? 1 : (allRows.Count() / pageSize) + 1;
            jqGrid.records = pageSize;
            jqGrid.page = pageIndex;
            IEnumerable<DataRow> dataRows = allRows.Skip((pageIndex - 1) * pageSize).Take(pageSize);

            if (dataRows.Count() == 0)
            {
                jqGrid = GetEmptyGrid(listingTypeID);
            }

            if (listingTypeID == 100 || listingTypeID == 110) //Selling Offers/Active
            {
                foreach (DataRow item in dataRows)
                {
                    object encryptedListingID = Secure.Encrypt(item["ListingID"]);
                    object encryptedMemberID = Secure.Encrypt(item["MemberID"]);
                    string listingStatus = string.Empty;
                    if (listingTypeID == 110)
                        listingStatus = Convert.ToDateTime(item["ListingEndDate"]) >= DateTime.Now ? " - <span style='color:green;'>Active</span>" : " - <span style='color:red;'>Expired</span>";

                    JQGrid.Row row = new JQGrid.Row();
                    row.id = Convert.ToInt32(item["MemberID"]);
                    row.cell.Add(item["MemberID"].ToString());
                    row.cell.Add("<img width='48' style='margin:5px 0px 5px 5px;' height='48' src='" + (item["ThumbnailURL"].ToString() == "" ? getDefaultImage(Convert.ToInt32(item["ListingTypeID"].ToString())) : item["ThumbnailURL"]) + "' />");
                    row.cell.Add(string.Format("<a href='ItemDetails.aspx?Action=View&RecordID={0}' title='{1}'>{2}</a><br/>{3}<br/>{4}{5}", encryptedListingID, item["Title"], GetTite(item["Title"].ToString()), item["ListingDate"], item["ListingEndDate"], listingStatus));
                    row.cell.Add(GetOfferPriceText(item) + (item["IsBuyEntireListing"].ToString() == "0" ? " Per Item" : " Entire Listing"));
                    row.cell.Add(item["Quantity"].ToString());
                    if (listingTypeID == 110)// Buying Active [qcqa=388]
                    {
                        row.cell.Add(string.Format("<center>{0}</center>", item["OfferStatus"]));
                    }
                    else
                    {
                        row.cell.Add(item["Buyer"].ToString());
                    }
                    StringBuilder buttons = new StringBuilder();
                    if (listingTypeID == 100)
                    {
                        buttons.AppendFormat("<span><a title='View' href='ViewOffer.aspx?Action=View&RecordID={0}&MID={2}'><span title='View' class='liView'>&nbsp;</span></sapn></a></span><span><a title='Print' target='_blank' href='Invoice.aspx?Action=Print&RecordID={1}'><span title='Print' class='liPrint'></span></a></span>", encryptedListingID, item["ListingOfferID"], Secure.Encrypt(item["OfferBy"]));
                    }
                    else
                    {
                        buttons.AppendFormat("<span><a title='View' href='ViewOffer.aspx?Action=View&RecordID={0}&MID={2}'><span title='View' class='liView'>&nbsp;</span></a></span><span><a title='Print' target='_blank' href='Invoice.aspx?Action=Print&RecordID={1}'><span title='Print' class='liPrint'></span></a></span>", encryptedListingID, item["ListingOfferID"], Secure.Encrypt(item["OfferBy"]));
                        if (listingTypeID == 110 && Convert.ToDateTime(item["ListingEndDate"]) < DateTime.Now)
                        {
                            buttons.Append(string.Format("&nbsp;<span title='Remove' class='hyperlink liDelete' onclick=\"OnAction(this,'expirelistingoffer');\"></span><input type='hidden' value='{0}'/>", Secure.Encrypt(item["ListingOfferID"])));
                        }
                    }
                    row.cell.Add(buttons.ToString());
                    jqGrid.rows.Add(row);
                }
            }
            else
                if (listingTypeID == 400 || listingTypeID == 200) // Pending Payments Selling/Buying
                {
                    foreach (DataRow item in dataRows)
                    {
                        object encryptedListingID = Secure.Encrypt(item["ListingID"]);
                        object encryptedMemberID = Secure.Encrypt(item["MemberID"]);
                        JQGrid.Row row = new JQGrid.Row();
                        row.id = Convert.ToInt32(item["MemberID"]);
                        row.cell.Add(item["MemberID"].ToString());
                        row.cell.Add("<img width='48' style='margin:5px 0px 5px 5px;' height='48' src='" + (item["ThumbnailURL"].ToString() == "" ? getDefaultImage(Convert.ToInt32(item["ListingTypeID"].ToString())) : item["ThumbnailURL"]) + "' />");
                        row.cell.Add(string.Format("<a href='ItemDetails.aspx?Action=View&RecordID={0}' title='{1}'>{2}</a><br/>{3}<br/>{4}", encryptedListingID, item["Title"], GetTite(item["Title"].ToString()), item["ListingDate"], item["ListingEndDate"]));
                        row.cell.Add("$" + item["OfferPrice"].ToString() + (item["IsBuyEntireListing"].ToString() == "0" ? " Per Item" : " Entire Listing"));
                        row.cell.Add(item["Quantity"].ToString());

                        if (listingTypeID == 400) //only show for seller
                            row.cell.Add(item["Buyer"].ToString());

                        StringBuilder buttons = new StringBuilder();
                        buttons.AppendFormat("<span title='View'><a title='View' href='ViewOffer.aspx?Action=View&RecordID={0}&MID={1}'><span  title='View' class='liView'>&nbsp;</span></a></span>", encryptedListingID, Secure.Encrypt(item["OfferBy"]));
                        //buttons.AppendFormat("<span class='spanLinkButton' title='Send Invoice' onclick=\"OnAction(this,'sendinvoice')\"><img style='padding:2px 4px -7px 0px; margin:2px 4px -2px -2px;;' src='../Images/Icons/send-invoice.png'/></span><input type='hidden' value='{0}'/>", Secure.Encrypt(item["ListingOfferID"]));
                        //buttons.AppendFormat("<span class='spanLinkButton' title='Mark as Paid' onclick=\"OnAction(this,'markpaid');\"><img style='padding:2px 4px -7px 2px; margin:2px 4px -2px 2px;' src='../Images/Icons/paid.png'/></span><input type='hidden' value='{0}'/>", Secure.Encrypt(item["ListingOfferID"]));


                        // * WHAT IS THE LOGIC BEHIND THIS?
                        //if (!item["TimeLeft"].ToString().ToLower().Equals("expired") && Web.SessionMembers.MemberID == Convert.ToInt32(item["MemberID"]))
                        if (Web.SessionMembers.MemberID == Convert.ToInt32(item["MemberID"]))
                        {
                            if (listingTypeID == 400)
                            {
                                buttons.AppendFormat("<span class='spanLinkButton' title='Send Invoice' onclick=\"OnAction(this,'sendinvoice')\"><img style='padding:2px 4px -7px 0px; margin:2px 4px -2px -2px;;' src='../Images/Icons/send-invoice.png'/></span><input type='hidden' value='{0}'/>", Secure.Encrypt(item["ListingOfferID"]));
                                buttons.AppendFormat("<span class='spanLinkButton' title='Mark as Paid' onclick=\"OnAction(this,'markpaid');\"><img style='padding:2px 4px -7px 2px; margin:2px 4px -2px 2px;' src='../Images/Icons/paid.png'/></span><input type='hidden' value='{0}'/>", Secure.Encrypt(item["ListingOfferID"]));
                            }
                            else
                            {
                                buttons.AppendFormat("<span class='spanLinkButton' title='Send Invoice' onclick=\"OnAction(this,'sendinvoice')\"><img style='padding:2px;' src='../Images/Icons/send-invoice.png'/></span><input type='hidden' value='{0}'/>", Secure.Encrypt(item["ListingOfferID"]));
                                buttons.AppendFormat("<span class='spanLinkButton' title='Mark as Paid' onclick=\"OnAction(this,'markpaid');\"><img style='padding:2px 2px 2px 2px;' src='../Images/Icons/paid.png'/></span><input type='hidden' value='{0}'/>", Secure.Encrypt(item["ListingOfferID"]));
                            }
                        }

                        buttons.AppendFormat("<span  title='Print'><a title='Print' target='_blank' href='Invoice.aspx?Action=Print&RecordID={0}'><span title='Print' class='liPrint'></span></a></span>", Secure.Encrypt(item["ListingOfferID"]));
                        row.cell.Add(buttons.ToString());
                        jqGrid.rows.Add(row);
                    }
                }
                else
                    if (listingTypeID == 500 || listingTypeID == 900) // Pending Shipment Selling/Buying
                    {
                        foreach (DataRow item in dataRows)
                        {
                            object encryptedListingID = Secure.Encrypt(item["ListingID"]);
                            object encryptedMemberID = Secure.Encrypt(item["MemberID"]);
                            JQGrid.Row row = new JQGrid.Row();
                            row.id = Convert.ToInt32(item["MemberID"]);
                            row.cell.Add(item["MemberID"].ToString());
                            row.cell.Add("<img width='48' style='margin:5px 0px 5px 5px;' height='48' src='" + (item["ThumbnailURL"].ToString() == "" ? getDefaultImage(Convert.ToInt32(item["ListingTypeID"].ToString())) : item["ThumbnailURL"]) + "' />");
                            row.cell.Add(string.Format("<a href='ItemDetails.aspx?Action=View&RecordID={0}' title='{1}'>{2}</a><br/>{3}<br/>{4}", encryptedListingID, item["Title"], GetTite(item["Title"].ToString()), item["ListingDate"], item["ListingEndDate"]));
                            row.cell.Add("$" + item["OfferPrice"].ToString() + (item["IsBuyEntireListing"].ToString() == "0" ? " Per Item" : " Entire Listing"));
                            row.cell.Add(item["Quantity"].ToString());

                            if (listingTypeID == 500) //only show for seller
                                row.cell.Add(item["Buyer"].ToString());

                            StringBuilder buttons = new StringBuilder();
                            buttons.AppendFormat("<span title='View'><a title='View' href='ViewOffer.aspx?Action=View&RecordID={0}&MID={1}'><span title='View' class='liView'></span></a></span>", encryptedListingID, Secure.Encrypt(item["OfferBy"]));
                            if (Web.SessionMembers.MemberID == Convert.ToInt32(item["MemberID"]))
                            {
                                buttons.AppendFormat("<span class='spanLinkButton' title='Mark as Shipped' onclick=\"OnAction(this,'markshipped');\"><img style='padding:2px;margin:0px 2px -5px 0px;' src='../Images/Icons/shipped.png'/></span><input type='hidden' value='{0}'/>", Secure.Encrypt(item["ListingOfferID"]));
                            }
                            buttons.AppendFormat("<span title='Print'><a title='Print' target='_blank' href='Invoice.aspx?Action=Print&RecordID={0}'><span title='Print' class='liPrint'></span></a></span>", Secure.Encrypt(item["ListingOfferID"]));
                            row.cell.Add(buttons.ToString());
                            jqGrid.rows.Add(row);
                        }
                    }
                    else
                        if (listingTypeID == 600 || listingTypeID == 1000) // Waiting to be Received selleing/buying
                        {
                            foreach (DataRow item in dataRows)
                            {
                                object encryptedListingID = Secure.Encrypt(item["ListingID"]);
                                object encryptedMemberID = Secure.Encrypt(item["MemberID"]);
                                JQGrid.Row row = new JQGrid.Row();
                                row.id = Convert.ToInt32(item["MemberID"]);
                                row.cell.Add(item["MemberID"].ToString());
                                row.cell.Add("<img width='48' style='margin:5px 0px 5px 5px;' height='48' src='" + (item["ThumbnailURL"].ToString() == "" ? getDefaultImage(Convert.ToInt32(item["ListingTypeID"].ToString())) : item["ThumbnailURL"]) + "' />");
                                row.cell.Add(string.Format("<a href='ItemDetails.aspx?Action=View&RecordID={0}' title='{1}'>{2}</a><br/>{3}<br/>{4}", encryptedListingID, item["Title"], GetTite(item["Title"].ToString()), item["ListingDate"], item["ListingEndDate"]));
                                row.cell.Add("$" + item["OfferPrice"].ToString() + (item["IsBuyEntireListing"].ToString() == "0" ? " Per Item" : " Entire Listing"));
                                row.cell.Add(item["Quantity"].ToString());

                                if (listingTypeID == 600) //only show for seller
                                    row.cell.Add(item["Buyer"].ToString());

                                StringBuilder buttons = new StringBuilder();
                                buttons.AppendFormat("<span><a title='View' href='ViewOffer.aspx?Action=View&RecordID={0}&MID={1}'><span title='View' class='liView'>&nbsp;</span></a></span>", encryptedListingID, Secure.Encrypt(item["OfferBy"]));
                                // Mark received is done by buyer
                                if (listingTypeID == 1000) // Buying waiting to be received
                                {
                                    buttons.AppendFormat("<span title='Mark as Received' class='spanLinkButton' onclick=\"OnAction(this,'markreceived');\"><img style='padding:2px 2px 2px 0px; margin:0px 4px -5px 0px;' src='../Images/Icons/shipped.png'/></span><input type='hidden' value='{0}'/>", Secure.Encrypt(item["ListingOfferID"]));
                                }
                                buttons.AppendFormat("<span><a title='Print' target='_blank' href='Invoice.aspx?Action=Print&RecordID={0}'><span title='Print' class='liPrint'></span></a></span>", Secure.Encrypt(item["ListingOfferID"]));
                                row.cell.Add(buttons.ToString());
                                jqGrid.rows.Add(row);
                            }
                        }
                        else
                            if (listingTypeID == 700 || listingTypeID == 1100) // Comleted Seelling/Buying
                            {
                                foreach (DataRow item in dataRows)
                                {
                                    object encryptedListingID = Secure.Encrypt(item["ListingID"]);
                                    object encryptedMemberID = Secure.Encrypt(item["MemberID"]);
                                    JQGrid.Row row = new JQGrid.Row();
                                    row.id = Convert.ToInt32(item["MemberID"]);
                                    row.cell.Add(item["MemberID"].ToString());
                                    row.cell.Add("<img width='48' style='margin:5px 0px 5px 5px;' height='48' src='" + (item["ThumbnailURL"].ToString() == "" ? getDefaultImage(Convert.ToInt32(item["ListingTypeID"].ToString())) : item["ThumbnailURL"]) + "' />");
                                    row.cell.Add(string.Format("<a href='ItemDetails.aspx?Action=View&RecordID={0}' title='{1}'>{2}</a><br/>{3}<br/>{4}", encryptedListingID, item["Title"], GetTite(item["Title"].ToString()), item["ListingDate"], item["ListingEndDate"]));
                                    row.cell.Add("$" + item["OfferPrice"].ToString() + (item["IsBuyEntireListing"].ToString() == "0" ? " Per Item" : " Entire Listing"));
                                    row.cell.Add(item["Quantity"].ToString());

                                    if (listingTypeID == 700) //only show for seller
                                        row.cell.Add(item["Buyer"].ToString());

                                    StringBuilder buttons = new StringBuilder();
                                    buttons.AppendFormat("<span><a title='View' href='ViewOffer.aspx?Action=View&RecordID={0}&MID={1}'><span title='View' class='liView'>&nbsp;</span></a></span>", encryptedListingID, Secure.Encrypt(item["OfferBy"]));
                                    buttons.AppendFormat("<span><a title='Print' target='_blank' href='Invoice.aspx?Action=Print&RecordID={0}'><span title='Print' class='liPrint'></span></a></span>", Secure.Encrypt(item["ListingOfferID"]));
                                    row.cell.Add(buttons.ToString());
                                    jqGrid.rows.Add(row);
                                }
                            }
                            else
                                if (listingTypeID == 300) // Close and Expired
                                {
                                    foreach (DataRow item in dataRows)
                                    {
                                        object encryptedListingID = Secure.Encrypt(item["ListingID"]);
                                        object encryptedMemberID = Secure.Encrypt(item["MemberID"]);
                                        JQGrid.Row row = new JQGrid.Row();
                                        row.id = Convert.ToInt32(item["MemberID"]);
                                        row.cell.Add(item["MemberID"].ToString());
                                        row.cell.Add("<img width='48' style='margin:5px 0px 5px 5px;' height='48' src='" + (item["ThumbnailURL"].ToString() == "" ? getDefaultImage(Convert.ToInt32(item["ListingTypeID"].ToString())) : item["ThumbnailURL"]) + "' />");
                                        row.cell.Add(string.Format("<a href='ItemDetails.aspx?Action=View&RecordID={0}' title='{1}'>{2}</a><br/>{3}<br/>{4}", encryptedListingID, item["Title"], GetTite(item["Title"].ToString()), item["ListingDate"], item["ListingEndDate"]));
                                        row.cell.Add("$" + item["OfferPrice"].ToString() + (item["IsBuyEntireListing"].ToString() == "0" ? " Per Item" : " Entire Listing"));

                                        if (item["TotalOffers"].ToString() == "0")
                                            row.cell.Add(string.Format(item["TotalOffers"].ToString()));
                                        else
                                            row.cell.Add(string.Format("<a href='../Marketplace/ViewOffer.aspx?Action=View&RecordID={0}&MID={1}'>{2}</a>", encryptedListingID, Secure.Encrypt(item["OfferBy"]), item["TotalOffers"]));

                                        if (item["StatusCode"].ToString().Equals("200")) // Pending for Admin approval
                                        {
                                            row.cell.Add("<span title='Pending Approval' style='float:right;padding-right:10px;'>Pending for Admin Approval</span>");
                                        }
                                        else
                                        {
                                            if (listingTypeID >= 0 && listingTypeID <= 6)
                                                ShowSendMessage = false;

                                            row.cell.Add(GetButtonsHtmlForClosedExpired(item["MemberID"], item["ListingID"], "", ShowWatchItem, ShowSendMessage, ShowPrint, ShowDelete, ShowEnd, ShowArchive, ShowEdit));
                                        }
                                        jqGrid.rows.Add(row);
                                    }
                                }
                                else
                                    if (listingTypeID == 130) // Questions
                                    {
                                        int counter = 0;
                                        foreach (DataRow item in dataRows)
                                        {
                                            counter++;
                                            object encryptedListingID = Secure.Encrypt(item["ListingID"]);
                                            string itemTitle = Listings.GetTitle(Convert.ToInt32(item["ListingID"]));
                                            object encryptedMemberID = Secure.Encrypt(item["MemberID"]);
                                            JQGrid.Row row = new JQGrid.Row();
                                            row.id = counter;
                                            row.cell.Add(counter.ToString());
                                            row.cell.Add("<img width='48' style='margin:5px 0px 5px 5px;' height='48' src='" + (string.IsNullOrEmpty(item["ThumbnailURL"].ToString()) ? "" : "../Images/noimage.png") + "' />");
                                            row.cell.Add(string.Format("<a href='ItemDetails.aspx?Action=View&RecordID={0}' title='{1}'>{2}</a><br/> by {3}", encryptedListingID, itemTitle, GetTite(itemTitle), item["Seller"]));
                                            string questionFrom = Members.GetUserName(Convert.ToInt32(item["QuestionBy"]));
                                            row.cell.Add(string.Format("{0} by {1} </br>{2}", item["QuestionDate"], questionFrom, item["Question"]));
                                            row.cell.Add(string.IsNullOrEmpty(item["Answer"].ToString()) ? string.Empty : string.Format("{0} by {1}", item["Answer"], item["Seller"]));
                                            if (Web.SessionMembers.MemberID.ToString().Equals(item["MemberID"].ToString()) && item["IsReplied"].ToString().Equals("0"))
                                            {
                                                row.cell.Add(string.Format("<center><span title='Send Reply' class='hyperlink' onclick=\"OnSendQuestionReply(this,'','{1}')\"><img src='../App_Themes/Space/Images/eOpen 16X16 Icons/reply.png'/></span><input type='hidden' value='{0}'/></center>", Secure.Encrypt(item["QuestionID"]), questionFrom));
                                            }

                                            jqGrid.rows.Add(row);
                                        }
                                    }
                                    else // All remaing cases
                                    {
                                        foreach (DataRow item in dataRows)
                                        {
                                            //If 120 Selling > Active
                                            //proceed only for sell types
                                            if (listingTypeID == 120 && Convert.ToInt32(item["listingtypeid"].ToString()) != 1)
                                                continue;

                                            //dont show print icon for few types
                                            if (new int[8] { 0, 1, 2, 3, 4, 5, 6, 120 }.Contains(listingTypeID))
                                                ShowPrint = false;

                                            object encryptedListingID = Secure.Encrypt(item["ListingID"]);
                                            object encryptedMemberID = Secure.Encrypt(item["MemberID"]);
                                            JQGrid.Row row = new JQGrid.Row();
                                            row.id = Convert.ToInt32(item["MemberID"]);
                                            row.cell.Add(item["MemberID"].ToString());
                                            row.cell.Add("<img width='48' style='margin:5px 0px 5px 5px;' height='48' src='" + (item["ThumbnailURL"].ToString() == "" ? getDefaultImage(Convert.ToInt32(item["ListingTypeID"].ToString())) : item["ThumbnailURL"]) + "' />");

                                            string listingStatus = string.Empty;
                                            if (listingTypeID == 120)
                                                listingStatus = Convert.ToDateTime(item["ListingEndDate"]) >= DateTime.Now ? " - <span style='color:green;'>Active</span>" : " - <span style='color:red;'>Expired</span>";

                                            row.cell.Add(string.Format("<a href='ItemDetails.aspx?Action=View&RecordID={0}' title='{1}'>{2}</a><br/>{3}<br/>{4}{5}", encryptedListingID, item["Title"], GetTite(item["Title"].ToString()), item["ListingDate"], item["ListingEndDate"], listingStatus));
                                            row.cell.Add("$" + item["OfferPrice"].ToString() + (item["IsBuyEntireListing"].ToString() == "0" ? " Per Item" : " Entire Listing"));

                                            if (item["TotalOffers"].ToString() == "0")
                                                row.cell.Add(string.Format(item["TotalOffers"].ToString()));
                                            else
                                                row.cell.Add("<a href='#' onclick=\"selectTab('tabs-2.tabs-2-2');\">" + item["TotalOffers"] + "</a>");
                                            //row.cell.Add(string.Format("<a href='../Marketplace/ViewOffer.aspx?Action=View&RecordID={0}&MID={1}'>{2}</a>", encryptedListingID,Secure.Encrypt(Web.SessionMembers.MemberID) ,item["TotalOffers"]));

                                            if (item["StatusCode"].ToString().Equals("200")) // Pending for Admin approval
                                            {
                                                row.cell.Add("<span style='float:right;padding-right:10px;'>Pending for Admin Approval</span>");
                                            }
                                            else
                                            {
                                                if (listingTypeID >= 0 && listingTypeID <= 6)
                                                    ShowSendMessage = false;

                                                row.cell.Add(GetButtonsHtml(item["MemberID"], item["ListingID"], "", ShowWatchItem, ShowSendMessage, ShowPrint, ShowDelete, ShowEnd, ShowArchive, ShowEdit));
                                            }
                                            jqGrid.rows.Add(row);
                                        }
                                    }
        }// last else 

        return jqGrid;
    }

    [WebMethod(EnableSession = true)]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public static string PerformAction(string encryptedID, string actionType)
    {

        actionType = actionType.ToLower();
        int listingID = Convert.ToInt32(Secure.Decrypt(encryptedID));

        if (actionType.Equals("expirelistingoffer"))
        {
            try
            {
                ListingOffers listingOffers = new ListingOffers();
                listingOffers.LoadByPrimaryKey(listingID);
                if (listingOffers.RowCount > 0)
                {
                    listingOffers.OfferStatusID = 300;
                    listingOffers.UpdateDate = DateTime.Now;
                    listingOffers.Save();
                    return "success";
                }
            }
            catch (Exception exp)
            {
                Web.LogError(exp);
            }
            return "failed";
        }
        if (actionType.Equals("relist"))
        {
            if (Listings.Relist(listingID))
                return "success";
        }
        if (actionType.Equals("addtowatchlist"))
        {
            if (!String.IsNullOrEmpty(MembersWatchList.AddtoWatchList(listingID, Web.SessionMembers.MemberID)))
                return "success";
        }
        if (actionType.Equals("archive"))
        {
            if (Listings.ArchiveListing(listingID))
                return "success";
        }
        if (actionType.Equals("end"))
        {
            if (Listings.EndListing(listingID))
                return "success";
        }
        if (actionType.Equals("delete"))
        {
            if (Listings.Delete(listingID))
                return "success";
        }
        if (actionType.Equals("sendinvoice"))
        {
            if (SendInvoice(listingID))
                return "success";
        }
        if (actionType.Equals("markpaid"))
        {
            ListingOffers.MarkPaid(listingID);
            return "success";
        }
        if (actionType.Equals("markshipped"))
        {
            ListingOffers.MarkShipped(listingID);
            return "success";
        }
        if (actionType.Equals("markreceived"))
        {
            ListingOffers.MarkReceived(listingID);
            return "success";
        }
        return "success";
    }

    [WebMethod(EnableSession = true)]
    public static string SendQuestionReply(string questionID, string replyText)
    {
        string result = "success";
        try
        {
            int res = -1;
            if (int.TryParse(questionID, out res))
            {
                throw new Exception("Invalid Question ID passed in queystring.");
            }
            Questions question = new Questions();
            question.LoadByPrimaryKey(Convert.ToInt32(Secure.Decrypt(questionID)));
            question.IsReplied = 1;
            question.Answer = replyText;
            question.AnswerDate = DateTime.Now;
            question.Save();

            Listings lot = new Listings();
            lot.LoadByPrimaryKey(question.ObjectID);

            Members seller = new Members();
            seller.LoadByPrimaryKey(lot.MemberID);

            Members buyer = new Members();
            buyer.LoadByPrimaryKey(question.QuestionBy);

            string title = Listings.GetTitle(lot.ListingID);
            string replylink = Web.SystemConfigs.GetKey("SITE_URL") + "MarketPlace/Default.aspx";
            StringDictionary TemplateKeys = new StringDictionary();
            TemplateKeys.Add("#email_header#", Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER"));
            TemplateKeys.Add("#fullname#", buyer.FullName);
            TemplateKeys.Add("#seller#", Web.SessionMembers.FullName);
            TemplateKeys.Add("#question#", question.Question);
            TemplateKeys.Add("#reply#", question.Answer);
            TemplateKeys.Add("#link_item#", Web.SystemConfigs.GetKey("SITE_URL") + "MarketPlace/ItemDetails.aspx?Action=View&RecordID=" + Secure.Encrypt(question.ObjectID));
            TemplateKeys.Add("#link_log_myeoffer#", Web.SystemConfigs.GetKey("SITE_URL") + "index.aspx");
            TemplateKeys.Add("#email_footer#", Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER"));
            TemplateKeys.Add("#link_view#", replylink);
            //Web.NotifyMember(members.MemberID, 42, TemplateKeys);

            var templateKeys = new System.Collections.Specialized.StringDictionary();
            templateKeys.Add("#viewlink#", "../Listing/DealingFloor.aspx?TabIndex=130");
            templateKeys.Add("#initiatedto#", "#memberid#" + buyer.MemberID + "#endmemberid#");
            templateKeys.Add("#profileclass#", "#profileclass#" + buyer.MemberID + "#endprofileclass#");
            templateKeys.Add("#initiatedtoprofile#", "ViewContact.aspx?Action=ViewDealer&RecordID=#encrypt#" + buyer.MemberID + "#endencrypt#");
            Web.AddPrivateActivityLog(17, templateKeys, Web.SessionMembers.MemberID, question.QuestionID, buyer.MemberID);

            Web.SendMail(buyer.Email, Web.SystemConfigs.GetKey("ALERTS_EMAIL"), 310, TemplateKeys);
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
            result = "fail";
        }
        return result;
    }

    private static string GetPriceText(DataRow item)
    {
        string priceText = "";
        try
        {
            if (!string.IsNullOrEmpty(item.ItemArray[10].ToString()))
            {
                priceText = "$" + item.ItemArray[10].ToString() + " per listing";
            }
            if (!string.IsNullOrEmpty(item.ItemArray[4].ToString()))
            {
                var listingData = from d in XDocument.Parse("<listings>" + item.ItemArray[4].ToString() + "</listings>").Root.Descendants()
                                  select new
                                  {
                                      FieldID = d.Attribute("FieldID").Value,
                                      FieldName = d.Attribute("FieldName").Value,
                                      Data = d.Attribute("Data") == null ? "" : d.Attribute("Data").Value
                                  };

                if (listingData.Count() > 0)
                {
                    bool isOffer = false;

                    foreach (var i in listingData)
                    {
                        if (i.FieldName.Equals("MakeOffer") && Convert.ToBoolean(i.Data))
                        {
                            priceText = "Make an Offer";
                            isOffer = true;
                        }
                        else
                        {
                            if (i.FieldName.Equals("PriceEach") && !isOffer)
                            {
                                try
                                {
                                    double priceeach = Convert.ToDouble(i.Data);
                                    priceText = "$" + i.Data + " per Item";
                                }
                                catch
                                {
                                    priceText = "";
                                }
                            }
                        }
                    }
                }
            }
        }
        catch { }

        return priceText;
    }

    private static string GetOfferPriceText(DataRow item)
    {
        string priceText = "";
        string offerPrice = item["OfferPrice"].ToString();
        try
        {
            if (!string.IsNullOrEmpty(offerPrice))
            {
                priceText = "$" + offerPrice + " per listing";
            }
            if (!string.IsNullOrEmpty(item.ItemArray[4].ToString()))
            {
                var listingData = from d in XDocument.Parse("<listings>" + item.ItemArray[4].ToString() + "</listings>").Root.Descendants()
                                  select new
                                  {
                                      FieldID = d.Attribute("FieldID").Value,
                                      FieldName = d.Attribute("FieldName").Value,
                                      Data = d.Attribute("Data") == null ? "" : d.Attribute("Data").Value
                                  };

                if (listingData.Count() > 0)
                {
                    bool isOffer = false;

                    foreach (var i in listingData)
                    {
                        //if (i.FieldName.Equals("MakeOffer") && Convert.ToBoolean(i.Data))
                        //{
                        //    priceText = "Make an Offer";
                        //    isOffer = true;
                        //}
                        //else
                        {
                            if (i.FieldName.Equals("PriceEach") && !isOffer)
                            {
                                try
                                {
                                    double priceeach = Convert.ToDouble(i.Data);
                                    priceText = "$" + offerPrice; // +" per Item";
                                }
                                catch
                                {
                                    priceText = "";
                                }
                            }
                        }
                    }
                }
            }
        }
        catch { }

        return priceText;
    }

    private static bool SendInvoice(int listingOfferID)
    {

        // get the offer data 
        ListingOffers offer = new ListingOffers();
        offer.LoadByPrimaryKey(listingOfferID); //Web.RecordID
        var quantity = offer.Quantity.ToString();
        var price = "$" + offer.OfferPrice.ToString();
        var total = "$" + offer.TotalPrice.ToString();
        var shippingPrice = "$" + offer.s_ShippingPrice;
        var additionalTerms = offer.AdditionalTerms;

        // get payment method type
        PaymentTypes pTypes = new PaymentTypes();
        pTypes.LoadByPrimaryKey(offer.PaymentTypeID);
        var paymentMethod = pTypes.PaymentName;

        // get shipping method type
        ShippingTypes shippingTypes = new ShippingTypes();
        shippingTypes.LoadByPrimaryKey(offer.ShippingTypeID);
        var shippingMethod = shippingTypes.ShippingName;


        DataTable result = new DataTable();
        var xdoc = new XmlDocument();
        string xml = null;
        XmlNodeList _nodelist;
        string lotName = string.Empty;
        try
        {
            Listings listing = new CodenameRabbitFoot.BusinessLogic.Listings();
            listing.LoadByPrimaryKey(offer.ListingID);
            if (listing.RowCount == 0)
                Web.Redirect("~/ErrorPage.aspx?status=nolisting");

            else
            {
                result = Listings.GetListingDetails(listing.ListingID);
                // get seller information
                Members seller = new Members();
                seller.LoadByPrimaryKey(listing.MemberID);

                ShippingAddresses sellerAddress = ShippingAddresses.LoadByMemberID(seller.MemberID);

                // logic to get the buyer
                var buyer = new Members();
                if (listing.MemberID == offer.OfferBy) // mean the counter offer is by the seller to the buyer
                {
                    // get the buyer from the fucking counteroffer id
                    var previousOffer = new ListingOffers();
                    previousOffer.Where.ListingOfferID.Value = offer.CounterOfferID;
                    previousOffer.Query.AddResultColumn(ListingOffersSchema.OfferBy);
                    previousOffer.Query.Load();

                    if (previousOffer.RowCount > 0)
                        buyer.LoadByPrimaryKey(previousOffer.OfferBy);
                }
                else
                    buyer.LoadByPrimaryKey(offer.OfferBy);

                // get buyer Address
                var buyerAddress = ShippingAddresses.LoadByMemberID(buyer.MemberID);

                var shippingLocation = buyerAddress.Address1 + "<br />" + buyerAddress.City + ", " + buyerAddress.CountryName;

                foreach (DataRow row in result.Rows)
                {
                    xml = row["ListingData"].ToString();

                    if (!String.IsNullOrEmpty(xml))
                    {
                        xdoc.LoadXml("<listings>" + xml + "</listings>");
                        _nodelist = xdoc.SelectNodes("listings/ListingData");
                        if (_nodelist.Count > 0)
                        {
                            foreach (XmlNode node in _nodelist)
                            {
                                if (node.Attributes.Item(0).Value == "20")
                                    lotName = node.Attributes.Item(2).Value;
                            }

                        }
                    }
                }


                // send invoice email
                var TemplateKeys = new System.Collections.Specialized.StringDictionary();
                //TemplateKeys.Add("#email_header#", Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER"));                
                TemplateKeys.Add("#item#", lotName);
                TemplateKeys.Add("#quantity#", quantity);
                TemplateKeys.Add("#offerprice#", offer.s_OfferPrice);
                TemplateKeys.Add("#shippingprice#", offer.s_ShippingPrice);
                TemplateKeys.Add("#total#", offer.s_TotalPrice);
                TemplateKeys.Add("#seller#", seller.FullName);
                TemplateKeys.Add("#email#", seller.Email);
                TemplateKeys.Add("#phone#", sellerAddress.Phone);
                TemplateKeys.Add("#address#", sellerAddress.Address1);
                TemplateKeys.Add("#country#", sellerAddress.CountryName);
                TemplateKeys.Add("#city#", sellerAddress.City);
                TemplateKeys.Add("#state#", sellerAddress.State);
                TemplateKeys.Add("#company#", seller.CompanyName);


                TemplateKeys.Add("#paymentmethod#", paymentMethod);
                TemplateKeys.Add("#shippingmethod#", shippingMethod);
                TemplateKeys.Add("#shippinglocation#", shippingLocation);

                TemplateKeys.Add("#link_invoice#", Web.SystemConfigs.GetKey("SITE_URL") + "/Marketplace/Invoice.aspx?RecordID=" + Secure.Encrypt(offer.ListingOfferID)); // TO DO
                TemplateKeys.Add("#email_footer#", Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER"));
                Web.SendMail(buyer.Email, Web.SystemConfigs.GetKey("ALERTS_EMAIL"), 314, TemplateKeys);
                //ClientScript.RegisterStartupScript(Page.GetType(), "showmessage", "this.parent.parent.showMessage('Invoice has been emailed to " + buyerName + " successfully.'); ", true);

            }
        }
        catch (Exception ex)
        {
            throw ex;
            Web.LogError(ex);
        }


        return true;
    }

    private static JQGrid GetEmptyGrid(int listingTypeID)
    {
        JQGrid jqGrid = new JQGrid();

        List<int> items = new List<int>();
        items.Add(100);
        items.Add(110);
        items.Add(400);
        items.Add(200);
        items.Add(500);
        items.Add(900);
        items.Add(600);
        items.Add(1000);
        items.Add(700);
        items.Add(1100);

        JQGrid.Row row = new JQGrid.Row();
        row.id = 0;
        row.cell.Add("0");
        if (items.Contains(listingTypeID))
            row.cell.Add("");
        row.cell.Add("");
        row.cell.Add("<div style='text-align:left; padding:5px; width:300px; z-index:10;'>No records exists.</div>");
        row.cell.Add("");
        row.cell.Add("");
        row.cell.Add("");

        jqGrid.rows.Add(row);
        jqGrid.status = "empty";
        return jqGrid;
    }

    private static string GetTite(string title)
    {
        if (title.Length > 35)
        {
            return title.Substring(0, 32) + "...";
        }
        return title;
    }

    private static string GetButtonsHtml(object memberID, object listingID, object ListingOfferID, bool ShowWatchItem, bool ShowSendMessage, bool ShowPrint, bool ShowDelete, bool ShowEnd, bool ShowArchive, bool ShowEdit)
    {
        ShowWatchItem = !Web.SessionMembers.MemberID.ToString().Equals(memberID.ToString());

        string encryptedListingID = Secure.Encrypt(listingID);
        string encryptedMemberID = Secure.Encrypt(memberID);
        //string encryptedListingOfferID = Secure.Encrypt(ListingOfferID);

        ShowSendMessage = !Web.SessionMembers.MemberID.ToString().Equals(memberID.ToString());

        StringBuilder html = new StringBuilder();
        html.Append("<table style='margin-left:20px;height:40px; float:right;'><tr>");
        html.AppendFormat(@"<td style='border:0px;'><span class='feed_actionLinks' style='display: inline;'>
                          <a href='ItemDetails.aspx?Action=View&RecordID={0}' title='View'>
                          <span class='liView' Title='View'></span></a></span></td>", encryptedListingID);

        if (ShowWatchItem)
        {
            html.AppendFormat(@"<td style='border:0px;'><span class='feed_actionLinks' style='display:{0};'>
                             <a href='#' onclick=""OnAction(this,'AddToWatchlist')"" title='AddToWatchlist');' title='Add to watchlist'>
                            <img height='20' width='24' src='../Images/Icons/watch-list.png'/></a>
                            <input type='hidden' value='{1}' />
                            </span></td>", Web.SessionMembers.s_MemberID == memberID.ToString() ? "inline" : "none", encryptedListingID);
        }

        if (ShowSendMessage)
        {
            html.AppendFormat(@"<td style='border:0px;'><span class='feed_actionLinks' style='display: {0};'>
                                    <a href='../Contacts/MessageToSelected.aspx?Action=messagetoone&RecordID={1}'>
                                        <span class='liMessage' Title='Message'></span>
                                    </a>
                                </span></td>", Web.SessionMembers.s_MemberID == memberID.ToString() ? "inline" : "none", encryptedMemberID);
        }

        if (ShowArchive)
        {
            html.AppendFormat(@"<td style='border:0px;'><span class='feed_actionLinks' style='display:{0};'>
                                <a href='#' onclick=""OnAction(this,'Archive');"" title='Archive'>
                                <span class='liArchive' Title='Archvie'></span>
                                </a>
                                <input type='hidden' value='{1}' />
                                </span></td>", Web.SessionMembers.s_MemberID == memberID.ToString() ? "inline" : "none", encryptedListingID);
        }

        if (ShowPrint)
        {
            html.AppendFormat(@"<td style='border:0px;'><span class='feed_actionLinks'> <a target='_blank' href='PrintListing.aspx?Action=View&RecordID={0}'>
                                <span class='liPrint' Title='Print'></span>
                                </a></span></td>", encryptedListingID);
        }

        if (ShowEnd)
        {
            html.AppendFormat(@"<td style='border:0px;'><span class='feed_actionLinks' style='display:{0};'>
                                <a href='#' onclick=""OnAction(this,'End');"" title='End'>
                                <span class='liEnd' Title='End'></span>
                                </a>
                                <input type='hidden' value='{1}' />
                                </span></td>", Web.SessionMembers.s_MemberID == memberID.ToString() ? "inline" : "none", encryptedListingID);
        }

        if (ShowDelete)
        {
            html.AppendFormat(@"<td style='border:0px;'><span class='feed_actionLinks' style='display:{0};'>
                                <a href='#' onclick=""OnAction(this,'Delete');"" title='Delete'>                                
                                <span class='liDelete' Title='Delete'></span>
                                </a>
                                <input type='hidden' value='{1}' />
                                </span></td>", Web.SessionMembers.s_MemberID == memberID.ToString() ? "inline" : "none", encryptedListingID);
        }

        html.Append("</tr></table>");
        return html.ToString();
    }

    private static string GetButtonsHtmlForClosedExpired(object memberID, object listingID, object ListingOfferID, bool ShowWatchItem, bool ShowSendMessage, bool ShowPrint, bool ShowDelete, bool ShowEnd, bool ShowArchive, bool ShowEdit)
    {
        ShowWatchItem = !Web.SessionMembers.MemberID.ToString().Equals(memberID.ToString());

        string encryptedListingID = Secure.Encrypt(listingID);
        string encryptedMemberID = Secure.Encrypt(memberID);
        //string encryptedListingOfferID = Secure.Encrypt(ListingOfferID);


        ShowSendMessage = !Web.SessionMembers.MemberID.ToString().Equals(memberID.ToString());

        StringBuilder html = new StringBuilder();
        html.Append("<table style='margin-left:20px;height:40px; float:right;'><tr>");
        html.AppendFormat(@"<td style='border:0px;'><span class='feed_actionLinks' style='display: inline;'>
                          <a href='ItemDetails.aspx?Action=View&RecordID={0}' title='View'>
                          <span class='liView' Title='View'></span></a></span></td>", encryptedListingID);

        //        html.AppendFormat(@"<td style='border:0px;'><span class='feed_actionLinks'> <a target='_blank' href='PrintListing.aspx?Action=View&RecordID={0}'>
        //                                <span class='liPrint' Title='Print'></span>
        //                                </a></span></td>", encryptedListingOfferID);

        html.AppendFormat(@"<td style='border:0px;'><span class='feed_actionLinks' style='display:{0};'>
                                <a href='#' onclick=""OnAction(this,'Delete');"" title='Delete'>                                
                                <span class='liDelete' Title='Delete'></span>
                                </a>
                                <input type='hidden' value='{1}' />
                                </span></td>", Web.SessionMembers.s_MemberID == memberID.ToString() ? "inline" : "none", encryptedListingID);

        html.Append("</tr></table>");
        return html.ToString();
    }


    public static IEnumerable<DataRow> GetListings(int listingTypeID)
    {
        try
        {
            bool IsSorting = false;
            string SortColumn = "", sortOrder = "";
            DataTable result = null;

            if (listingTypeID > 0 && listingTypeID < 100) // load all for selected listing type
            {
                result = LoadActiveListings(listingTypeID, IsSorting, SortColumn, sortOrder);
            }
            else
            {
                switch (listingTypeID)
                {
                    case 0: // load all that im selling
                        {
                            result = LoadActiveListings(listingTypeID, IsSorting, SortColumn, sortOrder);
                            break;
                        }
                    case 110:
                        {
                            result = LoadBuyingListings(110, listingTypeID, IsSorting, SortColumn, sortOrder);
                            break;
                        }
                    case 120:
                        {
                            result = LoadSellingListings(120, listingTypeID, IsSorting, SortColumn, sortOrder);
                            break;
                        }
                    case 130:
                        {
                            // Questions
                            result = Questions.GetListingAllQuestions(Web.SessionMembers.MemberID);
                            break;
                        }
                    case 100:
                        {
                            result = LoadSellingListings(100, listingTypeID, IsSorting, SortColumn, sortOrder);
                            break;
                        }
                    case 200:
                        {
                            result = LoadBuyingListings(200, listingTypeID, IsSorting, SortColumn, sortOrder);
                            break;
                        }
                    case 300:
                        {
                            result = LoadSellingListings(300, listingTypeID, IsSorting, SortColumn, sortOrder);
                            break;
                        }
                    case 400:
                        {
                            result = LoadSellingListings(400, listingTypeID, IsSorting, SortColumn, sortOrder);
                            break;
                        }
                    case 500:
                        {
                            result = LoadSellingListings(500, listingTypeID, IsSorting, SortColumn, sortOrder);
                            break;
                        }
                    case 600:
                        {
                            result = LoadSellingListings(600, listingTypeID, IsSorting, SortColumn, sortOrder);
                            break;
                        }
                    case 700:
                        {
                            result = LoadSellingListings(700, listingTypeID, IsSorting, SortColumn, sortOrder);
                            break;
                        }
                    case 800:
                        {
                            result = LoadSellingListings(800, listingTypeID, IsSorting, SortColumn, sortOrder);
                            break;
                        }
                    case 900:
                        {
                            result = LoadBuyingListings(900, listingTypeID, IsSorting, SortColumn, sortOrder);
                            break;
                        }
                    case 1000:
                        {
                            result = LoadBuyingListings(1000, listingTypeID, IsSorting, SortColumn, sortOrder);
                            break;
                        }
                    case 1100:
                        {
                            result = LoadBuyingListings(1100, listingTypeID, IsSorting, SortColumn, sortOrder);
                            break;
                        }
                    case 9999:
                        {
                            result = LoadBuyingListings(9999, listingTypeID, IsSorting, SortColumn, sortOrder);
                            break;
                        }
                }
            }
            return result.Select();
        }
        catch (Exception exp)
        {
            Web.WriteLog("Error", "My Listing.aspx", exp);
            throw exp;
        }
    }

    private static DataTable LoadActiveListings(int ListingTypeID, bool IsSorting, string SortColumn, string sortOrder)
    {
        try
        {
            ShowWatchItem = true;
            ShowSendMessage = true;
            ShowPrint = true;
            ShowDelete = true;
            ShowEnd = true;
            ShowArchive = true;
            ShowEdit = true;

            DataTable dt = new DataTable();

            if (ListingTypeID > 0)
            {
                dt = Listings.GetMemberListingsByListingType(Web.SessionMembers.MemberID, 100, ListingTypeID);
            }
            else
                dt = Listings.GetMemberListings(Web.SessionMembers.MemberID, 100);

            DataRow[] rows = dt.Select("ListingTypeID=7");
            foreach (DataRow row in rows)
                row.Delete();
            dt.AcceptChanges();

            try
            {
                if (IsSorting && !String.IsNullOrEmpty(SortColumn))
                {
                    DataView dview = new DataView(dt);
                    dview.Sort = string.Format("{0} {1}", SortColumn, sortOrder);
                    dt = dview.ToTable();
                }
            }
            catch (Exception ex) { Web.LogError(ex); }

            return dt;
        }
        catch (Exception ex) { Web.LogError(ex); }
        return null;
    }

    private static DataTable LoadBuyingListings(int StatusID, int ListingTypeID, bool IsSorting, string SortColumn, string sortOrder)
    {
        try
        {
            if (StatusID > 0)
            {
                ShowPrint = true;
                ShowWatchItem = true;

                string titleType = "";

                if (StatusID == 100)
                {
                    //ShowOffer = true;
                    ShowEdit = true;
                }
                else if (StatusID == 200)
                {
                    ShowEdit = false;
                }
                else if (StatusID == 900)
                {
                    ShowEdit = false;
                }
                else if (StatusID == 1000)
                {
                    ShowEdit = false;
                }
                else if (StatusID == 1100)
                {
                    ShowEdit = false;
                    ShowWatchItem = false;
                }
                else
                {
                    ShowWatchItem = false;
                }

                DataTable dt = new DataTable();
                if (StatusID == 9999)
                {
                    dt = Listings.GetMemberWatchList(Web.SessionMembers.MemberID);

                    try
                    {
                        if (IsSorting && !String.IsNullOrEmpty(SortColumn))
                        {
                            DataView dview = new DataView(dt);
                            dview.Sort = string.Format("{0} {1}", SortColumn, sortOrder);
                            dt = dview.ToTable();
                        }
                    }
                    catch (Exception ex) { Web.LogError(ex); }

                    return dt;

                }
                else
                {
                    dt = Listings.GetBuyerListings(Web.SessionMembers.MemberID, StatusID);

                    try
                    {
                        if (IsSorting && !String.IsNullOrEmpty(SortColumn))
                        {
                            DataView dview = new DataView(dt);
                            dview.Sort = string.Format("{0} {1}", SortColumn, sortOrder);
                            dt = dview.ToTable();
                        }
                    }
                    catch (Exception ex) { Web.LogError(ex); }

                    return dt;
                }

            }
        }
        catch (Exception ex) { Web.LogError(ex); }

        return null;
    }

    private static DataTable LoadSellingListings(int StatusID, int ListingTypeID, bool IsSorting, string SortColumn, string sortOrder)
    {
        try
        {
            if (StatusID > 0)
            {
                ShowPrint = true;

                string titleType = "";

                if (StatusID == 120)
                {
                    ShowEdit = true;
                    ShowEnd = true;
                    ShowArchive = true;
                }
                else if (StatusID == 300)
                {
                    ShowRelist = true;
                }

                DataTable dt = new DataTable();
                if (StatusID == 120 || StatusID == 800)
                {
                    //if (StatusID == 120) StatusID = 100;
                    dt = Listings.GetMemberListings(Web.SessionMembers.MemberID, StatusID);

                    try
                    {
                        if (IsSorting && !String.IsNullOrEmpty(SortColumn))
                        {
                            DataView dview = new DataView(dt);
                            dview.Sort = string.Format("{0} {1}", SortColumn, sortOrder);
                            dt = dview.ToTable();
                        }
                    }
                    catch (Exception ex) { Web.LogError(ex); }

                    return dt;

                }
                else if (StatusID == 300)
                {
                    dt = Listings.GetMemberListings(Web.SessionMembers.MemberID, 300);
                    try
                    {
                        if (IsSorting && !String.IsNullOrEmpty(SortColumn))
                        {
                            DataView dview = new DataView(dt);
                            dview.Sort = string.Format("{0} {1}", SortColumn, sortOrder);
                            dt = dview.ToTable();
                        }
                    }
                    catch (Exception ex) { Web.LogError(ex); }

                    return dt;

                }
                else
                {
                    if (StatusID == 400)
                        StatusID = 200;
                    else if (StatusID == 500)
                        StatusID = 900;
                    else if (StatusID == 600)
                        StatusID = 1000;
                    else if (StatusID == 700)
                        StatusID = 1100;
                    dt = ListingOffers.GetOfferOnListings(Web.SessionMembers.MemberID, StatusID);
                    try
                    {
                        if (IsSorting && !String.IsNullOrEmpty(SortColumn))
                        {
                            DataView dview = new DataView(dt);
                            dview.Sort = string.Format("{0} {1}", SortColumn, sortOrder);
                            dt = dview.ToTable();
                        }
                    }
                    catch (Exception ex) { Web.LogError(ex); }
                }
                return dt;
            }
        }
        catch (Exception ex) { Web.LogError(ex); }
        return null;

    }

    private static object getDefaultImage(int listingTypeID)
    {
        switch (listingTypeID)
        {
            case 1:
                return "../App_Themes/Space/Images/eOpen post_tp_world Icons/sale.png";
            case 2:
                return "../App_Themes/Space/Images/eOpen post_tp_world Icons/rent.png";
            case 3:
                return "../App_Themes/Space/Images/eOpen post_tp_world Icons/service.png";
            case 4:
                return "../App_Themes/Space/Images/eOpen post_tp_world Icons/jobs.png";
            case 5:
                return "../App_Themes/Space/Images/eOpen post_tp_world Icons/personal.png";
            case 6:
                return "../App_Themes/Space/Images/eOpen post_tp_world Icons/coupon.png";
            case 7:
                return "../App_Themes/Space/Images/eOpen post_tp_world Icons/coupon.png";
            case 8:
                return "/Images/noimage.png";
            default:
                return "/Images/noimage.png";
        }
    }

}