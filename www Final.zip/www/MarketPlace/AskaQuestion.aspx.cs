﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Net.Mail;
using System.Collections.Specialized;
using VisualSoft.VSharp.Utils;
using CodenameRabbitFoot.BusinessLogic;

public partial class MarketPlace_AskaQuestion : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {
        //MessageBox.Visible = false;
        //if (!IsPostBack)
        //{
        //    bindgrid();
        //}
        //BtnLotQuestion.Attributes["onclick"] = string.Format("{0}.disabled=true;{1};", BtnLotQuestion.ClientID, GetPostBackEventReference(BtnLotQuestion));
    }


    protected void BtnLotQuestion_Click(object sender, EventArgs e)
    {
        //var test = Request.QueryString["RecordID"].ToString();
        try
        {
            Listings lot = new Listings();
            lot.LoadByPrimaryKey(Web.RecordID);

            BtnLotQuestion.Enabled = false;
            Questions question = new Questions();
            question.AddNew();
            question.ObjectID = Web.RecordID;
            question.QuestionBy = Web.SessionMembers.MemberID;
            question.QuestionDate = DateTime.Now;
            question.s_Question = TxtBoxLotQuestion.Text;
            question.IsActive = 1;
            question.IsReplied = 0;
            question.QuestionTo = lot.MemberID;
            question.SystemObjectTypeID = 600;
            question.Save();

            Members seller = new Members();
            seller.LoadByPrimaryKey(lot.MemberID);

            string title = Listings.GetTitle(Web.RecordID);
            string replylink = Web.SystemConfigs.GetKey("SITE_URL") + "Contacts/MessageToSelected.aspx?Action=messagetoone&RecordID=" + Secure.Encrypt(Web.SessionMembers.MemberID);
            StringDictionary TemplateKeys = new StringDictionary();
            TemplateKeys.Add("#email_header#", Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER"));
            TemplateKeys.Add("#fullname#", seller.FullName);
            TemplateKeys.Add("#item_title#", title);
            TemplateKeys.Add("#profile_name#", Web.SessionMembers.UserName);
            TemplateKeys.Add("#question#", question.s_Question);
            TemplateKeys.Add("#link#", replylink);
            TemplateKeys.Add("#reply_link#", replylink);
            TemplateKeys.Add("#link_log_myeoffer#", Web.SystemConfigs.GetKey("SITE_URL"));
            TemplateKeys.Add("#email_footer#", Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER"));
            Web.NotifyMember(seller.MemberID, 12, TemplateKeys);
            // Web.SendMail(seller.Email, Web.SystemConfigs.GetKey("ALERTS_EMAIL"), 302, TemplateKeys);

            // askd question from seller
            System.Collections.Specialized.StringDictionary templateKeys = new System.Collections.Specialized.StringDictionary();
            templateKeys = new System.Collections.Specialized.StringDictionary();
            templateKeys.Add("#viewlink#", "../Listing/DealingFloor.aspx?TabIndex=130");
            templateKeys.Add("#initiatedto#", "#memberid#" + seller.MemberID + "#endmemberid#");
            templateKeys.Add("#profileclass#", "#profileclass#" + seller.MemberID + "#endprofileclass#");
            templateKeys.Add("#initiatedtoprofile#", "/Contacts/ViewProfile.aspx?Action=ViewDealer&RecordID=#encrypt#" + seller.MemberID + "#endencrypt#");
            Web.AddPrivateActivityLog(16, templateKeys, seller.MemberID, question.QuestionID, Web.SessionMembers.MemberID);
            
        }
            
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
       // ClientScript.RegisterStartupScript(Page.GetType(), "CancelEdit", "CancelEdit();", true);
    }

    //private void bindgrid()
    //{

    //    try
    //    {
    //        GridViewLotQuestion.DataSource = LotQuestions.GetLotQuestionsByBuyer(Web.RecordID, Web.SessionMembers.MemberID);
    //        GridViewLotQuestion.DataBind();
    //        if (GridViewLotQuestion.Rows.Count > 0)
    //            GridViewLotQuestion.Visible = true;
    //        else
    //            GridViewLotQuestion.Visible = false;
    //    }
    //    catch (Exception ex)
    //    {
    //        Web.LogError(ex);
    //    }
    //}

    //protected void GridViewLotQuestion_OnPageIndexChanging(object sender, GridViewPageEventArgs e)
    //{
    //    try
    //    {
    //        GridViewLotQuestion.PageIndex = e.NewPageIndex;
    //        bindgrid();
    //    }
    //    catch (Exception ex)
    //    {
    //        Web.LogError(ex);
    //    }
    //}
    //private void ShowMessage(string message)
    //{
    //    string messageScript = "showMessage('" + message + "');";
    //    ScriptManager.RegisterStartupScript(this.Page, typeof(Page), "ShowMessageScript", messageScript, true);
    //}
    protected void btncancel_Click(object sender, EventArgs e)
    {
        Web.Redirect("/MarketPlace/ItemDetails.aspx");
    }
}