﻿using System;
using System.Data;
using System.Collections;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections.Specialized;
using CodenameRabbitFoot.BusinessLogic;
using Telerik.Web.UI;

public partial class PublicSite_Listing_SubmitOffer : System.Web.UI.Page
{
    protected int ListingType = 0;
    protected bool ShowQTY = false;
    protected bool ShowPrice = false;
    protected bool ShowShipping = false;
    protected bool ShowPayment = false;

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (Web.IsMemberSession)
            {
                if (!String.IsNullOrEmpty(Web.SessionMembers.shippingAddress.s_Address1))
                {
                    if (!IsPostBack)
                    {
                        if (Web.RecordID > 0)
                        {
                            if (!Web.HasPlacedOffer(Web.RecordID, Web.SessionMembers.MemberID))
                            {
                                multiView.ActiveViewIndex = 0;
                                LoadPaymentTypes();
                                LoadShippingTypes();
                                BindData();
                            }
                            else
                            {
                                multiView.ActiveViewIndex = 3;
                            }
                        }
                    }
                    btnSubmitOffer.Attributes["onclick"] = string.Format("{0}.disabled=true;{1};", btnSubmitOffer.ClientID, GetPostBackEventReference(btnSubmitOffer));
                    // txtOfferPrice.Attributes.Add("onblur", "calculate()");
                    // txtQTY.Attributes.Add("onblur", "calculate()");
                    rdlUnit.Attributes.Add("onClick", "calculate()");
                    rdoWillArrangePick.Attributes.Add("onClick", "calculate()");
                }
                else
                {
                    ClientScript.RegisterStartupScript(Page.GetType(), "returnToParent", "CancelEdit();parent.showMessage('Please fill in your contact information first.');", true);
                }
            }
            else
                ClientScript.RegisterStartupScript(Page.GetType(), "returnToParent", "CancelEdit();parent.showMessage('Please log in first to make an offer.');", true);
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
            ClientScript.RegisterStartupScript(Page.GetType(), "returnToParent", "CancelEdit();parent.showMessage('Please fill in your contact information first.');", true);
        }
    }

    public void BindData()
    {
        try
        {
            hdTotalPrice.Value = hdTotalQty.Value = hdTotalShippingPrice.Value = hdTotalOfferPrice.Value = hdQTY.Value = hdPrice.Value = "0";
            double ShippingPrice = 0, AdditionalPrice = 0;
            int ShippingPriceUnit = 0;

            Listings listing = new Listings();
            listing.LoadByPrimaryKey(Web.RecordID);
            if (listing.RowCount > 0)
            {
                ListingType = listing.ListingTypeID;
                List<int> categoryFields = CategoryFields.GetCategoryFields(listing.ListingTypeID, listing.CategoryID);
                TogglePanels(categoryFields);

                Members member = new Members();
                member.LoadByPrimaryKey(listing.MemberID);
                if (member.RowCount > 0)
                {
                    lnkSeller.Text = member.UserName;
                    lnkSeller.NavigateUrl = "~/Contacts/ViewProfile.aspx?Action=View&RecordID=" + Secure.Encrypt(listing.MemberID);
                    lnkSeller.Enabled = true;
                }

                TimeSpan timeleft = listing.ListingEndDate.Subtract(DateTime.Now);
                if (timeleft.TotalSeconds > 0)
                    lblTimeLeft.Text = timeleft.Days + " day(s), " + timeleft.Hours + " hr(s), " + timeleft.Minutes + " min(s)";
                else lblTimeLeft.Text = "Expired";

                if (ShowPrice)
                {
                    ListingExtendedFields fields = new ListingExtendedFields();
                    fields.Where.ObjectID.Value = listing.ListingID;
                    fields.Where.IsActive.Value = 1;
                    if (fields.Query.Load())
                    {
                        lblLotName.Text = Convert.ToString(Web.GetFieldData(fields, 20));
                        int QTY = Convert.ToInt32(Web.GetFieldData(fields, 4));
                        if (QTY > 0)
                        {
                            hdTotalQty.Value = lblQTY.Text = txtQTY.Text = rngVldQuantity.MaximumValue = hdQTY.Value = QTY.ToString();
                            ShowQTY = true;
                        }
                        else
                            ShowQTY = lblQTY.Visible = txtQTY.Visible = false;


                        if (!String.IsNullOrEmpty(listing.s_ShippingFee))
                        {
                            ShippingPrice = Convert.ToDouble(listing.ShippingFee);
                            AdditionalPrice = ShippingPrice;
                            ShippingPriceUnit = Convert.ToInt32(listing.ShippingFeeUnit);
                            lblShippingFee.Value = ShippingPrice.ToString();
                            lblShippingFeeUnit.Value = ShippingPriceUnit.ToString();

                            if (!String.IsNullOrEmpty(listing.s_AdditionalFee))
                                AdditionalPrice = Convert.ToDouble(listing.AdditionalFee);
                            lblAdditionalFee.Value = AdditionalPrice.ToString();

                            lblShippingPrice1.Text = lblShippingPrice.Text = "$" + ShippingPrice.ToString();
                            lblAdditionalPrice.Text = lblAdditionalPrice1.Text = "$" + AdditionalPrice.ToString();
                        }

                        double totalPrice = 0;
                        double Price = (Web.GetFieldData(fields, 9) != null) ? Convert.ToDouble(Web.GetFieldData(fields, 9)) : 0;
                        double PriceEach = (Web.GetFieldData(fields, 10) != null) ? Convert.ToDouble(Web.GetFieldData(fields, 10)) : 0;
                        if (listing.ListingTypeID == 1) // for sale
                        {
                            ShowQTY = true;
                            bool isSellSeparately = false;
                            string sellseparately = Web.GetFieldData(fields, 23).ToString();
                            if (!String.IsNullOrEmpty(sellseparately))
                            {
                                if (sellseparately == "Sell Separately")
                                    isSellSeparately = true;
                            }

                            if (PriceEach > 0 && QTY > 0)
                            {
                                if (!isSellSeparately)  // sell whole listing
                                {
                                    totalPrice = PriceEach * QTY;
                                    lblAskingPrice.Text = "$" + PriceEach.ToString() + " per unit";
                                    txtOfferPrice.Text = totalPrice.ToString();
                                    rdlUnit.SelectedIndex = 0;
                                    this.hdPrice.Value = totalPrice.ToString();
                                    txtQTY.Enabled = false;
                                    rdlUnit.Items[1].Enabled = false;
                                    hdTotalOfferPrice.Value = PriceEach.ToString();
                                }
                                else // sell items separately
                                {
                                    totalPrice = PriceEach * QTY;
                                    lblAskingPrice.Text = "$" + PriceEach.ToString() + " per unit";
                                    txtOfferPrice.Text = PriceEach.ToString();
                                    rdlUnit.SelectedIndex = 1;
                                    this.hdPrice.Value = PriceEach.ToString();
                                    hdTotalOfferPrice.Value = PriceEach.ToString();
                                }
                            }
                            hdPrice.Value = totalPrice.ToString();

                            // add shipping to total
                            if (ShippingPrice > 0)
                            {
                                if (listing.ShippingFeeUnit == 1)
                                {
                                    if (AdditionalPrice > 0)
                                        ShippingPrice = (ShippingPrice + (AdditionalPrice * (QTY - 1)));
                                }
                                hdTotalShippingPrice.Value = ShippingPrice.ToString();
                                totalPrice += ShippingPrice;
                            }
                        }
                        else // for rent
                        {
                            if (Price > 0)
                            {
                                ShowQTY = false;
                                totalPrice = Price;
                                lblAskingPrice.Text = "$" + Price.ToString() + " entire lot";
                                txtOfferPrice.Text = totalPrice.ToString();
                                this.hdPrice.Value = totalPrice.ToString();
                                hdTotalOfferPrice.Value = Price.ToString();
                                rdlUnit.SelectedIndex = 0;
                                rdlUnit.Items[1].Enabled = false;
                            }
                        }
                        hdTotalPrice.Value = totalPrice.ToString();
                        if (Convert.ToInt32(hdTotalPrice.Value) == 0)
                            lblTotalLotPrice.Visible = false;
                        lblTotalLotPrice.Text = lblTotalOfferPrice.Text = "$" + totalPrice.ToString();
                    }
                }
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }

    private void TogglePanels(List<int> categoryFields)
    {
        try
        {
            if (categoryFields.Contains(9) || categoryFields.Contains(10))
                ShowPrice = true;
            if (categoryFields.Contains(13))
                ShowPayment = true;
            if (categoryFields.Contains(12))
                ShowShipping = true;
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }
    private void LoadShippingTypes()
    {
        try
        {
            ddlShippingTypes.Items.Clear();
            ShippingTypes types = new ShippingTypes();
            types.Query.AddOrderBy(ShippingTypesSchema.ShippingName);
            types.Query.AddResultColumn(ShippingTypesSchema.ShippingName);
            types.Query.AddResultColumn(ShippingTypesSchema.ShippingTypeID);
            types.Where.IsActive.Value = 1;
            if (types.Query.Load())
            {
                do
                {
                    RadComboBoxItem listItem = new RadComboBoxItem();
                    listItem.Text = types.s_ShippingName;
                    listItem.Value = types.s_ShippingTypeID;
                    ddlShippingTypes.Items.Add(listItem);
                }
                while (types.MoveNext());
            }
            else
            {
                types = new ShippingTypes();
                types.Query.AddOrderBy(ShippingTypesSchema.ShippingName);
                types.Query.AddResultColumn(ShippingTypesSchema.ShippingName);
                types.Query.AddResultColumn(ShippingTypesSchema.ShippingTypeID);
                types.Where.IsActive.Value = 1;
                if (types.Query.Load())
                {
                    do
                    {
                        RadComboBoxItem listItem = new RadComboBoxItem();
                        listItem.Text = types.s_ShippingName;
                        listItem.Value = types.s_ShippingTypeID;
                        ddlShippingTypes.Items.Add(listItem);
                    }
                    while (types.MoveNext());
                }
                else
                {
                    RadComboBoxItem listItem = new RadComboBoxItem();
                    listItem.Text = " - - - - - None - - - - -";
                    listItem.Value = "-1";
                    ddlShippingTypes.Items.Add(listItem);
                }
            }
            ddlShippingTypes.DataBind();
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }
    private void LoadPaymentTypes()
    {
        try
        {
            ddlPayBy.Items.Clear();
            DataTable dt = ListingPaymentTypes.GetListingPaymentTypes(Web.RecordID);
            if (dt.Rows.Count > 0)
            {
                foreach (DataRow Dr in dt.Rows)
                {
                    RadComboBoxItem listItem = new RadComboBoxItem();
                    listItem.Text = Dr["PaymentName"].ToString();
                    listItem.Value = Dr["PaymentTypeID"].ToString();
                    ddlPayBy.Items.Add(listItem);
                }
            }
            else
            {
                PaymentTypes types = new PaymentTypes();
                types.Query.AddOrderBy(PaymentTypesSchema.PaymentName);
                types.Query.AddResultColumn(PaymentTypesSchema.PaymentName);
                types.Query.AddResultColumn(PaymentTypesSchema.PaymentTypeID);
                types.Where.IsActive.Value = 1;
                if (types.Query.Load())
                {
                    do
                    {
                        RadComboBoxItem listItem = new RadComboBoxItem();
                        listItem.Text = types.PaymentName;
                        listItem.Value = types.s_PaymentTypeID;
                        ddlPayBy.Items.Add(listItem);
                    } while (types.MoveNext());
                }
                else
                {
                    RadComboBoxItem listItem = new RadComboBoxItem();
                    listItem.Text = " - - - - - None - - - - -";
                    listItem.Value = "-1";
                    ddlPayBy.Items.Add(listItem);
                }
            }
            ddlPayBy.DataBind();
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }

    protected void btnOfferPreview_Click(object sender, CommandEventArgs e)
    {
        multiView.ActiveViewIndex = 1;
        LoadOfferPreview();
    }
    private void LoadOfferPreview()
    {
        try
        {
            lblLotName1.Text = lblLotName.Text;
            lnkSeller1.Text = lnkSeller.Text;
            lnkSeller1.NavigateUrl = lnkSeller.NavigateUrl;
            lnkSeller1.Enabled = lnkSeller.Enabled;
            lblPreviewPrice.Text = lblAskingPrice.Text;
            lblPreviewQTY.Text = lblQTY.Text;
            lblPreviewShipping.Text = lblPreviewShipping1.Text = lblShippingPrice.Text;
            lblPreviewAdditional.Text = lblPreviewAdditional1.Text = lblAdditionalPrice.Text;
            lblPreviewOfferPrice.Text = "$" + hdTotalOfferPrice.Value + ((rdlUnit.SelectedIndex == 0) ? " entire lot" : " per unit");
            lblPreviewOfferQTY.Text = hdTotalQty.Value;

            lblPreviewTotal.Text = lblTotalLotPrice.Text;
            int price = 0;
            int.TryParse(lblTotalLotPrice.Text, out price);
            if (price == 0)
                lblPreviewTotal.Visible = false;

            if (rdoWillArrangePick.Checked == true)
                lblShippingOption.Text = rdoWillArrangePick.Text;
            else
                lblShippingOption.Text = ddlShippingTypes.SelectedItem.Text;

            lblPaymentOption.Text = ddlPayBy.SelectedItem.Text;
            lblOfferValidFor.Text = ddlOfferValieTo.SelectedItem.Text;
            lblAdditionalTerms.Text = (!String.IsNullOrEmpty(txtAdditionalTerms.Text)) ? txtAdditionalTerms.Text : "N/A";
            lblPreviewOfferTotal.Text = "$" + hdTotalPrice.Value;
        }
        catch (Exception exp)
        {
            Web.LogError(exp);
        }
    }

    protected void btnBackToOffer_Click(object sender, EventArgs e)
    {
        LoadBackToOfferData();
        multiView.ActiveViewIndex = 0;
    }
    private void LoadBackToOfferData()
    {
        try
        {
            Listings listing = new Listings();
            listing.LoadByPrimaryKey(Web.RecordID);
            if (listing.RowCount > 0)
            {
                Members member = new Members();
                member.LoadByPrimaryKey(listing.MemberID);
                if (member.RowCount > 0)
                {
                    lnkSeller.Text = member.UserName;
                    lnkSeller.NavigateUrl = "~/Contacts/ViewProfile.aspx?Action=View&RecordID=" + Secure.Encrypt(listing.MemberID);
                    lnkSeller.Enabled = true;
                }

                if (listing.ListingEndDate >= DateTime.Now)
                {
                    TimeSpan timeleft = listing.ListingEndDate.Subtract(DateTime.Now);
                    lblTimeLeft.Text = timeleft.Days + " day(s), " + timeleft.Hours + " hr(s), " + timeleft.Minutes + " min(s)";

                    // Load offer details
                    lblAskingPrice.Text = lblPreviewPrice.Text;
                    lblQTY.Text = lblPreviewQTY.Text;
                    lblShippingPrice.Text = lblPreviewShipping.Text;
                    lblAdditionalPrice.Text = lblPreviewAdditional.Text;
                    //if (Convert.ToInt32(lblPreviewTotal.Text) == 0)
                    //    this.lblTotalLotPrice.Visible = false;
                    lblTotalLotPrice.Text = lblPreviewTotal.Text;

                    if (rdoWillArrangePick.Checked == true)
                        lblShippingOption.Text = rdoWillArrangePick.Text;
                    else
                        lblShippingOption.Text = ddlShippingTypes.SelectedItem.Text;

                    if (rdlUnit.SelectedIndex == 0) txtQTY.Enabled = false;

                    lblPaymentOption.Text = ddlPayBy.SelectedItem.Text;
                    lblOfferValidFor.Text = ddlOfferValieTo.SelectedItem.Text;
                    lblAdditionalTerms.Text = (!String.IsNullOrEmpty(txtAdditionalTerms.Text)) ? txtAdditionalTerms.Text : "N/A";

                    if (Convert.ToInt32(hdTotalOfferPrice.Value) == 0)
                        txtOfferPrice.Visible = false;

                    txtOfferPrice.Text = hdTotalOfferPrice.Value;
                    txtQTY.Text = hdTotalQty.Value;
                    lblTotalOfferPrice.Text = "$" + hdTotalPrice.Value;
                    //}
                }
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }

    protected void btnSubmitOffer_Click(object sender, EventArgs e)
    {
        try
        {
            if (!Web.HasPlacedOffer(Web.RecordID, Web.SessionMembers.MemberID))
            {
                string ListingTitle = lblLotName.Text;
                Listings listing = new Listings();
                listing.LoadByPrimaryKey(Web.RecordID);

                ListingExtendedFields fields = new ListingExtendedFields();
                fields.Where.ObjectID.Value = listing.ListingID;
                fields.Where.IsActive.Value = 1;
                if (fields.Query.Load())
                    ListingTitle = Convert.ToString(Web.GetFieldData(fields, 20));

                Members member = new Members();
                member.LoadByPrimaryKey(listing.MemberID);

                ListingOffers offer = new ListingOffers();
                offer.AddNew();
                offer.ListingID = Web.RecordID;
                offer.OfferDate = DateTime.Now;
                offer.OfferBy = Web.SessionMembers.MemberID;
                offer.OfferStatusID = 100;
                offer.s_ArrangePickup = (rdoWillArrangePick.Checked == true ? "1" : "0");
                offer.s_OfferValidFor = ddlOfferValieTo.SelectedValue;
                offer.s_PaymentTypeID = ddlPayBy.SelectedValue;
                offer.AdditionalTerms = Server.HtmlEncode(txtAdditionalTerms.Text);
                offer.ShippingPrice = Convert.ToDecimal(hdTotalShippingPrice.Value);
                offer.TotalPrice = Convert.ToDecimal(hdTotalPrice.Value);
                offer.OfferPrice = Convert.ToDecimal(lblTotalOfferPrice.Text.Replace("$","").ToString());
                offer.Quantity = Convert.ToInt32(hdTotalQty.Value);
                offer.s_IsBuyEntireListing = (rdlUnit.SelectedIndex == 0) ? "1" : "0";
                offer.ListingTypeID = listing.ListingTypeID;
                offer.s_ShippingTypeID = ddlShippingTypes.SelectedValue;
                offer.Save();

                // offer email to Seller
                System.Collections.Specialized.StringDictionary templateKeys = new System.Collections.Specialized.StringDictionary();
                templateKeys.Add("#initiatedto#", "#memberid#" + listing.MemberID + "#endmemberid#");
                templateKeys.Add("#profileclass#", "#profileclass#" + listing.MemberID + "#endprofileclass#");
                templateKeys.Add("#initiatedtoprofile#", "/Contacts/ViewProfile.aspx?Action=ViewDealer&RecordID=#encrypt#" + listing.MemberID + "#endencrypt#");
                templateKeys.Add("#lot#", ListingTitle);
                templateKeys.Add("#viewlot#", "../MarketPlace/ItemDetails.aspx?Action=View&RecordID=#encrypt#" + listing.ListingID + "#endencrypt#");
                Web.AddPrivateActivityLog(47, templateKeys, Web.SessionMembers.MemberID, offer.ListingOfferID, listing.MemberID);

                int memberID = listing.MemberID;
                Members members = new Members();
                members.LoadByPrimaryKey(memberID);
                string dealingfloorlink = Web.SystemConfigs.GetKey("SITE_URL") + "live.aspx";
                StringDictionary TemplateKeys = new StringDictionary();
                TemplateKeys.Add("#email_header#", Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER"));
                TemplateKeys.Add("#fullname#", members.FullName);
                TemplateKeys.Add("#item_title#", ListingTitle);
                TemplateKeys.Add("#dealing_floor_item#", dealingfloorlink);
                TemplateKeys.Add("#dealing_floor#", Web.SystemConfigs.GetKey("SITE_URL") + "live.aspx");
                TemplateKeys.Add("#link_log_myeoffer#", Web.SystemConfigs.GetKey("SITE_URL"));
                TemplateKeys.Add("#email_footer#", Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER"));
                Web.NotifyMember(members.MemberID, 7, TemplateKeys);

                multiView.ActiveViewIndex = 2;
            }
        }
        catch (Exception exp)
        {
            Web.LogError(exp);
        }
    }
}
