﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using CodenameRabbitFoot.BusinessLogic;
using Telerik.Web.UI;
using System.Data;
using System.Xml;

public partial class MarketPlace_ApplyNow : System.Web.UI.Page
{
    string sellerName = "";

    string s_lblLotName2 = "";
    string s_lblMemberName = "";

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!Web.IsMemberSession)
                ClientScript.RegisterStartupScript(Page.GetType(), "returnToParent", "CancelEdit();parent.showMessage('Please log in first to make an offer.');", true);

            if (!IsPostBack)
            {
                if (Web.RecordID > 0)
                {
                    if (!Web.HasPlacedOffer(Web.RecordID, Web.SessionMembers.MemberID))
                    {
                        Listings listing = new CodenameRabbitFoot.BusinessLogic.Listings();                         
                        listing.LoadByPrimaryKey(Web.RecordID);

                        if (listing.RowCount > 0)
                        {
                            if (listing.ListingTypeID == 4) //Jobs = resume
                                trResume.Visible = true;

                            //pnlAttachment.Visible = (listing.ListingTypeID == 4) ? true : false;
                            var xdoc = new XmlDocument();
                            string xml = null;
                            XmlNodeList _nodelist;
                            DataTable result = Listings.GetListingDetails(Web.RecordID);
                            foreach (DataRow row in result.Rows)
                            {
                                xml = row["ListingData"].ToString();
                                if (!String.IsNullOrEmpty(xml))
                                {
                                    xdoc.LoadXml("<listings>" + xml + "</listings>");
                                    _nodelist = xdoc.SelectNodes("listings/ListingData");
                                    if (_nodelist.Count > 0)
                                    {
                                        foreach (XmlNode node in _nodelist)
                                        {
                                            if (node.Attributes.Item(0).Value == "20")
                                            {
                                                lblLotName.Text = s_lblLotName2 = node.Attributes.Item(2).Value;
                                                break;
                                            }
                                        }
                                    }
                                }
                            }

                            s_lblMemberName = Web.SessionMembers.FullName;
                        }
                        else
                            Web.Redirect("~/ErrorPage.aspx");
                    }
                    else
                    {
                        ClientScript.RegisterStartupScript(Page.GetType(), "CancelEdit", "CancelEdit();this.parent.ShowMessage('You have already placed an offer on this listing.');", true);
                    }
                }
            }
            btnSend.Attributes["onclick"] = string.Format("{0}.disabled=true;{1};", btnSend.ClientID, GetPostBackEventReference(btnSend));
        } 
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }

    protected void btnSend_Click(object sender, EventArgs e)
    {
        try
        {
            if (Web.RecordID > 0)
            {
                //if (txtCaptchaValue.Text.ToLower() == Session["CaptchaImageText"].ToString().ToLower())
                //{
                DisableButton();
                Listings listing = new CodenameRabbitFoot.BusinessLogic.Listings();
                listing.LoadByPrimaryKey(Web.RecordID);
                if (listing.RowCount < 1)
                    return;

                /* Disable Placeing offer only send message to Job Poster*/
                if (listing.s_ListingTypeID == "2" || listing.s_ListingTypeID == "3" || listing.s_ListingTypeID == "4" || listing.s_ListingTypeID == "5")
                {
                    ContactMessages contactmessage = new ContactMessages();
                    contactmessage.AddNew();
                    contactmessage.From = Web.SessionMembers.MemberID;
                    contactmessage.To =listing.MemberID;
                    contactmessage.Message = txtMessage.Text;
                    contactmessage.MessageDate = System.DateTime.Now;
                    contactmessage.IsRead = 0;
                    contactmessage.IsPrivate = 1;
                    //if (!String.IsNullOrEmpty(contactmessage.s_GroupID))
                    //    contactmessage.GroupID = groupID;
                    contactmessage.SystemObjectID = (int)SystemObjects.Messages;
                    //contactmessage.ThreadID = threadID;
                    contactmessage.Save();

                    if (fupDocument.UploadedFiles.Count > 0)
                    {
                        // Save file to physical path
                        string targetFolder = Web.SystemConfigs.GetKey("ATTACHMENTS_PHYSICAL_PATH");
                        string folderVirtualPath = Web.SystemConfigs.GetKey("ATTACHMENTS_PATH");
                        string fileName = contactmessage.s_ContactMessageID + "_" + (int)SystemObjects.Listing_Offers + fupDocument.UploadedFiles[0].GetExtension();
                        string targetFileURL = System.IO.Path.Combine(targetFolder, fileName);
                        string virtualURL = System.IO.Path.Combine(folderVirtualPath, fileName);

                        while (System.IO.File.Exists(targetFileURL))
                        {
                            targetFileURL = System.IO.Path.Combine(targetFolder, fileName);
                        }

                        fupDocument.UploadedFiles[0].SaveAs(targetFileURL);

                        SystemObjectFiles objfile = new SystemObjectFiles();
                        objfile.AddNew();
                        objfile.FileDate = DateTime.Now;
                        objfile.FileTypeID = (int)FileTypes.FileURL;
                        objfile.s_IsActive = "1";
                        objfile.ObjectID = contactmessage.ContactMessageID;
                        objfile.s_FileName = fupDocument.UploadedFiles[0].FileName;
                        objfile.SystemObjectID = (int)SystemObjects.Listing_Offers;
                        objfile.RemoteIP = System.Web.HttpContext.Current.Request.UserHostAddress;
                        objfile.FileFormat = fupDocument.UploadedFiles[0].GetExtension();
                        objfile.MemberID = Web.SessionMembers.MemberID;
                        objfile.PrivacyTypeID = 5;
                        objfile.URL = virtualURL;
                        objfile.Save();
                    }

                    Members tomember = new Members();
                    tomember.LoadByPrimaryKey(listing.MemberID);
                    var templateKeys = new System.Collections.Specialized.StringDictionary();
                    templateKeys.Add("#viewlink#", "LiveFeed.aspx?Action=Message&RecordID=#encrypt#" + contactmessage.ContactMessageID + "#endencrypt#");
                    templateKeys.Add("#initiatedto#", "#memberid#" + tomember.MemberID + "#endmemberid#");
                    templateKeys.Add("#profileclass#", "#profileclass#" + contactmessage.To + "#endprofileclass#");
                    templateKeys.Add("#initiatedtoprofile#", "/Contacts/ViewProfile.aspx?Action=ViewDealer&RecordID=#encrypt#" + tomember.MemberID + "#endencrypt#");
                    Web.AddPrivateActivityLog(4, templateKeys, tomember.MemberID, contactmessage.ContactMessageID, tomember.MemberID);

                    templateKeys = new System.Collections.Specialized.StringDictionary();
                    templateKeys.Add("#email_header#", Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER"));
                    templateKeys.Add("#message#", Web.ParseTemplate(contactmessage.Message));
                    templateKeys.Add("#company_sender#", Web.SessionMembers.CompanyName);
                    templateKeys.Add("#fullname_sender#", Web.SessionMembers.FullName);
                    templateKeys.Add("#public_profile_sender#", Web.SessionMembers.UserName);
                    templateKeys.Add("#fullname#", tomember.FullName);
                    templateKeys.Add("#reply_link_on_contact_module#", Web.SystemConfigs.GetKey("SITE_URL") + "Contacts/MessageToSelected.aspx?Action=replytomessage&RecordID=" + Secure.Encrypt(contactmessage.ContactMessageID));
                    templateKeys.Add("#link_log_myeoffer#", Web.SystemConfigs.GetKey("SITE_URL") + "index.aspx");
                    templateKeys.Add("#email_footer#", Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER"));
                    Web.SendMail(tomember.Email, Web.SystemConfigs.GetKey("ALERTS_EMAIL"), 404, templateKeys);
                }
                else
                {
                    SendMail(txtMessage.Text);
                    ListingOffers offer = new ListingOffers();
                    offer.AddNew();
                    offer.ListingID = Web.RecordID;
                    offer.OfferDate = DateTime.Now;
                    offer.OfferBy = Web.SessionMembers.MemberID;
                    offer.OfferStatusID = 100;
                    offer.s_ArrangePickup = "0";
                    offer.OfferValidFor = 30;
                    offer.AdditionalTerms = Server.HtmlEncode(txtMessage.Text);
                    offer.ShippingPrice = 0;
                    offer.TotalPrice = 0;
                    offer.OfferPrice = 0;
                    offer.Quantity = 0;
                    offer.IsBuyEntireListing = 1;
                    offer.ListingTypeID = listing.ListingTypeID;
                    offer.Save();


                    if (fupDocument.UploadedFiles.Count > 0)
                    {
                        // Save file to physical path
                        string targetFolder = Web.SystemConfigs.GetKey("ATTACHMENTS_PHYSICAL_PATH");
                        string folderVirtualPath = Web.SystemConfigs.GetKey("ATTACHMENTS_PATH");
                        string fileName = offer.ListingOfferID + "_" + (int)SystemObjects.Listing_Offers + fupDocument.UploadedFiles[0].GetExtension();
                        string targetFileURL = System.IO.Path.Combine(targetFolder, fileName);
                        string virtualURL = System.IO.Path.Combine(folderVirtualPath, fileName);

                        while (System.IO.File.Exists(targetFileURL))
                        {
                            targetFileURL = System.IO.Path.Combine(targetFolder, fileName);
                        }

                        fupDocument.UploadedFiles[0].SaveAs(targetFileURL);

                        SystemObjectFiles objfile = new SystemObjectFiles();
                        objfile.AddNew();
                        objfile.FileDate = DateTime.Now;
                        objfile.FileTypeID = (int)FileTypes.FileURL;
                        objfile.s_IsActive = "1";
                        objfile.ObjectID = offer.ListingOfferID;
                        objfile.s_FileName = fupDocument.UploadedFiles[0].FileName;
                        objfile.SystemObjectID = (int)SystemObjects.Listing_Offers;
                        objfile.RemoteIP = System.Web.HttpContext.Current.Request.UserHostAddress;
                        objfile.FileFormat = fupDocument.UploadedFiles[0].GetExtension();
                        objfile.MemberID = Web.SessionMembers.MemberID;
                        objfile.PrivacyTypeID = 5;
                        objfile.URL = virtualURL;
                        objfile.Save();
                    }
                }
                txtMessage.Text = "";
                //}
                //else
                //  ShowMessage("Please refresh the page and try again.");
            }
            Web.Redirect("/Live.aspx");
        } 
        catch (Exception ex)
        {
            throw ex;
        }
    }

    protected void SendMail(string email)
    {
        try
        {
            var listing = new Listings();
            listing.LoadByPrimaryKey(Web.RecordID);
            if (listing.RowCount > 0)
            {
                var member = new Members();
                member.Where.MemberID.Value = listing.MemberID;
                if (member.Query.Load())
                {
                    string bcc = (chkBCCEmailToMe.Checked) ? Web.SessionMembers.Email : "";
                    string subject = s_lblMemberName + " has made an offer on your listing \"" + s_lblLotName2 + "\" at eOpen.com";
                    Web.SendMail(member.Email, Web.SystemConfigs.GetKey("ALERTS_EMAIL"), txtMessage.Text, subject, fupDocument, bcc);

                    Session["Message"] = "Offer has been submitted successfully";
                    ScriptManager.RegisterStartupScript(this.Page, typeof(Page), "CloseAndRebind", "CloseAndRebind();", true);
                }
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
            ShowMessage("Please refresh the page and try again.");
        }
    }

    private void ShowMessage(string message)
    {
        string messageScript = "showMessage('" + message + "');";
        ScriptManager.RegisterStartupScript(this.Page, typeof(Page), "ShowMessageScript", messageScript, true);
    }

    private void ShowSuccessMessage(string message)
    {
        string messageScript = "showSuccessMessage('" + message + "');";
        ScriptManager.RegisterStartupScript(this.Page, typeof(Page), "ShowSuccessMessageScript", messageScript, true);
    }

    private void DisableButton()
    {
        string disableButtonScript = "disableButton('" + btnSend.ClientID + "');";
        ScriptManager.RegisterStartupScript(this.Page, typeof(Page), "DisableButtonScript", disableButtonScript, true);
    }
}