﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CodenameRabbitFoot.BusinessLogic;
using System.Data;
using System.Xml;

public partial class PublicSite_MarketPlace_ItemDescription : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (Web.RecordID > 0)
            {
                var xdoc = new XmlDocument();
                string xml = null;
                XmlNodeList _nodelist;

                Listings listing = new CodenameRabbitFoot.BusinessLogic.Listings();
                listing.LoadByPrimaryKey(Web.RecordID);
                if (listing.RowCount > 0)
                {
                    List<int> categoryFields = CategoryFields.GetCategoryFields(listing.ListingTypeID, listing.CategoryID);
                    DataTable result = Listings.GetListingDetails(Web.RecordID);
                    foreach (DataRow row in result.Rows)
                    {
                        xml = row["ListingData"].ToString();
                        if (!String.IsNullOrEmpty(xml))
                        {
                            xdoc.LoadXml("<listings>" + xml + "</listings>");
                            _nodelist = xdoc.SelectNodes("listings/ListingData");
                            if (_nodelist.Count > 0)
                            {
                                foreach (XmlNode node in _nodelist)
                                {
                                    if (node.Attributes.Item(0).Value == "3")
                                    {
                                        lblDescription.Text += node.Attributes.Item(2).Value + "<br/>";
                                        continue;
                                    }
                                    else if (node.Attributes.Item(0).Value == "5")
                                    {
                                        lblDescription.Text += node.Attributes.Item(2).Value + "<br/>";
                                        continue;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }
}