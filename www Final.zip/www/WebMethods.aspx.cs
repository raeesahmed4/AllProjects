﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Services;
using CodenameRabbitFoot.BusinessLogic;
using System.Web.Script.Services;
using System.Data;
using System.Text;
using System.Collections.Specialized;
using System.Xml;


public partial class WebMethods : System.Web.UI.Page
{

    //   Alert Div Data
    [WebMethod(EnableSession = true)]
    public static string UpdateBillboardText(string newBillboard)
    {
        newBillboard = newBillboard.Replace("^", "'");
        string msg = "";
        try
        {
            MemberActivityLog.UpdateBillboard(Web.SessionMembers.MemberID, newBillboard);

        }
        catch (Exception ex)
        {
            Web.LogError(ex);
            msg = "error";
        }
        return msg;
    }

    [WebMethod]
    public static JQGrid LoadPendingclients(int pageIndex, int pageSize)
    {

        JQGrid jqGrid = new JQGrid();
        if (!Web.IsMemberSession)
        {
            jqGrid.status = "login";
        }
        else
        {

            DataSet ds = Fx.ExecuteSp("EN_PpendingClientVandors", Web.SessionMembers.MemberID);



            IEnumerable<DataRow> allRows = ds.Tables[0].Select();
            jqGrid.total = allRows.Count() == pageSize ? 1 : (allRows.Count() / pageSize) + 1;
            jqGrid.records = pageSize;
            jqGrid.page = pageIndex;
            IEnumerable<DataRow> selectedRows = allRows.Skip((pageIndex - 1) * pageSize).Take(pageSize);
            if (selectedRows.Count() == 0)
            {
                JQGrid.Row row = new JQGrid.Row();
                row.id = 0;
                row.cell.Add("0");
                row.cell.Add("<td style='width:300xp;'><div style='text-align:left; padding:5px; width:400px;'>No records exists.</div></td>");
                jqGrid.rows.Add(row);
                jqGrid.status = "empty";
            }

            foreach (DataRow obj in selectedRows)
            {

                JQGrid.Row row = new JQGrid.Row();
                row.cell.Add(obj["MemberID"].ToString());
                string LogoHtml = string.Format("<div style='padding:5px 0px 5px 0px; margin:0px 0px 0px 5px;' ><a  href='/Contacts/ViewProfile.aspx?Action=ViewDealer&RecordID={0}'><img style='border:5px solid #F1F6F6;' alt='' height='40px' width='40px' src='/ePage/ImageViewer.ashx?Action=MembersLogoThumbnail&amp&RecordID={0}'/></a></div>", Secure.Encrypt(obj["MemberID"].ToString()));
                row.cell.Add(LogoHtml);
                //string namehtml = string.Format("<a href='/Contacts/ViewProfile.aspx?Action=ViewDealer&RecordID={0}'>{1}</a>", Secure.Encrypt(obj["MemberID"].ToString()), obj["UserName"].ToString());
                //row.cell.Add(namehtml);
                row.cell.Add(obj["FullName"].ToString());
                string pendingstg = string.Format("<div style='color:#6495ED;'>Pending..</div>");
                row.cell.Add(pendingstg);
                jqGrid.rows.Add(row);

            }
        }
        return jqGrid;

    }


    //  End Alert Div Dat


     

    [WebMethod(EnableSession = true)]
    public static string SaveExtendedFieldValues(string listingID, string title, string quantity, string price, string description, string makeOffer)
    {
        try
        {
            object mutex = new object();

            lock (mutex)
            {
                List<ExhibitItem> items = HttpContext.Current.Session["UploadedImageFiles"] as List<ExhibitItem>;

                foreach (var item in items)
                {
                    if (item.id.Equals(listingID))
                    {
                        item.title = title;
                        item.quantity = quantity;
                        item.price = price;
                        item.description = description;
                        item.offer = makeOffer;
                    }
                }

                HttpContext.Current.Session["UploadedImageFiles"] = items;
            }
        }
        catch(Exception exp)
        {
            Web.LogError(exp);
        }
        return "";
        //// Title=20        
        //ListingExtendedFields.UpdateListingExtendedFieldData(int.Parse(listingID), 20, title);
        //// Quantity=4
        //ListingExtendedFields.UpdateListingExtendedFieldData(int.Parse(listingID), 4, quantity);
        //// Price=9
        //ListingExtendedFields.UpdateListingExtendedFieldData(int.Parse(listingID), 9, price);
        //// Description=3
        //ListingExtendedFields.UpdateListingExtendedFieldData(int.Parse(listingID), 3, description);
        //// Make Offer=24
        //ListingExtendedFields.UpdateListingExtendedFieldData(int.Parse(listingID), 24, makeOffer);

    }


    #region Live.aspx/ LiveFeed

    [WebMethod(EnableSession = true)]
    public static string LoadPostTypes()
    {
        StringBuilder outputHtml = new StringBuilder();

        outputHtml.Append("<OPTION value=0>-- Choose Post Type --</OPTION>");
        outputHtml.AppendLine();

        DataTable postingTypes = PostingTypes.GetPostingTypes();

        if (postingTypes != null)

            foreach (DataRow row in postingTypes.Rows)
            {
                //if (row["ParentCategory"].ToString() == "0")
                //{
                outputHtml.Append(string.Format("<OPTION value={0}>{1}</OPTION>", row["PostTypeID"], row["PostTypeName"]));
                outputHtml.AppendLine();
                //}
            }

        return outputHtml.ToString();
    }

    // To be merged with common...... Optimize :)
    [WebMethod(EnableSession = true)]
    public static string LoadCategories()//int postTypeID)
    {
        StringBuilder outputHtml = new StringBuilder();

        outputHtml.Append("<OPTION value=0>-- Choose Category --</OPTION>");
        outputHtml.AppendLine();

        DataTable categories = Web.Categories.DefaultView.Table;// CategorizedPostingTypes.GetCategorizedPostingTypes(postTypeID, Web.SessionMembers.MemberID);

        if (categories != null)
        {
            foreach (DataRow row in categories.Rows)
            {
                outputHtml.Append(string.Format("<OPTION value={0}>{1}</OPTION>", row["CategoryID"], row["CategoryName"]));
                outputHtml.AppendLine();
            }
        }

        return outputHtml.ToString();
    }

    #endregion

    #region Common Web Methods

    //[Done]
    [WebMethod(EnableSession = true)]
    public static string GetContactCount(string contactType)
    {
        if (Web.IsMemberSession)
        {
            if (contactType.ToLower() == "clients")
            {
                return Counters.GetCount(CountTypes.Clients_All, Web.SessionMembers.MemberID).ToString();
            }
            else
                if (contactType.ToLower() == "vendors")
                {
                    return Counters.GetCount(CountTypes.Vendors_All, Web.SessionMembers.MemberID).ToString();
                }
                else
                    if (contactType.ToLower() == "linkstome")
                    {
                        return Counters.GetCount(CountTypes.Linkings_To_Me_Total, Web.SessionMembers.MemberID).ToString();
                    }
                    else
                        if (contactType.ToLower() == "mylinkings")
                        {
                            return Counters.GetCount(CountTypes.Linkings_Total, Web.SessionMembers.MemberID).ToString();
                        }
        }
        return "0";
    }

    //[Done]
    [WebMethod(EnableSession = true)]
    public static string PerformContactAction(string encryptedMemberID, string actionType)
    {
        int contacMemberID = Convert.ToInt32(Secure.Decrypt(encryptedMemberID));
        actionType = actionType.ToLower();
        Contacts contact = null;

        if (actionType.Equals("delete"))
        {
            Contacts.DeleteContact(Web.SessionMembers.MemberID, contacMemberID);
        }
        else
            if (actionType.Equals("deleteinvitation"))
            {
                Invitations invitaion = new Invitations();
                invitaion.LoadByPrimaryKey(contacMemberID);
                if (invitaion.RowCount > 0)
                {
                    invitaion.MarkAsDeleted();
                    invitaion.Save();
                }
                // Contacts.DeleteContact(Web.SessionMembers.MemberID, contacMemberID);
            }
            else
                if (actionType.Equals("makeprivate"))
                {
                    contact = Contacts.LoadContact(Web.SessionMembers.MemberID, contacMemberID);
                    contact.ContactAccessibilityID = 2;
                    contact.Save();

                }
                else
                    if (actionType.Equals("makepublic"))
                    {
                        contact = Contacts.LoadContact(Web.SessionMembers.MemberID, contacMemberID);
                        contact.ContactAccessibilityID = 1;
                        contact.Save();
                    }
                    else
                        if (actionType.Equals("approve"))
                        {
                            //contact = Contacts.LoadContact(Web.SessionMembers.MemberID, contacMemberID);
                            // AcceptContact(contact.ContactID);
                            int contactID = Convert.ToInt32(contacMemberID);
                            AcceptContact(contactID);
                            //contact.Save();
                        }
                        else
                            if (actionType.Equals("decline"))
                            {
                                //contact = Contacts.LoadContact(Web.SessionMembers.MemberID, contacMemberID);
                                //DeclineContact(contact.ContactID);
                                int contactID = Convert.ToInt32(contacMemberID);
                                DeclineContact(contactID);
                                //contact.Save();
                            }
                            else
                                if (actionType.Equals("link"))
                                {
                                    Web.Link(contacMemberID);
                                }
                                else
                                    if (actionType.Equals("unlink"))
                                    {
                                        MembersWatchListDealers.Unlink(Web.SessionMembers.MemberID, contacMemberID);
                                    }
                                    else
                                        if (actionType.Equals("removefromwatchlist"))
                                        {
                                            MembersWatchListDealers.Unlink(Web.SessionMembers.MemberID, contacMemberID);
                                        }
                                        else
                                            if (actionType.Equals("removelinktome"))
                                            {
                                                MembersWatchListDealers dealers = new MembersWatchListDealers();
                                                dealers.Where.DealerID.Value = Web.SessionMembers.MemberID;
                                                dealers.Where.MemberID.Value = contacMemberID;
                                                dealers.Query.Load();
                                                if (dealers.RowCount > 0)
                                                {
                                                    dealers.MarkAsDeleted();
                                                    dealers.Save();
                                                }
                                            }
                                            else
                                                if (actionType.Equals("deletecontactlistitem"))
                                                {
                                                    MemberContactList contactListItem = new MemberContactList();
                                                    contactListItem.Where.MemberContactListID.Value = contacMemberID;
                                                    contactListItem.Query.Load();
                                                    if (contactListItem.RowCount > 0)
                                                    {
                                                        contactListItem.MarkAsDeleted();
                                                        contactListItem.Save();
                                                    }
                                                }

        return "success";
    }

    private static string DeclineContact(int ContactID)
    {
        try
        {
            Contacts contact = new Contacts();
            contact.LoadByPrimaryKey(ContactID);
            if (contact.RowCount > 0)
            {
                Invitations invitation = Contacts.DeclineContactRequest(contact.InvitationID, contact.ContactMemberID);

                var templateKeys = new System.Collections.Specialized.StringDictionary();
                Members member = new Members();
                member.LoadByPrimaryKey(invitation.InvitedBy);
                templateKeys.Add("#type#", Web.GetContactType(invitation.ContactType));
                templateKeys.Add("#profile_name#", Web.SessionMembers.UserName);
                templateKeys.Add("#company_name#", Web.SessionMembers.CompanyName + ": " + Web.SessionMembers.FullName);
                templateKeys.Add("#fullname#", member.FullName);
                templateKeys.Add("#email_header#", Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER"));
                templateKeys.Add("#email_footer#", Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER"));
                templateKeys.Add("#link_log_myeoffer#", Web.SystemConfigs.GetKey("SITE_URL"));
                Web.SendMail(member.Email, Web.SystemConfigs.GetKey("CONTACT_EMAIL"), 402, templateKeys);
                return "You have declined <span style=\"" + Web.GetProfileClass(member.MemberID, Web.SessionMembers.MemberID) + "\">" + member.UserName + "'s</span> contact request.";
            }
        }
        catch (Exception ex)
        {

            //Log.Write("Error:000", ex.GetBaseException().ToString(), ex);
            Web.LogError(ex);
        }
        return "";
    }

    private static string AcceptContact(int ContactID)
    {
        try
        {
            Contacts contacts = new Contacts();
            contacts.LoadByPrimaryKey(ContactID);
            if (contacts.ContactStatusID == 2)
            {
                Contacts contact = Contacts.AcceptContactRequest(contacts.InvitationID, contacts.ContactMemberID);

                System.Collections.Specialized.StringDictionary templateKeys = new System.Collections.Specialized.StringDictionary();
                MemberTrustScore.TrustMemberScore(contact.MemberID, Web.SessionMembers.MemberID, "Added as a " + Web.GetContactTypeInverse(contact.ContactType), ((contact.ContactType == 2) ? RatingTypes.Added_As_Client : RatingTypes.Added_As_Vendor), contact.ContactID);

                Members member = new Members();
                member.LoadByPrimaryKey(contact.MemberID);
                templateKeys = new System.Collections.Specialized.StringDictionary();
                templateKeys.Add("#type#", Web.GetContactType(contact.ContactType));
                templateKeys.Add("#initiatedto#", "#memberid#" + contact.ContactMemberID + "#endmemberid#");
                templateKeys.Add("#profileclass#", "#profileclass#" + contact.ContactMemberID + "#endprofileclass#");
                templateKeys.Add("#initiatedtoprofile#", "/Contacts/ViewProfile.aspx?Action=ViewDealer&RecordID=#encrypt#" + contact.ContactMemberID + "#endencrypt#");

                if (contact.ContactAccessibilityID == 1)
                    Web.AddActivityLog(contact.MemberID, 18, templateKeys, contact.ContactMemberID, contact.ContactMemberID);
                else
                    Web.AddPrivateActivityLog(contact.MemberID, 18, templateKeys, contact.MemberID, contact.ContactMemberID, contact.ContactMemberID);
                MemberTrustScore.TrustMemberScoreOne(Web.SessionMembers.MemberID, member.MemberID, "Added as a " + (ContactTypes)contact.ContactType, (RatingTypes)contact.ContactType, contact.ContactID);

                templateKeys = new StringDictionary();
                templateKeys.Add("#company_name#", Web.SessionMembers.CompanyName);
                templateKeys.Add("#fullname#", member.FullName);
                templateKeys.Add("#email_header#", Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER"));
                templateKeys.Add("#email_footer#", Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER"));
                templateKeys.Add("#contactnetwork#", Web.SystemConfigs.GetKey("SITE_URL") + "Contacts/Default.aspx");
                templateKeys.Add("#livefeed#", Web.SystemConfigs.GetKey("SITE_URL") + "Live.aspx");
                templateKeys.Add("#dealingfloor#", Web.SystemConfigs.GetKey("SITE_URL") + "MarketPlace/Default.aspx");
                templateKeys.Add("#type#", Web.GetContactTypeInverse(contact.ContactType));
                templateKeys.Add("#name_request_approver#", Web.SessionMembers.FullName);
                templateKeys.Add("#company_request_approver#", Web.SessionMembers.CompanyName);
                templateKeys.Add("#link_profile_name#", Web.SystemConfigs.GetKey("SITE_URL") + "Contacts/ViewProfile.aspx?Action=ViewDealer&RecordID=" + Secure.Encrypt(Web.SessionMembers.MemberID));
                templateKeys.Add("#profile_name#", Web.SessionMembers.UserName);
                Web.SendMail(member.Email, Web.SystemConfigs.GetKey("CONTACT_EMAIL"), 401, templateKeys);
                return "You have accepted <span style=\"color:rgb(236, 105, 40);\">" + member.UserName + "'s</span> contact request.";
            }
        }
        catch (Exception ex)
        {
            //Log.Write("Error", ex.GetBaseException().ToString(), ex);
            Web.LogError(ex);
        }
        return "";
    }

    [WebMethod(EnableSession = true)]
    public static string LoadCountriesDropDownItems()
    {
        StringBuilder outputHtml = new StringBuilder();

        outputHtml.Append("<OPTION value=0>All</OPTION>");
        outputHtml.AppendLine();
        DataTable dt = CodenameRabbitFoot.BusinessLogic.Country.GetCountries();
        foreach (DataRow row in dt.Rows)
        {
            outputHtml.Append(string.Format("<OPTION value={0}>{1}</OPTION>", row["CountryID"], row["CountryName"]));
            outputHtml.AppendLine();
        }

        return outputHtml.ToString();
    }

    [WebMethod(EnableSession = true)]
    public static string LoadCategoriesDropDownItems()
    {
        StringBuilder outputHtml = new StringBuilder();

        outputHtml.Append("<OPTION value=0>All</OPTION>");
        outputHtml.AppendLine();

        Categories categories = Web.Categories;

        if (categories != null)
            if (categories.RowCount > 0)
            {
                foreach (DataRow row in categories.DefaultView.Table.Rows)
                {
                    if (row["ParentCategory"].ToString() == "0")
                    {
                        outputHtml.Append(string.Format("<OPTION value={0}>{1}</OPTION>", row["CategoryID"], row["CategoryName"]));
                        outputHtml.AppendLine();
                    }
                }
            }
        return outputHtml.ToString();
    }

    [WebMethod(EnableSession = true)]
    public static string LoadCategoriesDropDownItems(string postTypeID)
    {
        if (Web.IsMemberSession)
        {
            if (string.IsNullOrWhiteSpace(postTypeID))
                return string.Empty;

            int typeID = 0;
            if (postTypeID.StartsWith("L_"))
            {
                typeID = Convert.ToInt32(postTypeID.Remove(0, 2));
            }
            else
            {
                typeID = Convert.ToInt32(postTypeID);
            }

            StringBuilder outputHtml = new StringBuilder();
            int cycle = 0;
            outputHtml.Append("<OPTION value=0>All</OPTION>");
            outputHtml.AppendLine();

            DataSet dsCategories = CategorizedPostingTypes.GetCategorizedPostingTypes(typeID, Web.SessionMembers.MemberID); // Web.Categories;

            foreach (DataTable dt in dsCategories.Tables)
            {
                foreach (DataRow row in dt.Rows)
                {
                    outputHtml.Append(string.Format("<OPTION value={0}>{1}</OPTION>", row["CategoryID"], row["CategoryName"]));
                    outputHtml.AppendLine();
                }
                if (cycle == 0)
                {
                    outputHtml.Append(string.Format("<OPTION value={0}>======================</OPTION>", 50000000 + cycle));
                    outputHtml.AppendLine();
                }
                cycle++;
            }

            return outputHtml.ToString();

        }
        else
            return "";
        /*
          DataSet dsCats = new DataSet();
        dsCats = CategorizedPostingTypes.GetCategorizedPostingTypes(PostTypeID, Web.SessionMembers.MemberID);
        foreach (DataTable dt in dsCats.Tables)
        {
            foreach (DataRow dr in dt.Rows)
            {
                ddlCategory.Items.Add(new RadComboBoxItem(dr["CategoryName"].ToString(), dr["CategoryID"].ToString()));
            }
            if (cycle == 0)
            {
                RadComboBoxItem item = new RadComboBoxItem("======================", "50000000");
                item.Enabled = false;
                ddlCategory.Items.Add(item);
            }
            cycle++;
        }
        ddlCategory.Items.Insert(0, new RadComboBoxItem("...Choose a Category...", "-1"));
        ddlCategory.DataBind();
         
         */
    }

    [WebMethod(EnableSession = true)]
    public static string BindMemberContactListDropDown()
    {
        StringBuilder outputHtml = new StringBuilder();

        outputHtml.Append("<OPTION value=0>--Select--</OPTION>");
        outputHtml.AppendLine();

        // Data fetching logic

        MemberContactList mList = new MemberContactList();
        mList.Where.MemberID.Value = Web.SessionMembers.MemberID;
        mList.Query.AddResultColumn(MemberContactListSchema.BatchNumber);
        mList.Query.AddResultColumn(MemberContactListSchema.ContactListName);
        mList.Query.Distinct = true;
        mList.Query.AddOrderBy(MemberContactListSchema.ContactListName);
        mList.Query.Load();

        if (mList != null)
        {
            if (mList.RowCount > 0)
            {
                foreach (DataRow row in mList.DefaultView.Table.Rows)
                {
                    outputHtml.Append(string.Format("<OPTION value={0}>{1}</OPTION>", row["BatchNumber"], row["ContactListName"]));
                    outputHtml.AppendLine();
                }
            }
        }
        return outputHtml.ToString();
    }


    [WebMethod(EnableSession = true)]
    public static string OnBlock(int recordID, string reason)
    {
        try
        {
            bool result = AbuseList.ReportAbuse(recordID, Web.SessionMembers.MemberID, reason, HttpContext.Current.Request.UserHostAddress);
        }
        catch (Exception ex) { Web.LogError(ex); }

        return "success";
    }

    [WebMethod(EnableSession = true)]
    public static string LoadBillBoard(string recordID)
    {
        string result = string.Empty;

        try
        {
            int intRecordID = 0;

            if (string.IsNullOrEmpty(recordID))
            {
                recordID = Web.SessionMembers.MemberID.ToString();
            }
            else
                if (int.TryParse(recordID, out intRecordID))
                {
                    recordID = intRecordID.ToString();
                }
                else
                {
                    recordID = Secure.Decrypt(recordID);
                }

            MembersModuleSubscriptions mms = new MembersModuleSubscriptions();
            mms.Where.MemberID.Value = recordID;
            mms.Where.ModuleID.Conjunction = NCI.EasyObjects.WhereParameter.Conj.And;
            mms.Where.ModuleID.Value = 10;
            mms.Query.Load();

            if (mms.RowCount > 0)
            {
                DataTable billBoard = MemberActivityLog.LoadBillboard(Convert.ToInt32(recordID));
                if (billBoard.Rows.Count > 0)
                    result = billBoard.Rows[0]["Description"].ToString();
            } 
           
        }
        catch (Exception ex) { Web.LogError(ex); }

        return result;
    }

    [WebMethod(EnableSession = true)]
    public static string LoadCompanyName(string recordID)
    {
        string result = string.Empty;

        try
        {
            int intRecordID = 0;

            if (recordID == null)
            {
                recordID = Web.SessionMembers.MemberID.ToString();
            }
            else
                if (int.TryParse(recordID, out intRecordID))
                {
                    recordID = intRecordID.ToString();
                }
                else
                {
                    recordID = Secure.Decrypt(recordID);
                }

            Members member = new Members();
            member.Where.MemberID.Value = recordID;
            member.Query.Load();
            result = member.CompanyName;

        }
        catch (Exception ex) { Web.LogError(ex); }

        return result;
    }

    [WebMethod(EnableSession = true)]
    public static string GetNewActivitiesCount()
    {
        int count = 0;
        try
        {
            if (Web.IsMemberSession)
            {
                count += Counters.GetCount(CountTypes.Clients_Pending_MyApproval, Web.SessionMembers.MemberID);
                count += Counters.GetCount(CountTypes.Vendors_Pending_MyApproval, Web.SessionMembers.MemberID);
                count += Counters.GetCount(CountTypes.Clients_Waiting_ToApproveMe, Web.SessionMembers.MemberID);
                count += Counters.GetCount(CountTypes.Vendors_Waiting_ToApproveMe, Web.SessionMembers.MemberID);
                count += Counters.GetCount(CountTypes.New_Messages, Web.SessionMembers.MemberID);
                count += Counters.GetCount(CountTypes.Offers_To_Buy_My_Entire_Lot, Web.SessionMembers.MemberID) > 0 ? Counters.GetCount(CountTypes.Offers_To_Buy_My_Entire_Lot, Web.SessionMembers.MemberID) : 0;
                count += Counters.GetCount(CountTypes.Offers_On_My_Selected_Items, Web.SessionMembers.MemberID) > 0 ? Counters.GetCount(CountTypes.Offers_On_My_Selected_Items, Web.SessionMembers.MemberID) : 0;
                //count += Counters.GetCount(CountTypes.Offers_On_My_Selected_Items, Web.SessionMembers.MemberID) > 0 ? Counters.GetCount(CountTypes.Offers_On_My_Selected_Items, Web.SessionMembers.MemberID) : 0;
                count += Counters.GetCount(CountTypes.Offers_On_My_Listings, Web.SessionMembers.MemberID) > 0 ? Counters.GetCount(CountTypes.Offers_On_My_Listings, Web.SessionMembers.MemberID) : 0;
                
                //if (Web.SessionMembers.s_IsDealerProfileUpdate == "0")
                //count++;
            }
        }
        catch (Exception ex)
        { Web.LogError(ex); throw ex; }
        return count.ToString();
    }


    #endregion



    #region Login and Authentication

    [WebMethod]
    public static string CheckUserName(string userName)
    {
        userName = userName.Trim();
        string configs = Web.SystemConfigs.GetKey("RESERVE_WORDS");
        if (!String.IsNullOrEmpty(configs))
        {
            string[] values = configs.Split(',');
            foreach (string str in values)
                if (userName == str)
                    return "<font color='#cc0000'><b>" + userName + "</b> is not valid.</font>";
        }

        Members members = new Members();
        members.Where.UserName.Value = userName;
        if (members.Query.Load())
            return "<font color='#cc0000'><b>" + userName + "</b> is already in use.</font>";
        else
            return "OK";
    }


    [WebMethod]
    public static string AuthenticateUser(string userName, string userPass, bool chkKeepSignedIn, bool chkRememberMe, string currentPageUrl)
    {
        //System.Threading.Thread.Sleep(10000);
        Members members = new Members();
        userName = userName.Trim();
        userPass = userPass.Trim();

        string redirectURL = "";
        string secureUserEmail = Web.IsEmailAddress(userName) ? userName : "";

        if (Web.IsEmailAddress(userName))
            members.Where.Email.Value = userName;
        else
            members.Where.UserName.Value = userName;

        redirectURL = Web.AuthenticateUser(userName, userPass, chkKeepSignedIn, chkRememberMe, true, currentPageUrl);
        if (redirectURL == "")
            return "ERROR`Email is not registered";
        else
            return "OK`" + Web.RedirectURL;
    }

    [WebMethod]
    public static string RegisterUser(string userName, string userEmail, string userCompany, string userFirstName, string userLastname, string userPassword, string userPostalCode, string userCountryID)
    {
        userName = userName.Trim();
        userEmail = userEmail.Trim();
        userCompany = userCompany.Trim();
        userFirstName = userFirstName.Trim();
        userLastname = userLastname.Trim();
        userPostalCode = userPostalCode.Trim();
        userPassword = userPassword.Trim();

        string companyName = userCompany;
        if (companyName.Contains("Leave blank") || companyName == "")
            companyName = userFirstName + " " + userLastname.Substring(0, 1) + " Company";
        string errorMessage;

        try
        {
            Random rand = new Random();
            Members newMember = new Members();

            //check if email exists
            Members member = new Members();
            member.Where.Email.Value = userEmail;
            member.Query.Load();
            if (member.RowCount < 1)
            {
                bool isvalidusername = true;
                //check if username exists
                SystemConfigKeys configs = new SystemConfigKeys();
                configs.Where.ConfigKey.Value = "RESERVE_WORDS";
                configs.Query.Load();
                if (configs.RowCount > 0)
                {
                    string[] values = configs.Value.Split(',');
                    foreach (string str in values)
                        if (userName == str)
                            isvalidusername = false;
                }
                if (isvalidusername)
                {
                    member = new Members();
                    member.Where.UserName.Value = userName;
                    member.Query.Load();
                    if (member.RowCount < 1)
                    {
                        newMember.AddNew();
                        newMember.Email = userEmail;
                        newMember.CompanyName = userCompany;
                        newMember.FullName = userFirstName + " " + userLastname;
                        newMember.UserName = userName;
                        newMember.Password = userPassword;  //rand.Next(9999).ToString(); //txtPass.Text; 
                        newMember.RequestsToAddContacts = 0;
                        newMember.IsDealerProfileUpdate = 0;
                        newMember.MemberStatusID = 102;
                        newMember.RegistrationCode = Web.CalculateRegCode();
                        newMember.LastProfileUpdate = DateTime.Today;
                        newMember.Save();
                        Web.WriteMemberStatusChangeLog(newMember.MemberID, newMember.MemberStatusID, "System");

                        ShippingAddresses address = new ShippingAddresses();
                        address.Where.MemberID.Value = newMember.MemberID;
                        address.Query.Load();
                        if (address.RowCount <= 0)
                            address.AddNew();
                        address.City = "";//txtCity.Text;
                        address.State = "";//txtState.Text;
                        address.Zip = userPostalCode;
                        address.s_CountryID = userCountryID;
                        address.MemberID = newMember.MemberID;
                        address.Save();

                        //txtEmailActivate.Text = newMember.Email;
                        if (newMember.s_MemberID != null)
                        {
                            StringDictionary templateKeys = new StringDictionary();
                            try
                            {
                                templateKeys.Add("#email_header#", Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER"));
                                templateKeys.Add("#fullname#", (!String.IsNullOrEmpty(newMember.FullName)) ? newMember.FullName : newMember.Email);
                                templateKeys.Add("#email_address#", newMember.Email);
                                templateKeys.Add("#activation_link#", Web.SystemConfigs.GetKey("SITE_URL") + "Account/Verify.aspx?rand=" + rand.Next() + "&Action=Activate&code=" + newMember.RegistrationCode + "&RecordID=" + Secure.Encrypt(newMember.s_MemberID) + "&sid=" + newMember.SurrogateID);
                                templateKeys.Add("#code#", newMember.RegistrationCode);
                                templateKeys.Add("#link#", Web.SystemConfigs.GetKey("SITE_URL") + "Account/Verify.aspx?Action=Activate&RecordID=" + Secure.Encrypt(newMember.s_MemberID) + "&sid=" + newMember.SurrogateID);
                                templateKeys.Add("#site_url#", Web.SystemConfigs.GetKey("SITE_URL"));
                                templateKeys.Add("#email_footer#", Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER"));

                                Web.SendMail(newMember.Email, Web.SystemConfigs.GetKey("REG_EMAIL"), 002, templateKeys);
                            }
                            catch (Exception ex)
                            {
                                Web.LogError(ex);
                            }
                        }
                        else
                        {
                            errorMessage = "Please try again.";
                            return "ERROR`" + errorMessage;
                        }
                    }
                    else
                    {
                        //this.Master.ShowMessage("Username already exists.", "simpleerr"); 
                        errorMessage = "Username already exists.";
                        return "ERROR`" + errorMessage;
                    }
                }
                else
                {
                    errorMessage = "Username is invalid.";
                    return "ERROR`" + errorMessage;
                }
            }
            else
            {
                return "ERROR`Email Address is already registered";
            }
        }
        catch (Exception exp)
        {
            Web.LogError(exp);

            return "ERROR";
        }

        return "OK`" + "~/Account/Verify.aspx?Action=Activate&Email=" + Secure.Encrypt(userEmail);
    }

    [WebMethod(EnableSession = true)]
    public static string RegisterUserWithSession(string userName, string userEmail, string userCompany, string userFirstName, string userLastname, string userPassword, string userPostalCode, string userCountryID, string invitationID)
    {
        int orignalInvitaionID = 0;

        if (!int.TryParse(invitationID, out orignalInvitaionID))
        {
            try
            {
                orignalInvitaionID = Convert.ToInt32(Secure.Decrypt(invitationID));
            }
            catch { }
        }

        userName = userName.Trim();
        userEmail = userEmail.Trim();
        userCompany = userCompany.Trim();
        userFirstName = userFirstName.Trim();
        userLastname = userLastname.Trim();
        userPostalCode = userPostalCode.Trim();
        userPassword = userPassword.Trim();

        string companyName = userCompany;
        if (companyName.Contains("Leave blank") || companyName == "")
            companyName = userFirstName + " " + userLastname.Substring(0, 1) + " Company";
        string errorMessage;

        try
        {
            Random rand = new Random();
            Members newMember = new Members();


            //check if email exists
            Members member = new Members();
            member.Where.Email.Value = userEmail;
            member.Query.Load();
            if (member.RowCount < 1)
            {
                bool isvalidusername = true;
                //check if username exists
                SystemConfigKeys configs = new SystemConfigKeys();
                configs.Where.ConfigKey.Value = "RESERVE_WORDS";
                configs.Query.Load();
                if (configs.RowCount > 0)
                {
                    string[] values = configs.Value.Split(',');
                    foreach (string str in values)
                        if (userName == str)
                            isvalidusername = false;
                }
                if (isvalidusername)
                {
                    member = new Members();
                    member.Where.UserName.Value = userName;
                    member.Query.Load();
                    if (member.RowCount < 1)
                    {
                        newMember.AddNew();
                        newMember.Email = userEmail;
                        newMember.CompanyName = userCompany;
                        newMember.FullName = userFirstName + " " + userLastname;
                        newMember.UserName = userName;
                        newMember.Password = userPassword;
                        //newMember.Password = rand.Next(9999).ToString(); //txtPass.Text; 
                        newMember.RequestsToAddContacts = 0;
                        newMember.IsDealerProfileUpdate = 0;

                        //if (string.IsNullOrEmpty(invitationID) || invitationID == "null")
                        if (orignalInvitaionID <= 0)
                        {
                            newMember.MemberStatusID = 102;
                            newMember.RegistrationCode = Web.CalculateRegCode();
                        }
                        else
                        {
                            newMember.MemberStatusID = 200;
                        }

                        newMember.LastProfileUpdate = DateTime.Today;
                        newMember.Save();
                        Web.WriteMemberStatusChangeLog(newMember.MemberID, newMember.MemberStatusID, "System");
                        Web.SessionMembers = newMember;
                        Web.AddActivityLog(1, new StringDictionary()); // ActivityID=1 for joined
                        Web.IsMemberSession = true;
                        ShippingAddresses address = new ShippingAddresses();
                        address.Where.MemberID.Value = newMember.MemberID;
                        address.Query.Load();
                        if (address.RowCount <= 0)
                            address.AddNew();

                        address.City = "";//txtCity.Text;
                        address.State = "";//txtState.Text;
                        address.Zip = userPostalCode;
                        address.s_CountryID = userCountryID;
                        address.MemberID = newMember.MemberID;
                        address.Save();

                        //if (!(string.IsNullOrEmpty(invitationID) || invitationID == "null"))
                        if (orignalInvitaionID > 0)
                        {
                            Contacts.AddToContact(newMember.MemberID, orignalInvitaionID);
                        }


                        //txtEmailActivate.Text = newMember.Email;
                        if (newMember.s_MemberID != null)
                        {

                            try
                            {
                                if (newMember.MemberStatusID != 200)// No verification email in case of coupons :)
                                {
                                    StringDictionary templateKeysVerify = new StringDictionary();
                                    templateKeysVerify.Add("#email_header#", Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER"));
                                    templateKeysVerify.Add("#fullname#", (!String.IsNullOrEmpty(newMember.FullName)) ? newMember.FullName : newMember.Email);
                                    templateKeysVerify.Add("#email_address#", newMember.Email);
                                    templateKeysVerify.Add("#activation_link#", Web.SystemConfigs.GetKey("SITE_URL") + "Account/Verify.aspx?rand=" + rand.Next() + "&Action=Activate&code=" + newMember.RegistrationCode + "&RecordID=" + Secure.Encrypt(newMember.s_MemberID) + "&sid=" + newMember.SurrogateID);
                                    templateKeysVerify.Add("#code#", newMember.RegistrationCode);
                                    templateKeysVerify.Add("#link#", Web.SystemConfigs.GetKey("SITE_URL") + "Account/Verify.aspx?Action=Activate&RecordID=" + Secure.Encrypt(newMember.s_MemberID) + "&sid=" + newMember.SurrogateID);
                                    templateKeysVerify.Add("#site_url#", Web.SystemConfigs.GetKey("SITE_URL"));
                                    templateKeysVerify.Add("#email_footer#", Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER"));

                                    Web.SendMail(newMember.Email, Web.SystemConfigs.GetKey("REG_EMAIL"), 002, templateKeysVerify);
                                }

                                StringDictionary templateKeysWelcome = new StringDictionary();
                                templateKeysWelcome.Add("#email_header#", Web.SystemConfigs.GetKey("HTML_EMAIL_HEADER"));
                                templateKeysWelcome.Add("#fullname#", (!String.IsNullOrEmpty(newMember.FullName)) ? newMember.FullName : newMember.Email);
                                templateKeysWelcome.Add("#email_footer#", Web.SystemConfigs.GetKey("HTML_EMAIL_FOOTER"));
                                templateKeysWelcome.Add("#password#", newMember.Password);
                                templateKeysWelcome.Add("#link_log_myeoffer#", Web.SystemConfigs.GetKey("SITE_URL") + "Post.aspx?Action=worldwide");
                                Web.SendMail(newMember.Email, Web.SystemConfigs.GetKey("REG_EMAIL"), 008, templateKeysWelcome);
                            }
                            catch (Exception ex)
                            {
                                Web.LogError(ex);
                            }
                        }
                        else
                        {
                            errorMessage = "Please try again.";
                            return "ERROR`" + errorMessage;
                        }
                    }
                    else
                    {
                        //this.Master.ShowMessage("Username already exists.", "simpleerr"); 
                        errorMessage = "Username already exists.";
                        return "ERROR`" + errorMessage;
                    }
                }
                else
                {
                    errorMessage = "Username is invalid.";
                    return "ERROR`" + errorMessage;
                }
            }
            else
            {
                return "ERROR`Email Address is already registered";

            }
        }
        catch (Exception exp)
        {
            Web.LogError(exp);

            return "ERROR";
        }

        return "success";
    }



    [WebMethod]
    public static string ReadCookie()
    {
        string cookie = "";
        try
        {
            if (HttpContext.Current.Request.Cookies["loginCookie"] != null)
            {
                HttpCookie eofferCookie = HttpContext.Current.Request.Cookies.Get("loginCookie");
                string pwd = null;
                string userlogin = null;

                if (eofferCookie.Values["login"] != null)
                    userlogin = Web.DecryptRijndaelManaged(eofferCookie.Values["login"]);

                if (eofferCookie.Values["rememberMe"] != null)
                    if (eofferCookie.Values["rememberMe"].ToString() == "True")
                        cookie = userlogin;

                //txtPass.Attributes["value"] = pwd; // eofferCookie.Values["password"];

                if (eofferCookie.Values["rememberMe"] != null)
                    if (eofferCookie.Values["keepLoggedIn"].ToString() == "True")
                    {
                        if (eofferCookie.Values["password"] != null)
                            pwd = Web.DecryptRijndaelManaged(eofferCookie.Values["password"]);

                        bool rememberMe = (eofferCookie.Values["rememberMe"].ToString() == "True") ? true : false;
                        Web.AuthenticateMember(userlogin, pwd, true, rememberMe, true);
                    }

            }
        }
        catch (Exception exp)
        {
            Web.LogError(exp);
        }
        return cookie;
    }


    #endregion





}