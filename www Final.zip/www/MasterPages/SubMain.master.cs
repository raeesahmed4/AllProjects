﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MasterPages_SubMain : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    #region MessageBox
    /// <summary>
    /// Message Box Visibility
    /// </summary>
    private bool showMessageBox;
    public bool ShowMessageBox
    {
        get { return showMessageBox; }
        set
        {
            showMessageBox = value;

            if (showMessageBox)
            {
                //ucMessageBox.Visible = true;
                //ucMessageBox.ShowMessage(messageBoxText, "info");
            }
            //else
            //ucMessageBox.Visible = false;
        }
    }

    public void ShowMessage(string message, string type)
    {
    }
    public void ShowMessage(string message)
    {
    }

    #endregion
}
