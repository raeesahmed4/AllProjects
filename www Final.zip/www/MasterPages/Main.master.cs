﻿using System;
using System.Web.UI;
using CodenameRabbitFoot.BusinessLogic;
using System.Data;

public partial class MasterPages_Main : System.Web.UI.MasterPage
{
    public bool ShowPageIcon
    {
        get;
        set;
    }

    public bool ShowAddToContaccts
    {
        get;
        set;
    }

    public MasterPages_Main()
    {
        HideLeftMenu = false;
    }

    public bool HideLeftMenu
    {
        get;
        set;
    }

    public int MemberID
    {
        get;
        set;
    }

    public void HideLinkApps()
    {
        divLinkApps.Visible = false;
    }

    public void ShowLinkApps()
    {
        divLinkApps.Visible = true;
    }

    public string SearchText
    {
        get
        {
            return txtSearch.Value;
        }
    }

    public bool ViewContactInfo
    {
        get
        {
            return dvContactInfo.Visible;
        }
        set
        {
            this.dvContactInfo.Visible = value;
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {   
            if (Request.Url.AbsolutePath.Contains("/Live.aspx"))
                overlay.Visible = false;
            
            // To load counter for Left menu usig ajax. this resovles virtual path to WebMethods 
            //(http://leedumond.com/blog/the-controls-collection-cannot-be-modified-because-the-control-contains-code-blocks/)
            this.Page.Header.DataBind();
            
            Web.CheckSession();
            this.divAddToContacts.Visible = ShowAddToContaccts;

            if (Web.IsMemberSession && (Web.SessionMembers.MemberStatusID == 102 || Web.SessionMembers.MemberStatusID == 103))
            {
                //if (Web.SessionMembers.RegistrationDate.AddDays(7) < DateTime.Now)
                //    ScriptManager.RegisterStartupScript(this.Page, typeof(Page), "Show Alert", "RedirectToVerifyPage()", true);
            }

            if (Web.IsMemberSession)
                litUserName.Text = Web.SessionMembers.FullName;

            if (Request.Url.AbsolutePath.Contains("Contacts/ViewProfile.aspx"))
            {
                MemberID = Web.RecordID;
                int localMemberId = MemberID;
                Members member = Members.GetMemberByID(MemberID);
                ShippingAddresses memberAddress = ShippingAddresses.LoadByMemberID(MemberID);
                Country memberCountry = Country.LoadCountry(memberAddress.CountryID);

                litCompanyName.Text = member.CompanyName;
                litCompanyNameSimple.Text = member.CompanyName;
                lblusername.Text = member.UserName;
                lblcompnayname.Text = member.CompanyName;
                lblemail.Text = member.Email;
                lblContacInfromation.Text = member.CompanyName + " Contact Info";
                lblfullname.Text = member.FullName;
                if (string.IsNullOrEmpty(lblfullname.Text))
                {
                    rowcontact.Visible = false;
                }
                if (string.IsNullOrEmpty(memberAddress.City))
                {
                    this.rowCity.Visible = false;
                }
                else
                {
                    lblCity.Text = memberAddress.City;
                }
                if (string.IsNullOrEmpty(memberAddress.State))
                {
                    this.rowState.Visible = false;
                }
                else
                {
                    lblState.Text = memberAddress.State;
                }
                if (string.IsNullOrEmpty(memberAddress.Zip))
                {
                    this.rowZip.Visible = false;
                }
                else
                {
                    lblZip.Text = memberAddress.Zip;
                }
                if (memberAddress.CountryID < 1)
                {
                    this.rowCountry.Visible = false;
                }
                else
                {
                    lblCountry.Text = memberCountry.CountryName;
                }
                //  MemberPrivacySetting settengs = new MemberPrivacySetting();
                PrivacySettings pSettings = MemberPrivacySetting.GetPrivacySettings(ref localMemberId);
                rowcontact.Visible = pSettings.ShowFullName;
                rowcompany.Visible = pSettings.ShowCompanyName;
                rowemail.Visible = pSettings.ShowEmail;
                rowemaillbl.Visible = pSettings.ShowEmail;

                lblwebsite.Text = member.Website;
                if (string.IsNullOrEmpty(lblwebsite.Text))
                {
                    webrow.Visible = false;
                    webrowweb.Visible = false;
                }
                webrow.Visible = webrowweb.Visible = pSettings.ShowWebsite;
                lblFacebook.Text = member.Facebook;
                if (string.IsNullOrEmpty(lblFacebook.Text))
                {
                    rowfb.Visible = false;

                }
                lblTwitter.Text = member.Twitter;
                if (string.IsNullOrEmpty(lblTwitter.Text))
                {
                    rowtiwtter.Visible = false;
                }
                lblServiceBrand.Text = member.MemberServiceDescription;
                if (string.IsNullOrEmpty(lblServiceBrand.Text))
                {
                    rowdescriptoin.Visible = false;
                    rowdescriptionlbl.Visible = false;
                }
                HandleBillBoardDisplay(member.MemberID, false);
                dvCompanyNameSimple.Visible = true;
                dvCompanyName.Visible = false;
                
                dvLinKApps.Visible = false;
                //myLinkApps.OwnerID = Web.RecordID;
                //if(Web.RecordID != Web.SessionMembers.MemberID)
                //    lblLinkApp.Text = "LinkApps";

                dvWarehouse.Visible = true;
                myWareHouse.OwnerID = Web.RecordID;
                if (Web.RecordID != Web.SessionMembers.MemberID)
                    lblWareHouse.Text = "LinkApps Warehouse";
                
                dvContactInfo.Visible = true;

                this.Page.Title = member.FullName + " - " + member.CompanyName;
                memberRating.MemberID = member.MemberID;

            }
            else
            {
                if (Web.IsMemberSession)
                {
                    MemberID = Web.SessionMembers.MemberID;
                    myWareHouse.OwnerID = myLinkApps.OwnerID = Web.SessionMembers.MemberID;
                    litCompanyName.Text = Web.SessionMembers.CompanyName;
                    litCompanyNameSimple.Text = Web.SessionMembers.CompanyName;
                    HandleBillBoardDisplay(Web.SessionMembers.MemberID, true);
                    memberRating.MemberID = Web.SessionMembers.MemberID;
                }
                dvCompanyNameSimple.Visible = false;
                dvCompanyName.Visible = true;
            }

            if (Session["Message"] != null)
            {
                //splitting message for applicance store message to show custom title
                string[] message = Session["Message"].ToString().Split('^');
                if (message.Length == 2)
                    ShowMessage(message[0], message[1]);
                else
                    ShowMessage(Session["Message"].ToString(), "Info");
                Session["Message"] = null;
            }
        }
        catch (Exception exp)
        {
            Web.LogError(exp);
        }
        if (!Web.IsMemberSession)
        {

            this.divLinkApps.Visible = false;
            if (Request.FilePath.ToLower().Trim().Contains("/live.aspx") || Request.FilePath.ToLower().Trim().Contains("/login.aspx"))
            {
                this.divAllLinkApps.Visible = true;
            }
            else
            {
                this.divAllLinkApps.Visible = false;
            }
        }
        else
        {
            //this.divLinkApps.Visible = true;
            this.divAllLinkApps.Visible = false;

        }
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        try
        {
            Web.Redirect("~/SearchResults.aspx?RecordString=" + Secure.Encrypt(txtSearch.Value));
        }
        catch (Exception exp)
        {
            Web.LogError(exp);
        }
    }

    public void ShowMessage(string message, string type)
    {
        ShowMessage(message, type, "");
    }

    public void ShowMessage(string message, string type, string redirectUrl)
    {
        if (string.IsNullOrEmpty(type))
            type = "Message";

        if (string.IsNullOrEmpty(redirectUrl))
            redirectUrl = "";

        string messageScript = string.Format(" ShowMessageBox('{0}','{1}','{2}' );", type, message.Replace("'", ""), redirectUrl);
        Page.ClientScript.RegisterStartupScript(GetType(), "Javascript", messageScript, true);
    }

    #region Billboard Section

    protected void btnEnableBillBoard_Click(object sender, EventArgs e)
    {
        try
        {
            MembersModuleSubscriptions mms = new MembersModuleSubscriptions();
            mms.AddNew();
            mms.ModuleID = 10;
            mms.MemberID = Web.SessionMembers.MemberID;
            mms.Save();
            Web.Redirect("~/live.aspx");
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }

    }

    void HandleBillBoardDisplay(int memberId, bool isMe)
    {
        //check if the user is subscribed for billboard

        MembersModuleSubscriptions mms = new MembersModuleSubscriptions();
        mms.Where.MemberID.Value = memberId;
        mms.Where.ModuleID.Conjunction = NCI.EasyObjects.WhereParameter.Conj.And;
        mms.Where.ModuleID.Value = 10;
        mms.Query.Load();

        if (mms.RowCount > 0)
        {
            // litBillBoard.Visible = true;
            pnlEnableBillBoard.Visible = false;

            DataTable billBoard = MemberActivityLog.LoadBillboard(memberId);
            if (billBoard.Rows.Count > 0)

                litBillBoardText.Text = billBoard.Rows[0]["Description"].ToString();
            if (litBillBoardText.Text.Length > 360)
            {
                litBillBoardText.Text = litBillBoardText.Text.Substring(0, 360) + "...";
                litBillBoardText.ToolTip = litBillBoardText.Text;
            }

        }
        else
        {
            if (isMe == true)
                pnlEnableBillBoard.Visible = true;
        }
    }

    #endregion

}
