﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Text;
using System.Web.Services;
using System.Web.Script.Services;
using CodenameRabbitFoot.BusinessLogic;

public partial class UploadFile : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Page.Header.DataBind();

        if (this.fupUpload.UploadedFiles.Count > 0)
        {
            string folderPath = Path.Combine(Web.ConfigVariables.UserTempFiles, Path.Combine(Session.SessionID, Web.QueryStringVariables.WebPageName));
            if (!Directory.Exists(folderPath))
                Directory.CreateDirectory(folderPath);

            for (int i = 0; i < this.fupUpload.UploadedFiles.Count; i++)
            {
                Telerik.Web.UI.UploadedFile file = this.fupUpload.UploadedFiles[i] as Telerik.Web.UI.UploadedFile;

                string filePath = Path.Combine(folderPath, Path.GetFileName(file.FileName));                 
                file.SaveAs(filePath, true);
                Web.AddToSessionFiles(Web.QueryStringVariables.WebPageName, filePath);

            }
        }

        int remainingUploadFileCount = Web.GetRemainingAllowedFilesCount(Web.RecordID, Web.QueryStringVariables.WebPageName);
        if (remainingUploadFileCount < 1)
        {
            this.fupUpload.Visible = false;
            this.divMaxLimitMessage.Visible = true;
            this.divUploadButton.Visible = false;
        }
        else
        {
            this.fupUpload.MaxFileInputsCount = remainingUploadFileCount;
            this.fupUpload.InitialFileInputsCount = remainingUploadFileCount;
        } 
    }
     
    [WebMethod(EnableSession = true)]
    public static string DeleteUploadedFile(int id, string webPageName, string filePath)
    {
        string result = "success";
        try
        {
            if (id < 1)
            {
                Web.RemoveFromSessionFiles(webPageName, HttpContext.Current.Server.UrlDecode(filePath));
            }
            else
            {
                SystemObjectFiles systemObjectFiles = new SystemObjectFiles();
                systemObjectFiles.Where.SystemObjectFileID.Value = id;
                systemObjectFiles.Query.Load();

                if (systemObjectFiles.RowCount > 0)
                {
                    systemObjectFiles.DeleteAll();
                    systemObjectFiles.Save();
                }

                string fileName = Path.GetFileName(HttpContext.Current.Server.UrlDecode(filePath));

                filePath = Path.Combine(HttpContext.Current.Server.MapPath("SystemObjectFiles"), fileName);
                if (File.Exists(filePath))
                    File.Delete(filePath);

                filePath = Path.Combine(HttpContext.Current.Server.MapPath("Thumbnails"), fileName);
                if (File.Exists(filePath))
                    File.Delete(filePath);
            }
        }
        catch (Exception exp)
        {
            result = "fail";
            result = exp.Message;
        }
        return result;
    }
      
    [WebMethod(EnableSession = true)]
    public static string LoadFiles(int recordID, string webPageName)
    {
        try
        {
            StringBuilder html = new StringBuilder();

            var filesList = Web.GetSessionAndListingFiles(recordID, webPageName);
            if (filesList == null)
                return string.Empty;
            html.Append("<div style='width:610px; border:1px solid #aaaaaa; border-radius:5px; -moz-border-radius:5px;'>");
            string fileUrl = string.Empty;

            foreach (var item in filesList)
            {
                html.Append("<table width='100%'>");
                html.Append("<tr><td style='width:100px;'>");
                if (item.Key > 0)
                {
                    fileUrl = item.Value;
                }
                else
                {
                    fileUrl = string.Format("http://{0}/{1}/{2}/{3}/{4}", HttpContext.Current.Request.Url.Authority, Directory.GetParent(Web.ConfigVariables.UserTempFiles).Name, HttpContext.Current.Session.SessionID, webPageName, Path.GetFileName(item.Value));
                }
                html.AppendFormat(@"<img height='80' width='80' src='{0}' /></td>
                                <td align='left' style='width:300px;'>{4}</td>
                                <td align='right' style='padding:0px 30px 0px 0px;width:200px;'>
                                <span class='hyperlink'><img style='vertical-align:top;' title='Delete' src='../Images/Contacts/delete.png' alt='Delete' onclick=""RemoveFile(this,'{1}','{3}')""; style='height:16px;width:16px;border-width:0px;' tabindex='0' /><input type='hidden' value='{2}'/></span>
                                </td></tr>", fileUrl, webPageName, HttpContext.Current.Server.UrlEncode(item.Value), item.Key, Path.GetFileName(item.Value));
                html.Append("</table>");
            }
            html.Append("</div>");
            return html.ToString();
        }
        catch (Exception exp)
        {
            Web.LogError(exp);
            return string.Empty;
        }

    }

    [WebMethod(EnableSession = true)]
    public static string LoadMessageFiles(int recordID, string webPageName)
    {
        try
        {
            StringBuilder html = new StringBuilder();

            var filesList = Web.GetSessionAndListingFiles(recordID, webPageName);
            if (filesList == null)
                return string.Empty;
            html.Append("<div style='width:486px; border:1px solid #aaaaaa; border-radius:5px; -moz-border-radius:5px;'>");
            string fileUrl = string.Empty;

            foreach (var item in filesList)
            {
                html.Append("<table width='100%'>");
                html.Append("<tr><td style='width:100px;'>");
                if (item.Key > 0)
                {
                    fileUrl = item.Value;
                }
                else
                {
                    fileUrl = string.Format("http://{0}/{1}/{2}/{3}/{4}", HttpContext.Current.Request.Url.Authority, Directory.GetParent(Web.ConfigVariables.UserTempFiles).Name, HttpContext.Current.Session.SessionID, webPageName, Path.GetFileName(item.Value));
                }
                html.AppendFormat(@"<img height='80' width='80' src='{0}' /></td>
                                <td align='left' style='width:300px;'>{4}</td>
                                <td align='right' style='padding:0px 30px 0px 0px;width:200px;'>
                                <span class='hyperlink'><img style='vertical-align:top;' title='Delete' src='../Images/Contacts/delete.png' alt='Delete' onclick=""RemoveFile(this,'{1}','{3}')""; style='height:16px;width:16px;border-width:0px;' tabindex='0' /><input type='hidden' value='{2}'/></span>
                                </td></tr>", fileUrl, webPageName, HttpContext.Current.Server.UrlEncode(item.Value), item.Key, Path.GetFileName(item.Value));
                html.Append("</table>");
            }
            html.Append("</div>");
            return html.ToString();
        }
        catch (Exception exp)
        {
            Web.LogError(exp);
            return string.Empty;
        }

    }

}