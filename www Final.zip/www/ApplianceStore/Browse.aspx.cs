﻿using System;
using CodenameRabbitFoot.BusinessLogic;
using System.Text.RegularExpressions;

public partial class ApplianceStore_Browse : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
       
        if (!IsPostBack)
        {
            AddApplianceStoreActivityLog();
            Web.LogUserActivity(Radium.Platform.Core.UserActivity.View);

        }

    }

    protected void AddApplianceStoreActivityLog()
    {
        try
        {
            string os = "";
               
            if (Request.UserAgent != null)
            {
                Regex regex = new Regex("Windows(.*?);", RegexOptions.IgnoreCase);
                Match match = regex.Match(Request.UserAgent);
                while (match.Success)
                {
                    os = match.Value;
                    break;
                }


              
            }

            var appstore = new ApplianceStore();
            appstore.Query.AddResultColumn(ApplianceStoreSchema.URL);
            appstore.Where.ApplianceStoreID.Value = Web.RecordID;
            appstore.Query.Load();
            if (appstore.RowCount > 0)
            {
                var appstoreactivitylog = new ApplianceStoreActivityLogs();
                appstoreactivitylog.AddNew();
                appstoreactivitylog.ApplianceStoreID = Web.RecordID;
                appstoreactivitylog.ClickDate = DateTime.Now;
                appstoreactivitylog.ClientIP = Request.UserHostAddress;

                if (Web.IsMemberSession)
                    appstoreactivitylog.MemberID = Web.SessionMembers.MemberID;

                appstoreactivitylog.OS = os;
                appstoreactivitylog.Save();

                if (!appstore.URL.StartsWith("http://"))
                    Web.Redirect("http://" + appstore.URL);
                else
                    Web.Redirect(appstore.URL);

            }
            else
                Web.Redirect("/");

        } 
        catch (Exception exp)
        {
            Web.LogError(exp);
        }
    }
}