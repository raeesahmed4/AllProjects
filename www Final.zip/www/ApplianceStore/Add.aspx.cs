﻿using System;
using System.Collections;
using System.Data;
using System.Web.UI.WebControls;
using CodenameRabbitFoot.BusinessLogic;
using System.Net;
using Telerik.Web.UI;
using VisualSoft.VSharp.Utils;
using System.IO;
using System.Drawing;

public partial class ApplianceStore_Add : System.Web.UI.Page
{
    private int surrogateID = 0;
    public int SurrogateID
    {
        get { return surrogateID; }
        set { surrogateID = value; }
    }
    protected static string FileURL = string.Empty;
    protected string website = string.Empty;
    protected string File = string.Empty;
    protected string message = "";
    protected byte[] applog = null;
    protected void Page_Load(object sender, EventArgs e)
    {
        this.Master.HideLinkApps();
       
        if (!IsPostBack)
        {  
            if (Web.IsMemberSession)
            {
                txtURL.Text = Web.SessionMembers.Website;        
            }
            BindCategories();
            Web.LogUserActivity(Radium.Platform.Core.UserActivity.View);           

            //string action = System.Web.HttpContext.Current.Request.QueryString["Action"];
            //if (action == "InsertValue")
            //{
            //    txtApplianceName.Text = Session["linkappname"].ToString();
            //    txtURL.Text = Session["website"].ToString();
            //    txtDescription.Text = Session["description"].ToString();
            //    bindappliancecategory();

            //}
            //else if (action == "mailsent")
            //{
            //    mviewApplienceStore.ActiveViewIndex = 3;
            //    message = "Password has been sent to your email address. Please enter your password  below in the textbox.";
            //}
        }
    }

   
    private void BindCategories()
    {
        try
        {
            buildTree(null, 0);
        }
        catch (Exception exp)
        {

            Web.LogError(exp);
        }
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {

            /*Members member = new Members();
            member.Where.MemberID.Value = Web.SessionMembers.MemberID;
            member.Query.Load();

            ShippingAddresses address = new ShippingAddresses();
            if (member.RowCount > 0)
            {
                address.Query.AddResultColumn(ShippingAddressesSchema.Phone);
                address.Where.MemberID.Value = member.MemberID;
                address.Query.Load();
            }


            Random rand = new Random();
             */

            var appliancestore = new ApplianceStore();
            appliancestore.AddNew();
            appliancestore.ApplianceName = txtApplianceName.Text;
            appliancestore.URL = txtURL.Text;
            appliancestore.s_IsFeatured = "0";
            appliancestore.Description = txtDescription.Text;
            appliancestore.Price = Convert.ToInt32(txtPrice.Text);
            appliancestore.ContactPersonName = Web.SessionMembers.FullName;
            appliancestore.MemberID = Web.SessionMembers.MemberID;
            appliancestore.VerificationCode = "-000";
            appliancestore.ApplianceStatusID = 200;
            appliancestore.CreateDate = DateTime.Now;
            appliancestore.Save();

            
            foreach (UploadedFile file in ApplianceLogo.UploadedFiles)
            {

                // save the original file
                string tempFolder = Web.SystemConfigs.GetKey("ATTACHMENTS_PHYSICAL_PATH") + "/ApplianceStore/real";
                string filePath = Path.Combine(tempFolder,
                                               appliancestore.ApplianceStoreID +
                                               ".jpg");
                file.SaveAs(filePath, true);

                //Create the thumbnail
                System.Drawing.Image img = System.Drawing.Image.FromStream(ApplianceLogo.UploadedFiles[0].InputStream);
                tempFolder = Web.SystemConfigs.GetKey("ATTACHMENTS_PHYSICAL_PATH") + "/ApplianceStore/";
                filePath = Path.Combine(tempFolder,appliancestore.ApplianceStoreID + ".jpg");
                Web.CreateThumbnail(img, 50, 50).Save(filePath);
            }

            if (appliancestore.RowCount > 0)
            {
                SaveApplianceStoreCategories(appliancestore.ApplianceStoreID);
                // website = appliancestore.URL;
                // File = appliancestore.VerificationCode;
                // FileURL = website + "/" + File;
                Session["Message"] = "Thank you for submitting an application to have your site listed in our LinkApp Board™. Your request will be reviewed for approval.^Submit Confirmation";
                Web.Redirect("/ApplianceStore/Default.aspx");
            }
        } 
        catch (Exception exp)
        {
            Web.LogError(exp);
        }
       
    }

 

    private void SaveAppLinksOfActiveMembers(int MemberID)
    {
       
    }
    protected void btnverifyTextFile_Click(object sender, EventArgs e)
    {
        bool result;

        string url = "http://www.eOpen.com:8081/mushtaq.txt";
        try
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
            {
                if (response.StatusCode == HttpStatusCode.OK)
                {
                    result = true;
                    mviewApplienceStore.ActiveViewIndex = 2;
                }
                else
                {
                    result = false;
                }
            }
        }
        catch (Exception exp)
        {

            Web.LogError(exp);

        }



    }


    public void buildTree(TreeNode n, int categoryID)
    {
        try
        {
            DataTable resultData = CodenameRabbitFoot.BusinessLogic.Categories.GetSubCategories(categoryID, 1);

            ChckkCategories.DataSource = resultData.DefaultView;
            ChckkCategories.DataTextField = "CategoryName";
            ChckkCategories.DataValueField = "CategoryID";
            ChckkCategories.DataBind();


            ////Bind First tree
            //foreach (DataRow row in resultData.Rows)
            //{
            //    TreeNode node = new TreeNode(row["CategoryName"].ToString(), row["CategoryID"].ToString());
            //    node.SelectAction = TreeNodeSelectAction.Expand;
            //    buildTree(node, int.Parse(row["CategoryID"].ToString()));

            //    if (n == null)
            //    {

            //        treeviewCategories.Nodes.Add(node);
            //    }
            //    else
            //        n.ChildNodes.Add(node);
            //}
        }
        catch (VException vx)
        {

            Web.LogError(vx);
        }
        catch (Exception ex)
        {

            Web.LogError(ex);
        }
    }


    protected void SaveApplianceStoreCategories(int ApplianceStoreID)
    {
        try
        {

            //if (treeviewCategories.Nodes.Count > 0)
            //{
            //    if (treeviewCategories.CheckedNodes.Count > 0)
            //    {
            //        ApplianceStoreCategories apstorecategory;
            //        foreach (TreeNode n in treeviewCategories.CheckedNodes)
            //        {
            //            apstorecategory = new ApplianceStoreCategories();
            //            apstorecategory.AddNew();
            //            apstorecategory.ApplianceStoreID = ApplianceStoreID;
            //            apstorecategory.CategoryID = Convert.ToInt32(n.Value);
            //            apstorecategory.Save();

            //        }

            //    }

            //}
            checkedCategories();

            ArrayList arr = (ArrayList)Session["checkednodes"];
            if (arr.Count > 0)
            {
                ApplianceStoreCategories apstorecategory;
                foreach (int categoryid in arr)
                {
                    apstorecategory = new ApplianceStoreCategories();
                    apstorecategory.AddNew();
                    apstorecategory.ApplianceStoreID = ApplianceStoreID;
                    apstorecategory.CategoryID = categoryid;
                    apstorecategory.Save();
                }

            }
        }
        catch (Exception exp)
        {

            Web.LogError(exp);
        }
    }
    public bool checkedCategories()
    {

        try
        {
            ArrayList arr = new ArrayList();
            if (ChckkCategories.Items.Count > 0)
            {
                foreach (ListItem n in ChckkCategories.Items)
                {
                    if (n.Selected)
                        arr.Add(Convert.ToInt32(n.Value));
                }
            }
            Session["checkednodes"] = arr;
            if (arr.Count > 4)
            {
                return false;
            }
            else
                return true;

        }
        catch (Exception exp)
        {

            Web.LogError(exp);
            return false;
        }
    }

    public void bindappliancecategory()
    {

        try
        {
            //ArrayList arrWTS = (ArrayList)Session["checkednodes"];
            //foreach (TreeNode n in treeviewCategories.Nodes)
            //{
            //    foreach (string str in arrWTS)
            //    {
            //        if (n.Value == str)
            //            n.Checked = true;
            //    }

            //    foreach (TreeNode cn in n.ChildNodes)
            //    {
            //        foreach (string str in arrWTS)
            //        {
            //            if (cn.Value == str)
            //            {
            //                cn.Checked = true;
            //                cn.Parent.Expand();
            //            }
            //        }
            //        foreach (TreeNode cnn in cn.ChildNodes)
            //        {
            //            foreach (string str in arrWTS)
            //            {
            //                if (cnn.Value == str)
            //                {
            //                    cnn.Checked = true;
            //                    cnn.Parent.Expand();
            //                }
            //            }
            //        }
            //    }
            //}
        }
        catch (Exception exp)
        {

            Web.LogError(exp);
        }
    }

    protected void lnkLogin_Click(object sender, EventArgs e)
    {

        try
        {
            Members member = new Members();

            string membremail = Session["appmemberemail"].ToString();
            Members members = new Members();
            members.Where.Email.Value = Session["appmemberemail"].ToString();// txtcontactemail.Text;
            members.Query.Load();
            member.LoadByPrimaryKey(members.MemberID);

            if (member.RowCount > 0)
            {
                CodenameRabbitFoot.BusinessLogic.Members registeredmember = CodenameRabbitFoot.BusinessLogic.Members.Authenticate(member.UserName, txtPasswordLogin.Text);
                if (registeredmember.RowCount > 0)
                {
                    Web.SessionMembers = member;
                    Web.IsMemberSession = true;
                    ShippingAddresses address = new ShippingAddresses();
                    address.Where.MemberID.Value = member.MemberID;
                    address.Query.Load();
                    if (address.RowCount > 0)
                        Web.SessionMembers.shippingAddress = address;
                    //mviewApplienceStore.ActiveViewIndex = 0;

                    //
                    SaveAppLinksOfActiveMembers(Web.SessionMembers.MemberID);
                    //
                }

                else
                {
                    lblloginmessage.Text = "Invalid Password";
                }

            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }


}