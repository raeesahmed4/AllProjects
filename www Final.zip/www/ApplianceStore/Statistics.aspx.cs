﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System;
using CodenameRabbitFoot.BusinessLogic;
using System.Data;

public partial class ApplianceStore_Statistics : System.Web.UI.Page
{
    protected int rptcount = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        //Master.ShowLine = true;
        //Master.PageHeading = "LinkApp Statistics";
        //Master.HeadingIcon = "~/Images/PageIcons/link_apps_main.png";

        if (!IsPostBack)
        {
            LoadData();

        }
    }

    private void LoadData()
    {
        if (Web.RecordID > 0)
        {
            Members member = new Members();
            member.LoadByPrimaryKey(Web.RecordID);
            if (member.RowCount > 0)
            {
                try
                {
                    DataTable dTable = ApplianceStore.GetApplianceStoreStats(Web.RecordID);
                    if (dTable.Rows.Count > 0)
                    {
                        pnlEmpty.Visible = false;

                        rptStats.DataSource = dTable;
                        rptStats.DataBind();
                    }
                    else
                    {
                        pnlEmpty.Visible = true;
                    }
                }
                catch (Exception exp)
                {
                    Web.LogError(exp);
                }
            }

        }
    }
}