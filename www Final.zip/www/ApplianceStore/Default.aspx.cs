﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using CodenameRabbitFoot.BusinessLogic;
using System.Collections.Specialized;
using System.Web.Services;
using System.Text;
using System.Web.Script.Services;

public partial class ApplianceStore_Default : System.Web.UI.Page
{
    private string _heading = "Featured";
    public string Heading
    {
        get { return _heading; }
        set { _heading = value; }
    }

    private bool _hasLApp = false;
    public bool HasLApp
    {
        get { return _hasLApp; }
        set { _hasLApp = value; }
    }
    protected int rptcount1, rptcount2, rptcount3, rptcount4, rptcount5, rptcount6, rptcount7 = 0;

    public int counterAd = 1;
    public int exactAdCounter = 0;
    private int _maxRandNumber = 0;

    protected void Page_Load(object sender, EventArgs e)
    {
        string javascript = "";
        if (!Web.IsMemberSession)
        {
            javascript = "javascript: disabletab('tabs-warehouse') ";
            Page.ClientScript.RegisterStartupScript(GetType(), "Javascript", javascript, true);
        }
        this.Master.HideLinkApps();
        string wharhouse = "ViewWarehouse";
        var wharh = Request.QueryString["Action"];
        if (wharh == wharhouse)
        {
            javascript = "javascript: selectTab('tabs-warehouse') ";
            Page.ClientScript.RegisterStartupScript(GetType(), "Javascript", javascript, true);
        }

        if (!IsPostBack)
        {
            populateCategories();
            // LoadData();
        }

    }

    [WebMethod(EnableSession = true)]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public static JQGrid LoadMySiteLinkApps(string grid, int pageIndex, int pageSize, int categoryid, string searchcriteria)
    {
        JQGrid jqGrid = new JQGrid();

        DataTable dTable = null;
        bool remove = false;
        if (grid == "warehouse")
        {
            if (searchcriteria != "")
                dTable = ApplianceStore.SearchApplianceStore(searchcriteria);
            else if (categoryid == -1)
                dTable = ApplianceStore.GetApplianceStoreByStatusAndMember(300, Web.SessionMembers.MemberID);
            else
                dTable = ApplianceStore.GetApplianceStoreMostVisitedByCategory(categoryid);
            remove = true;
        }
        else if (grid == "MySiteLinkApps")
        {
            if (searchcriteria != "")
                dTable = ApplianceStore.SearchApplianceStore(searchcriteria);
            else if (categoryid == -1)
                dTable = ApplianceStore.GetApplianceStore(Web.SessionMembers.MemberID);
            else
                dTable = ApplianceStore.SearchApplianceStoreByCategory(categoryid);
            remove = false;
        }
        else if (grid == "JustAddedAll")
        {
            if (searchcriteria != "")
                dTable = ApplianceStore.SearchApplianceStore(searchcriteria);
            else if (categoryid == -1)
                dTable = ApplianceStore.GetAllApplianceStore();
            else
                dTable = ApplianceStore.SearchApplianceStoreByCategory(categoryid);
            remove = false;
        }
        else if (grid == "FeaturedStore")
        {
            dTable = ApplianceStore.GetApplianceStoreFeatured();
            remove = false;
        }
        else if (grid == "JustAdded")
        {
            if (categoryid == -1)
                dTable = ApplianceStore.GetApplianceStoreJustAddedByStatus(300);
            else
                dTable = ApplianceStore.GetApplianceStoreMostVisitedByCategory(categoryid);
            remove = false;
        }
        else if (grid == "MostVisited")
        {
            if (categoryid == -1 )
                dTable = ApplianceStore.GetApplianceStoreMostVisited();
            else
                dTable = ApplianceStore.GetApplianceStoreMostVisitedByCategory(categoryid);
            remove = false;
        }

        IEnumerable<DataRow> allRows = dTable.Select();

        // all filterign is made abov 
        jqGrid.total = allRows.Count() == pageSize ? 1 : (allRows.Count() / pageSize) + 1;
        jqGrid.records = pageSize;
        jqGrid.page = pageIndex;
        IEnumerable<DataRow> dataRows = allRows.Skip((pageIndex - 1) * pageSize).Take(pageSize);
        if (dataRows.Count() == 0)
        {
            if (allRows.Count() > 0)
            {
                dataRows = allRows.Skip((pageIndex - 2) * pageSize).Take(pageSize);
                jqGrid.page = pageIndex - 1;
                if (jqGrid.total > 1)
                    jqGrid.total = jqGrid.total - 1;
            }
            else
            {
                JQGrid.Row row = new JQGrid.Row();
                row.id = 0;
                row.cell.Add("0");
                row.cell.Add("<div style='text-align:left; padding:5px;'>" + Constants.MSG_MEMBER_CONTACT_LIST_EMPTY_GRID + "</div>");
                jqGrid.rows.Add(row);
                jqGrid.status = "empty";
            }
        }
        string logoPath = Web.SystemConfigs.GetKey("ATTACHMENTS_PATH") + "/ApplianceStore/";
        foreach (DataRow row in dataRows)
        {
            JQGrid.Row jrow = new JQGrid.Row();
            jrow.id = Convert.ToInt32(row["appliancestoreid"]);
            jrow.cell.Add(row["appliancestoreid"].ToString());
            jrow.cell.Add("<div style='padding: 5px;'><img width='50' height='50' border='1' src=\"../ePage/ImageViewer.ashx?Action=ApplianceStoreLogo&RecordID=" + Secure.Encrypt(row["ApplianceStoreID"]) + "\" /></div>");            
            jrow.cell.Add("<span style='padding: 5px;'><a href='browse.aspx?RecordID=" + Secure.Encrypt(row["ApplianceStoreID"]) + "' title='" + row["ApplianceName"].ToString() + "' target='_blank'>" + row["appliancename"].ToString() + "</a></span>");
            jrow.cell.Add("<span style='padding: 5px;'>" + row["description"] + "</span>");
            jrow.cell.Add("<span style='padding: 5px;'>" + row["viewed"] + "</span>");
            jrow.cell.Add("<span style='padding: 5px;'>" + row["installed"] + "</span>");
            string showHideImages = "";
            if (AllowEditing(Convert.ToInt32(row["ApplianceStoreID"].ToString())))
                showHideImages = "<a href='Edit.aspx?Action=Edit&RecordID=" + row["ApplianceStoreID"] + "' title='Edit'><img alt='Delete' src='/App_Themes/Space/Images/eOpen 16X16 Icons/eo_icon_edit_1.png' /></a>&nbsp;";
            if (AllowDeleting(Convert.ToInt32(row["ApplianceStoreID"].ToString())))
                showHideImages += "<a onclick='DeleteApplianceStore(" + row["ApplianceStoreID"] + ")' title='Delete'><img alt='Delete' src='/Images/Icons/delete_small.png' /></a>";
            if (AllowAdding(Convert.ToInt32(row["ApplianceStoreID"].ToString())))
                showHideImages += "<a onclick='AddApplianceStore(" + row["ApplianceStoreID"] + ")' title='Add'><img alt='Add' src='/Images/Icons/Add_Icon.png' /></a>";
            if (AllowRemove(remove))
                showHideImages += "<a onclick='RemoveApplianceStore(" + row["ApplianceStoreID"] + ")' title='Remove'><img alt='remove' src='/Images/LiveFeed/cross.png' /></a>";

            jrow.cell.Add("<span style='padding: 5px;'><a target='_blank' href='browse.aspx?RecordID=" + Secure.Encrypt(row["ApplianceStoreID"]) + "' class='liView' title='View'>&nbsp;</a>" + showHideImages + "</span>");



            //row.cell.Add("<span style='padding: 5px;'><a href=# onclick=PerformContactAction(this,'EditContactListItem');><img title='Edit' src='../images/contacts/editcontact.png' /></a> <a href=# onclick=PerformContactAction(this,'DeleteContactListItem');><img title='Delete' src='../images/contacts/delete.png' /></a></span><input type='hidden' value='" + Secure.Encrypt(member["MemberContactListID"]) + "' />");

            jqGrid.rows.Add(jrow);
        }
        return jqGrid;
    }

    [WebMethod]
    public static string RemoveApplianceStore(string appliancestoreid)
    {
        try
        {
            ApplianceStoreSubscriptions subscriptions = new ApplianceStoreSubscriptions();
            subscriptions.Where.ApplianceStoreID.Value = Convert.ToInt32(appliancestoreid);
            subscriptions.Where.MemberID.Value = Web.SessionMembers.MemberID;
            subscriptions.Query.Load();
            if (subscriptions.RowCount > 0)
            {
                do
                {
                    subscriptions.MarkAsDeleted();
                    subscriptions.Save();
                }
                while (subscriptions.MoveNext());
            }
        }
        catch (Exception ex)
        {
            return ex.ToString();
        }

        return "success";
    }

    [WebMethod]
    public static string DeleteApplianceStore(string appliancestoreid)
    {
        try
        {
            int ApplianceStoreID = Convert.ToInt32(appliancestoreid);
            ApplianceStore appstore = new ApplianceStore();

            ApplianceStoreSubscriptions appsubscription = new ApplianceStoreSubscriptions();
            appsubscription.Where.ApplianceStoreID.Value = ApplianceStoreID;
            appsubscription.Query.Load();
            if (appsubscription.RowCount > 0)
            {
                do
                {
                    appsubscription.MarkAsDeleted();
                    appsubscription.Save();
                } while (appsubscription.MoveNext());
            }
            ApplianceRatings ratings = new ApplianceRatings();
            ratings.Where.ApplianceStoreID.Value = ApplianceStoreID;
            ratings.Query.Load();
            if (ratings.RowCount > 0)
            {
                do
                {
                    ratings.MarkAsDeleted();
                    ratings.Save();
                } while (ratings.MoveNext());
            }
            ApplianceStoreActivityLogs logs = new ApplianceStoreActivityLogs();
            logs.Where.ApplianceStoreID.Value = ApplianceStoreID;
            logs.Query.Load();
            if (logs.RowCount > 0)
            {
                do
                {
                    logs.MarkAsDeleted();
                    logs.Save();
                } while (logs.MoveNext());
            }
            ApplianceStoreCategories categories = new ApplianceStoreCategories();
            categories.Where.ApplianceStoreID.Value = ApplianceStoreID;
            categories.Query.Load();
            if (categories.RowCount > 0)
            {
                do
                {
                    categories.MarkAsDeleted();
                    categories.Save();
                } while (categories.MoveNext());
            }

            appstore.LoadByPrimaryKey(ApplianceStoreID);
            appstore.MarkAsDeleted();
            appstore.Save();
        }
        catch (Exception ex)
        {
            return ex.ToString();
        }

        return "success";
    }

    [WebMethod]
    public static string AddApplianceStore(string appliancestoreid)
    {
        try
        {
            int ApplianceStoreID = Convert.ToInt32(appliancestoreid);
            ApplianceStore appstore = new ApplianceStore();
            appstore.Query.AddResultColumn(ApplianceStoreSchema.ApplianceName);
            appstore.Query.AddResultColumn(ApplianceStoreSchema.MemberID);
            appstore.Query.AddResultColumn(ApplianceStoreSchema.ApplianceStoreID);
            appstore.Where.ApplianceStoreID.Value = ApplianceStoreID;
            appstore.Query.Load();

            ApplianceStoreSubscriptions appsubscription = new ApplianceStoreSubscriptions();
            appsubscription.Where.MemberID.Value = Web.SessionMembers.MemberID;
            appsubscription.Where.ApplianceStoreID.Value = ApplianceStoreID;
            appsubscription.Query.Load();

            if (appsubscription.RowCount > 0)
            {
                // Master.ShowMessage("You have already added this LinkAPP;", "warning");
            }
            else
            {
                appsubscription = new ApplianceStoreSubscriptions();
                appsubscription.AddNew();
                appsubscription.MemberID = Web.SessionMembers.MemberID;
                appsubscription.ApplianceStoreID = ApplianceStoreID;
                appsubscription.Save();
                System.Collections.Specialized.StringDictionary templateKeys = new System.Collections.Specialized.StringDictionary();
                templateKeys.Add("#lapp#", "<a target=\"_blank\" href=\"../ApplianceStore/Browse.aspx?RecordID=#encrypt#" + appstore.ApplianceStoreID + "#endencrypt#\">" + appstore.s_ApplianceName + "</a>");
                templateKeys.Add("#pronoun#", "#pronoun#" + Web.SessionMembers.s_MemberID + "#endpronoun#");
                Web.AddActivityLog(Web.SessionMembers.MemberID, 36, templateKeys, appstore.ApplianceStoreID);


            }

        }
        catch (Exception ex)
        {
            return ex.ToString();
        }

        return "success";
    }


    //private void BindAllLinkApps()
    //{
    //    try
    //    {
    //        DataTable AllLinkApps = new DataTable();

    //        if (ddlCategories.SelectedValue == "0" || ddlCategories.SelectedValue == "")
    //        {
    //            AllLinkApps = ApplianceStore.GetAllApplianceStore();
    //            _maxRandNumber = AllLinkApps.Rows.Count;
    //            rptJustAddedAll.DataSource = AllLinkApps;
    //        }
    //        else
    //        {
    //            AllLinkApps = ApplianceStore.GetApplianceStoreJustAddedByCategory(Convert.ToInt32(ddlCategories.SelectedValue));
    //            _maxRandNumber = AllLinkApps.Rows.Count;
    //            rptJustAddedAll.DataSource = AllLinkApps;
    //        }

    //        DataColumn dc = new DataColumn("AllowRemove");
    //        dc.DefaultValue = false;
    //        AllLinkApps.Columns.Add(dc);


    //        rptJustAddedAll.DataBind();
    //        Session["JustAdded"] = rptJustAddedAll.DataSource;
    //    }
    //    catch (Exception exp)
    //    {
    //        Web.LogError(exp);
    //    }
    //}

    private void LoadData()
    {
        // BindMyLApps();
        //BindMyLAppsWareHouse();
        // BindFeaturedLApps();
        // BindrptJustAdded();
        BindrptMostVisited();
        //  BindAllLinkApps();
        // 

        //try
        //{
        //    rptcount1 = rptcount2 = rptcount3 = 0;

        //    populateCategories();

        //    if (Web.RecordID > 0)
        //    {
        //        Members member = new Members();

        //        member.LoadByPrimaryKey(Web.RecordID);

        //        if (member.RowCount > 0)
        //        {
        //            if (Web.IsAction("ViewWarehouse"))
        //            {
        //                // Master.PageHeading = Heading = (Web.RecordID == Web.SessionMembers.MemberID) ? "My LinkAPPs Warehouse" : member.UserName + "'s LinkAPPs Warehouse";
        //                BindWarehouse();
        //            }
        //            else if (Web.IsAction("ViewCommon"))
        //            {
        //                //Master.PageHeading = Heading = "LinkAPPs in Common";
        //                BindCommonLApps();
        //            }
        //            else if (Web.IsAction("ViewLinkApps"))
        //            {
        //                // Master.PageHeading = Heading = (Web.RecordID == Web.SessionMembers.MemberID) ? "My Site LinkAPPs" : member.UserName + "'s Site LinkAPPs";
        //                BindLApps();
        //            }
        //        }
        //        else
        //            BindrptApplianceStore();
        //    }

        //    else
        //    {

        //        BindrptApplianceStore();
        //        BindrptJustAdded();
        //        BindrptMostVisited();
        //    }

        //   // BindMyLApps();
        //    Web.LogUserActivity(Radium.Platform.Core.UserActivity.View);
        //    CheckIfHasLApp();
        //}
        //catch (Exception exp)
        //{
        //    Web.LogError(exp);
        //}
        //finally
        //{

        //}
    }

    private void CheckIfHasLApp()
    {
        try
        {
            if (Web.RecordID > 0 && Web.IsAction("ViewLinkApps"))
            {
                ApplianceStore stores = new ApplianceStore();
                stores.Where.MemberID.Value = Web.SessionMembers.MemberID;
                stores.Query.Load();
                HasLApp = (stores.RowCount > 0) ? true : false;                
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }


    /// <summary>
    /// Display the LinkApps created by members
    /// </summary>
    /// 
    //private void BindMyLApps()
    //{

    //    try
    //    {
    //        DataTable dTable = ApplianceStore.GetApplianceStore(Web.SessionMembers.MemberID);
    //        DataColumn dc = new DataColumn("AllowRemove");
    //        dc.DefaultValue = false;
    //        dTable.Columns.Add(dc);

    //        rptMySiteLinkApps.DataSource = dTable.DefaultView;
    //        rptMySiteLinkApps.DataBind();

    //        if (dTable.Rows.Count == 0)
    //            pnlEmpty.Visible = true;
    //        else
    //            pnlEmpty.Visible = false;
    //    }
    //    catch (Exception exp)
    //    {
    //        Web.LogError(exp);
    //    }
    //}

    /// <summary>
    /// 
    /// </summary>
    //private void BindFeaturedLApps()
    //{
    //    try
    //    {
    //        DataTable dTable = ApplianceStore.GetApplianceStoreFeatured();
    //        DataColumn dc = new DataColumn("AllowRemove");
    //        dc.DefaultValue = false;
    //        dTable.Columns.Add(dc);

    //        rptFeaturedStore.DataSource = dTable;
    //        rptFeaturedStore.DataBind();

    //    }
    //    catch (Exception exp)
    //    {
    //        Web.LogError(exp);
    //    }
    //}

    //private void BindMyLAppsWareHouse()
    //{

    //    try
    //    {

    //        DataTable dTable = ApplianceStore.GetApplianceStoreByStatusAndMember(300, Web.SessionMembers.MemberID);

    //        DataColumn dc = new DataColumn("AllowRemove");
    //        dc.DefaultValue = true;
    //        dTable.Columns.Add(dc);

    //        rptMyWareHouse.DataSource = dTable;
    //        rptMyWareHouse.DataBind();

    //    }
    //    catch (Exception exp)
    //    {
    //        Web.LogError(exp);
    //    }
    //}

    //private void BindLApps()
    //{rptApplianceStore
    //    try
    //    {
    //        DataTable dTable = ApplianceStore.GetApplianceStore(Web.RecordID);
    //        if (dTable.Rows.Count == 0 && Web.RecordID == Web.SessionMembers.MemberID)
    //        {
    //            pnlEmpty.Visible = true;
    //        }
    //        else
    //        {
    //            //pnlEmpty.Visible = false;

    //            rptApplianceStore.DataSource = dTable;
    //            rptApplianceStore.DataBind();
    //            Session["DataSource"] = rptApplianceStore.DataSource;
    //        }
    //    }
    //    catch (Exception exp)
    //    {
    //        Web.LogError(exp);
    //    }
    //}
    //private void BindCommonLApps()
    //{
    //    try
    //    {
    //        rptApplianceStore.DataSource = ApplianceStore.GetCommonAppliances(Web.SessionMembers.MemberID, Web.RecordID);
    //        rptApplianceStore.DataBind();
    //        Session["DataSource"] = rptApplianceStore.DataSource;
    //    }
    //    catch (Exception exp)
    //    {
    //        Web.LogError(exp);
    //    }
    //}
    //private void BindWarehouse()
    //{
    //    try
    //    {
    //        rptApplianceStore.DataSource = ApplianceStore.GetApplianceStoreByStatusAndMember(300, Web.RecordID);
    //        rptApplianceStore.DataBind();
    //        Session["DataSource"] = rptApplianceStore.DataSource;
    //    }
    //    catch (Exception exp)
    //    {
    //        Web.LogError(exp);
    //    }
    //}

    protected string showLink(string MemberID)
    {
        var member = new Members();
        if (member.LoadByPrimaryKey(int.Parse(MemberID)) && member.MemberStatusID == 200)
            return "<a style='font-size: 10px;' href='../contacts/viewprofile.aspx?Action=View&RecordID=" + Secure.Encrypt(MemberID) + "'>View Profile>></a>";
        return "&nbsp;";
    }

    protected string showAppStatus(string AppStatus)
    {
        if (AppStatus == "Live")
            return "";
        return "<span style='color: Gray; font-size: 7pt;'>" + AppStatus + "</span>";
    }

    private void populateCategories()
    {
        try
        {
            BindCategories(ddlCategories, true);
        }
        catch (Exception ex)
        {
            //Log.Write("444", ex.GetBaseException().ToString(), ex);
            Web.LogError(ex);
        }
    }

    public static void BindCategories(DropDownList ddlCategories, bool AddAllCategoriesItem)
    {
        try
        {
            ListItem item = new ListItem();
            if (AddAllCategoriesItem)
            {
                item = new ListItem("All Categories", "-1");
                ddlCategories.Items.Add(item);
            }

            Categories categories = Web.Categories;
            if (categories != null)
                if (categories.RowCount > 0)
                {
                    foreach (DataRow row in categories.DefaultView.Table.Rows)
                    {
                        if (row["ParentCategory"].ToString() == "0")
                        {
                            item = new ListItem(row["CategoryName"].ToString(), row["CategoryID"].ToString());
                            ddlCategories.Items.Add(item);
                        }
                    }
                }
            ddlCategories.DataBind();
        }
        catch (Exception ex)
        {
            //Log.Write("444", ex.GetBaseException().ToString(), ex);
            Web.LogError(ex);
        }
    }

    //private void BindrptJustAdded()
    //{
    //    try
    //    {
    //        DataTable justAddedLinkApps = new DataTable();
    //        DataColumn dc = new DataColumn("AllowRemove");
    //        dc.DefaultValue = false;
    //        justAddedLinkApps.Columns.Add(dc);

    //        if (ddlCategories.SelectedValue == "0" || ddlCategories.SelectedValue == "")
    //        {
    //            justAddedLinkApps = ApplianceStore.GetApplianceStoreJustAddedByStatus(300);
    //            _maxRandNumber = justAddedLinkApps.Rows.Count;
    //            rptJustAdded.DataSource = justAddedLinkApps;
    //        }
    //        else
    //        {
    //            justAddedLinkApps = ApplianceStore.GetApplianceStoreJustAddedByCategory(Convert.ToInt32(ddlCategories.SelectedValue));
    //            _maxRandNumber = justAddedLinkApps.Rows.Count;
    //            rptJustAdded.DataSource = justAddedLinkApps;
    //        }

    //        rptJustAdded.DataBind();
    //        Session["JustAdded"] = rptJustAdded.DataSource;
    //    }
    //    catch (Exception exp)
    //    {
    //        Web.LogError(exp);
    //    }
    //}

    private void BindrptMostVisited()
    {
        try
        {
            DataTable MostVisitedLinkApps = new DataTable();

            if (ddlCategories.SelectedValue == "0" || ddlCategories.SelectedValue == "")
                MostVisitedLinkApps = ApplianceStore.GetApplianceStoreMostVisited();
            else
                MostVisitedLinkApps = ApplianceStore.GetApplianceStoreMostVisitedByCategory(Convert.ToInt32(ddlCategories.SelectedValue));

            DataColumn dc = new DataColumn("AllowRemove");
            dc.DefaultValue = false;
            MostVisitedLinkApps.Columns.Add(dc);

            rptMyLinkApps.DataSource = MostVisitedLinkApps.DefaultView;
            rptMyLinkApps.DataBind();

            Session["MostVisited"] = rptMyLinkApps.DataSource;
        }
        catch (Exception exp)
        {
            Web.LogError(exp);
        }
    }
    //private void BindrptApplianceStore()
    //{
    //    try
    //    {
    //        rptApplianceStore.DataSource = ApplianceStore.GetApplianceStoreFeatured();
    //        rptApplianceStore.DataBind();
    //        Session["DataSource"] = rptApplianceStore.DataSource;
    //    }
    //    catch (Exception exp)
    //    {
    //        Web.LogError(exp);
    //    }
    //}

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        try
        {
            if (Web.RecordID > 0)
            {
                SearchWithinResults(null);
            }
            else
            {
                // DataTable applianceStore = ApplianceStore.SearchApplianceStore(txtKeyWord.Text);
                //if (applianceStore.Rows.Count > 0)
                //{
                //    rptApplianceStore.DataSource = applianceStore;
                //    rptApplianceStore.DataBind();
                //    Session["DataSource"] = rptApplianceStore.DataSource;
                //}


                //applianceStore = ApplianceStore.SearchApplianceStoreJustAdded(txtKeyWord.Text);
                //if (applianceStore.Rows.Count > 0)
                //{
                //    rptJustAdded.DataSource = applianceStore;
                //    rptJustAdded.DataBind();
                //    Session["JustAdded"] = rptJustAdded.DataSource;
                //}

                //applianceStore = ApplianceStore.SearchApplianceStoreMostViewed(txtKeyWord.Text);
                //if (applianceStore.Rows.Count > 0)
                //{
                //    rptMyLinkApps.DataSource = applianceStore;
                //    rptMyLinkApps.DataBind();
                //    Session["MostVisited"] = rptMyLinkApps.DataSource;
                //}

                //string javascript = "javascript: selectTab('tabs-Featured') ";
                //Page.ClientScript.RegisterStartupScript(GetType(), "Javascript", javascript, true);
            }
        }
        catch (Exception exp)
        {
            Web.LogError(exp);
        }
    }
    private void SearchWithinResults(int? CategoryID)
    {
        try
        {
            DataTable dt = new DataTable();
            string query = "";
            DataView dv = new DataView();

            //if (Session["DataSource"] != null)
            //{
            //    dt = (DataTable)Session["DataSource"];
            //    if (dt.Rows.Count > 0)
            //    {
            //        //if (CategoryID.HasValue)
            //        //    query = " Categories like '%" + CategoryID.Value + "%' ";
            //        //else
            //        query = " ApplianceName like '%" + txtKeyWord.Text + "%' ";

            //        dv = new DataView(dt, query, "", DataViewRowState.CurrentRows);
            //        rptApplianceStore.DataSource = dv.ToTable();
            //        rptApplianceStore.DataBind();
            //        Session["DataSource"] = dv.ToTable();
            //    }
            //}
            //if (Session["JustAdded"] != null)
            //{
            //    dt = (DataTable)Session["JustAdded"];
            //    if (dt.Rows.Count > 0)
            //    {
            //        //if (CategoryID.HasValue)
            //        //    query = " Categories like '%" + CategoryID.Value + "%' ";
            //        //else
            //        query = " ApplianceName like '%" + txtKeyWord.Text + "%' ";

            //        dv = new DataView(dt, query, "", DataViewRowState.CurrentRows);
            //        rptJustAdded.DataSource = dv.ToTable();
            //        rptJustAdded.DataBind();
            //        Session["JustAdded"] = dv.ToTable();
            //    }
            //}
            //if (Session["MostVisited"] != null)
            //{
            //    dt = (DataTable)Session["MostVisited"];
            //    if (dt.Rows.Count > 0)
            //    {
            //        //if (CategoryID.HasValue)
            //        //    query = " Categories like '%" + CategoryID.Value + "%' ";
            //        //else
            //        query = " ApplianceName like '%" + txtKeyWord.Text + "%' ";

            //        dv = new DataView(dt, query, "", DataViewRowState.CurrentRows);
            //        rptMyLinkApps.DataSource = dv.ToTable();
            //        rptMyLinkApps.DataBind();
            //        Session["MostVisited"] = dv.ToTable();
            //    }
            //}
        }
        catch (Exception exp)
        {
            Web.LogError(exp);
        }
    }

    protected void rptApplianceStore_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        try
        {
            if (e.CommandName.Equals("Add"))
            {
                int ApplianceStoreID = Convert.ToInt32(e.CommandArgument.ToString());
                ApplianceStore appstore = new ApplianceStore();
                appstore.Query.AddResultColumn(ApplianceStoreSchema.ApplianceName);
                appstore.Query.AddResultColumn(ApplianceStoreSchema.MemberID);
                appstore.Query.AddResultColumn(ApplianceStoreSchema.ApplianceStoreID);
                appstore.Where.ApplianceStoreID.Value = ApplianceStoreID;
                appstore.Query.Load();

                ApplianceStoreSubscriptions appsubscription = new ApplianceStoreSubscriptions();
                appsubscription.Where.MemberID.Value = Web.SessionMembers.MemberID;
                appsubscription.Where.ApplianceStoreID.Value = ApplianceStoreID;
                appsubscription.Query.Load();

                if (appsubscription.RowCount > 0)
                {
                    // Master.ShowMessage("You have already added this LinkAPP;", "warning");
                }
                else
                {
                    appsubscription = new ApplianceStoreSubscriptions();
                    appsubscription.AddNew();
                    appsubscription.MemberID = Web.SessionMembers.MemberID;
                    appsubscription.ApplianceStoreID = ApplianceStoreID;
                    appsubscription.Save();
                    System.Collections.Specialized.StringDictionary templateKeys = new System.Collections.Specialized.StringDictionary();
                    templateKeys.Add("#lapp#", "<a target=\"_blank\" href=\"../ApplianceStore/Browse.aspx?RecordID=#encrypt#" + appstore.ApplianceStoreID + "#endencrypt#\">" + appstore.s_ApplianceName + "</a>");
                    templateKeys.Add("#pronoun#", "#pronoun#" + Web.SessionMembers.s_MemberID + "#endpronoun#");
                    Web.AddActivityLog(Web.SessionMembers.MemberID, 36, templateKeys, appstore.ApplianceStoreID);

                    //  BindMyLAppsWareHouse();
                    string javascript = "javascript: selectTab('tabs-warehouse') ";
                    Page.ClientScript.RegisterStartupScript(GetType(), "Javascript", javascript, true);
                    // Master.ShowMessage("LinkAPP added to your warehouse successfully", "info");
                }


            }
            else if (e.CommandName.Equals("Delete"))
            {
                int ApplianceStoreID = Convert.ToInt32(e.CommandArgument.ToString());
                ApplianceStore appstore = new ApplianceStore();


                ApplianceStoreSubscriptions appsubscription = new ApplianceStoreSubscriptions();
                appsubscription.Where.ApplianceStoreID.Value = ApplianceStoreID;
                appsubscription.Query.Load();
                if (appsubscription.RowCount > 0)
                {
                    do
                    {
                        appsubscription.MarkAsDeleted();
                        appsubscription.Save();
                    } while (appsubscription.MoveNext());
                }
                ApplianceRatings ratings = new ApplianceRatings();
                ratings.Where.ApplianceStoreID.Value = ApplianceStoreID;
                ratings.Query.Load();
                if (ratings.RowCount > 0)
                {
                    do
                    {
                        ratings.MarkAsDeleted();
                        ratings.Save();
                    } while (ratings.MoveNext());
                }
                ApplianceStoreActivityLogs logs = new ApplianceStoreActivityLogs();
                logs.Where.ApplianceStoreID.Value = ApplianceStoreID;
                logs.Query.Load();
                if (logs.RowCount > 0)
                {
                    do
                    {
                        logs.MarkAsDeleted();
                        logs.Save();
                    } while (logs.MoveNext());
                }
                ApplianceStoreCategories categories = new ApplianceStoreCategories();
                categories.Where.ApplianceStoreID.Value = ApplianceStoreID;
                categories.Query.Load();
                if (categories.RowCount > 0)
                {
                    do
                    {
                        categories.MarkAsDeleted();
                        categories.Save();
                    } while (categories.MoveNext());
                }

                appstore.LoadByPrimaryKey(ApplianceStoreID);
                appstore.MarkAsDeleted();
                appstore.Save();
                //Master.ShowMessage("LinkAPP deleted successfully", "info");
            }
            else if (e.CommandName.Equals("Remove"))
            {
                ApplianceStoreSubscriptions subscriptions = new ApplianceStoreSubscriptions();
                subscriptions.Where.ApplianceStoreID.Value = e.CommandArgument;
                subscriptions.Where.MemberID.Value = Web.SessionMembers.MemberID;
                subscriptions.Query.Load();
                if (subscriptions.RowCount > 0)
                {
                    do
                    {
                        subscriptions.MarkAsDeleted();
                        subscriptions.Save();
                    }
                    while (subscriptions.MoveNext());
                }
            }
            LoadData();
        }
        catch (Exception exp)
        {
            throw exp;

            Web.LogError(exp);
        }
    }
    protected void rptJustAdded_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        try
        {
            if (e.CommandName.Equals("Add"))
            {
                int ApplianceStoreID = Convert.ToInt32(e.CommandArgument.ToString());
                ApplianceStore appstore = new ApplianceStore();
                appstore.Query.AddResultColumn(ApplianceStoreSchema.ApplianceName);
                appstore.Query.AddResultColumn(ApplianceStoreSchema.MemberID);
                appstore.Query.AddResultColumn(ApplianceStoreSchema.ApplianceStoreID);
                appstore.Where.ApplianceStoreID.Value = ApplianceStoreID;
                appstore.Query.Load();

                ApplianceStoreSubscriptions appsubscription = new ApplianceStoreSubscriptions();
                appsubscription.Where.MemberID.Value = Web.SessionMembers.MemberID;
                appsubscription.Where.ApplianceStoreID.Value = ApplianceStoreID;
                appsubscription.Query.Load();
                if (appsubscription.RowCount > 0)
                {
                    // Master.ShowMessage("You have already added this LinkAPP", "warning");
                }
                else
                {
                    appsubscription = new ApplianceStoreSubscriptions();
                    appsubscription.AddNew();
                    appsubscription.MemberID = Web.SessionMembers.MemberID;
                    appsubscription.ApplianceStoreID = ApplianceStoreID;
                    appsubscription.Save();
                    System.Collections.Specialized.StringDictionary templateKeys = new System.Collections.Specialized.StringDictionary();
                    templateKeys.Add("#lapp#", "<a target=\"_blank\" href=\"../ApplianceStore/Browse.aspx?RecordID=#encrypt#" + appstore.ApplianceStoreID + "#endencrypt#\">" + appstore.s_ApplianceName + "</a>");
                    templateKeys.Add("#pronoun#", "#pronoun#" + Web.SessionMembers.s_MemberID + "#endpronoun#");
                    Web.AddActivityLog(Web.SessionMembers.MemberID, 36, templateKeys, appstore.ApplianceStoreID);
                    // Master.ShowMessage("LinkAPP added to your warehouse successfully", "info");
                }
            }
            else if (e.CommandName.Equals("Delete"))
            {
                int ApplianceStoreID = Convert.ToInt32(e.CommandArgument.ToString());
                ApplianceStore appstore = new ApplianceStore();


                ApplianceStoreSubscriptions appsubscription = new ApplianceStoreSubscriptions();
                appsubscription.Where.ApplianceStoreID.Value = ApplianceStoreID;
                appsubscription.Query.Load();
                if (appsubscription.RowCount > 0)
                {
                    do
                    {
                        appsubscription.MarkAsDeleted();
                        appsubscription.Save();
                    } while (appsubscription.MoveNext());
                }
                ApplianceRatings ratings = new ApplianceRatings();
                ratings.Where.ApplianceStoreID.Value = ApplianceStoreID;
                ratings.Query.Load();
                if (ratings.RowCount > 0)
                {
                    do
                    {
                        ratings.MarkAsDeleted();
                        ratings.Save();
                    } while (ratings.MoveNext());
                }
                ApplianceStoreActivityLogs logs = new ApplianceStoreActivityLogs();
                logs.Where.ApplianceStoreID.Value = ApplianceStoreID;
                logs.Query.Load();
                if (logs.RowCount > 0)
                {
                    do
                    {
                        logs.MarkAsDeleted();
                        logs.Save();
                    } while (logs.MoveNext());
                }
                ApplianceStoreCategories categories = new ApplianceStoreCategories();
                categories.Where.ApplianceStoreID.Value = ApplianceStoreID;
                categories.Query.Load();
                if (categories.RowCount > 0)
                {
                    do
                    {
                        categories.MarkAsDeleted();
                        categories.Save();
                    } while (categories.MoveNext());
                }

                appstore.LoadByPrimaryKey(ApplianceStoreID);
                appstore.MarkAsDeleted();
                appstore.Save();
                //Master.ShowMessage("LinkAPP deleted successfully", "info");
            }
            LoadData();
        }
        catch (Exception exp)
        {

            Web.LogError(exp);
        }
    }
    protected void rptMyLinkApps_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        try
        {
            if (e.CommandName.Equals("Add"))
            {
                int ApplianceStoreID = Convert.ToInt32(e.CommandArgument.ToString());
                ApplianceStore appstore = new ApplianceStore();
                appstore.Query.AddResultColumn(ApplianceStoreSchema.ApplianceName);
                appstore.Query.AddResultColumn(ApplianceStoreSchema.MemberID);
                appstore.Query.AddResultColumn(ApplianceStoreSchema.ApplianceStoreID);
                appstore.Where.ApplianceStoreID.Value = ApplianceStoreID;
                appstore.Query.Load();

                ApplianceStoreSubscriptions appsubscription = new ApplianceStoreSubscriptions();
                appsubscription.Where.MemberID.Value = Web.SessionMembers.MemberID;
                appsubscription.Where.ApplianceStoreID.Value = ApplianceStoreID;
                appsubscription.Query.Load();
                if (appsubscription.RowCount > 0)
                {
                    //Master.ShowMessage("You have already added this LinkAPP", "warning");
                }
                else
                {
                    appsubscription = new ApplianceStoreSubscriptions();
                    appsubscription.AddNew();
                    appsubscription.MemberID = Web.SessionMembers.MemberID;
                    appsubscription.ApplianceStoreID = ApplianceStoreID;
                    appsubscription.Save();
                    System.Collections.Specialized.StringDictionary templateKeys = new System.Collections.Specialized.StringDictionary();
                    templateKeys.Add("#lapp#", "<a target=\"_blank\" href=\"../ApplianceStore/Browse.aspx?RecordID=#encrypt#" + appstore.ApplianceStoreID + "#endencrypt#\">" + appstore.s_ApplianceName + "</a>");
                    templateKeys.Add("#pronoun#", "#pronoun#" + Web.SessionMembers.s_MemberID + "#endpronoun#");
                    Web.AddActivityLog(Web.SessionMembers.MemberID, 36, templateKeys, appstore.ApplianceStoreID);
                    //Master.ShowMessage("LinkAPP added to your warehouse successfully", "info");
                }
            }
            else if (e.CommandName.Equals("Delete"))
            {
                int ApplianceStoreID = Convert.ToInt32(e.CommandArgument.ToString());
                ApplianceStore appstore = new ApplianceStore();


                ApplianceStoreSubscriptions appsubscription = new ApplianceStoreSubscriptions();
                appsubscription.Where.ApplianceStoreID.Value = ApplianceStoreID;
                appsubscription.Query.Load();
                if (appsubscription.RowCount > 0)
                {
                    do
                    {
                        appsubscription.MarkAsDeleted();
                        appsubscription.Save();
                    } while (appsubscription.MoveNext());
                }
                ApplianceRatings ratings = new ApplianceRatings();
                ratings.Where.ApplianceStoreID.Value = ApplianceStoreID;
                ratings.Query.Load();
                if (ratings.RowCount > 0)
                {
                    do
                    {
                        ratings.MarkAsDeleted();
                        ratings.Save();
                    } while (ratings.MoveNext());
                }
                ApplianceStoreActivityLogs logs = new ApplianceStoreActivityLogs();
                logs.Where.ApplianceStoreID.Value = ApplianceStoreID;
                logs.Query.Load();
                if (logs.RowCount > 0)
                {
                    do
                    {
                        logs.MarkAsDeleted();
                        logs.Save();
                    } while (logs.MoveNext());
                }
                ApplianceStoreCategories categories = new ApplianceStoreCategories();
                categories.Where.ApplianceStoreID.Value = ApplianceStoreID;
                categories.Query.Load();
                if (categories.RowCount > 0)
                {
                    do
                    {
                        categories.MarkAsDeleted();
                        categories.Save();
                    } while (categories.MoveNext());
                }

                appstore.LoadByPrimaryKey(ApplianceStoreID);
                appstore.MarkAsDeleted();
                appstore.Save();
                //Master.ShowMessage("LinkAPP deleted successfully", "info");
            }
            LoadData();
        }
        catch (Exception exp)
        {
            Web.LogError(exp);
        }
    }
    protected void ddlCategories_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            exactAdCounter = 1;
            int CategoryID = Convert.ToInt32(ddlCategories.SelectedValue);

            if (CategoryID > 0)
            {
                //if (Web.RecordID > 0)
                //else
                //{
                //DataTable rptApplianceStoreData = ApplianceStore.SearchApplianceStoreByCategory(CategoryID);
                //DataColumn dc = new DataColumn("AllowRemove");
                //dc.DefaultValue = false;
                //rptApplianceStoreData.Columns.Add(dc);

                //rptApplianceStore.DataSource = rptApplianceStoreData.DefaultView;
                //rptApplianceStore.DataBind();

                //  Session["DataSource"] = rptApplianceStore.DataSource;

                //DataTable rptJustAddedData = ApplianceStore.GetApplianceStoreJustAddedByCategory(CategoryID);
                //DataColumn dc1 = new DataColumn("AllowRemove");
                //dc.DefaultValue = false;
                //rptJustAddedData.Columns.Add(dc1);

                //rptJustAdded.DataSource = rptJustAddedData;
                //rptJustAdded.DataBind();
                //Session["JustAdded"] = rptJustAdded.DataSource;

                //DataTable rptMyLinkAppsData = ApplianceStore.GetApplianceStoreMostVisitedByCategory(CategoryID);
                //DataColumn dc2 = new DataColumn("AllowRemove");
                //dc.DefaultValue = false;
                //rptMyLinkAppsData.Columns.Add(dc2);


                //rptMyLinkApps.DataSource = rptMyLinkAppsData;
                //rptMyLinkApps.DataBind();
                //Session["MostVisited"] = rptMyLinkApps.DataSource;
                ////}
                //string javascript = "javascript: selectTab('tabs-All') ";
                //Page.ClientScript.RegisterStartupScript(GetType(), "Javascript", javascript, true);

            }
            //else
            //    LoadData();
        }
        catch (Exception exp)
        {
            Web.LogError(exp);
        }
    }
    protected void ddlSort_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            exactAdCounter = 1;
            if (ddlSort.SelectedIndex > 0)
            {
                DataView dv = new DataView();
                //if (Session["DataSource"] != null)
                //{
                //    dv.Table = Session["DataSource"] as DataTable;
                //    if (ddlSort.SelectedValue == "Name")
                //        dv.Sort = "ApplianceName ASC";
                //    else if (ddlSort.SelectedValue == "Company")
                //        dv.Sort = "CompanyName ASC";

                //    rptApplianceStore.DataSource = dv.ToTable();
                //    rptApplianceStore.DataBind();
                //    Session["DataSource"] = dv.ToTable();
                //}

                //if (Session["JustAdded"] != null)
                //{
                //    dv = new DataView();
                //    dv.Table = Session["JustAdded"] as DataTable;
                //    if (ddlSort.SelectedValue == "Name")
                //        dv.Sort = "ApplianceName ASC";
                //    else if (ddlSort.SelectedValue == "Company")
                //        dv.Sort = "CompanyName ASC";
                //    rptJustAdded.DataSource = dv.ToTable();
                //    rptJustAdded.DataBind();
                //    Session["JustAdded"] = dv.ToTable();
                //}

                //if (Session["MostVisited"] != null)
                //{
                //    dv = new DataView();
                //    dv.Table = Session["MostVisited"] as DataTable;
                //    if (ddlSort.SelectedValue == "Name")
                //        dv.Sort = "ApplianceName ASC";
                //    else if (ddlSort.SelectedValue == "Company")
                //        dv.Sort = "CompanyName ASC";
                //    rptMyLinkApps.DataSource = dv.ToTable();
                //    rptMyLinkApps.DataBind();
                //    Session["MostVisited"] = dv.ToTable();
                //}
            }
            else
                LoadData();
        }
        catch (Exception exp)
        {
            Web.LogError(exp);
        }
    }

    public static bool AllowRemove(bool? Allow)
    {
        if (Allow == null)
            return false;
        else
            return Convert.ToBoolean(Allow);
    }
    public static bool AllowAdding(int ApplianceStoreID)
    {
        bool result = false;
        try
        {
            if (Web.IsMemberSession)
            {
                var store = new ApplianceStore();
                store.Where.MemberID.Value = Web.SessionMembers.MemberID;
                store.Where.ApplianceStoreID.Value = ApplianceStoreID;
                store.Query.Load();
                if (store.RowCount == 0)
                {
                    var appstoreSubscription = new ApplianceStoreSubscriptions();
                    appstoreSubscription.Where.MemberID.Value = Web.SessionMembers.MemberID;
                    appstoreSubscription.Where.ApplianceStoreID.Value = ApplianceStoreID;
                    appstoreSubscription.Query.Load();
                    if (appstoreSubscription.RowCount == 0)
                        result = true;
                }
            }
        }
        catch (Exception exp)
        {
            Web.LogError(exp);
        }
        return result;
    }

    public static bool AllowEditing(int ApplianceStoreID)
    {
        bool result = false;
        try
        {
            if (Web.IsMemberSession)
            {
                var store = new ApplianceStore();
                store.Where.MemberID.Value = Web.SessionMembers.MemberID;
                store.Where.ApplianceStoreID.Value = ApplianceStoreID;
                store.Query.Load();
                if (store.RowCount > 0)
                    result = true;
            }
        }
        catch (Exception exp)
        {
            Web.LogError(exp);
        }
        return result;
    }
    public static bool AllowDeleting(int ApplianceStoreID)
    {
        bool result = false;
        try
        {
            if (Web.IsMemberSession)
            {
                var store = new ApplianceStore();
                store.Where.MemberID.Value = Web.SessionMembers.MemberID;
                store.Where.ApplianceStoreID.Value = ApplianceStoreID;
                store.Query.Load();
                if (store.RowCount > 0)
                    result = true;
            }
        }
        catch (Exception exp)
        {
            Web.LogError(exp);
        }
        return result;
    }

}