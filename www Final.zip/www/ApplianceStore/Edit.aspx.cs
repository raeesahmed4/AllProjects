﻿using System;
using System.Collections;
using System.Data;
using System.Web.UI.WebControls;
using CodenameRabbitFoot.BusinessLogic;
using System.Net;
using VisualSoft.VSharp.Utils;
using System.IO;
using System.Drawing;

public partial class ApplianceStore_Edit : System.Web.UI.Page
{

    protected static string FileURL = string.Empty;
    protected string website = string.Empty;
    protected string File = string.Empty;
    protected string message = "";
    protected byte[] applog = null;
    protected void Page_Load(object sender, EventArgs e)
    {
        Web.CheckSession();
        
        this.Master.HideLinkApps();

        if (!IsPostBack)
        {
            if (Web.RecordID > 0)
            {
               // treeviewCategories.Attributes.Add("onclick", "OnTreeClick(event)");
                BindCategories();
                LoadData();
                Web.LogUserActivity(Radium.Platform.Core.UserActivity.View);
            }
        }
    }

    private void LoadData()
    {
        try
        {
            ApplianceStore store = new ApplianceStore();
            store.LoadByPrimaryKey(Web.RecordID);
            if (store.RowCount > 0)
            {
                txtApplianceName.Text = store.ApplianceName;
                txtDescription.Text = store.Description;
                txtURL.Text = store.URL;

                ApplianceStoreCategories categories = new ApplianceStoreCategories();
                categories.Where.ApplianceStoreID.Value = store.ApplianceStoreID;
                categories.Query.Load();
                if (categories.RowCount > 0)
                {
                    do
                    {
                        if (ChckkCategories.Items.Count > 0)
                        {
                            foreach (ListItem n in ChckkCategories.Items)
                            {
                                if (n.Value == categories.s_CategoryID)
                                    n.Selected = true;
                            }
                        }

                        //foreach (TreeNode n in treeviewCategories.Nodes)
                        //{
                        //    if (n.Value == categories.s_CategoryID)
                        //        n.Checked = true;

                        //    foreach (TreeNode cn in n.ChildNodes)
                        //    {
                        //        if (cn.Value == categories.s_CategoryID)
                        //        {
                        //            cn.Checked = true;
                        //            cn.Parent.Expand();
                        //        }
                        //        foreach (TreeNode cnn in cn.ChildNodes)
                        //        {
                        //            if (cnn.Value == categories.s_CategoryID)
                        //            {
                        //                cnn.Checked = true;
                        //                cnn.Parent.Expand();
                        //            }
                        //        }
                        //    }
                        //}
                    } while (categories.MoveNext());
                }
            }
        }
        catch (Exception ex)
        {
            Web.LogError(ex);
        }
    }

    private void BindCategories()
    {
        try
        {
            buildTree(null, 0);
        }
        catch (Exception exp)
        {

            Web.LogError(exp);
        }
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        //Web.Redirect("/index.aspx");
        try
        {
            bool IsValid = true;
            if (ApplianceLogo.UploadedFiles.Count > 0)
            {
                applog = new byte[ApplianceLogo.UploadedFiles[0].ContentLength];
                applog = Web.UploadImage(ApplianceLogo);

                //make it 72x72 thumbnail
                Stream imgstream = ApplianceLogo.UploadedFiles[0].InputStream;
                Bitmap imgbitmap = new Bitmap(imgstream);
                if (imgbitmap.Width > 72 && imgbitmap.Height > 72)
                {
                    //IsValid = false;
                    applog = Web.CreateThumbnail(imgstream, 72, 72);
                }

                Session["appliancelogo"] = applog;              
            }
            else
            {
                IsValid = true;
            }
            if (IsValid)
            {
                checkedCategories();
                SaveAppLinksOfActiveMembers(Web.SessionMembers.MemberID);
            }
            else
            {
                //Master.ShowMessage("Logo Must be a square image, and not bigger than 300x300 pixels", "warning");
            }
        }
        catch (Exception exp)
        {

            Web.LogError(exp);
        }
        this.Master.ShowMessage("Your LinkApp has been updated successfully", "Edit Link App");
        Web.Redirect("/ApplianceStore/Default.aspx");
    }
    private void SaveAppLinksOfActiveMembers(int MemberID)
    {
        try
        {

            Members member = new Members();
            member.Where.MemberID.Value = MemberID;
            member.Query.Load();
            ShippingAddresses address = new ShippingAddresses();
            if (member.RowCount > 0)
            {
                address.Query.AddResultColumn(ShippingAddressesSchema.Phone);
                address.Where.MemberID.Value = member.MemberID;
                address.Query.Load();
            }

            Random rand = new Random();
            ApplianceStore appliancestore = new ApplianceStore();
            appliancestore.LoadByPrimaryKey(Web.RecordID);
            appliancestore.ApplianceName = txtApplianceName.Text;
            applog = (byte[])Session["appliancelogo"];
            if (applog != null)
            {
                //appliancestore.Logo = applog;
                string fileName = Web.SystemConfigs.GetKey("ATTACHMENTS_PHYSICAL_PATH") + @"\ApplianceStore\" + Secure.Decrypt(Web.RecordID.ToString()) + ".jpg";
                Web.byteArrayToImage(applog).Save(fileName, System.Drawing.Imaging.ImageFormat.Jpeg);
            }

            appliancestore.URL = txtURL.Text;
            appliancestore.Description = txtDescription.Text;
            appliancestore.VerificationCode = rand.Next(1000).ToString() + ".txt";
            appliancestore.Save();
            if (appliancestore.RowCount > 0)
            {
                SaveApplianceStoreCategories(appliancestore.ApplianceStoreID);
                website = appliancestore.URL;
                File = appliancestore.VerificationCode;
                FileURL = website + "/" + File;
                mviewApplienceStore.ActiveViewIndex = 1;
            }
        }
        catch (Exception exp)
        {
            Web.LogError(exp);
        }
    }
    protected void btnverifyTextFile_Click(object sender, EventArgs e)
    {
        bool result;

        string url = "http://www.eOpen.com:8081/mushtaq.txt";
        try
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
            {
                if (response.StatusCode == HttpStatusCode.OK)
                {
                    result = true;
                    mviewApplienceStore.ActiveViewIndex = 1;
                }
                else
                {
                    result = false;
                }
            }
        }
        catch (Exception exp)
        {
            Web.LogError(exp);
        }
    }


    public void buildTree(TreeNode n, int categoryID)
    {
        try
        {
            DataTable resultData = CodenameRabbitFoot.BusinessLogic.Categories.GetSubCategories(categoryID, 1);

            ChckkCategories.DataSource = resultData.DefaultView;
            ChckkCategories.DataTextField = "CategoryName";
            ChckkCategories.DataValueField = "CategoryID";
            ChckkCategories.DataBind();

            //Bind First tree
            //foreach (DataRow row in resultData.Rows)
            //{
            //    TreeNode node = new TreeNode(row["CategoryName"].ToString(), row["CategoryID"].ToString());
            //    node.SelectAction = TreeNodeSelectAction.Expand;
            //    buildTree(node, int.Parse(row["CategoryID"].ToString()));

            //    if (n == null)
            //    {

            //        treeviewCategories.Nodes.Add(node);
            //    }
            //    else
            //        n.ChildNodes.Add(node);
            //}
        }
        catch (VException vx)
        {

            Web.LogError(vx);
        }
        catch (Exception ex)
        {

            Web.LogError(ex);
        }
    }


    protected void SaveApplianceStoreCategories(int ApplianceStoreID)
    {
        try
        {
            ArrayList arr = (ArrayList)Session["checkednodes"];
            if (arr.Count > 0)
            {
                ApplianceStoreCategories apstorecategory = new ApplianceStoreCategories();
                apstorecategory.Where.ApplianceStoreID.Value = Web.RecordID;
                apstorecategory.Query.Load();
                if (apstorecategory.RowCount > 0)
                {
                    do
                    {
                        apstorecategory.MarkAsDeleted();
                        apstorecategory.Save();
                    } while (apstorecategory.MoveNext());
                }

                foreach (int categoryid in arr)
                {
                    apstorecategory = new ApplianceStoreCategories();
                    apstorecategory.AddNew();
                    apstorecategory.ApplianceStoreID = ApplianceStoreID;
                    apstorecategory.CategoryID = categoryid;
                    apstorecategory.Save();
                }
            }
        }
        catch (Exception exp)
        {
            Web.LogError(exp);
        }
    }
    public void checkedCategories()
    {
        try
        {
            ArrayList arr = new ArrayList();
            //if (treeviewCategories.Nodes.Count > 0)
            //{
            //    if (treeviewCategories.CheckedNodes.Count > 0)
            //    {
            //        foreach (TreeNode n in treeviewCategories.CheckedNodes)
            //        {
            //            arr.Add(Convert.ToInt32(n.Value.ToString()));

            //        }
            //    }
            //}

            if (ChckkCategories.Items.Count > 0)
            {
                foreach (ListItem n in ChckkCategories.Items)
                {
                    if (n.Selected)
                        arr.Add(Convert.ToInt32(n.Value));
                }
            }

            Session["checkednodes"] = arr;
        }
        catch (Exception exp)
        {
            Web.LogError(exp);
        }
    }

    //public void bindappliancecategory()
    //{

    //    try
    //    {
    //        ArrayList arrWTS = (ArrayList)Session["checkednodes"];
    //        foreach (TreeNode n in treeviewCategories.Nodes)
    //        {
    //            foreach (string str in arrWTS)
    //            {
    //                if (n.Value == str)
    //                    n.Checked = true;
    //            }

    //            foreach (TreeNode cn in n.ChildNodes)
    //            {
    //                foreach (string str in arrWTS)
    //                {
    //                    if (cn.Value == str)
    //                    {
    //                        cn.Checked = true;
    //                        cn.Parent.Expand();
    //                    }
    //                }
    //                foreach (TreeNode cnn in cn.ChildNodes)
    //                {
    //                    foreach (string str in arrWTS)
    //                    {
    //                        if (cnn.Value == str)
    //                        {
    //                            cnn.Checked = true;
    //                            cnn.Parent.Expand();
    //                        }
    //                    }
    //                }
    //            }
    //        }
    //    }
    //    catch (Exception exp)
    //    {

    //        Web.LogError(exp);
    //    }
    //}
}