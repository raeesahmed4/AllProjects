﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Amazon;
using Amazon.SimpleEmail.Model;
using System.Collections.Specialized;
using CodenameRabbitFoot.BusinessLogic;
using VisualSoft.SystemManagement;
using System.IO;
using System.Text;

public partial class TestEmail : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        //SendEmailUsigAmazonService();
    }

    private static void SendEmailUsigAmazonService()
    {
        try
        {
            //Amazon.SimpleEmail.AmazonSimpleEmailServiceConfig config = new Amazon.SimpleEmail.AmazonSimpleEmailServiceConfig();
            string accessKeyID = "AKIAJDCL7GBAUCPQPZVA";
            string secretKey = "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";

            Amazon.SimpleEmail.AmazonSimpleEmailServiceClient client = new Amazon.SimpleEmail.AmazonSimpleEmailServiceClient(accessKeyID, secretKey);

            SendEmailRequest emailRequest = new SendEmailRequest().WithSource("members@eopen.com");
            List<string> toAddresses = new List<string>();
            toAddresses.Add("fawad@ensx.com");
            List<string> ccAddresses = new List<string>();
            ccAddresses.Add("shafqat@ensx.com");

            Destination destination = new Destination().WithToAddresses(toAddresses).WithCcAddresses(ccAddresses);
            emailRequest.WithDestination(destination);
            Message message = new Message();
            message.Subject = new Amazon.SimpleEmail.Model.Content("Test Email");
            message.Body = new Body(new Amazon.SimpleEmail.Model.Content(" This is test email froom Amazon SES service from shafqat :)"));
            emailRequest.Message = message;

            client.SendEmail(emailRequest);
        }
        catch (Exception exp)
        {
            Web.LogError(exp);
        }
    }

    /// <summary>
    /// Send Email with Amazon Simple Email Service.
    /// </summary>
    /// <param name="toAddresses">List of address to whome email will be sent.</param>
    /// <param name="From">From email address.</param>
    /// <param name="TemplateID">Email template ID.</param>
    /// <param name="templateKeys">Template keys.</param>
    public static void SendEmailWithAmazonSES(List<string> toAddresses, string From, int TemplateID, StringDictionary templateKeys)
    {
        string accessKeyID, secretKey, body, subject;

        TemplateManager templateManager = new TemplateManager();
        EmailTemplates template = new EmailTemplates();

        accessKeyID = Web.SystemConfigs.GetKey("AmazonAccessKeyID");
        secretKey = Web.SystemConfigs.GetKey("AmazonSecretKey");

        template.LoadByPrimaryKey(TemplateID);
        body = templateManager.ParseTemplate(template.HTMLTemplateBody, templateKeys);
        subject = templateManager.ParseTemplate(template.TemplateSubject, templateKeys);

        Amazon.SimpleEmail.AmazonSimpleEmailServiceClient client = new Amazon.SimpleEmail.AmazonSimpleEmailServiceClient(accessKeyID, secretKey);
        SendEmailRequest emailRequest = new SendEmailRequest().WithSource(From);
        Destination destination = new Destination().WithToAddresses(toAddresses);
        emailRequest.WithDestination(destination);
        Message message = new Message();
        message.Subject = new Amazon.SimpleEmail.Model.Content(subject);
        message.Body = new Body(new Amazon.SimpleEmail.Model.Content(body));
        emailRequest.Message = message;

        client.SendEmail(emailRequest);

        StringBuilder strToAddresses = new StringBuilder();
        foreach (string address in toAddresses)
            strToAddresses.Append(address + " ; ");

        // Log Email in file
        try
        {
            string outputFile = string.Format(@"C:\eOffer_Email_Debug\{0}.htm", TemplateID);
            TextWriter output;
             
            if (!File.Exists(outputFile))
                output = File.CreateText(outputFile);
            else
                output = File.AppendText(outputFile);
             
            output.Write(String.Format("TemplateID: {0} {1} To: {2} {3} From: {4} {5} Subject: {6} {7} Message: {8}",
                                TemplateID, "<br>", strToAddresses.ToString(), "<br>",
                                From, "<br>", subject, "<br>", body));

            // add email to Email log in DB
            var email = new Emails();
            email.AddNew();
            email.FromEmail = From;
            email.ToEmail = strToAddresses.ToString();
            email.Subject = subject;
            email.Body = body;
            email.Save();
        }
        catch {}         
       
    }

    /// <summary>
    /// Send Email with Amazon Simple Email Service.
    /// </summary>
    /// <param name="toAddress">To email address.</param>
    /// <param name="From">From email address.</param>
    /// <param name="TemplateID">Email template ID.</param>
    /// <param name="templateKeys">Template keys.</param>
    public static void SendEmailWithAmazonSES( string toAddress, string From, int TemplateID, StringDictionary templateKeys)
    {
        List<string> toAddresses = new List<string>();
        string[] strToAddresses = toAddress.Split(';');
        foreach (string address in strToAddresses)
            toAddresses.Add(address);

        SendEmailWithAmazonSES(toAddresses, From, TemplateID, templateKeys);
    }

}