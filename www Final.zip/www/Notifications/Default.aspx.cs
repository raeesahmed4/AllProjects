﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Quartz;
using Quartz.Impl;

public partial class Notifications_Default : System.Web.UI.Page
{
    private static IScheduler sched;
    private static IScheduler schedweekly;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            int count = 0;
            foreach (DayOfWeek r in Enum.GetValues(typeof(DayOfWeek)))
            {
                ListItem item = new ListItem(Enum.GetName(typeof(DayOfWeek), r), count++.ToString());
                ddldays.Items.Add(item);
            }
        }
        if (sched != null)
        {            
            lblStatus.Text = sched.IsStarted ? "Started" : "Stopped";
        }
        else
            lblStatus.Text = "Stopped";
    }
    protected void btnStart_Click(object sender, EventArgs e)
    {

        //if (sched.IsStarted)
        //    return;

        // construct a scheduler factory
        ISchedulerFactory schedFact = new StdSchedulerFactory();

        // get a scheduler
        sched = schedFact.GetScheduler();
        sched.Start();

        schedweekly = schedFact.GetScheduler();
        schedweekly.Start();

        // construct job info
        JobDetail jobDetail = new JobDetail("myJob", null, typeof(Notifications));

        Trigger trigger = TriggerUtils.MakeHourlyTrigger(1);
        // start on the next even hour
        //trigger.StartTimeUtc = TriggerUtils.GetEvenHourDate(DateTime.UtcNow);
        trigger.StartTimeUtc = TriggerUtils.GetNextGivenSecondDate(null, 1);
        trigger.Name = "myTrigger";

        JobDetail jobDetailWeekly = new JobDetail("myJobWeekly", null, typeof(Notifications));

        Trigger triggerweekly = TriggerUtils.MakeWeeklyTrigger((DayOfWeek)Convert.ToInt32(ddldays.SelectedValue), Convert.ToInt32(txtHours.Text), Convert.ToInt32(txtMinutes.Text)); //TriggerUtils.MakeWeeklyTrigger(DayOfWeek.Saturday, 9, 0); //TriggerUtils.MakeHourlyTrigger(1); 
        // start on the next even hour
        //trigger.StartTimeUtc = TriggerUtils.GetEvenHourDate(DateTime.UtcNow);
        //     triggerweekly.StartTimeUtc = TriggerUtils.GetNextGivenMinuteDate(null,1);
        triggerweekly.Name = "myTriggerWeekly";

        sched.ScheduleJob(jobDetail, trigger);
        schedweekly.ScheduleJob(jobDetailWeekly, triggerweekly);
    }
    protected void btnstop_Click(object sender, EventArgs e)
    {

        // if (sched.IsShutdown)
        sched.Shutdown(true);
        schedweekly.Shutdown(true);
    }
}