using System;
using System.Drawing.Imaging;
using StringGenerator; // class for random string 

public partial class CaptchaFiles_Captcha : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            this.Session["CaptchaImageText"] = RandomPassword.Generate().Substring(0, 4);
            var ci = new CaptchaImage(this.Session["CaptchaImageText"].ToString(), 200, 40, "Century Schoolbook");
            this.Response.Clear();
            this.Response.ContentType = "image/jpeg";
            // Write the image to the response stream in JPEG format.
            ci.Image.Save(this.Response.OutputStream, ImageFormat.Jpeg);
            // Dispose of the CAPTCHA image object.
            ci.Dispose();
        }
        catch
        {
        }
    }
}
