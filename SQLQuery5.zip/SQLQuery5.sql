use WareHouse
select *From employees
create procedure SpInserEmployees 'MARKI','MALE',2000
@Name varchar(50),
@Gender varchar(50),
@Salary varchar(50)
as
begin
		insert into Employees  values(@Name,@Gender,@Salary)
end

create procedure SpUpdateEmployee
@ID int ,
@Name varchar(50),
@Gender varchar(50),
@Salary varchar(50)
as
begin
		update Employees set Name=@Name, Gender=@Gender, Salary=@Salary 
		where ID=@ID
end

create procedure SpDeleteEmployees 
@ID int
as
begin
		delete from Employees where ID=@ID
end


select *from Employees